import { NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, afterRenderEffect, computed, contentChildren, effect, input, linkedSignal, model, untracked, viewChild } from "@angular/core";
import { NeatBreadcrumbs, NeatIcon } from "@sima/neat-ui";
import { NeatInput } from "@sima/neat-ui/input";
import { NeatColumn, NeatSelectList } from "@sima/neat-ui/select-list";
import { NeatStatusChip } from "@sima/neat-ui/status-chip";
const collator = new Intl.Collator("en", { sensitivity: "base" });
const byName = (a, b) => collator.compare(a.name, b.name);
function childrenAt(tree, folderPath) {
	let nodes = tree ?? [];
	if (!folderPath) return nodes;
	let path = "";
	for (const segment of folderPath.split("/")) {
		path = path ? `${path}/${segment}` : segment;
		const next = nodes.find((node) => node.type === "folder" && node.path === path);
		if (!next) return null;
		nodes = next.children ?? [];
	}
	return nodes;
}
function folderExists(tree, folderPath) {
	return childrenAt(tree, folderPath) !== null;
}
function listFolder(tree, folderPath) {
	const nodes = childrenAt(tree, folderPath) ?? [];
	return {
		folders: nodes.filter((node) => node.type === "folder").sort(byName).map((node) => ({
			node,
			name: node.name,
			path: node.path,
			count: availableFilePaths(node.children).length
		})),
		files: nodes.filter((node) => node.type === "file").sort(byName)
	};
}
function playableCount(tree, folderPath) {
	return availableFilePaths(childrenAt(tree, folderPath) ?? []).length;
}
function parentPath(folderPath) {
	if (!folderPath) return "";
	const index = folderPath.lastIndexOf("/");
	return index === -1 ? "" : folderPath.slice(0, index);
}
function breadcrumbs(folderPath, rootLabel) {
	const crumbs = [{
		name: rootLabel,
		path: ""
	}];
	if (!folderPath) return crumbs;
	let path = "";
	for (const segment of folderPath.split("/")) {
		path = path ? `${path}/${segment}` : segment;
		crumbs.push({
			name: segment,
			path
		});
	}
	return crumbs;
}
function searchFolder(tree, folderPath, query) {
	const needle = query.trim().toLowerCase();
	const nodes = childrenAt(tree, folderPath);
	if (!needle || nodes === null) return [];
	const prefix = folderPath ? `${folderPath}/` : "";
	const matches = [];
	const walk = (list) => {
		for (const node of list) if (node.type === "folder") walk(node.children ?? []);
		else {
			const relative = node.path.startsWith(prefix) ? node.path.slice(prefix.length) : node.path;
			if (relative.toLowerCase().includes(needle)) matches.push({
				node,
				relative
			});
		}
	};
	walk(nodes);
	return matches.sort((a, b) => collator.compare(a.relative, b.relative));
}
function nearestExistingFolder(tree, folderPath) {
	let candidate = folderPath || "";
	while (candidate && !folderExists(tree, candidate)) candidate = parentPath(candidate);
	return candidate;
}
function childTowards(descendant, ancestor) {
	if (descendant === ancestor) return null;
	const prefix = ancestor ? `${ancestor}/` : "";
	if (!descendant.startsWith(prefix)) return null;
	return `${prefix}${descendant.slice(prefix.length).split("/")[0]}`;
}
function availableFilePaths(tree, acc = []) {
	for (const node of tree ?? []) {
		if (node.type === "file" && !node.unavailable) acc.push(node.path);
		if (node.type === "folder") availableFilePaths(node.children, acc);
	}
	return acc;
}
function allFilePaths(tree, acc = []) {
	for (const node of tree ?? []) {
		if (node.type === "file") acc.push(node.path);
		if (node.type === "folder") allFilePaths(node.children, acc);
	}
	return acc;
}
const plural = (count, one, many) => `${count} ${count === 1 ? one : many}`;
const DEFAULT_LABELS = {
	breadcrumb: "Current folder",
	files: "Files",
	name: "Name",
	filter: "Filter files in the current folder and its subfolders",
	empty: "This folder is empty.",
	noMatches: "No files match the filter.",
	folder: "Folder",
	folderCount: (folder, count) => `${plural(count, "file", "files")} in ${folder} and its subfolders`,
	matches: (folder, count) => `${plural(count, "match", "matches")} in ${folder}`
};
const defaultCountLabel = (_folder, count) => plural(count, "file", "files");
var FileRowContext = class FileRowContext {
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FileRowContext,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FileRowContext,
		isStandalone: true,
		selector: "ng-template[neatFileRow]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FileRowContext,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatFileRow]" }]
	}]
});
const rowPath = (row) => row.node.path;
const isFile = (row) => row.node.type === "file";
var NeatFileBrowser = class NeatFileBrowser {
	root = input.required(...ngDevMode ? [{ debugName: "root" }] : /* istanbul ignore next */ []);
	rootLabel = input.required(...ngDevMode ? [{ debugName: "rootLabel" }] : /* istanbul ignore next */ []);
	folder = model("", ...ngDevMode ? [{ debugName: "folder" }] : /* istanbul ignore next */ []);
	selected = model(null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	mode = input("pick", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	checked = model([], ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	filterPlaceholder = input("", ...ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []);
	countLabel = input(defaultCountLabel, ...ngDevMode ? [{ debugName: "countLabel" }] : /* istanbul ignore next */ []);
	labels = input({}, ...ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []);
	filter = model("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	rowPath = rowPath;
	isFile = isFile;
	text = computed(() => ({
		...DEFAULT_LABELS,
		...this.labels()
	}), ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	current = computed(() => nearestExistingFolder(this.root(), this.folder()), ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	crumbs = computed(() => breadcrumbs(this.current(), this.rootLabel()), ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	crumbItems = computed(() => this.crumbs().map(({ name }) => ({ label: name })), ...ngDevMode ? [{ debugName: "crumbItems" }] : /* istanbul ignore next */ []);
	folderName = computed(() => this.crumbs().at(-1)?.name ?? this.rootLabel(), ...ngDevMode ? [{ debugName: "folderName" }] : /* istanbul ignore next */ []);
	query = computed(() => this.filter().trim(), ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	columns = contentChildren(NeatColumn, ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	list = viewChild.required(NeatSelectList, ...ngDevMode ? [{ debugName: "list" }] : /* istanbul ignore next */ []);
	matches = computed(() => this.query() ? searchFolder(this.root(), this.current(), this.query()) : [], ...ngDevMode ? [{ debugName: "matches" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const text = this.text();
		const fileRow = (node, label) => ({
			node,
			label,
			count: null,
			countLabel: "",
			context: { $implicit: node }
		});
		if (this.query()) return this.matches().map(({ node, relative }) => fileRow(node, relative));
		const { folders, files } = listFolder(this.root(), this.current());
		return [...folders.map(({ node, name, count }) => ({
			node,
			label: name,
			count,
			countLabel: text.folderCount(name, count),
			context: { $implicit: node }
		})), ...files.map((node) => fileRow(node, node.name))];
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	countText = computed(() => this.query() ? this.text().matches(this.folderName(), this.matches().length) : this.countLabel()(this.folderName(), playableCount(this.root(), this.current())), ...ngDevMode ? [{ debugName: "countText" }] : /* istanbul ignore next */ []);
	cursorFolder = linkedSignal({
		...ngDevMode ? { debugName: "cursorFolder" } : /* istanbul ignore next */ {},
		source: () => ({
			folder: this.current(),
			query: this.query(),
			selected: this.selected()
		}),
		computation: () => null
	});
	highlighted = computed(() => {
		const path = this.cursorFolder() ?? this.selected();
		return this.rows().find((row) => row.node.path === path) ?? null;
	}, ...ngDevMode ? [{ debugName: "highlighted" }] : /* istanbul ignore next */ []);
	constructor() {
		let shown;
		effect(() => {
			const current = this.current();
			if (shown !== void 0 && current !== shown) this.filter.set("");
			shown = current;
		});
		afterRenderEffect(() => {
			this.current();
			this.query();
			untracked(() => this.list().resetScroll());
		});
		effect(() => {
			const current = this.current();
			if (untracked(this.folder) !== current) this.folder.set(current);
		});
		effect(() => {
			const present = new Set(allFilePaths(this.root()));
			const checked = untracked(this.checked);
			const kept = checked.filter((path) => present.has(path));
			if (kept.length !== checked.length) this.checked.set(kept);
		});
	}
	onFilter(event) {
		this.filter.set(event.target.value);
	}
	navigate(path) {
		const from = this.current();
		this.folder.set(path);
		this.cursorFolder.set(childTowards(from, path));
		this.list().focus();
	}
	moveCursor(row) {
		if (row === null) return;
		if (row.node.type === "folder") this.cursorFolder.set(row.node.path);
		else {
			this.cursorFolder.set(null);
			this.selected.set(row.node.path);
		}
	}
	open(row) {
		if (row.node.type === "folder") this.navigate(row.node.path);
	}
	onKeydown(event) {
		if (event.target.getAttribute("role") !== "listbox") return;
		if (event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
		if (event.key === "Backspace") {
			event.preventDefault();
			if (this.current() !== "") this.navigate(parentPath(this.current()));
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatFileBrowser,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatFileBrowser,
		isStandalone: true,
		selector: "neat-file-browser",
		inputs: {
			root: {
				classPropertyName: "root",
				publicName: "root",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			rootLabel: {
				classPropertyName: "rootLabel",
				publicName: "rootLabel",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			folder: {
				classPropertyName: "folder",
				publicName: "folder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checked: {
				classPropertyName: "checked",
				publicName: "checked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterPlaceholder: {
				classPropertyName: "filterPlaceholder",
				publicName: "filterPlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			countLabel: {
				classPropertyName: "countLabel",
				publicName: "countLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			folder: "folderChange",
			selected: "selectedChange",
			checked: "checkedChange",
			filter: "filterChange"
		},
		host: { classAttribute: "flex h-full min-h-0 flex-col gap-(--neat-space-2)" },
		queries: [{
			propertyName: "columns",
			predicate: NeatColumn,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "list",
			first: true,
			predicate: NeatSelectList,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <neat-breadcrumbs
      [label]="text().breadcrumb"
      [crumbs]="crumbItems()"
      (go)="navigate(crumbs()[$event].path)"
    />
    <p data-slot="file-browser-count" aria-live="polite" class="m-0 text-sm text-muted-foreground">
      {{ countText() }}
    </p>
    <input
      neatInput
      size="small"
      type="text"
      autocomplete="off"
      spellcheck="false"
      [attr.aria-label]="text().filter"
      [placeholder]="filterPlaceholder()"
      [value]="filter()"
      (input)="onFilter($event)"
    />
    <neat-select-list
      class="min-h-0 flex-1"
      [label]="text().files"
      [items]="rows()"
      [trackBy]="rowPath"
      [selected]="highlighted()"
      [emptyLabel]="query() ? text().noMatches : text().empty"
      [checkable]="mode() === 'manage'"
      [canCheck]="isFile"
      [(checked)]="checked"
      (selectedChange)="moveCursor($event)"
      (activated)="open($event)"
      (keydown)="onKeydown($event)"
    >
      <ng-template
        neatColumn="name"
        neatFileRow
        [header]="columns().length ? text().name : ''"
        let-row
      >
        <span
          data-slot="file-name"
          class="flex min-w-0 items-center gap-(--neat-space-2)"
          [class.text-muted-foreground]="row.node.unavailable"
        >
          @if (row.node.type === 'folder') {
            <neat-icon name="folder" [size]="16" class="shrink-0" />
            <span class="sr-only">{{ text().folder }}</span>
          } @else {
            <neat-icon name="file" [size]="16" class="shrink-0" />
          }
          <span class="truncate">{{ row.label }}</span>
          @if (row.node.tag) {
            <neat-status-chip class="shrink-0">{{ row.node.tag }}</neat-status-chip>
          }
          @if (row.count !== null) {
            <span
              aria-hidden="true"
              class="shrink-0 text-muted-foreground tabular-nums"
              [class.ms-auto]="!columns().length"
              [attr.title]="row.countLabel"
              >{{ row.count }}</span
            >
            <span class="sr-only">{{ row.countLabel }}</span>
          }
        </span>
      </ng-template>
      @for (column of columns(); track column) {
        <ng-template
          [neatColumn]="column.key()"
          [header]="column.header()"
          [width]="column.width()"
          [align]="column.align()"
          [hideBelow]="column.hideBelow()"
          neatFileRow
          let-row
        >
          @if (row.node.type === 'file') {
            <ng-container
              [ngTemplateOutlet]="column.template"
              [ngTemplateOutletContext]="row.context"
            />
          }
        </ng-template>
      }
    </neat-select-list>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: FileRowContext,
				selector: "ng-template[neatFileRow]"
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatBreadcrumbs,
				selector: "neat-breadcrumbs",
				inputs: ["label", "crumbs"],
				outputs: ["go"]
			},
			{
				kind: "directive",
				type: NeatInput,
				selector: "input[neatInput]",
				inputs: ["size"]
			},
			{
				kind: "component",
				type: NeatSelectList,
				selector: "neat-select-list",
				inputs: [
					"label",
					"items",
					"trackBy",
					"selected",
					"checkable",
					"checked",
					"canCheck",
					"checkBlocked",
					"rowTone",
					"groups",
					"groupOf",
					"emptyLabel",
					"hint"
				],
				outputs: [
					"selectedChange",
					"checkedChange",
					"activated"
				]
			},
			{
				kind: "directive",
				type: NeatColumn,
				selector: "ng-template[neatColumn]",
				inputs: [
					"neatColumn",
					"header",
					"width",
					"align",
					"hideBelow"
				]
			},
			{
				kind: "component",
				type: NeatStatusChip,
				selector: "neat-status-chip",
				inputs: ["tone"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatFileBrowser,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-file-browser",
			imports: [
				FileRowContext,
				NeatIcon,
				NeatBreadcrumbs,
				NeatInput,
				NeatSelectList,
				NeatColumn,
				NeatStatusChip,
				NgTemplateOutlet
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "flex h-full min-h-0 flex-col gap-(--neat-space-2)" },
			template: `
    <neat-breadcrumbs
      [label]="text().breadcrumb"
      [crumbs]="crumbItems()"
      (go)="navigate(crumbs()[$event].path)"
    />
    <p data-slot="file-browser-count" aria-live="polite" class="m-0 text-sm text-muted-foreground">
      {{ countText() }}
    </p>
    <input
      neatInput
      size="small"
      type="text"
      autocomplete="off"
      spellcheck="false"
      [attr.aria-label]="text().filter"
      [placeholder]="filterPlaceholder()"
      [value]="filter()"
      (input)="onFilter($event)"
    />
    <neat-select-list
      class="min-h-0 flex-1"
      [label]="text().files"
      [items]="rows()"
      [trackBy]="rowPath"
      [selected]="highlighted()"
      [emptyLabel]="query() ? text().noMatches : text().empty"
      [checkable]="mode() === 'manage'"
      [canCheck]="isFile"
      [(checked)]="checked"
      (selectedChange)="moveCursor($event)"
      (activated)="open($event)"
      (keydown)="onKeydown($event)"
    >
      <ng-template
        neatColumn="name"
        neatFileRow
        [header]="columns().length ? text().name : ''"
        let-row
      >
        <span
          data-slot="file-name"
          class="flex min-w-0 items-center gap-(--neat-space-2)"
          [class.text-muted-foreground]="row.node.unavailable"
        >
          @if (row.node.type === 'folder') {
            <neat-icon name="folder" [size]="16" class="shrink-0" />
            <span class="sr-only">{{ text().folder }}</span>
          } @else {
            <neat-icon name="file" [size]="16" class="shrink-0" />
          }
          <span class="truncate">{{ row.label }}</span>
          @if (row.node.tag) {
            <neat-status-chip class="shrink-0">{{ row.node.tag }}</neat-status-chip>
          }
          @if (row.count !== null) {
            <span
              aria-hidden="true"
              class="shrink-0 text-muted-foreground tabular-nums"
              [class.ms-auto]="!columns().length"
              [attr.title]="row.countLabel"
              >{{ row.count }}</span
            >
            <span class="sr-only">{{ row.countLabel }}</span>
          }
        </span>
      </ng-template>
      @for (column of columns(); track column) {
        <ng-template
          [neatColumn]="column.key()"
          [header]="column.header()"
          [width]="column.width()"
          [align]="column.align()"
          [hideBelow]="column.hideBelow()"
          neatFileRow
          let-row
        >
          @if (row.node.type === 'file') {
            <ng-container
              [ngTemplateOutlet]="column.template"
              [ngTemplateOutletContext]="row.context"
            />
          }
        </ng-template>
      }
    </neat-select-list>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		root: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "root",
				required: true
			}]
		}],
		rootLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rootLabel",
				required: true
			}]
		}],
		folder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "folder",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["folderChange"]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		checked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checked",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedChange"]
		}],
		filterPlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterPlaceholder",
				required: false
			}]
		}],
		countLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "countLabel",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["filterChange"]
		}],
		columns: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => NeatColumn), { isSignal: true }]
		}],
		list: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatSelectList), { isSignal: true }]
		}]
	}
});
export { NeatFileBrowser };

//# sourceMappingURL=sima-neat-ui-file-browser.mjs.map