import * as i1 from "@sima/neat-ui";
import { NEAT_DANGER_BASE, NeatButton, NeatExpand, NeatIcon, NeatTooltip, SIMA_PALETTE, ɵNeatOverlayColors as NeatOverlayColors, ɵclassStyles, ɵclassStyles as classStyles, ɵcreateColorAllocator as createColorAllocator, ɵheldColor as heldColor, ɵresolveColor as resolveColor, ɵstyleFor as styleFor } from "@sima/neat-ui";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, ElementRef, Injector, NgZone, Renderer2, afterNextRender, afterRenderEffect, booleanAttribute, computed, effect, inject, input, isDevMode, linkedSignal, model, output, signal, untracked, viewChild } from "@angular/core";
import { NeatStatusChip } from "@sima/neat-ui/status-chip";
const LATE_SHARE_ON = .5;
const LATE_SHARE_OFF = .1;
const BUFFER_MARGIN_MS = 50;
const BUFFER_STEP_MS = 50;
const BUFFER_MAX_MS = 4e3;
const SETTLE_MS_PER_RAISED_MS = 10;
const SETTLE_BASE_MS = 1e3;
function nextWarningActive(active, recentLateShare) {
	if (recentLateShare == null) return active;
	if (recentLateShare >= LATE_SHARE_ON) return true;
	if (recentLateShare < LATE_SHARE_OFF) return false;
	return active;
}
function suggestedBufferMs(currentBufferMs, p90LatenessMs) {
	if (p90LatenessMs === null) return null;
	if (!Number.isFinite(currentBufferMs) || !Number.isFinite(p90LatenessMs)) return null;
	const needed = currentBufferMs + p90LatenessMs + BUFFER_MARGIN_MS;
	const suggested = Math.ceil(needed / BUFFER_STEP_MS) * BUFFER_STEP_MS;
	return suggested > BUFFER_MAX_MS ? null : suggested;
}
function bufferSettleMs(previousBufferMs, nextBufferMs) {
	const raisedBy = Math.max(0, nextBufferMs - previousBufferMs);
	if (!Number.isFinite(raisedBy)) return SETTLE_BASE_MS;
	return raisedBy * SETTLE_MS_PER_RAISED_MS + SETTLE_BASE_MS;
}
function globalActionFor(suggested, followedBufferMs) {
	if (suggested === null) return null;
	if (typeof followedBufferMs === "number" && Number.isFinite(followedBufferMs) && followedBufferMs >= suggested) return {
		kind: "follow",
		valueMs: followedBufferMs
	};
	return {
		kind: "raise",
		valueMs: suggested
	};
}
function lateNoticeDetails(snapshot, currentBufferMs, bufferSupported, followedBufferMs) {
	const suggested = bufferSupported ? suggestedBufferMs(currentBufferMs, snapshot.recentLatenessP90Ms) : null;
	let blockedBy = null;
	if (!bufferSupported) blockedBy = "unsupported";
	else if (!Number.isFinite(snapshot.recentLatenessP90Ms)) blockedBy = "unmeasured";
	else if (suggested === null) blockedBy = "maximum";
	return {
		latenessMs: snapshot.recentLatenessMedianMs == null ? null : Math.round(snapshot.recentLatenessMedianMs),
		latePercent: snapshot.recentLateShare == null ? null : Math.round(snapshot.recentLateShare * 100),
		bufferMs: currentBufferMs,
		suggestedBufferMs: suggested,
		blockedBy,
		globalAction: globalActionFor(suggested, followedBufferMs)
	};
}
const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
function withAlphaHex(hex, alpha) {
	return `${hex}${Math.round(alpha * 255).toString(16).padStart(2, "0")}`;
}
const OVERLAY_ROI_COLORS = {
	inclusion: {
		fill: withAlphaHex(SIMA_PALETTE.green, .1),
		fillActive: withAlphaHex(SIMA_PALETTE.green, .3),
		stroke: SIMA_PALETTE.green
	},
	exclusion: {
		fill: withAlphaHex(NEAT_DANGER_BASE, .1),
		fillActive: withAlphaHex(NEAT_DANGER_BASE, .3),
		stroke: NEAT_DANGER_BASE
	}
};
const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
const NEAT_OVERLAY_DEFAULTS = {
	general: {
		lineWidth: 3,
		showRoi: true,
		applyRoiFiltering: true
	},
	types: {
		"object-detection": {
			visible: true,
			confidenceThreshold: 0,
			objects: []
		},
		segmentation: {
			visible: true,
			confidenceThreshold: 0,
			maskOpacity: .4,
			objects: []
		},
		tracking: {
			visible: true,
			confidenceThreshold: 0,
			history: {
				enabled: true,
				trailLength: 10,
				lostTrackTtlMs: 2e3
			}
		},
		"pose-estimation": {
			visible: true,
			showKeypoints: true,
			showKeypointLabels: false,
			showBoxes: true,
			objects: []
		},
		classification: { visible: true }
	},
	roi: []
};
const NEAT_MIN_TILE_WIDTH = 64;
const HEIGHT_PER_WIDTH = 9 / 16;
function sanitizeArea(area) {
	const dimension = (value) => Number.isFinite(value) && value > 0 ? value : 0;
	return {
		width: dimension(area.width),
		height: dimension(area.height)
	};
}
function sanitizeGap(gap) {
	return Number.isFinite(gap) && gap > 0 ? gap : 0;
}
function packTiles(area, tileWidth, gap) {
	const { width: areaWidth, height: areaHeight } = sanitizeArea(area);
	const spacing = sanitizeGap(gap);
	const requested = Number.isNaN(tileWidth) ? 64 : Math.max(64, tileWidth);
	const fitting = Math.min(requested, areaWidth, areaHeight / HEIGHT_PER_WIDTH);
	const width = Math.max(1, fitting < requested ? Math.floor(fitting) : requested);
	const height = width * HEIGHT_PER_WIDTH;
	const columns = Math.max(1, Math.floor((areaWidth + spacing) / (width + spacing)));
	const rows = Math.max(1, Math.floor((areaHeight + spacing) / (height + spacing)));
	return {
		columns,
		rows,
		perPage: columns * rows,
		tileWidth: width,
		tileHeight: height
	};
}
function fitAllTileWidth(area, count, gap) {
	const { width: areaWidth, height: areaHeight } = sanitizeArea(area);
	const spacing = sanitizeGap(gap);
	const tiles = Number.isFinite(count) ? Math.max(1, Math.floor(count)) : 1;
	const widestRow = Math.floor((areaWidth + spacing) / (64 + spacing));
	const maxColumns = Math.min(tiles, Math.max(1, widestRow));
	let widest = 64;
	for (let columns = 1; columns <= maxColumns; columns++) {
		const rows = Math.ceil(tiles / columns);
		const byWidth = (areaWidth - (columns - 1) * spacing) / columns;
		const byHeight = (areaHeight - (rows - 1) * spacing) / rows / HEIGHT_PER_WIDTH;
		widest = Math.max(widest, Math.floor(Math.min(byWidth, byHeight)));
	}
	return widest;
}
const FALLBACK_GAP = 8;
function sameArea(a, b) {
	return a.width === b.width && a.height === b.height;
}
function sameLayout(a, b) {
	if (a === null || b === null) return a === b;
	return Object.keys(a).every((field) => a[field] === b[field]);
}
var NeatTileGrid = class NeatTileGrid {
	tileWidth = input.required(...ngDevMode ? [{ debugName: "tileWidth" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	count = input.required(...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	layout = output();
	gridElement = viewChild.required("grid", ...ngDevMode ? [{ debugName: "gridElement" }] : /* istanbul ignore next */ []);
	area = signal(null, {
		...ngDevMode ? { debugName: "area" } : /* istanbul ignore next */ {},
		equal: (a, b) => a === null || b === null ? a === b : sameArea(a, b)
	});
	tokenGap = signal(null, ...ngDevMode ? [{ debugName: "tokenGap" }] : /* istanbul ignore next */ []);
	gapPx = computed(() => {
		const token = this.tokenGap();
		return token === null ? null : this.gap() ?? token;
	}, ...ngDevMode ? [{ debugName: "gapPx" }] : /* istanbul ignore next */ []);
	packed = computed(() => {
		const area = this.area();
		const gap = this.gapPx();
		if (area === null || !(area.width > 0 && area.height > 0) || gap === null) return null;
		return {
			...packTiles(area, this.tileWidth(), gap),
			gap,
			areaWidth: area.width,
			areaHeight: area.height
		};
	}, {
		...ngDevMode ? { debugName: "packed" } : /* istanbul ignore next */ {},
		equal: sameLayout
	});
	view = computed(() => {
		const packed = this.packed();
		if (packed === null) return null;
		return {
			...packed,
			columns: Math.min(packed.columns, Math.max(1, this.count()))
		};
	}, ...ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []);
	constructor() {
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		effect(() => {
			const layout = this.packed();
			if (layout !== null) untracked(() => this.layout.emit(layout));
		});
		afterNextRender(() => {
			const resolved = parseFloat(getComputedStyle(this.gridElement().nativeElement).columnGap);
			this.tokenGap.set(Number.isFinite(resolved) ? resolved : FALLBACK_GAP);
			const observer = new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.area.set({
					width,
					height
				});
			});
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTileGrid,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatTileGrid,
		isStandalone: true,
		selector: "neat-tile-grid",
		inputs: {
			tileWidth: {
				classPropertyName: "tileWidth",
				publicName: "tileWidth",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { layout: "layout" },
		viewQueries: [{
			propertyName: "gridElement",
			first: true,
			predicate: ["grid"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      #grid
      class="grid"
      [attr.data-ready]="view() !== null"
      [style.--grid-columns]="view()?.columns"
      [style.--grid-tile-width.px]="view()?.tileWidth"
      [style.--grid-tile-height.px]="view()?.tileHeight"
      [style.--grid-gap.px]="gapPx()"
    >
      <ng-content />
    </div>
  `,
		isInline: true,
		styles: [":host{display:block;width:100%;height:100%;min-height:0;overflow:hidden}.grid{display:grid;box-sizing:border-box;width:100%;height:100%;justify-content:center;align-content:center;grid-template-columns:repeat(var(--grid-columns, 1),var(--grid-tile-width, auto));grid-auto-rows:var(--grid-tile-height, auto);gap:var(--grid-gap, var(--neat-space-2))}.grid[data-ready=false]{visibility:hidden}.grid[data-ready=true]{visibility:visible}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTileGrid,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tile-grid",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <div
      #grid
      class="grid"
      [attr.data-ready]="view() !== null"
      [style.--grid-columns]="view()?.columns"
      [style.--grid-tile-width.px]="view()?.tileWidth"
      [style.--grid-tile-height.px]="view()?.tileHeight"
      [style.--grid-gap.px]="gapPx()"
    >
      <ng-content />
    </div>
  `,
			styles: [":host{display:block;width:100%;height:100%;min-height:0;overflow:hidden}.grid{display:grid;box-sizing:border-box;width:100%;height:100%;justify-content:center;align-content:center;grid-template-columns:repeat(var(--grid-columns, 1),var(--grid-tile-width, auto));grid-auto-rows:var(--grid-tile-height, auto);gap:var(--grid-gap, var(--neat-space-2))}.grid[data-ready=false]{visibility:hidden}.grid[data-ready=true]{visibility:visible}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		tileWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tileWidth",
				required: true
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: true
			}]
		}],
		layout: [{
			type: i0.Output,
			args: ["layout"]
		}],
		gridElement: [{
			type: i0.ViewChild,
			args: ["grid", { isSignal: true }]
		}]
	}
});
const TYPE_NAMES = {
	inclusion: "Inclusion",
	exclusion: "Exclusion"
};
function neatRoiNames(regions) {
	const counts = {
		inclusion: 0,
		exclusion: 0
	};
	return regions.map((region) => `${TYPE_NAMES[region.type]} ${++counts[region.type]}`);
}
const RULES = {
	"object-detection": {
		namespace: "class",
		by: "label",
		rows: (settings) => settings.types["object-detection"].objects
	},
	segmentation: {
		namespace: "class",
		by: "label",
		rows: (settings) => settings.types.segmentation.objects
	},
	classification: {
		namespace: "class",
		by: "label"
	},
	tracking: {
		namespace: "track",
		by: "id"
	},
	"pose-estimation": {
		namespace: "pose",
		by: "id",
		rows: (settings) => settings.types["pose-estimation"].objects
	}
};
function queryOf(allocator, channel, type, item, overrides) {
	const { namespace, by } = RULES[type];
	return {
		allocator,
		channelIndex: channel,
		namespace,
		identity: item[by],
		label: item.label,
		overrides
	};
}
function resolveItemColor(allocator, channel, type, item, overrides, now) {
	return resolveColor({
		...queryOf(allocator, channel, type, item, overrides),
		now
	});
}
function heldItemColor(allocator, channel, settings, type, item) {
	const { overrides } = ɵclassStyles(RULES[type].rows?.(settings) ?? []);
	return heldColor(queryOf(allocator, channel, type, item, overrides));
}
function letterbox(videoWidth, videoHeight, boxWidth, boxHeight) {
	if (!videoWidth || !videoHeight) return {
		scaleX: 1,
		scaleY: 1,
		offsetX: 0,
		offsetY: 0
	};
	const videoAspect = videoWidth / videoHeight;
	let drawWidth;
	let drawHeight;
	let offsetX = 0;
	let offsetY = 0;
	if (boxWidth / boxHeight > videoAspect) {
		drawHeight = boxHeight;
		drawWidth = videoAspect * drawHeight;
		offsetX = (boxWidth - drawWidth) / 2;
	} else {
		drawWidth = boxWidth;
		drawHeight = drawWidth / videoAspect;
		offsetY = (boxHeight - drawHeight) / 2;
	}
	return {
		scaleX: drawWidth / videoWidth,
		scaleY: drawHeight / videoHeight,
		offsetX,
		offsetY
	};
}
function orientLetterbox(box, boxWidth, boxHeight, mirror, flipVertical) {
	return {
		scaleX: mirror ? -box.scaleX : box.scaleX,
		scaleY: flipVertical ? -box.scaleY : box.scaleY,
		offsetX: mirror ? boxWidth - box.offsetX : box.offsetX,
		offsetY: flipVertical ? boxHeight - box.offsetY : box.offsetY
	};
}
const MAX_RLE_MASK_PIXELS = 4194304;
const offscreenMaskSurface = {
	createContext() {
		const context = new OffscreenCanvas(1, 1).getContext("2d");
		if (!context) throw new Error("OffscreenCanvas has no 2d context");
		return context;
	},
	wrapPixels: (pixels, width, height) => new ImageData(pixels, width, height)
};
function decodeRleMaskAlpha(pixels, counts, maskWidth, maskHeight) {
	const total = maskWidth * maskHeight;
	let pos = 0;
	let foreground = false;
	for (let i = 0; i < counts.length && pos < total; i += 1) {
		const run = Number(counts[i]);
		const end = run > 0 ? Math.min(pos + run, total) : pos;
		if (foreground) for (; pos < end; pos += 1) pixels[(pos % maskHeight * maskWidth + Math.floor(pos / maskHeight)) * 4 + 3] = 255;
		else pos = end;
		foreground = !foreground;
	}
	return pixels;
}
var RleMaskCanvas = class {
	surface;
	context = null;
	pixels = /* @__PURE__ */ new Uint8ClampedArray(0);
	constructor(surface) {
		this.surface = surface;
	}
	paint(counts, width, height, color) {
		this.context ??= this.surface.createContext();
		const context = this.context;
		if (context.canvas.width !== width) context.canvas.width = width;
		if (context.canvas.height !== height) context.canvas.height = height;
		const length = width * height * 4;
		if (this.pixels.length < length) this.pixels = new Uint8ClampedArray(length);
		else this.pixels.fill(0, 0, length);
		const pixels = this.pixels.subarray(0, length);
		decodeRleMaskAlpha(pixels, counts, width, height);
		context.putImageData(this.surface.wrapPixels(pixels, width, height), 0, 0);
		context.save();
		context.globalCompositeOperation = "source-in";
		context.fillStyle = color;
		context.fillRect(0, 0, width, height);
		context.restore();
		return context.canvas;
	}
};
let pageMaskCanvas = null;
function sharedMaskCanvas() {
	pageMaskCanvas ??= new RleMaskCanvas(offscreenMaskSurface);
	return pageMaskCanvas;
}
function mapRoi(polygons, videoWidth, videoHeight, box) {
	return {
		polygons: polygons.map(({ type, points }) => ({
			type,
			points: points.map((p) => [p.x * videoWidth * box.scaleX + box.offsetX, p.y * videoHeight * box.scaleY + box.offsetY])
		})),
		drawn: false
	};
}
function drawRoiOnce(ctx, roi) {
	if (roi.drawn) return;
	roi.drawn = true;
	for (const { type, points } of roi.polygons) {
		if (points.length < 3) continue;
		ctx.beginPath();
		ctx.moveTo(points[0][0], points[0][1]);
		for (let i = 1; i < points.length; i += 1) ctx.lineTo(points[i][0], points[i][1]);
		ctx.closePath();
		const colors = type === "inclusion" ? OVERLAY_ROI_COLORS.inclusion : OVERLAY_ROI_COLORS.exclusion;
		ctx.fillStyle = colors.fill;
		ctx.strokeStyle = colors.stroke;
		ctx.lineWidth = 2;
		ctx.fill();
		ctx.stroke();
	}
}
function contains(polygon, x, y) {
	const pts = polygon.points;
	if (pts.length < 3) return false;
	let inside = false;
	for (let i = 0, j = pts.length - 1; i < pts.length; j = i, i += 1) {
		const [xi, yi] = pts[i];
		const [xj, yj] = pts[j];
		if (yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi || 1e-6) + xi) inside = !inside;
	}
	return inside;
}
function passesRoiFilter(roi, bbox, box, applyRoiFiltering) {
	if (!applyRoiFiltering) return true;
	const [x, y, w, h] = bbox;
	const cx = (x + w / 2) * box.scaleX + box.offsetX;
	const cy = (y + h / 2) * box.scaleY + box.offsetY;
	const inclusion = roi.polygons.filter((polygon) => polygon.type === "inclusion");
	const exclusion = roi.polygons.filter((polygon) => polygon.type === "exclusion");
	return (inclusion.length === 0 || inclusion.some((polygon) => contains(polygon, cx, cy))) && !exclusion.some((polygon) => contains(polygon, cx, cy));
}
function itemColor(dc, type, item, overrides) {
	return resolveItemColor(dc.colors, dc.channel, type, item, overrides, dc.now);
}
function applyLineStyle(ctx, style, lineWidth) {
	ctx.lineWidth = style?.width ?? lineWidth;
	ctx.setLineDash(style?.style === "dashed" ? [6, 4] : style?.style === "dotted" ? [2, 2] : []);
}
const LABEL_PLATES = {
	label: {
		height: 18,
		baseline: 3
	},
	large: {
		height: 21,
		baseline: 5
	}
};
function labelPlateHeight(font) {
	return LABEL_PLATES[font].height;
}
const PLATE_EDGE = 2;
function drawLabelPlate(dc, text, x, y, color, font = "label") {
	const { ctx } = dc;
	const paddingX = 4;
	const { height, baseline } = LABEL_PLATES[font];
	ctx.font = dc.fonts[font];
	const width = ctx.measureText(text).width + 8;
	const plateX = Math.max(PLATE_EDGE, Math.min(dc.mirrored ? x - width : x, dc.width - PLATE_EDGE - width));
	const plateY = Math.max(PLATE_EDGE, y - height);
	ctx.fillStyle = OVERLAY_LABEL_PLATE_COLOR;
	ctx.fillRect(plateX, plateY, width, height);
	ctx.fillStyle = color;
	ctx.fillText(text, dc.mirrored ? plateX + width - paddingX : plateX + paddingX, plateY + height - baseline);
}
const BOX_LABEL_GAP = 6;
function boxLabelAnchor(box, x, y, width, height) {
	const top = y * box.scaleY + box.offsetY;
	return {
		left: x * box.scaleX + box.offsetX,
		top: Math.min(top, top + height * box.scaleY)
	};
}
function drawBoxLabels(dc, labels) {
	for (const { text, left, top, color } of labels) drawLabelPlate(dc, text, left, top - BOX_LABEL_GAP, color);
}
function withConfidence(text, confidence) {
	if (typeof confidence !== "number" || !Number.isFinite(confidence)) return text;
	return `${text} (${Math.round(confidence * 100)}%)`;
}
const INSET = 8;
const GAP = 2;
const drawClassification = (dc, data) => {
	const classes = data?.top_classes;
	if (!classes || !dc.settings.types.classification.visible) return;
	const { box } = dc;
	const height = labelPlateHeight("large");
	const x = box.offsetX + (dc.mirrored ? -8 : INSET);
	const pictureTop = dc.flipped ? dc.height - box.offsetY : box.offsetY;
	classes.slice(0, 3).forEach((entry, i) => {
		const color = itemColor(dc, "classification", entry);
		const bottom = pictureTop + INSET + height + i * (height + GAP);
		drawLabelPlate(dc, withConfidence(String(entry.label), entry.confidence), x, bottom, color, "large");
	});
};
const SAME_HEIGHT = 1e-6;
function orientedCorners(value) {
	if (!Array.isArray(value) || value.length !== 5) return null;
	if (!value.every((entry) => typeof entry === "number" && Number.isFinite(entry))) return null;
	const [cx, cy, w, h, angle] = value;
	const cos = Math.cos(angle);
	const sin = Math.sin(angle);
	return [
		[-w / 2, -h / 2],
		[w / 2, -h / 2],
		[w / 2, h / 2],
		[-w / 2, h / 2]
	].map(([dx, dy]) => [cx + dx * cos - dy * sin, cy + dx * sin + dy * cos]);
}
function labelCorner(corners, flipped) {
	const height = (corner) => flipped ? -corner[1] : corner[1];
	return corners.reduce((best, corner) => {
		if (height(corner) < height(best) - SAME_HEIGHT) return corner;
		if (Math.abs(corner[1] - best[1]) <= SAME_HEIGHT && corner[0] < best[0]) return corner;
		return best;
	});
}
const drawObjectDetection = (dc, data) => {
	const objects = data?.objects;
	if (!objects) return;
	const { ctx, box, settings } = dc;
	const type = settings.types["object-detection"];
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) return;
	const { styles, overrides } = classStyles(type.objects);
	const labels = [];
	for (const object of objects) {
		if (Number(object.confidence) < type.confidenceThreshold) continue;
		const [x, y, w, h] = object.bbox;
		if (!passesRoiFilter(dc.roi, object.bbox, box, settings.general.applyRoiFiltering)) continue;
		const color = itemColor(dc, "object-detection", object, overrides);
		ctx.strokeStyle = color;
		applyLineStyle(ctx, styleFor(styles, object.label), settings.general.lineWidth);
		const corners = orientedCorners(object.oriented_bbox);
		let anchor;
		if (corners) {
			ctx.beginPath();
			corners.forEach(([cx, cy], i) => {
				const px = cx * box.scaleX + box.offsetX;
				const py = cy * box.scaleY + box.offsetY;
				if (i === 0) ctx.moveTo(px, py);
				else ctx.lineTo(px, py);
			});
			ctx.closePath();
			ctx.stroke();
			const [ax, ay] = labelCorner(corners, dc.flipped);
			anchor = boxLabelAnchor(box, ax, ay, 0, 0);
		} else {
			ctx.strokeRect(x * box.scaleX + box.offsetX, y * box.scaleY + box.offsetY, w * box.scaleX, h * box.scaleY);
			anchor = boxLabelAnchor(box, x, y, w, h);
		}
		labels.push({
			text: withConfidence(String(object.label), object.confidence),
			...anchor,
			color
		});
	}
	drawBoxLabels(dc, labels);
};
const COCO_SKELETON = [
	["nose", "left_eye"],
	["nose", "right_eye"],
	["left_eye", "left_ear"],
	["right_eye", "right_ear"],
	["nose", "left_shoulder"],
	["nose", "right_shoulder"],
	["left_shoulder", "left_elbow"],
	["left_elbow", "left_wrist"],
	["right_shoulder", "right_elbow"],
	["right_elbow", "right_wrist"],
	["left_shoulder", "left_hip"],
	["right_shoulder", "right_hip"],
	["left_hip", "right_hip"],
	["left_hip", "left_knee"],
	["left_knee", "left_ankle"],
	["right_hip", "right_knee"],
	["right_knee", "right_ankle"]
];
const HAND_SKELETON = [
	["wrist", "thumb_cmc"],
	["thumb_cmc", "thumb_mcp"],
	["thumb_mcp", "thumb_ip"],
	["thumb_ip", "thumb_tip"],
	["wrist", "index_finger_mcp"],
	["index_finger_mcp", "index_finger_pip"],
	["index_finger_pip", "index_finger_dip"],
	["index_finger_dip", "index_finger_tip"],
	["index_finger_mcp", "middle_finger_mcp"],
	["middle_finger_mcp", "middle_finger_pip"],
	["middle_finger_pip", "middle_finger_dip"],
	["middle_finger_dip", "middle_finger_tip"],
	["middle_finger_mcp", "ring_finger_mcp"],
	["ring_finger_mcp", "ring_finger_pip"],
	["ring_finger_pip", "ring_finger_dip"],
	["ring_finger_dip", "ring_finger_tip"],
	["ring_finger_mcp", "pinky_mcp"],
	["wrist", "pinky_mcp"],
	["pinky_mcp", "pinky_pip"],
	["pinky_pip", "pinky_dip"],
	["pinky_dip", "pinky_tip"]
];
const SKELETON = [...COCO_SKELETON, ...HAND_SKELETON];
const KEYPOINT_MIN_CONFIDENCE = .3;
const BOX_PADDING = 8;
function confidenceAlpha(confidence) {
	const value = Number.isFinite(Number(confidence)) ? Number(confidence) : 1;
	return .18 + .82 * Math.min(1, Math.max(0, value));
}
function hasId$1(id) {
	return id !== null && id !== void 0 && id !== "";
}
const drawPoseEstimation = (dc, data) => {
	const poses = data?.poses;
	const type = dc.settings.types["pose-estimation"];
	if (!poses || !type.visible) return;
	const { ctx, box } = dc;
	const at = (kp) => [kp.x * box.scaleX + box.offsetX, kp.y * box.scaleY + box.offsetY];
	const { styles, overrides } = classStyles(type.objects);
	ctx.font = dc.fonts.label;
	const labels = [];
	for (const pose of poses) {
		if (!Array.isArray(pose?.keypoints)) continue;
		const row = styleFor(styles, pose.label);
		const color = itemColor(dc, "pose-estimation", pose, overrides);
		applyLineStyle(ctx, row, dc.settings.general.lineWidth);
		const keypoints = pose.keypoints.filter((kp) => Boolean(kp));
		const byName = new Map(keypoints.map((kp) => [kp.name, kp]));
		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		for (const [a, b] of SKELETON) {
			const from = byName.get(a);
			const to = byName.get(b);
			if (!from || !to) continue;
			ctx.beginPath();
			ctx.moveTo(...at(from));
			ctx.lineTo(...at(to));
			ctx.globalAlpha = confidenceAlpha(Math.min(Number(from.confidence ?? 1), Number(to.confidence ?? 1)));
			ctx.stroke();
		}
		for (const kp of keypoints) {
			ctx.globalAlpha = confidenceAlpha(kp.confidence);
			if (type.showKeypoints) {
				ctx.beginPath();
				ctx.arc(...at(kp), 3, 0, 2 * Math.PI);
				ctx.fill();
			}
			if (type.showKeypointLabels) ctx.fillText(String(kp.name), (kp.x + 4) * box.scaleX + box.offsetX, kp.y * box.scaleY + box.offsetY - 4 * Math.abs(box.scaleY));
		}
		ctx.globalAlpha = 1;
		if (!type.showBoxes) continue;
		const confident = keypoints.filter((kp) => Number(kp.confidence) > KEYPOINT_MIN_CONFIDENCE);
		if (confident.length < 2) continue;
		const xs = confident.map((kp) => kp.x);
		const ys = confident.map((kp) => kp.y);
		const left = Math.min(...xs) - BOX_PADDING;
		const top = Math.min(...ys) - BOX_PADDING;
		const width = Math.max(...xs) - Math.min(...xs) + 16;
		const height = Math.max(...ys) - Math.min(...ys) + 16;
		ctx.strokeRect(left * box.scaleX + box.offsetX, top * box.scaleY + box.offsetY, width * box.scaleX, height * box.scaleY);
		const label = `${pose.label || "pose"}${hasId$1(pose.id) ? ` #${pose.id}` : ""}`;
		labels.push({
			text: label,
			...boxLabelAnchor(box, left, top, width, height),
			color
		});
	}
	drawBoxLabels(dc, labels);
};
function polygonBounds(points) {
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const [px, py] of points) {
		if (px < minX) minX = px;
		if (py < minY) minY = py;
		if (px > maxX) maxX = px;
		if (py > maxY) maxY = py;
	}
	return [
		minX,
		minY,
		maxX - minX,
		maxY - minY
	];
}
function warnDropped(dc, id, reason) {
	const name = String(id ?? "<no id>");
	dc.warnOnce(`segment:${name}`, `segmentation: channel ${dc.channel} dropped RLE segment "${name}": ${reason}`);
}
function drawRleMask(dc, segment, bbox, color, opacity) {
	const mask = segment.mask;
	if (!mask || !Array.isArray(mask.size)) {
		warnDropped(dc, segment.id, "mask.size must be an array [mask_h, mask_w]");
		return false;
	}
	if (!Array.isArray(mask.counts)) {
		warnDropped(dc, segment.id, "mask.counts must be an array of run lengths, not a compressed byte string");
		return false;
	}
	const maskHeight = Math.floor(mask.size[0]);
	const maskWidth = Math.floor(mask.size[1]);
	if (!(maskWidth > 0) || !(maskHeight > 0)) {
		warnDropped(dc, segment.id, `mask.size must be positive, got ${maskHeight}x${maskWidth}`);
		return false;
	}
	if (maskWidth * maskHeight > 4194304) {
		warnDropped(dc, segment.id, `mask is ${maskHeight}x${maskWidth}, over the ${MAX_RLE_MASK_PIXELS} pixel decode buffer limit`);
		return false;
	}
	const image = dc.masks.paint(mask.counts, maskWidth, maskHeight, color);
	const { ctx, box } = dc;
	ctx.save();
	ctx.globalAlpha = opacity;
	ctx.imageSmoothingEnabled = true;
	ctx.translate(bbox[0] * box.scaleX + box.offsetX, bbox[1] * box.scaleY + box.offsetY);
	ctx.scale(Math.sign(box.scaleX), Math.sign(box.scaleY));
	ctx.drawImage(image, 0, 0, bbox[2] * Math.abs(box.scaleX), bbox[3] * Math.abs(box.scaleY));
	ctx.restore();
	return true;
}
const drawSegmentation = (dc, data) => {
	const segments = data?.segments;
	if (!Array.isArray(segments)) return;
	const { ctx, box, settings } = dc;
	const type = settings.types.segmentation;
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) return;
	const { styles, overrides } = classStyles(type.objects);
	const labels = [];
	for (const segment of segments) {
		if (Number(segment.confidence ?? 1) < type.confidenceThreshold) continue;
		if (segment.mask_format !== "polygon" && segment.mask_format !== "rle") continue;
		let bbox = Array.isArray(segment.bbox) && segment.bbox.length === 4 ? segment.bbox : null;
		let polygon = null;
		if (segment.mask_format === "polygon") {
			if (!Array.isArray(segment.mask) || segment.mask.length < 3) continue;
			polygon = segment.mask;
			bbox ??= polygonBounds(polygon);
		}
		if (!bbox) {
			warnDropped(dc, segment.id, "an RLE mask needs a bbox as its destination rectangle");
			continue;
		}
		if (!passesRoiFilter(dc.roi, bbox, box, settings.general.applyRoiFiltering)) continue;
		const color = itemColor(dc, "segmentation", segment, overrides);
		ctx.strokeStyle = color;
		applyLineStyle(ctx, styleFor(styles, segment.label), settings.general.lineWidth);
		ctx.fillStyle = color;
		if (polygon) {
			ctx.beginPath();
			ctx.moveTo(polygon[0][0] * box.scaleX + box.offsetX, polygon[0][1] * box.scaleY + box.offsetY);
			for (let i = 1; i < polygon.length; i += 1) ctx.lineTo(polygon[i][0] * box.scaleX + box.offsetX, polygon[i][1] * box.scaleY + box.offsetY);
			ctx.closePath();
			ctx.save();
			ctx.globalAlpha = type.maskOpacity;
			ctx.fill();
			ctx.restore();
			ctx.stroke();
		} else if (!drawRleMask(dc, segment, bbox, color, type.maskOpacity)) continue;
		const [x, y, w, h] = bbox;
		if (segment.show_rectangle === true) ctx.strokeRect(x * box.scaleX + box.offsetX, y * box.scaleY + box.offsetY, w * box.scaleX, h * box.scaleY);
		labels.push({
			text: withConfidence(String(segment.label), segment.confidence),
			...boxLabelAnchor(box, x, y, w, h),
			color
		});
	}
	drawBoxLabels(dc, labels);
};
function hasId(id) {
	return id !== null && id !== void 0 && id !== "";
}
function isIdentified(track) {
	return track.id !== null && track.id !== void 0;
}
function isDrawable(track) {
	const bbox = track?.bbox;
	return Array.isArray(bbox) && bbox.length >= 4 && bbox.slice(0, 4).every(Number.isFinite);
}
function updateTrackHistory(history, tracks, now, settings) {
	if (!settings.enabled) {
		history.clear();
		return;
	}
	const trailLength = Math.max(1, settings.trailLength);
	const current = /* @__PURE__ */ new Set();
	for (const track of tracks) {
		if (!isIdentified(track)) continue;
		const key = String(track.id);
		const [x, y, width, height] = track.bbox;
		current.add(key);
		const trail = history.get(key) ?? {
			points: [],
			lastSeen: now
		};
		trail.points = [...trail.points, {
			x: x + width / 2,
			y: y + height / 2
		}].slice(-trailLength);
		trail.lastSeen = now;
		history.set(key, trail);
	}
	for (const [key, trail] of history) if (!current.has(key) && now - trail.lastSeen > settings.lostTrackTtlMs) history.delete(key);
}
function drawTrail(dc, points, color, alpha) {
	if (points.length < 2) return;
	const { ctx, box } = dc;
	ctx.save();
	ctx.strokeStyle = color;
	ctx.lineWidth = dc.settings.general.lineWidth;
	ctx.globalAlpha = alpha;
	ctx.setLineDash([]);
	ctx.beginPath();
	points.forEach((point, i) => {
		const x = point.x * box.scaleX + box.offsetX;
		const y = point.y * box.scaleY + box.offsetY;
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	});
	ctx.stroke();
	ctx.restore();
}
const drawTracking = (dc, data) => {
	const tracks = data?.tracks;
	if (!Array.isArray(tracks)) return;
	const { ctx, box, settings } = dc;
	const type = settings.types.tracking;
	const visible = tracks.filter((track) => isDrawable(track) && !(Number(track.confidence ?? 1) < type.confidenceThreshold) && passesRoiFilter(dc.roi, track.bbox, box, settings.general.applyRoiFiltering));
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) {
		dc.trackHistory.clear();
		return;
	}
	if (!dc.held) updateTrackHistory(dc.trackHistory, visible, dc.now, type.history);
	const frameColors = /* @__PURE__ */ new Map();
	const trackColor = (id) => {
		if (id === null || id === void 0) return itemColor(dc, "tracking", { id });
		const key = String(id);
		let color = frameColors.get(key);
		if (color === void 0) {
			color = itemColor(dc, "tracking", { id });
			frameColors.set(key, color);
		}
		return color;
	};
	if (type.history.enabled) {
		const active = new Set(visible.filter(isIdentified).map((track) => String(track.id)));
		for (const [key, trail] of dc.trackHistory) drawTrail(dc, trail.points, trackColor(key), active.has(key) ? .72 : .35);
	}
	const labels = [];
	for (const track of visible) {
		const [x, y, w, h] = track.bbox;
		const color = trackColor(track.id);
		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		ctx.lineWidth = settings.general.lineWidth;
		ctx.setLineDash([]);
		ctx.strokeRect(x * box.scaleX + box.offsetX, y * box.scaleY + box.offsetY, w * box.scaleX, h * box.scaleY);
		const idText = hasId(track.id) ? ` #${track.id}` : "";
		const text = withConfidence(`${track.label || "track"}${idText}`, track.confidence);
		labels.push({
			text,
			...boxLabelAnchor(box, x, y, w, h),
			color
		});
	}
	drawBoxLabels(dc, labels);
};
function stateOf$1(state) {
	return state;
}
const STRATEGIES = /* @__PURE__ */ new Map([
	["object-detection", drawObjectDetection],
	["segmentation", drawSegmentation],
	["tracking", drawTracking],
	["pose-estimation", drawPoseEstimation],
	["classification", drawClassification]
]);
const AUXILIARY_METADATA_TYPE$1 = "auxiliary-visualization";
const WARNING_MEMORY_LIMIT = 64;
const FALLBACK_FONTS = fontsOf("sans-serif");
function fontsOf(family) {
	return {
		label: `14px ${family}`,
		large: `16px ${family}`
	};
}
function createOverlayState(channel, colors) {
	return newOverlayState(channel, colors, sharedMaskCanvas());
}
function newOverlayState(channel, colors, masks) {
	return {
		channel,
		colors: createColorAllocator(colors),
		trackHistory: /* @__PURE__ */ new Map(),
		masks,
		warned: {
			unknown: /* @__PURE__ */ new Set(),
			failed: /* @__PURE__ */ new Set(),
			strategy: /* @__PURE__ */ new Set()
		},
		fonts: null
	};
}
function overlayColor(handle, settings, type, item) {
	const state = stateOf$1(handle);
	return heldItemColor(state.colors, state.channel, settings, type, item);
}
function resetOverlayState(handle) {
	const state = stateOf$1(handle);
	state.trackHistory.clear();
	state.colors.clear();
}
function warnOnce(state, kind, key, message, ...details) {
	const warned = state.warned[kind];
	if (warned.has(key) || warned.size >= WARNING_MEMORY_LIMIT) return;
	warned.add(key);
	console.warn(message, ...details);
}
function fontsFor(state, canvas) {
	if (state.fonts) return state.fonts;
	const family = canvas instanceof HTMLCanvasElement ? getComputedStyle(canvas).getPropertyValue("--font-sans").trim() : "";
	if (!family) return FALLBACK_FONTS;
	state.fonts = fontsOf(family);
	return state.fonts;
}
function drawFrame(ctx, view, items, handle, settings, now) {
	const state = stateOf$1(handle);
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
	ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
	if (items.length === 0) return;
	const box = orientLetterbox(letterbox(view.videoWidth, view.videoHeight, view.cssWidth, view.cssHeight), view.cssWidth, view.cssHeight, view.mirror, view.flipVertical);
	const frame = {
		ctx,
		channel: state.channel,
		settings,
		box,
		width: view.cssWidth,
		height: view.cssHeight,
		mirrored: view.mirror,
		flipped: view.flipVertical,
		roi: mapRoi(settings.roi, view.videoWidth, view.videoHeight, box),
		colors: state.colors,
		fonts: fontsFor(state, ctx.canvas),
		now,
		trackHistory: state.trackHistory,
		masks: state.masks,
		warnOnce: (key, message) => warnOnce(state, "strategy", key, message)
	};
	for (const { message, held } of items) {
		const { type } = message;
		if (type === AUXILIARY_METADATA_TYPE$1) continue;
		const draw = STRATEGIES.get(type);
		if (!draw) {
			warnOnce(state, "unknown", type, `metadata: channel ${state.channel} has no overlay for type "${type}"`);
			continue;
		}
		ctx.save();
		ctx.textAlign = view.mirror ? "right" : "left";
		try {
			draw({
				...frame,
				held
			}, message.data);
		} catch (error) {
			warnOnce(state, "failed", type, `metadata: channel ${state.channel} failed to draw ${type}`, error);
		} finally {
			ctx.restore();
		}
	}
}
function parseMetadataMessage(text) {
	let parsed;
	try {
		parsed = JSON.parse(text);
	} catch {
		return null;
	}
	if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return null;
	if (typeof parsed.type !== "string") return null;
	return parsed;
}
const METADATA_QUEUE_LIMIT = 300;
const LATENESS_WINDOW_MS = 5e3;
const LATENESS_WINDOW_MIN_MESSAGES = 10;
const LATENESS_MEMORY_LIMIT = 1024;
const AUXILIARY_METADATA_TYPE = "auxiliary-visualization";
const AUXILIARY_MAX_ID_LENGTH = 128;
function stateOf(queue) {
	return queue;
}
function metadataTypeOf(message) {
	if (message.type !== AUXILIARY_METADATA_TYPE) return message.type;
	const data = message.data;
	const id = typeof data?.id === "string" ? data.id.trim() : "";
	return id && id.length <= AUXILIARY_MAX_ID_LENGTH ? `${AUXILIARY_METADATA_TYPE}\u0000${id}` : AUXILIARY_METADATA_TYPE;
}
function createMetadataQueue() {
	return {
		timestamped: /* @__PURE__ */ new Map(),
		timestampedEntries: 0,
		arrival: [],
		presented: /* @__PURE__ */ new Map(),
		lastPresented: null,
		lastPresentedAt: 0,
		outcomes: [],
		stats: {
			timestampMatches: 0,
			arrivalFallbacks: 0,
			frameMisses: 0,
			expired: 0,
			evicted: 0,
			untimestampedReceived: 0,
			late: 0
		}
	};
}
function enqueueMetadata(handle, message, receivedAt) {
	const queue = stateOf(handle);
	const key = message._insight?.rtp_timestamp;
	const item = {
		receivedAt,
		data: message
	};
	if (key !== void 0 && Number.isInteger(key) && key >= 0 && key <= 4294967295) {
		if (isLate(queue, key)) {
			const presentedAt = queue.presented.get(key);
			queue.stats.late += 1;
			recordOutcome(queue, {
				at: queue.lastPresentedAt,
				late: true,
				latenessMs: presentedAt === void 0 ? null : Math.max(0, receivedAt - presentedAt)
			});
			return;
		}
		const byType = queue.timestamped.get(key) ?? /* @__PURE__ */ new Map();
		const type = metadataTypeOf(message);
		if (!byType.has(type)) queue.timestampedEntries += 1;
		queue.timestamped.delete(key);
		byType.delete(type);
		byType.set(type, item);
		queue.timestamped.set(key, byType);
		while (queue.timestampedEntries > METADATA_QUEUE_LIMIT) {
			const [oldest, evictedTypes] = queue.timestamped.entries().next().value;
			queue.timestampedEntries -= evictedTypes.size;
			queue.stats.evicted += evictedTypes.size;
			queue.timestamped.delete(oldest);
		}
		return;
	}
	queue.stats.untimestampedReceived += 1;
	queue.arrival.push(item);
	if (queue.arrival.length > METADATA_QUEUE_LIMIT) {
		const evicted = queue.arrival.length - METADATA_QUEUE_LIMIT;
		queue.arrival.splice(0, evicted);
		queue.stats.evicted += evicted;
	}
}
function takeMetadataForFrame(handle, rtpTimestamp, metadataRetentionMs, now) {
	const queue = stateOf(handle);
	pruneMetadataQueue(queue, metadataRetentionMs, now);
	const hasFrameTimestamp = rtpTimestamp !== null && Number.isInteger(rtpTimestamp) && rtpTimestamp >= 0;
	if (hasFrameTimestamp) {
		const key = rtpTimestamp >>> 0;
		recordPresentedFrame(queue, key, now);
		const byType = queue.timestamped.get(key) ?? null;
		if (byType && byType.size > 0) {
			queue.timestamped.delete(key);
			queue.timestampedEntries -= byType.size;
			queue.stats.timestampMatches += 1;
			for (let matched = 0; matched < byType.size; matched += 1) recordOutcome(queue, {
				at: now,
				late: false,
				latenessMs: null
			});
			return [...byType.values()];
		}
	}
	if (!hasFrameTimestamp) {
		let latest = null;
		let latestFrame = null;
		for (const byType of queue.timestamped.values()) for (const item of byType.values()) if (!latest || item.receivedAt >= latest.receivedAt) {
			latest = item;
			latestFrame = byType;
		}
		for (const item of queue.arrival) if (!latest || item.receivedAt >= latest.receivedAt) {
			latest = item;
			latestFrame = null;
		}
		queue.timestamped.clear();
		queue.timestampedEntries = 0;
		queue.arrival.length = 0;
		if (latest) {
			queue.stats.arrivalFallbacks += 1;
			return latestFrame ? [...latestFrame.values()] : [latest];
		}
	}
	if (queue.arrival.length > 0) {
		const latest = queue.arrival[queue.arrival.length - 1];
		queue.arrival.length = 0;
		queue.stats.arrivalFallbacks += 1;
		return [latest];
	}
	queue.stats.frameMisses += 1;
	return [];
}
function holdOverlays(held, overlays, now) {
	const fresh = /* @__PURE__ */ new Set();
	for (const item of overlays) {
		const type = metadataTypeOf(item.data);
		fresh.add(type);
		held.set(type, {
			item,
			matchedAt: now
		});
	}
	const repeats = [];
	for (const [type, { item, matchedAt }] of held) {
		if (fresh.has(type)) continue;
		if (now - matchedAt > 200) held.delete(type);
		else repeats.push({
			...item,
			held: true
		});
	}
	return [...overlays, ...repeats];
}
function metadataQueueSnapshot(handle) {
	const queue = stateOf(handle);
	const lateOutcomes = queue.outcomes.filter((outcome) => outcome.late);
	const lateness = lateOutcomes.map((outcome) => outcome.latenessMs).filter((value) => value !== null).sort((a, b) => a - b);
	return {
		...queue.stats,
		timestampedPending: queue.timestampedEntries,
		arrivalPending: queue.arrival.length,
		recentLateShare: queue.outcomes.length >= LATENESS_WINDOW_MIN_MESSAGES ? lateOutcomes.length / queue.outcomes.length : null,
		recentLatenessMedianMs: nearestRank(lateness, .5),
		recentLatenessP90Ms: nearestRank(lateness, .9),
		recentLatenessMaxMs: lateness.length ? lateness[lateness.length - 1] : null
	};
}
function resetLatenessWindow(handle) {
	stateOf(handle).outcomes.length = 0;
}
function isLate(queue, key) {
	return queue.lastPresented !== null && (key - queue.lastPresented | 0) <= 0;
}
function recordPresentedFrame(queue, key, now) {
	queue.presented.delete(key);
	queue.presented.set(key, now);
	queue.lastPresented = key;
	queue.lastPresentedAt = now;
	for (const [timestamp, presentedAt] of queue.presented) {
		if (now - presentedAt <= LATENESS_WINDOW_MS && queue.presented.size <= LATENESS_MEMORY_LIMIT) break;
		queue.presented.delete(timestamp);
	}
	let expired = 0;
	while (expired < queue.outcomes.length && now - queue.outcomes[expired].at > LATENESS_WINDOW_MS) expired += 1;
	if (expired > 0) queue.outcomes.splice(0, expired);
}
function recordOutcome(queue, outcome) {
	queue.outcomes.push(outcome);
	if (queue.outcomes.length > LATENESS_MEMORY_LIMIT) queue.outcomes.splice(0, queue.outcomes.length - LATENESS_MEMORY_LIMIT);
}
function nearestRank(sorted, fraction) {
	if (sorted.length === 0) return null;
	return sorted[Math.min(sorted.length - 1, Math.ceil(fraction * sorted.length) - 1)];
}
function pruneMetadataQueue(queue, metadataRetentionMs, now) {
	if (metadataRetentionMs <= 0) return;
	for (const [timestamp, byType] of queue.timestamped) {
		for (const [type, item] of byType) {
			if (now - item.receivedAt <= metadataRetentionMs) continue;
			byType.delete(type);
			queue.timestampedEntries -= 1;
			queue.stats.expired += 1;
		}
		if (byType.size === 0) queue.timestamped.delete(timestamp);
	}
	while (queue.arrival.length && now - queue.arrival[0].receivedAt > metadataRetentionMs) {
		queue.arrival.shift();
		queue.stats.expired += 1;
	}
}
function startFrameLoop(video, onFrame, onNoCurrentFrame) {
	return typeof video.requestVideoFrameCallback === "function" ? videoFrameLoop(video, onFrame, onNoCurrentFrame) : animationFrameLoop(video, onFrame, onNoCurrentFrame);
}
function hasCurrentFrame(video) {
	return video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA;
}
function videoFrameLoop(video, onFrame, onNoCurrentFrame) {
	let stopped = false;
	let pending = 0;
	const request = () => {
		pending = video.requestVideoFrameCallback((now, metadata) => {
			if (stopped) return;
			request();
			if (hasCurrentFrame(video)) onFrame({
				now,
				rtpTimestamp: metadata.rtpTimestamp ?? null
			});
			else onNoCurrentFrame();
		});
	};
	request();
	return () => {
		stopped = true;
		video.cancelVideoFrameCallback(pending);
	};
}
function animationFrameLoop(video, onFrame, onNoCurrentFrame) {
	let stopped = false;
	let pending = 0;
	let decoded = 0;
	const request = () => {
		pending = requestAnimationFrame((now) => {
			if (stopped) return;
			request();
			if (!hasCurrentFrame(video)) {
				onNoCurrentFrame();
				return;
			}
			const total = video.getVideoPlaybackQuality().totalVideoFrames;
			if (total === decoded) return;
			decoded = total;
			onFrame({
				now,
				rtpTimestamp: null
			});
		});
	};
	request();
	return () => {
		stopped = true;
		cancelAnimationFrame(pending);
	};
}
const FRAME_GRACE_MS = 1e3;
function startFrameScheduler(frames, onFrame, onDecodeError) {
	let stopped = false;
	let queue = [];
	let animationFrame = 0;
	let decoding = false;
	let next = null;
	const schedule = () => {
		if (animationFrame === 0 && queue.length > 0) animationFrame = requestAnimationFrame(tick);
	};
	const tick = (now) => {
		animationFrame = 0;
		let due = -1;
		queue.forEach((frame, index) => {
			if (frame.presentAt <= now) due = index;
		});
		if (due >= 0) {
			const chosen = queue[due];
			queue = queue.slice(due + 1);
			if (decoding) next = chosen;
			else decode(chosen);
		}
		schedule();
	};
	const reportDecodeError = (error) => {
		try {
			onDecodeError(error);
		} catch (thrown) {
			reportError(thrown);
		}
	};
	const decode = async (frame) => {
		decoding = true;
		try {
			const bitmap = await createImageBitmap(frame.data);
			try {
				if (!stopped) onFrame({
					bitmap,
					rtpTimestamp: frame.rtpTimestamp,
					now: performance.now()
				});
			} catch (error) {
				reportError(error);
			} finally {
				bitmap.close();
			}
		} catch (error) {
			if (!stopped) reportDecodeError(error);
		} finally {
			decoding = false;
		}
		if (next && !stopped) {
			const following = next;
			next = null;
			decode(following);
		}
	};
	const unsubscribe = frames.onFrame((frame) => {
		if (stopped) return;
		queue.push(frame);
		const oldest = performance.now() - FRAME_GRACE_MS;
		let stale = 0;
		while (stale < queue.length && queue[stale].presentAt < oldest) stale += 1;
		if (stale > 0) queue = queue.slice(stale);
		schedule();
	});
	return () => {
		stopped = true;
		unsubscribe();
		if (animationFrame !== 0) cancelAnimationFrame(animationFrame);
		animationFrame = 0;
		queue = [];
		next = null;
	};
}
const NO_VIDEO_TEXT = "No active video received";
const NEAT_STREAM_STALE_MS = 1800;
const FRAME_STATS_INTERVAL_MS = 1e3;
const MAX_CANVAS_DPR = 2;
function reasonOf(error) {
	return error instanceof DOMException ? `${error.name}: ${error.message}` : error;
}
function sameVideoBox(a, b) {
	if (a === null || b === null) return a === b;
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
var NeatVideoTile = class NeatVideoTile {
	source = input(null, ...ngDevMode ? [{ debugName: "source" }] : /* istanbul ignore next */ []);
	settings = input(NEAT_OVERLAY_DEFAULTS, ...ngDevMode ? [{ debugName: "settings" }] : /* istanbul ignore next */ []);
	retentionMs = input(0, ...ngDevMode ? [{ debugName: "retentionMs" }] : /* istanbul ignore next */ []);
	channel = input(0, ...ngDevMode ? [{ debugName: "channel" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	status = input(null, ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	bars = input(true, ...ngDevMode ? [{ debugName: "bars" }] : /* istanbul ignore next */ []);
	notice = input(null, ...ngDevMode ? [{ debugName: "notice" }] : /* istanbul ignore next */ []);
	noticeTone = input("warning", ...ngDevMode ? [{ debugName: "noticeTone" }] : /* istanbul ignore next */ []);
	selected = input(false, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	mirror = input(false, ...ngDevMode ? [{ debugName: "mirror" }] : /* istanbul ignore next */ []);
	flipVertical = input(false, ...ngDevMode ? [{ debugName: "flipVertical" }] : /* istanbul ignore next */ []);
	frameListener = input(null, ...ngDevMode ? [{ debugName: "frameListener" }] : /* istanbul ignore next */ []);
	expandControl = input(false, {
		...ngDevMode ? { debugName: "expandControl" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	stateChange = output();
	frameStats = output();
	state = signal("empty", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	playsFrames = signal(false, ...ngDevMode ? [{ debugName: "playsFrames" }] : /* istanbul ignore next */ []);
	expand = inject(NeatExpand, { self: true });
	expandLabel = computed(() => {
		if (this.expand.expanded()) return "Close";
		return this.label() ? `Expand ${this.label()}` : "Expand";
	}, ...ngDevMode ? [{ debugName: "expandLabel" }] : /* istanbul ignore next */ []);
	noVideoText = computed(() => this.notice() ?? (this.bars() ? NO_VIDEO_TEXT : null), ...ngDevMode ? [{ debugName: "noVideoText" }] : /* istanbul ignore next */ []);
	box = signal(null, {
		...ngDevMode ? { debugName: "box" } : /* istanbul ignore next */ {},
		equal: sameVideoBox
	});
	videoBox = this.box.asReadonly();
	barSize = signal(0, ...ngDevMode ? [{ debugName: "barSize" }] : /* istanbul ignore next */ []);
	barHeight = this.barSize.asReadonly();
	videoElement = viewChild.required("video", ...ngDevMode ? [{ debugName: "videoElement" }] : /* istanbul ignore next */ []);
	canvasElement = viewChild.required("canvas", ...ngDevMode ? [{ debugName: "canvasElement" }] : /* istanbul ignore next */ []);
	framesElement = viewChild.required("frames", ...ngDevMode ? [{ debugName: "framesElement" }] : /* istanbul ignore next */ []);
	barElement = viewChild("bar", ...ngDevMode ? [{ debugName: "barElement" }] : /* istanbul ignore next */ []);
	colors = inject(NeatOverlayColors);
	overlay = computed(() => createOverlayState(this.channel(), this.colors), ...ngDevMode ? [{ debugName: "overlay" }] : /* istanbul ignore next */ []);
	zone = inject(NgZone);
	document = inject(DOCUMENT);
	frameSettings = NEAT_OVERLAY_DEFAULTS;
	frameRetentionMs = 0;
	frameListenerFn = null;
	overlayState = null;
	currentState = "empty";
	canvas = null;
	context = null;
	framesContext = null;
	pictureWidth = 0;
	pictureHeight = 0;
	view = {
		cssWidth: 0,
		cssHeight: 0,
		dpr: 1,
		videoWidth: 0,
		videoHeight: 0,
		mirror: false,
		flipVertical: false
	};
	playing = null;
	queue = createMetadataQueue();
	held = /* @__PURE__ */ new Map();
	lastFrameAt = null;
	staleTimer = null;
	staleCheckSawHidden = false;
	messagesThisSecond = 0;
	warnedUnreadable = false;
	warnedPlayback = false;
	warnedBoth = false;
	warnedDecode = false;
	warnedListener = false;
	destroyed = false;
	constructor() {
		effect(() => {
			this.frameSettings = this.settings();
			this.frameRetentionMs = this.retentionMs();
			this.view.mirror = this.mirror();
			this.view.flipVertical = this.flipVertical();
			this.frameListenerFn = this.frameListener();
		});
		afterRenderEffect((onCleanup) => {
			this.bars();
			const bar = untracked(this.barElement)?.nativeElement;
			if (bar === void 0) {
				this.barSize.set(0);
				return;
			}
			const observer = this.zone.runOutsideAngular(() => new ResizeObserver((entries) => {
				this.barSize.set(entries[entries.length - 1].borderBoxSize[0].blockSize);
			}));
			observer.observe(bar);
			onCleanup(() => observer.disconnect());
		});
		effect(() => {
			this.overlayState = this.overlay();
		});
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			this.canvas = this.canvasElement().nativeElement;
			const observer = this.zone.runOutsideAngular(() => new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.view.cssWidth = width;
				this.view.cssHeight = height;
				this.sizeCanvas(currentDpr());
				this.updateVideoBox();
			}));
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
			const video = this.videoElement().nativeElement;
			const onVideoSize = () => {
				if (!this.playing?.stream) return;
				this.setPictureSize(video.videoWidth, video.videoHeight);
				this.updateVideoBox();
			};
			this.zone.runOutsideAngular(() => {
				video.addEventListener("loadedmetadata", onVideoSize);
				video.addEventListener("resize", onVideoSize);
			});
			destroyRef.onDestroy(() => {
				video.removeEventListener("loadedmetadata", onVideoSize);
				video.removeEventListener("resize", onVideoSize);
			});
		});
		afterRenderEffect(() => {
			const source = this.source();
			const stream = source?.stream() ?? null;
			const frames = source?.frames?.() ?? null;
			untracked(() => this.play(source, stream, frames));
		});
		destroyRef.onDestroy(() => {
			this.destroyed = true;
			this.stop();
		});
	}
	colorOf(type, item) {
		return overlayColor(this.overlay(), this.settings(), type, item);
	}
	snapshot() {
		return metadataQueueSnapshot(this.queue);
	}
	resetLatenessWindow() {
		resetLatenessWindow(this.queue);
	}
	play(source, stream, frames) {
		const run = stream === null ? frames : null;
		if (stream !== null && frames !== null && !this.warnedBoth && isDevMode()) {
			this.warnedBoth = true;
			console.warn(`video: channel ${this.channel()} has both a stream and encoded frames; it plays the stream`);
		}
		const playing = this.playing;
		if (playing?.source === source && playing.stream === stream && playing.frames === run) return;
		this.stop();
		if (source === null) return;
		let stopPicture;
		if (stream !== null) stopPicture = this.playStream(stream);
		else if (run !== null) stopPicture = this.playFrames(run);
		else return;
		this.context ??= this.canvasElement().nativeElement.getContext("2d");
		this.queue = createMetadataQueue();
		this.lastFrameAt = null;
		this.staleCheckSawHidden = false;
		this.messagesThisSecond = 0;
		const unsubscribe = source.onMetadata((text, receivedAt) => this.receive(text, receivedAt));
		const statsTimer = this.zone.runOutsideAngular(() => setInterval(() => this.reportFrameStats(), FRAME_STATS_INTERVAL_MS));
		this.playing = {
			source,
			stream,
			frames: run,
			stop: () => {
				stopPicture();
				clearInterval(statsTimer);
				unsubscribe();
			}
		};
	}
	playStream(stream) {
		const video = this.videoElement().nativeElement;
		video.srcObject = stream;
		this.startPlayback(video);
		const replay = () => this.startPlayback(video);
		const tracks = stream.getVideoTracks();
		for (const track of tracks) track.addEventListener("unmute", replay);
		const stopFrames = this.zone.runOutsideAngular(() => startFrameLoop(video, (frame) => {
			this.setPictureSize(video.videoWidth, video.videoHeight);
			this.present(frame);
		}, () => this.clearOverlays()));
		return () => {
			stopFrames();
			for (const track of tracks) track.removeEventListener("unmute", replay);
			video.srcObject = null;
		};
	}
	playFrames(run) {
		this.framesContext ??= this.framesElement().nativeElement.getContext("2d");
		this.playsFrames.set(true);
		const stopFrames = this.zone.runOutsideAngular(() => startFrameScheduler(run, (frame) => this.drawPicture(frame), (error) => this.warnDecode(error)));
		return () => {
			stopFrames();
			this.playsFrames.set(false);
		};
	}
	warnDecode(error) {
		if (this.warnedDecode) return;
		this.warnedDecode = true;
		console.warn(`video: channel ${this.channel()} cannot decode a frame (${reasonOf(error)}); later ones are skipped silently`);
	}
	setPictureSize(width, height) {
		this.pictureWidth = width;
		this.pictureHeight = height;
	}
	drawPicture({ bitmap, rtpTimestamp, now }) {
		if (bitmap.width !== this.pictureWidth || bitmap.height !== this.pictureHeight) {
			this.setPictureSize(bitmap.width, bitmap.height);
			const canvas = this.framesElement().nativeElement;
			canvas.width = bitmap.width;
			canvas.height = bitmap.height;
			this.updateVideoBox();
		}
		this.framesContext?.drawImage(bitmap, 0, 0);
		this.present({
			now,
			rtpTimestamp
		});
	}
	startPlayback(video) {
		video.play().catch((error) => {
			if (error instanceof DOMException && error.name === "AbortError") return;
			if (this.warnedPlayback) return;
			this.warnedPlayback = true;
			console.warn(`video: channel ${this.channel()} cannot play its stream (${reasonOf(error)})`);
		});
	}
	stop() {
		if (this.playing === null) return;
		this.playing.stop();
		this.playing = null;
		this.setPictureSize(0, 0);
		if (this.staleTimer !== null) clearTimeout(this.staleTimer);
		this.staleTimer = null;
		this.clearOverlays();
		this.setState("empty");
	}
	receive(text, receivedAt) {
		const message = parseMetadataMessage(text);
		if (message === null) {
			if (!this.warnedUnreadable) {
				this.warnedUnreadable = true;
				console.warn(`metadata: channel ${this.channel()} dropped a message that is not a JSON object with a string "type"; later ones are dropped silently`);
			}
			return;
		}
		this.messagesThisSecond += 1;
		enqueueMetadata(this.queue, message, receivedAt);
	}
	present({ now, rtpTimestamp }) {
		this.lastFrameAt = now;
		this.setState("playing");
		this.staleTimer ??= setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS);
		const messages = holdOverlays(this.held, takeMetadataForFrame(this.queue, rtpTimestamp, this.frameRetentionMs, now), now).map((item) => ({
			message: item.data,
			held: item.held === true
		}));
		const ctx = this.context;
		if (ctx !== null && this.overlayState !== null) {
			const dpr = currentDpr();
			if (dpr !== this.view.dpr) this.sizeCanvas(dpr);
			this.view.videoWidth = this.pictureWidth;
			this.view.videoHeight = this.pictureHeight;
			drawFrame(ctx, this.view, messages, this.overlayState, this.frameSettings, now);
		}
		this.notifyListener({
			now,
			messages
		});
	}
	notifyListener(frame) {
		const listener = this.frameListenerFn;
		if (listener === null) return;
		try {
			listener(frame);
		} catch (error) {
			if (this.warnedListener) return;
			this.warnedListener = true;
			console.warn(`video: channel ${this.channel()} frameListener threw; later errors are dropped silently`, error);
		}
	}
	checkStale() {
		this.staleTimer = null;
		if (this.lastFrameAt === null) return;
		const idle = performance.now() - this.lastFrameAt;
		if (this.document.hidden || this.staleCheckSawHidden) {
			this.staleCheckSawHidden = this.document.hidden;
			this.staleTimer = setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS);
			return;
		}
		if (idle < 1800) {
			this.staleTimer = setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS - idle);
			return;
		}
		this.clearOverlays();
		this.setState("stopped");
	}
	clearOverlays() {
		const ctx = this.context;
		if (ctx !== null) {
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
		}
		this.held.clear();
		if (this.overlayState !== null) resetOverlayState(this.overlayState);
	}
	setState(next) {
		if (this.currentState === next) return;
		this.currentState = next;
		this.state.set(next);
		this.updateVideoBox();
		if (!this.destroyed) this.stateChange.emit(next);
	}
	pictureStats(lastFrameAt) {
		const base = {
			lastFrameAgeMs: lastFrameAt === null ? null : Math.round(performance.now() - lastFrameAt),
			active: this.currentState === "playing"
		};
		if (this.playing?.frames) return {
			readyState: lastFrameAt === null ? 0 : HTMLMediaElement.HAVE_ENOUGH_DATA,
			paused: false,
			currentTime: 0,
			videoWidth: this.pictureWidth,
			videoHeight: this.pictureHeight,
			...base
		};
		const video = this.videoElement().nativeElement;
		return {
			readyState: video.readyState,
			paused: video.paused,
			currentTime: video.currentTime,
			videoWidth: video.videoWidth,
			videoHeight: video.videoHeight,
			...base
		};
	}
	reportFrameStats() {
		const snapshot = metadataQueueSnapshot(this.queue);
		const lastFrameAt = this.lastFrameAt;
		this.frameStats.emit({
			timestampMatches: snapshot.timestampMatches,
			arrivalFallbacks: snapshot.arrivalFallbacks,
			frameMisses: snapshot.frameMisses,
			expired: snapshot.expired,
			evicted: snapshot.evicted,
			late: snapshot.late,
			untimestampedReceived: snapshot.untimestampedReceived,
			timestampedPending: snapshot.timestampedPending,
			arrivalPending: snapshot.arrivalPending,
			recentLatenessMedianMs: snapshot.recentLatenessMedianMs,
			recentLatenessMaxMs: snapshot.recentLatenessMaxMs,
			metadataMessagesPerSecond: this.messagesThisSecond,
			video: this.pictureStats(lastFrameAt)
		});
		this.messagesThisSecond = 0;
	}
	updateVideoBox() {
		if (this.currentState !== "playing") {
			this.box.set(null);
			return;
		}
		const { pictureWidth, pictureHeight } = this;
		const { cssWidth, cssHeight } = this.view;
		if (!pictureWidth || !pictureHeight || !cssWidth || !cssHeight) {
			this.box.set(null);
			return;
		}
		const { scaleX, scaleY, offsetX, offsetY } = letterbox(pictureWidth, pictureHeight, cssWidth, cssHeight);
		this.box.set({
			x: offsetX,
			y: offsetY,
			width: scaleX * pictureWidth,
			height: scaleY * pictureHeight
		});
	}
	sizeCanvas(dpr) {
		const canvas = this.canvas;
		if (canvas === null) return;
		this.view.dpr = dpr;
		canvas.width = Math.round(this.view.cssWidth * dpr);
		canvas.height = Math.round(this.view.cssHeight * dpr);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatVideoTile,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatVideoTile,
		isStandalone: true,
		selector: "neat-video-tile",
		inputs: {
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			settings: {
				classPropertyName: "settings",
				publicName: "settings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			retentionMs: {
				classPropertyName: "retentionMs",
				publicName: "retentionMs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			channel: {
				classPropertyName: "channel",
				publicName: "channel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bars: {
				classPropertyName: "bars",
				publicName: "bars",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			notice: {
				classPropertyName: "notice",
				publicName: "notice",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			noticeTone: {
				classPropertyName: "noticeTone",
				publicName: "noticeTone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mirror: {
				classPropertyName: "mirror",
				publicName: "mirror",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flipVertical: {
				classPropertyName: "flipVertical",
				publicName: "flipVertical",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			frameListener: {
				classPropertyName: "frameListener",
				publicName: "frameListener",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expandControl: {
				classPropertyName: "expandControl",
				publicName: "expandControl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			stateChange: "stateChange",
			frameStats: "frameStats"
		},
		host: { properties: {
			"attr.data-state": "state()",
			"attr.data-selected": "selected() ? \"\" : null",
			"attr.data-mirrored": "mirror() ? \"\" : null",
			"attr.data-flipped": "flipVertical() ? \"\" : null",
			"attr.data-frames": "playsFrames() ? \"\" : null"
		} },
		viewQueries: [
			{
				propertyName: "videoElement",
				first: true,
				predicate: ["video"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "canvasElement",
				first: true,
				predicate: ["canvas"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "framesElement",
				first: true,
				predicate: ["frames"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "barElement",
				first: true,
				predicate: ["bar"],
				descendants: true,
				isSignal: true
			}
		],
		hostDirectives: [{
			directive: i1.NeatExpand,
			inputs: ["expanded", "expanded"],
			outputs: ["expandedChange", "expandedChange"]
		}],
		ngImport: i0,
		template: `
    <video #video class="video" autoplay playsinline [muted]="true"></video>
    <canvas #frames class="frames" aria-hidden="true"></canvas>
    <canvas #canvas class="overlay" aria-hidden="true"></canvas>
    <div class="overlay-slot"><ng-content select="[neatTileOverlay]" /></div>
    @if (state() !== 'playing') {
      @if (noVideoText(); as text) {
        <p class="no-video">
          <neat-icon class="no-video-icon" name="video-off" [size]="22" />
          <span class="no-video-text">{{ text }}</span>
        </p>
      }
    } @else if (notice(); as notice) {
      @let picture = videoBox();
      <div
        class="picture"
        [style.left.px]="picture?.x"
        [style.top.px]="picture?.y"
        [style.width.px]="picture?.width"
        [style.height.px]="picture?.height"
      >
        <p class="notice">
          <neat-status-chip [tone]="noticeTone()">{{ notice }}</neat-status-chip>
        </p>
      </div>
    }
    @if (bars()) {
      <div #bar class="bar">
        <span class="label">{{ label() }}</span>
        <span class="status">{{ status() }}</span>
        <ng-content select="[neatTileChip]" />
      </div>
    }
    @if (expandControl()) {
      <button
        neatButton
        class="expand"
        type="button"
        variant="secondary"
        size="small"
        iconOnly
        neatTooltipPosition="bottom"
        [attr.aria-label]="expandLabel()"
        [neatTooltip]="expandLabel()"
        (click)="expand.toggle()"
      >
        <neat-icon [name]="expand.expanded() ? 'close' : 'expand-window'" [size]="16" />
      </button>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:block;width:100%;height:100%;overflow:hidden;isolation:isolate;background:var(--neat-video-surface)}.video,.frames,.overlay{position:absolute;inset:0;width:100%;height:100%}.video,.frames{object-fit:contain}:host([data-frames]) .video,:host(:not([data-frames])) .frames{display:none}.overlay{pointer-events:none}.overlay-slot{position:absolute;inset:0;z-index:1;pointer-events:none}:host([data-state=\"empty\"]):after{content:\"\";position:absolute;inset:0;background:var(--neat-video-surface)}:host([data-mirrored]) :is(.video,.frames){transform:scaleX(-1)}:host([data-flipped]) :is(.video,.frames){transform:scaleY(-1)}:host([data-mirrored][data-flipped]) :is(.video,.frames){transform:scale(-1)}:host([data-state=\"stopped\"]) :is(.video,.frames){filter:blur(9px) saturate(.6) brightness(var(--neat-video-frost-brightness));scale:1.07}:host([data-state=\"stopped\"]) .overlay{visibility:hidden}:host{container-type:inline-size}.no-video{position:absolute;inset:0;z-index:1;pointer-events:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:var(--neat-space-2);margin:0;padding:var(--neat-space-2);text-align:center;font-size:var(--neat-text-xs);color:var(--muted-foreground)}:host([data-state=\"stopped\"]) .no-video{color:var(--neat-video-scrim-foreground)}.no-video-icon{zoom:calc(18 / 22)}@container (min-width: 240px){.no-video{font-size:var(--neat-text-sm)}.no-video-icon{zoom:1}}.picture{position:absolute;inset:0;z-index:1;pointer-events:none}.notice{position:absolute;top:var(--neat-space-3);right:var(--neat-space-3);display:flex;max-width:calc(50% - var(--neat-space-3));margin:0}.bar{position:absolute;inset-inline:0;bottom:0;z-index:1;display:flex;align-items:center;gap:var(--neat-space-2);padding:var(--neat-space-2) var(--neat-space-3);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground);font-size:var(--neat-text-xs)}.label{flex:none;font-weight:500}.status{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.expand{position:absolute;top:var(--neat-space-2);left:var(--neat-space-2);z-index:1;opacity:0;transition:opacity var(--neat-transition-duration)}:host(:hover) .expand,:host([data-neat-expanded]) .expand,.expand:focus-visible{opacity:1}:host([data-selected]):before{content:\"\";position:absolute;inset:0;z-index:2;box-shadow:inset 0 0 0 var(--neat-focus-ring-width) var(--ring);pointer-events:none}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatStatusChip,
				selector: "neat-status-chip",
				inputs: ["tone", "variant"]
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatVideoTile,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-video-tile",
			imports: [
				NeatButton,
				NeatIcon,
				NeatStatusChip,
				NeatTooltip
			],
			hostDirectives: [{
				directive: NeatExpand,
				inputs: ["expanded"],
				outputs: ["expandedChange"]
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-state]": "state()",
				"[attr.data-selected]": "selected() ? \"\" : null",
				"[attr.data-mirrored]": "mirror() ? \"\" : null",
				"[attr.data-flipped]": "flipVertical() ? \"\" : null",
				"[attr.data-frames]": "playsFrames() ? \"\" : null"
			},
			template: `
    <video #video class="video" autoplay playsinline [muted]="true"></video>
    <canvas #frames class="frames" aria-hidden="true"></canvas>
    <canvas #canvas class="overlay" aria-hidden="true"></canvas>
    <div class="overlay-slot"><ng-content select="[neatTileOverlay]" /></div>
    @if (state() !== 'playing') {
      @if (noVideoText(); as text) {
        <p class="no-video">
          <neat-icon class="no-video-icon" name="video-off" [size]="22" />
          <span class="no-video-text">{{ text }}</span>
        </p>
      }
    } @else if (notice(); as notice) {
      @let picture = videoBox();
      <div
        class="picture"
        [style.left.px]="picture?.x"
        [style.top.px]="picture?.y"
        [style.width.px]="picture?.width"
        [style.height.px]="picture?.height"
      >
        <p class="notice">
          <neat-status-chip [tone]="noticeTone()">{{ notice }}</neat-status-chip>
        </p>
      </div>
    }
    @if (bars()) {
      <div #bar class="bar">
        <span class="label">{{ label() }}</span>
        <span class="status">{{ status() }}</span>
        <ng-content select="[neatTileChip]" />
      </div>
    }
    @if (expandControl()) {
      <button
        neatButton
        class="expand"
        type="button"
        variant="secondary"
        size="small"
        iconOnly
        neatTooltipPosition="bottom"
        [attr.aria-label]="expandLabel()"
        [neatTooltip]="expandLabel()"
        (click)="expand.toggle()"
      >
        <neat-icon [name]="expand.expanded() ? 'close' : 'expand-window'" [size]="16" />
      </button>
    }
  `,
			styles: [":host{position:relative;display:block;width:100%;height:100%;overflow:hidden;isolation:isolate;background:var(--neat-video-surface)}.video,.frames,.overlay{position:absolute;inset:0;width:100%;height:100%}.video,.frames{object-fit:contain}:host([data-frames]) .video,:host(:not([data-frames])) .frames{display:none}.overlay{pointer-events:none}.overlay-slot{position:absolute;inset:0;z-index:1;pointer-events:none}:host([data-state=\"empty\"]):after{content:\"\";position:absolute;inset:0;background:var(--neat-video-surface)}:host([data-mirrored]) :is(.video,.frames){transform:scaleX(-1)}:host([data-flipped]) :is(.video,.frames){transform:scaleY(-1)}:host([data-mirrored][data-flipped]) :is(.video,.frames){transform:scale(-1)}:host([data-state=\"stopped\"]) :is(.video,.frames){filter:blur(9px) saturate(.6) brightness(var(--neat-video-frost-brightness));scale:1.07}:host([data-state=\"stopped\"]) .overlay{visibility:hidden}:host{container-type:inline-size}.no-video{position:absolute;inset:0;z-index:1;pointer-events:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:var(--neat-space-2);margin:0;padding:var(--neat-space-2);text-align:center;font-size:var(--neat-text-xs);color:var(--muted-foreground)}:host([data-state=\"stopped\"]) .no-video{color:var(--neat-video-scrim-foreground)}.no-video-icon{zoom:calc(18 / 22)}@container (min-width: 240px){.no-video{font-size:var(--neat-text-sm)}.no-video-icon{zoom:1}}.picture{position:absolute;inset:0;z-index:1;pointer-events:none}.notice{position:absolute;top:var(--neat-space-3);right:var(--neat-space-3);display:flex;max-width:calc(50% - var(--neat-space-3));margin:0}.bar{position:absolute;inset-inline:0;bottom:0;z-index:1;display:flex;align-items:center;gap:var(--neat-space-2);padding:var(--neat-space-2) var(--neat-space-3);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground);font-size:var(--neat-text-xs)}.label{flex:none;font-weight:500}.status{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.expand{position:absolute;top:var(--neat-space-2);left:var(--neat-space-2);z-index:1;opacity:0;transition:opacity var(--neat-transition-duration)}:host(:hover) .expand,:host([data-neat-expanded]) .expand,.expand:focus-visible{opacity:1}:host([data-selected]):before{content:\"\";position:absolute;inset:0;z-index:2;box-shadow:inset 0 0 0 var(--neat-focus-ring-width) var(--ring);pointer-events:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		settings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "settings",
				required: false
			}]
		}],
		retentionMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "retentionMs",
				required: false
			}]
		}],
		channel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "channel",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		bars: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bars",
				required: false
			}]
		}],
		notice: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "notice",
				required: false
			}]
		}],
		noticeTone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "noticeTone",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}],
		mirror: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mirror",
				required: false
			}]
		}],
		flipVertical: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flipVertical",
				required: false
			}]
		}],
		frameListener: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "frameListener",
				required: false
			}]
		}],
		expandControl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expandControl",
				required: false
			}]
		}],
		stateChange: [{
			type: i0.Output,
			args: ["stateChange"]
		}],
		frameStats: [{
			type: i0.Output,
			args: ["frameStats"]
		}],
		videoElement: [{
			type: i0.ViewChild,
			args: ["video", { isSignal: true }]
		}],
		canvasElement: [{
			type: i0.ViewChild,
			args: ["canvas", { isSignal: true }]
		}],
		framesElement: [{
			type: i0.ViewChild,
			args: ["frames", { isSignal: true }]
		}],
		barElement: [{
			type: i0.ViewChild,
			args: ["bar", { isSignal: true }]
		}]
	}
});
function currentDpr() {
	return Math.min(MAX_CANVAS_DPR, window.devicePixelRatio || 1);
}
const CLOSE_DISTANCE_PX = 10;
const MIN_POLYGON_POINTS = 3;
const STROKE_WIDTH = 2;
const HIGHLIGHT_STROKE_WIDTH = 3;
function clamp01(value) {
	return Math.min(1, Math.max(0, value));
}
function fitInto(start, length, limit) {
	return Math.max(0, Math.min(start, limit - length));
}
function sameSize(a, b) {
	if (a === null || b === null) return a === b;
	return a.width === b.width && a.height === b.height;
}
function distancePx(a, b, box) {
	return Math.hypot((a.x - b.x) * box.width, (a.y - b.y) * box.height);
}
function polylinePoints(points, box) {
	return points.map((point) => `${point.x * box.width},${point.y * box.height}`).join(" ");
}
var NeatRoiEditor = class NeatRoiEditor {
	regions = input.required(...ngDevMode ? [{ debugName: "regions" }] : /* istanbul ignore next */ []);
	mode = input("off", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	regionsChange = output();
	highlighted = model(null, ...ngDevMode ? [{ debugName: "highlighted" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef);
	injector = inject(Injector);
	renderer = inject(Renderer2);
	document = inject(DOCUMENT);
	videoBox = inject(NeatVideoTile).videoBox;
	menuElement = viewChild("menu", ...ngDevMode ? [{ debugName: "menuElement" }] : /* istanbul ignore next */ []);
	size = signal(null, {
		...ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {},
		equal: sameSize
	});
	boxSource = computed(() => {
		if (this.videoBox() !== null) return "video";
		return this.size() === null ? null : "tile";
	}, ...ngDevMode ? [{ debugName: "boxSource" }] : /* istanbul ignore next */ []);
	box = computed(() => {
		const video = this.videoBox();
		if (video !== null) return video;
		const size = this.size();
		return size === null ? null : {
			x: 0,
			y: 0,
			width: size.width,
			height: size.height
		};
	}, ...ngDevMode ? [{ debugName: "box" }] : /* istanbul ignore next */ []);
	open = linkedSignal({
		...ngDevMode ? { debugName: "open" } : /* istanbul ignore next */ {},
		source: () => ({
			mode: this.mode(),
			regions: this.regions(),
			boxSource: this.boxSource()
		}),
		computation: () => []
	});
	pointer = signal(null, ...ngDevMode ? [{ debugName: "pointer" }] : /* istanbul ignore next */ []);
	menu = linkedSignal({
		...ngDevMode ? { debugName: "menu" } : /* istanbul ignore next */ {},
		source: () => ({
			regions: this.regions(),
			boxSource: this.boxSource()
		}),
		computation: () => null
	});
	focusBeforeMenu = null;
	drawing = computed(() => this.open().length > 0, ...ngDevMode ? [{ debugName: "drawing" }] : /* istanbul ignore next */ []);
	placed = computed(() => {
		const box = this.box();
		if (box === null) return [];
		const highlighted = this.highlighted();
		return this.regions().map((region, index) => ({
			region,
			index
		})).filter(({ region }) => region.points.length >= MIN_POLYGON_POINTS).map(({ region, index }) => {
			const colors = OVERLAY_ROI_COLORS[region.type];
			const active = index === highlighted;
			return {
				index,
				points: polylinePoints(region.points, box),
				fill: active ? colors.fillActive : colors.fill,
				stroke: colors.stroke,
				strokeWidth: active ? HIGHLIGHT_STROKE_WIDTH : STROKE_WIDTH
			};
		});
	}, ...ngDevMode ? [{ debugName: "placed" }] : /* istanbul ignore next */ []);
	draft = computed(() => {
		const box = this.box();
		const mode = this.mode();
		const points = this.open();
		if (box === null || mode === "off" || points.length === 0) return null;
		const through = this.pointer() ?? points[points.length - 1];
		return {
			line: polylinePoints([...points, through], box),
			stroke: OVERLAY_ROI_COLORS[mode].stroke,
			startX: points[0].x * box.width,
			startY: points[0].y * box.height
		};
	}, ...ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []);
	menuLabel = computed(() => {
		const menu = this.menu();
		if (menu === null) return null;
		const name = neatRoiNames(this.regions())[menu.index];
		return name === void 0 ? null : `Delete ${name}`;
	}, ...ngDevMode ? [{ debugName: "menuLabel" }] : /* istanbul ignore next */ []);
	constructor() {
		const host = this.host.nativeElement;
		const destroyRef = inject(DestroyRef);
		const stopListening = this.renderer.listen(host, "pointermove", (event) => {
			if (this.open().length === 0) return;
			const located = this.locate(event);
			if (located !== null) this.pointer.set(located.point);
		});
		destroyRef.onDestroy(stopListening);
		const zone = inject(NgZone);
		afterNextRender(() => {
			const observer = zone.runOutsideAngular(() => new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.size.set(width > 0 && height > 0 ? {
					width,
					height
				} : null);
			}));
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
		});
		effect((onCleanup) => {
			if (this.menu() === null) return;
			onCleanup(this.renderer.listen(this.document, "pointerdown", (event) => {
				if (!this.inMenu(event.target)) this.closeMenu(false);
			}, { capture: true }));
		});
	}
	onClick(event) {
		const mode = this.mode();
		if (mode === "off" || event.button !== 0 || event.detail >= 2) return;
		if (this.inMenu(event.target)) return;
		const located = this.locate(event);
		if (located === null) return;
		const { point, box } = located;
		const points = this.open();
		if (points.length >= MIN_POLYGON_POINTS && distancePx(points[0], point, box) <= CLOSE_DISTANCE_PX) {
			this.close(mode, points);
			return;
		}
		this.pointer.set(point);
		this.open.set([...points, point]);
		if (points.length === 0) afterNextRender(() => this.host.nativeElement.focus({ preventScroll: true }), { injector: this.injector });
	}
	onDoubleClick(event) {
		const mode = this.mode();
		if (mode === "off" || event.button !== 0 || this.inMenu(event.target)) return;
		const points = this.open();
		if (points.length >= MIN_POLYGON_POINTS) this.close(mode, points);
	}
	cancelOnEscape(event) {
		if (this.open().length === 0) return;
		event.stopPropagation();
		this.open.set([]);
	}
	undoOnBackspace(event) {
		if (this.open().length === 0) return;
		event.preventDefault();
		event.stopPropagation();
		this.undoPoint();
	}
	undoOnRightClick(event) {
		if (this.open().length === 0) return;
		event.preventDefault();
		this.undoPoint();
	}
	openMenu(event, index) {
		event.preventDefault();
		if (this.open().length > 0) return;
		if (index >= this.regions().length) return;
		const origin = this.host.nativeElement.getBoundingClientRect();
		const active = this.document.activeElement;
		this.focusBeforeMenu = active instanceof HTMLElement ? active : null;
		const menu = {
			index,
			x: event.clientX - origin.left,
			y: event.clientY - origin.top
		};
		this.menu.set(menu);
		afterNextRender(() => this.placeMenu(menu), { injector: this.injector });
	}
	deleteFromMenu() {
		const menu = this.menu();
		if (menu === null) return;
		if (this.highlighted() === menu.index) this.highlighted.set(null);
		this.closeMenu(true);
		this.regionsChange.emit(this.regions().filter((_, index) => index !== menu.index));
	}
	closeMenuOnEscape(event) {
		event.stopPropagation();
		this.closeMenu(true);
	}
	closeMenuOnFocusOut(event) {
		if (event.relatedTarget === null || this.inMenu(event.relatedTarget)) return;
		this.closeMenu(false);
	}
	closeMenu(restoreFocus) {
		this.menu.set(null);
		const previous = this.focusBeforeMenu;
		this.focusBeforeMenu = null;
		if (restoreFocus && previous?.isConnected) previous.focus({ preventScroll: true });
	}
	placeMenu(menu) {
		const element = this.menuElement()?.nativeElement;
		if (element === void 0 || this.menu() !== menu) return;
		const size = this.size();
		const x = size === null ? menu.x : fitInto(menu.x, element.offsetWidth, size.width);
		const y = size === null ? menu.y : fitInto(menu.y, element.offsetHeight, size.height);
		this.renderer.setStyle(element, "left", `${x}px`);
		this.renderer.setStyle(element, "top", `${y}px`);
		element.querySelector("button")?.focus({ preventScroll: true });
	}
	inMenu(target) {
		const element = this.menuElement()?.nativeElement;
		return element !== void 0 && target instanceof Node && element.contains(target);
	}
	undoPoint() {
		this.open.update((points) => points.slice(0, -1));
	}
	close(mode, points) {
		this.open.set([]);
		this.regionsChange.emit([...this.regions(), {
			type: mode,
			points
		}]);
	}
	locate(event) {
		const box = this.box();
		if (box === null || box.width <= 0 || box.height <= 0) return null;
		const origin = this.host.nativeElement.getBoundingClientRect();
		return {
			point: {
				x: clamp01((event.clientX - origin.left - box.x) / box.width),
				y: clamp01((event.clientY - origin.top - box.y) / box.height)
			},
			box
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRoiEditor,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatRoiEditor,
		isStandalone: true,
		selector: "neat-roi-editor",
		inputs: {
			regions: {
				classPropertyName: "regions",
				publicName: "regions",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			highlighted: {
				classPropertyName: "highlighted",
				publicName: "highlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			regionsChange: "regionsChange",
			highlighted: "highlightedChange"
		},
		host: {
			listeners: {
				"click": "onClick($event)",
				"dblclick": "onDoubleClick($event)",
				"keydown.escape": "cancelOnEscape($event)",
				"keydown.backspace": "undoOnBackspace($event)",
				"contextmenu": "undoOnRightClick($event)"
			},
			properties: {
				"attr.tabindex": "drawing() ? -1 : null",
				"attr.role": "drawing() ? \"group\" : null",
				"attr.aria-label": "drawing() ? \"Region drawing surface\" : null"
			}
		},
		viewQueries: [{
			propertyName: "menuElement",
			first: true,
			predicate: ["menu"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (box(); as box) {
      <svg
        class="surface"
        aria-hidden="true"
        [attr.data-mode]="mode()"
        [style.left.px]="box.x"
        [style.top.px]="box.y"
        [style.width.px]="box.width"
        [style.height.px]="box.height"
      >
        @for (region of placed(); track region.index) {
          <polygon
            class="region"
            [attr.points]="region.points"
            [attr.fill]="region.fill"
            [attr.stroke]="region.stroke"
            [attr.stroke-width]="region.strokeWidth"
            (pointerenter)="highlighted.set(region.index)"
            (pointerleave)="highlighted.set(null)"
            (contextmenu)="openMenu($event, region.index)"
          />
        }
        @if (draft(); as open) {
          <polyline
            [attr.points]="open.line"
            [attr.stroke]="open.stroke"
            fill="none"
            stroke-width="2"
            stroke-dasharray="4 4"
          />
          <circle [attr.cx]="open.startX" [attr.cy]="open.startY" r="4" [attr.fill]="open.stroke" />
        }
      </svg>
      @if (menuLabel(); as label) {
        <!-- A press on the card around the button must not take focus from it: focus would fall
             to the page, and Escape would no longer reach the bubble. Focus moves on mousedown,
             which browsers also send after a touch. -->
        <div #menu class="menu" (mousedown)="$event.preventDefault()">
          <button
            neatButton
            variant="text"
            size="small"
            type="button"
            [attr.aria-label]="label"
            (click)="deleteFromMenu()"
            (keydown.escape)="closeMenuOnEscape($event)"
            (focusout)="closeMenuOnFocusOut($event)"
          >
            Delete
          </button>
        </div>
      }
    }
  `,
		isInline: true,
		styles: [":host{position:absolute;inset:0;pointer-events:none;outline:none}.surface{position:absolute;overflow:visible}.surface[data-mode=off]{pointer-events:none}.surface[data-mode=inclusion],.surface[data-mode=exclusion]{pointer-events:auto;cursor:crosshair}.region{pointer-events:auto}.menu{position:absolute;padding:calc(var(--neat-space-2) / 2);border:1px solid color-mix(in oklch,var(--border),var(--foreground) 20%);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);pointer-events:auto}\n"],
		dependencies: [{
			kind: "directive",
			type: NeatButton,
			selector: "button[neatButton], a[neatButton]",
			inputs: [
				"variant",
				"size",
				"iconOnly",
				"rounded",
				"pressed"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRoiEditor,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-roi-editor",
			imports: [NeatButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.tabindex]": "drawing() ? -1 : null",
				"[attr.role]": "drawing() ? \"group\" : null",
				"[attr.aria-label]": "drawing() ? \"Region drawing surface\" : null",
				"(click)": "onClick($event)",
				"(dblclick)": "onDoubleClick($event)",
				"(keydown.escape)": "cancelOnEscape($event)",
				"(keydown.backspace)": "undoOnBackspace($event)",
				"(contextmenu)": "undoOnRightClick($event)"
			},
			template: `
    @if (box(); as box) {
      <svg
        class="surface"
        aria-hidden="true"
        [attr.data-mode]="mode()"
        [style.left.px]="box.x"
        [style.top.px]="box.y"
        [style.width.px]="box.width"
        [style.height.px]="box.height"
      >
        @for (region of placed(); track region.index) {
          <polygon
            class="region"
            [attr.points]="region.points"
            [attr.fill]="region.fill"
            [attr.stroke]="region.stroke"
            [attr.stroke-width]="region.strokeWidth"
            (pointerenter)="highlighted.set(region.index)"
            (pointerleave)="highlighted.set(null)"
            (contextmenu)="openMenu($event, region.index)"
          />
        }
        @if (draft(); as open) {
          <polyline
            [attr.points]="open.line"
            [attr.stroke]="open.stroke"
            fill="none"
            stroke-width="2"
            stroke-dasharray="4 4"
          />
          <circle [attr.cx]="open.startX" [attr.cy]="open.startY" r="4" [attr.fill]="open.stroke" />
        }
      </svg>
      @if (menuLabel(); as label) {
        <!-- A press on the card around the button must not take focus from it: focus would fall
             to the page, and Escape would no longer reach the bubble. Focus moves on mousedown,
             which browsers also send after a touch. -->
        <div #menu class="menu" (mousedown)="$event.preventDefault()">
          <button
            neatButton
            variant="text"
            size="small"
            type="button"
            [attr.aria-label]="label"
            (click)="deleteFromMenu()"
            (keydown.escape)="closeMenuOnEscape($event)"
            (focusout)="closeMenuOnFocusOut($event)"
          >
            Delete
          </button>
        </div>
      }
    }
  `,
			styles: [":host{position:absolute;inset:0;pointer-events:none;outline:none}.surface{position:absolute;overflow:visible}.surface[data-mode=off]{pointer-events:none}.surface[data-mode=inclusion],.surface[data-mode=exclusion]{pointer-events:auto;cursor:crosshair}.region{pointer-events:auto}.menu{position:absolute;padding:calc(var(--neat-space-2) / 2);border:1px solid color-mix(in oklch,var(--border),var(--foreground) 20%);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);pointer-events:auto}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		regions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "regions",
				required: true
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		regionsChange: [{
			type: i0.Output,
			args: ["regionsChange"]
		}],
		highlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "highlighted",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["highlightedChange"]
		}],
		menuElement: [{
			type: i0.ViewChild,
			args: ["menu", { isSignal: true }]
		}]
	}
});
var NeatRoiSwatch = class NeatRoiSwatch {
	type = input.required(...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	color = computed(() => OVERLAY_ROI_COLORS[this.type()].stroke, ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRoiSwatch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatRoiSwatch,
		isStandalone: true,
		selector: "neat-roi-swatch",
		inputs: { type: {
			classPropertyName: "type",
			publicName: "type",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "aria-hidden": "true" },
			properties: { "style.background-color": "color()" }
		},
		ngImport: i0,
		template: "",
		isInline: true,
		styles: [":host{display:inline-block;flex-shrink:0;width:.625em;height:.625em;border-radius:50%}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRoiSwatch,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-roi-swatch",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"aria-hidden": "true",
				"[style.background-color]": "color()"
			},
			template: "",
			styles: [":host{display:inline-block;flex-shrink:0;width:.625em;height:.625em;border-radius:50%}\n"]
		}]
	}],
	propDecorators: { type: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "type",
			required: true
		}]
	}] }
});
export { NEAT_MIN_TILE_WIDTH, NEAT_OVERLAY_DEFAULTS, NEAT_OVERLAY_STYLE_FALLBACK_COLOR, NeatRoiEditor, NeatRoiSwatch, NeatTileGrid, NeatVideoTile, bufferSettleMs, fitAllTileWidth, lateNoticeDetails, neatRoiNames, nextWarningActive };

//# sourceMappingURL=sima-neat-ui-video.mjs.map