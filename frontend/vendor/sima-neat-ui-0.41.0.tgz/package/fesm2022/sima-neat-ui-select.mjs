import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, model } from "@angular/core";
import { BrnPopover, BrnPopoverContent, provideBrnPopoverConfig, provideBrnPopoverDefaultOptions } from "@spartan-ng/brain/popover";
import { BrnSelect, BrnSelectContent, BrnSelectItem, BrnSelectList, BrnSelectTrigger, provideBrnSelectConfig } from "@spartan-ng/brain/select";
import { NeatIcon, ɵFIELD_LABEL_CLASSES, ɵhlm } from "@sima/neat-ui";
const SIZES = {
	small: "sm",
	medium: "default"
};
const SELECT_HELM_CLASSES = {
	trigger: "border-input data-placeholder:text-muted-foreground dark:bg-input/30 dark:hover:bg-input/50 focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 gap-1.5 rounded-md border bg-transparent py-2 ps-2.5 pe-2 text-sm shadow-xs transition-[color,box-shadow] focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 data-[size=default]:h-9 data-[size=sm]:h-8 *:data-[slot=select-value]:gap-1.5 flex w-fit items-center justify-between whitespace-nowrap outline-none disabled:cursor-not-allowed disabled:opacity-50 *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0",
	triggerIcon: "text-muted-foreground text-[length:--spacing(4)] ms-auto",
	content: "bg-popover no-scrollbar text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 max-h-72 min-w-36 flex-col rounded-md shadow-md ring-1 duration-100 relative flex w-(--brn-select-width) overflow-x-hidden overflow-y-auto",
	item: "data-highlighted:bg-accent data-highlighted:text-accent-foreground not-data-[variant=destructive]:data-highlighted:**:text-accent-foreground gap-2 rounded-sm py-1.5 ps-2 pe-8 text-sm *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2 relative flex w-full cursor-default items-center outline-hidden select-none data-disabled:pointer-events-none data-disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0",
	itemCheck: "absolute end-2 flex items-center justify-center text-[length:--spacing(4)]"
};
const TRIGGER_CLASSES = ɵhlm(SELECT_HELM_CLASSES.trigger, "w-full focus-visible:ring-ring dark:bg-transparent dark:hover:bg-transparent");
const CONTENT_CLASSES = ɵhlm(SELECT_HELM_CLASSES.content, "ring-border");
const LAYOUTS = {
	above: {
		host: ɵFIELD_LABEL_CLASSES.stack,
		label: ɵFIELD_LABEL_CLASSES.label,
		select: "block"
	},
	inline: {
		host: "flex items-center gap-2",
		label: ɵhlm(ɵFIELD_LABEL_CLASSES.label, "shrink-0"),
		select: "block min-w-0 flex-1"
	}
};
const SIDE_OFFSET = 4;
let nextSelectId = 0;
var NeatSelect = class NeatSelect {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	showLabel = input(false, {
		...ngDevMode ? { debugName: "showLabel" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	labelPosition = input("above", ...ngDevMode ? [{ debugName: "labelPosition" }] : /* istanbul ignore next */ []);
	describedBy = input(...ngDevMode ? [void 0, { debugName: "describedBy" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	layout = computed(() => LAYOUTS[this.labelPosition()], ...ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []);
	labelShown = computed(() => this.showLabel() || this.labelPosition() === "inline", ...ngDevMode ? [{ debugName: "labelShown" }] : /* istanbul ignore next */ []);
	helmSize = computed(() => SIZES[this.size()], ...ngDevMode ? [{ debugName: "helmSize" }] : /* istanbul ignore next */ []);
	triggerId = `neat-select-${++nextSelectId}`;
	triggerClasses = TRIGGER_CLASSES;
	triggerIconClasses = SELECT_HELM_CLASSES.triggerIcon;
	contentClasses = CONTENT_CLASSES;
	itemClasses = SELECT_HELM_CLASSES.item;
	checkClasses = SELECT_HELM_CLASSES.itemCheck;
	selectedLabel = computed(() => this.optionOf(this.value())?.label, ...ngDevMode ? [{ debugName: "selectedLabel" }] : /* istanbul ignore next */ []);
	labelOf = (value) => this.optionOf(value)?.label ?? "";
	pick(value) {
		this.value.set(value);
	}
	optionOf(value) {
		return this.options().find((option) => Object.is(option.value, value));
	}
	closeOnEscape(event, select) {
		if (!select.isExpanded()) return;
		select.close();
		event.stopPropagation();
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSelect,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSelect,
		isStandalone: true,
		selector: "neat-select",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showLabel: {
				classPropertyName: "showLabel",
				publicName: "showLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelPosition: {
				classPropertyName: "labelPosition",
				publicName: "labelPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: {
			attributes: { "data-slot": "select-field" },
			properties: { "class": "layout().host" }
		},
		providers: [
			provideBrnPopoverConfig({
				align: "start",
				sideOffset: SIDE_OFFSET
			}),
			provideBrnPopoverDefaultOptions({ role: null }),
			provideBrnSelectConfig({ isSingleValuePresent: (value) => value !== null && value !== void 0 })
		],
		ngImport: i0,
		template: `
    @if (labelShown()) {
      <label [class]="layout().label" [attr.for]="triggerId">{{ label() }}</label>
    }
    <div
      brnSelect
      brnPopover
      #select="brnSelect"
      data-slot="select"
      [class]="layout().select"
      [value]="value()"
      [disabled]="disabled()"
      [itemToString]="labelOf"
      (valueChange)="pick($event)"
      (keydown.escape)="closeOnEscape($event, select)"
    >
      <button
        brnSelectTrigger
        data-slot="select-trigger"
        [attr.data-size]="helmSize()"
        [id]="triggerId"
        [class]="triggerClasses"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="describedBy() ?? null"
      >
        <span
          data-slot="select-value"
          [class.text-muted-foreground]="selectedLabel() === undefined"
          >{{ selectedLabel() ?? placeholder() }}</span
        >
        <neat-icon name="expand" [size]="16" [class]="triggerIconClasses" />
      </button>
      <ng-template brnPopoverContent>
        <div brnSelectContent data-slot="select-content" [class]="contentClasses">
          <div brnSelectList class="flex flex-col" [attr.aria-label]="label()">
            @for (option of options(); track option.value) {
              <div
                brnSelectItem
                #item="brnSelectItem"
                data-slot="select-item"
                [value]="option.value"
                [disabled]="option.disabled ?? false"
                [class]="itemClasses"
              >
                {{ option.label }}
                @if (item.active()) {
                  <neat-icon name="check" [size]="16" aria-hidden="true" [class]="checkClasses" />
                }
              </div>
            }
          </div>
        </div>
      </ng-template>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnPopover,
				selector: "[brnPopover],brn-popover",
				inputs: [
					"align",
					"sideOffset",
					"offsetX"
				],
				exportAs: ["brnPopover"]
			},
			{
				kind: "directive",
				type: BrnPopoverContent,
				selector: "[brnPopoverContent]",
				exportAs: ["brnPopoverContent"]
			},
			{
				kind: "directive",
				type: BrnSelect,
				selector: "[brnSelect]",
				inputs: [
					"disabled",
					"value",
					"isSingleValuePresent",
					"isItemEqualToValue",
					"itemToString"
				],
				outputs: ["valueChange"],
				exportAs: ["brnSelect"]
			},
			{
				kind: "directive",
				type: BrnSelectContent,
				selector: "[brnSelectContent]",
				exportAs: ["brnSelectContent"]
			},
			{
				kind: "directive",
				type: BrnSelectItem,
				selector: "[brnSelectItem]",
				inputs: [
					"id",
					"value",
					"disabled"
				],
				exportAs: ["brnSelectItem"]
			},
			{
				kind: "directive",
				type: BrnSelectList,
				selector: "[brnSelectList]",
				inputs: ["id"],
				exportAs: ["brnSelectList"]
			},
			{
				kind: "directive",
				type: BrnSelectTrigger,
				selector: "button[brnSelectTrigger]",
				inputs: [
					"id",
					"forceInvalid",
					"aria-invalid"
				],
				exportAs: ["brnSelectTrigger"]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSelect,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-select",
			imports: [
				BrnPopover,
				BrnPopoverContent,
				BrnSelect,
				BrnSelectContent,
				BrnSelectItem,
				BrnSelectList,
				BrnSelectTrigger,
				NeatIcon
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				provideBrnPopoverConfig({
					align: "start",
					sideOffset: SIDE_OFFSET
				}),
				provideBrnPopoverDefaultOptions({ role: null }),
				provideBrnSelectConfig({ isSingleValuePresent: (value) => value !== null && value !== void 0 })
			],
			host: {
				"data-slot": "select-field",
				"[class]": "layout().host"
			},
			template: `
    @if (labelShown()) {
      <label [class]="layout().label" [attr.for]="triggerId">{{ label() }}</label>
    }
    <div
      brnSelect
      brnPopover
      #select="brnSelect"
      data-slot="select"
      [class]="layout().select"
      [value]="value()"
      [disabled]="disabled()"
      [itemToString]="labelOf"
      (valueChange)="pick($event)"
      (keydown.escape)="closeOnEscape($event, select)"
    >
      <button
        brnSelectTrigger
        data-slot="select-trigger"
        [attr.data-size]="helmSize()"
        [id]="triggerId"
        [class]="triggerClasses"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="describedBy() ?? null"
      >
        <span
          data-slot="select-value"
          [class.text-muted-foreground]="selectedLabel() === undefined"
          >{{ selectedLabel() ?? placeholder() }}</span
        >
        <neat-icon name="expand" [size]="16" [class]="triggerIconClasses" />
      </button>
      <ng-template brnPopoverContent>
        <div brnSelectContent data-slot="select-content" [class]="contentClasses">
          <div brnSelectList class="flex flex-col" [attr.aria-label]="label()">
            @for (option of options(); track option.value) {
              <div
                brnSelectItem
                #item="brnSelectItem"
                data-slot="select-item"
                [value]="option.value"
                [disabled]="option.disabled ?? false"
                [class]="itemClasses"
              >
                {{ option.label }}
                @if (item.active()) {
                  <neat-icon name="check" [size]="16" aria-hidden="true" [class]="checkClasses" />
                }
              </div>
            }
          </div>
        </div>
      </ng-template>
    </div>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		showLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showLabel",
				required: false
			}]
		}],
		labelPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelPosition",
				required: false
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
export { NeatSelect };

//# sourceMappingURL=sima-neat-ui-select.mjs.map