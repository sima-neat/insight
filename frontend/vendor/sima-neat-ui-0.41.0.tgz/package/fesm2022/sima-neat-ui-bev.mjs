import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, ElementRef, NgZone, afterNextRender, booleanAttribute, computed, effect, inject, input, model, output, signal, untracked, viewChild } from "@angular/core";
import { NeatButton, NeatIcon, NeatSwatch, NeatTooltip, ThemeService, neatResolveColor, neatThemeColors, ɵNeatOverlayColors, ɵREADOUT_CLASSES, ɵclassStyles, ɵcreateColorAllocator, ɵheldColor, ɵresolveColor, ɵstyleFor } from "@sima/neat-ui";
import { zoom, zoomIdentity, zoomTransform } from "d3-zoom";
import { select } from "d3-selection";
const ZOOM_EXTENT = [1, 4];
function zoomLimits(extent) {
	const [min, max] = extent;
	return [Number.isFinite(min) && min > 0 ? Math.min(min, 1) : ZOOM_EXTENT[0], Number.isFinite(max) && max > 0 ? Math.max(max, 1) : ZOOM_EXTENT[1]];
}
const LABEL_ANGLE = Math.PI / 4;
function bevPlot(shape, range, bounds = null) {
	if (shape === "rect" && bounds) {
		const [back, front] = bounds.x;
		const [right, left] = bounds.y;
		return {
			shape,
			range,
			back,
			front,
			right,
			left
		};
	}
	return {
		shape,
		range,
		back: -range,
		front: range,
		right: -range,
		left: range
	};
}
function hasArea(plot) {
	const { back, front, right, left } = plot;
	if (plot.shape === "round" && !(plot.range > 0 && Number.isFinite(plot.range))) return false;
	return Number.isFinite(front - back) && Number.isFinite(left - right) && front > back && left > right;
}
function plotAspect(plot) {
	return hasArea(plot) ? (plot.left - plot.right) / (plot.front - plot.back) : 1;
}
function plotReach(plot) {
	return Math.min(plot.left - plot.right, plot.front - plot.back) / 2;
}
function onPlot(plot, x, y) {
	if (plot.shape === "round") return Math.hypot(x, y) <= plot.range;
	return x >= plot.back && x <= plot.front && y >= plot.right && y <= plot.left;
}
function defaultView(width, height, plot) {
	const w = Math.max(0, width);
	const h = Math.max(0, height);
	let ppm = 0;
	if (hasArea(plot)) {
		const fit = Math.min((w - 24) / (plot.left - plot.right), (h - 24) / (plot.front - plot.back));
		if (fit > 0) ppm = fit;
	}
	return {
		cx: w / 2 + (plot.left + plot.right) / 2 * ppm,
		cy: h / 2 + (plot.front + plot.back) / 2 * ppm,
		ppm,
		k: 1,
		tx: 0,
		ty: 0
	};
}
function panArea(view, plot, overflow, width, height, extra = null) {
	if (extra) {
		const [back, front] = extra.x;
		const [right, left] = extra.y;
		if ([
			back,
			front,
			right,
			left
		].every(Number.isFinite) && front > back && left > right) return [[Math.min(0, view.cx - left * view.ppm), Math.min(0, view.cy - front * view.ppm)], [Math.max(width, view.cx - right * view.ppm), Math.max(height, view.cy - back * view.ppm)]];
	}
	if (overflow === "visible") return [[0, 0], [width, height]];
	return [[view.cx - plot.left * view.ppm, view.cy - plot.front * view.ppm], [view.cx - plot.right * view.ppm, view.cy - plot.back * view.ppm]];
}
function plotRect(view, plot) {
	const scale = view.ppm * view.k;
	const x = view.tx + view.k * view.cx;
	const y = view.ty + view.k * view.cy;
	return [[x - plot.left * scale, y - plot.front * scale], [x - plot.right * scale, y - plot.back * scale]];
}
function boxPlot(view, width, height, range) {
	const scale = view.ppm * view.k;
	const x = view.tx + view.k * view.cx;
	const y = view.ty + view.k * view.cy;
	return {
		shape: "rect",
		range,
		back: (y - height) / scale,
		front: y / scale,
		right: (x - width) / scale,
		left: x / scale
	};
}
function farthestCorner(plot) {
	return Math.hypot(Math.max(Math.abs(plot.back), Math.abs(plot.front)), Math.max(Math.abs(plot.right), Math.abs(plot.left)));
}
function labelAngle(view, width, height) {
	const scale = view.ppm * view.k;
	const x = view.tx + view.k * view.cx;
	const y = view.ty + view.k * view.cy;
	if (x >= 0 && x <= width && y >= 0 && y <= height) return LABEL_ANGLE;
	return Math.atan2((x - width / 2) / scale, (y - height / 2) / scale);
}
function toScreen(view, x, y, into) {
	into.x = view.tx + view.k * (view.cx - y * view.ppm);
	into.y = view.ty + view.k * (view.cy - x * view.ppm);
	return into;
}
function toVehicle(view, sx, sy, into) {
	into.x = (view.cy - (sy - view.ty) / view.k) / view.ppm;
	into.y = (view.cx - (sx - view.tx) / view.k) / view.ppm;
	return into;
}
function ringStep(range) {
	if (!(range > 0) || !Number.isFinite(range)) return 1;
	const target = range / 6;
	const power = 10 ** Math.floor(Math.log10(target));
	let best = power;
	for (const factor of [
		1,
		2,
		5,
		10
	]) {
		const step = factor * power;
		if (Math.abs(Math.log(step / target)) < Math.abs(Math.log(best / target))) best = step;
	}
	return best;
}
function stepFor(range, view) {
	let step = ringStep(range / view.k);
	const scale = view.ppm * view.k;
	if (!(scale > 0)) return step;
	while (step * scale < 44) step = nextNice(step);
	return step;
}
function nextNice(step) {
	const power = 10 ** Math.floor(Math.log10(step) + 1e-9);
	const factor = Math.round(step / power);
	return (factor < 2 ? 2 : factor < 5 ? 5 : 10) * power;
}
function metersText(value) {
	return `${Number(value.toFixed(1))} m`;
}
const CENTER = {
	x: 0,
	y: 0
};
function spokeList(spokes) {
	if (typeof spokes === "number") {
		const count = Number.isFinite(spokes) && spokes > 0 ? Math.floor(spokes) : 0;
		return Array.from({ length: count }, (_, i) => ({
			angle: 2 * Math.PI * i / count,
			origin: CENTER
		}));
	}
	return spokes.filter((spoke) => Number.isFinite(spoke.angle)).map((spoke) => ({
		angle: spoke.angle,
		origin: spoke.origin ?? CENTER
	}));
}
function spokeLength(origin, angle, plot) {
	const dx = Math.cos(angle);
	const dy = Math.sin(angle);
	if (plot.shape === "round") {
		const range = plot.range;
		const along = origin.x * dx + origin.y * dy;
		const inside = range * range - (origin.x * origin.x + origin.y * origin.y);
		if (inside <= 0) return 0;
		return -along + Math.sqrt(along * along + inside);
	}
	const { back, front, right, left } = plot;
	if (origin.x <= back || origin.x >= front || origin.y <= right || origin.y >= left) return 0;
	let t = Infinity;
	if (Math.abs(dx) > 1e-12) t = Math.min(t, ((dx > 0 ? front : back) - origin.x) / dx);
	if (Math.abs(dy) > 1e-12) t = Math.min(t, ((dy > 0 ? left : right) - origin.y) / dy);
	return Number.isFinite(t) ? t : 0;
}
function objectCorners(object, into) {
	const cos = Math.cos(object.yaw);
	const sin = Math.sin(object.yaw);
	const l = object.length / 2;
	const w = object.width / 2;
	const along = [
		l,
		l,
		-l,
		-l
	];
	const across = [
		w,
		-w,
		-w,
		w
	];
	for (let i = 0; i < 4; i++) {
		into[2 * i] = object.x + along[i] * cos - across[i] * sin;
		into[2 * i + 1] = object.y + along[i] * sin + across[i] * cos;
	}
	return into;
}
function hitObject(objects, x, y, tolerance) {
	for (let i = objects.length - 1; i >= 0; i--) {
		const object = objects[i];
		const dx = x - object.x;
		const dy = y - object.y;
		const cos = Math.cos(object.yaw);
		const sin = Math.sin(object.yaw);
		const along = dx * cos + dy * sin;
		const across = -dx * sin + dy * cos;
		if (Math.abs(along) <= object.length / 2 + tolerance && Math.abs(across) <= object.width / 2 + tolerance) return i;
	}
	return -1;
}
const OBJECT_FILL_ALPHA = .25;
const GUIDE_ALPHA = .18;
const OUTLINE_ALPHA = .5;
const GRID_ALPHA = .18;
function dashOf(style) {
	return style === "dashed" ? DASHED : style === "dotted" ? DOTTED : SOLID$1;
}
const SOLID$1 = [];
const DASHED = [6, 4];
const DOTTED = [2, 2];
var LabelColors = class {
	allocator;
	styles = Object.create(null);
	overrides;
	held = /* @__PURE__ */ new Map();
	rgb = /* @__PURE__ */ new Map();
	frame = 0;
	now = 0;
	constructor(colors) {
		this.allocator = ɵcreateColorAllocator(colors);
	}
	setStyles(rows) {
		const { styles, overrides } = ɵclassStyles(rows);
		this.styles = styles;
		this.overrides = rows.length > 0 ? overrides : void 0;
		this.held.clear();
	}
	begin(now) {
		this.frame++;
		this.now = now;
	}
	of(label) {
		let held = this.held.get(label);
		if (held?.frame === this.frame) return held;
		const color = ɵresolveColor({
			allocator: this.allocator,
			channelIndex: 0,
			namespace: "class",
			identity: label,
			overrides: this.overrides,
			now: this.now
		});
		const row = ɵstyleFor(this.styles, label);
		if (!held) {
			held = {
				frame: 0,
				color,
				rgb: null,
				style: null,
				width: 2
			};
			this.held.set(label, held);
		}
		held.frame = this.frame;
		held.color = color;
		held.rgb = this.resolve(color);
		held.style = row?.style ?? null;
		held.width = row?.width ?? 2;
		return held;
	}
	heldColorOf(label, rows) {
		return ɵheldColor({
			allocator: this.allocator,
			channelIndex: 0,
			namespace: "class",
			identity: label,
			overrides: ɵclassStyles(rows).overrides
		});
	}
	resolve(color) {
		if (!this.rgb.has(color)) this.rgb.set(color, neatResolveColor(color));
		return this.rgb.get(color) ?? null;
	}
};
const POINT_HALF = 1;
const MARKER_TIP = 9;
const MARKER_BASE = 6;
const GRID_LABEL_LEFT = 4;
const GRID_LABEL_TOP = 10;
const CORNER_WIDTH = 36;
const LABEL_CLEARANCE = 12;
const HALO_WIDTH = 3;
const HOVER_EXTRA = 2;
const LABEL_MARGIN = 8;
const NO_FRAME = {};
const SOLID = dashOf(null);
const PIXEL_BYTES = /* @__PURE__ */ new Uint8Array(4);
const PIXEL_WORD = new Uint32Array(PIXEL_BYTES.buffer);
function packRgb([red, green, blue]) {
	const byte = (value) => Math.round(Math.min(1, Math.max(0, value)) * 255);
	PIXEL_BYTES[0] = byte(red);
	PIXEL_BYTES[1] = byte(green);
	PIXEL_BYTES[2] = byte(blue);
	PIXEL_BYTES[3] = 255;
	return PIXEL_WORD[0];
}
var BevCanvas = class {
	canvas;
	createCanvas;
	context = null;
	boxWidth = 0;
	boxHeight = 0;
	width = 0;
	height = 0;
	ratio = 0;
	under = {
		canvas: null,
		context: null,
		used: false
	};
	over = {
		canvas: null,
		context: null,
		used: false
	};
	layerView = null;
	layerInputs = null;
	layerTheme = null;
	layerRatio = 0;
	layerWidth = 0;
	layerHeight = 0;
	staticColors = [];
	layerDraws = 0;
	grids = [];
	points = null;
	corners = /* @__PURE__ */ new Float64Array(8);
	labels = [];
	areaLabels = [];
	point = {
		x: 0,
		y: 0
	};
	other = {
		x: 0,
		y: 0
	};
	constructor(canvas, createCanvas = () => canvas.ownerDocument.createElement("canvas")) {
		this.canvas = canvas;
		this.createCanvas = createCanvas;
	}
	size(width, height) {
		this.boxWidth = width;
		this.boxHeight = height;
	}
	draw(ratio, view, inputs, theme, colors, frame, hover) {
		if (this.boxWidth <= 0 || this.boxHeight <= 0) return false;
		if (this.boxWidth !== this.width || this.boxHeight !== this.height || ratio !== this.ratio) {
			this.width = this.boxWidth;
			this.height = this.boxHeight;
			this.ratio = ratio;
			this.canvas.width = Math.round(this.width * ratio);
			this.canvas.height = Math.round(this.height * ratio);
		}
		this.context ??= this.canvas.getContext("2d");
		const context = this.context;
		if (!context) return false;
		context.setTransform(1, 0, 0, 1, 0, 0);
		context.clearRect(0, 0, this.canvas.width, this.canvas.height);
		if (!(view.ppm > 0)) return false;
		const shown = frame ?? NO_FRAME;
		if (this.layerStale(ratio, view, inputs, theme, colors)) this.drawLayers(ratio, view, inputs, theme, colors);
		this.putLayer(context, this.under);
		context.setTransform(ratio, 0, 0, ratio, 0, 0);
		context.save();
		this.clip(context, view, inputs);
		this.drawAreas(context, view, shown, colors, theme);
		this.drawLines(context, view, shown, colors);
		this.drawPoints(context, view, shown, colors, inputs);
		this.drawObjects(context, view, shown, colors, hover);
		context.restore();
		this.putLayer(context, this.over);
		context.setTransform(ratio, 0, 0, ratio, 0, 0);
		context.save();
		this.clip(context, view, inputs);
		this.drawEgo(context, view, theme);
		context.restore();
		return true;
	}
	putLayer(context, layer) {
		if (!layer.used || !layer.canvas) return;
		context.setTransform(1, 0, 0, 1, 0, 0);
		context.drawImage(layer.canvas, 0, 0);
	}
	clip(context, view, inputs) {
		if (inputs.overflow === "visible") return;
		this.plotPath(context, view, inputs.plot);
		context.clip();
	}
	plotPath(context, view, plot) {
		context.beginPath();
		if (plot.shape === "round") {
			const center = toScreen(view, 0, 0, this.point);
			const radius = Math.max(0, plot.range * view.ppm * view.k);
			context.arc(center.x, center.y, radius, 0, 2 * Math.PI);
		} else {
			const [[x0, y0], [x1, y1]] = plotRect(view, plot);
			context.rect(x0, y0, x1 - x0, y1 - y0);
		}
	}
	layerStale(ratio, view, inputs, theme, colors) {
		let stale = this.over.canvas === null || ratio !== this.layerRatio || this.width !== this.layerWidth || this.height !== this.layerHeight || inputs !== this.layerInputs || theme !== this.layerTheme || !sameView(view, this.layerView);
		let i = 0;
		forEachStaticLabel(inputs, (label) => {
			if (this.staticColors[i++] !== colors.of(label).color) stale = true;
		});
		return stale || i !== this.staticColors.length;
	}
	drawLayers(ratio, view, inputs, theme, colors) {
		this.layerRatio = ratio;
		this.layerWidth = this.width;
		this.layerHeight = this.height;
		this.layerView = view;
		this.layerInputs = inputs;
		this.layerTheme = theme;
		this.staticColors.length = 0;
		forEachStaticLabel(inputs, (label) => this.staticColors.push(colors.of(label).color));
		this.layerDraws++;
		const step = stepFor(plotReach(inputs.plot), view);
		const guidesUnder = inputs.guides === "under";
		this.under.used = inputs.background !== null || guidesUnder;
		const under = this.under.used ? this.prepare(this.under, ratio) : null;
		if (under) {
			this.drawStatic(under, view, inputs, inputs.background, colors);
			if (guidesUnder) this.drawGuides(under, view, inputs, theme, step);
		}
		this.over.used = true;
		const over = this.prepare(this.over, ratio);
		if (!over) return;
		if (!guidesUnder) this.drawGuides(over, view, inputs, theme, step);
		this.drawStatic(over, view, inputs, inputs.foreground, colors);
		this.labelStyle(over, theme);
		if (inputs.plot.shape === "round") this.ringLabels(over, view, inputs, theme, step);
		else this.gridLabels(over, view, inputs, theme, step);
	}
	prepare(layer, ratio) {
		layer.canvas ??= this.createCanvas();
		const canvas = layer.canvas;
		if (canvas.width !== this.canvas.width || canvas.height !== this.canvas.height) {
			canvas.width = this.canvas.width;
			canvas.height = this.canvas.height;
		}
		layer.context ??= canvas.getContext("2d");
		const context = layer.context;
		if (!context) {
			layer.used = false;
			return null;
		}
		context.setTransform(1, 0, 0, 1, 0, 0);
		context.clearRect(0, 0, canvas.width, canvas.height);
		context.setTransform(ratio, 0, 0, ratio, 0, 0);
		return context;
	}
	drawGuides(context, view, inputs, theme, step) {
		context.save();
		this.clip(context, view, inputs);
		if (inputs.plot.shape === "round") this.drawRings(context, view, inputs, theme, step);
		else this.drawGridLines(context, view, inputs, theme, step);
		this.drawSpokes(context, view, inputs, theme);
		context.restore();
		if (inputs.outline) this.drawOutline(context, view, inputs.plot, theme);
	}
	drawStatic(context, view, inputs, layer, colors) {
		if (!layer) return;
		context.save();
		this.clip(context, view, inputs);
		if (layer.lines) {
			this.fillPolygons(context, view, layer.lines, colors, "");
			this.drawLines(context, view, layer, colors);
		}
		for (const set of layer.points ?? []) {
			const xy = set.xy;
			context.beginPath();
			for (let i = 0; i + 1 < xy.length; i += 2) {
				const at = toScreen(view, xy[i], xy[i + 1], this.point);
				context.rect(at.x - POINT_HALF, at.y - POINT_HALF, 2, 2);
			}
			context.fillStyle = colors.of(set.label).color;
			context.fill();
		}
		context.restore();
	}
	drawRings(context, view, inputs, theme, step) {
		const scale = view.ppm * view.k;
		const center = toScreen(view, 0, 0, this.point);
		const last = this.ringLimit(view, inputs);
		context.lineWidth = 1;
		context.setLineDash(SOLID);
		context.strokeStyle = theme.line;
		context.beginPath();
		for (let r = step; r < last - step * 1e-6; r += step) {
			context.moveTo(center.x + r * scale, center.y);
			context.arc(center.x, center.y, r * scale, 0, 2 * Math.PI);
		}
		context.stroke();
	}
	ringLimit(view, inputs) {
		const { plot } = inputs;
		if (inputs.overflow === "clip") return plot.range;
		return farthestCorner(boxPlot(view, this.width, this.height, plot.range)) + 1;
	}
	ringLabels(context, view, inputs, theme, step) {
		const { range } = inputs.plot;
		const angle = labelAngle(view, this.width, this.height);
		const cos = Math.cos(angle);
		const sin = Math.sin(angle);
		const last = inputs.overflow === "clip" ? range + step * 1e-6 : this.ringLimit(view, inputs);
		for (let r = step; r <= last; r += step) {
			const at = toScreen(view, r * cos, r * sin, this.other);
			if (at.x < LABEL_MARGIN || at.y < LABEL_MARGIN || at.x > this.width - LABEL_MARGIN || at.y > this.height - LABEL_MARGIN) continue;
			this.label(context, metersText(r), at.x, at.y, theme);
		}
	}
	region(view, inputs) {
		if (inputs.overflow === "visible") return [
			0,
			0,
			this.width,
			this.height
		];
		const [[x0, y0], [x1, y1]] = plotRect(view, inputs.plot);
		return [
			Math.max(0, x0),
			Math.max(0, y0),
			Math.min(this.width, x1),
			Math.min(this.height, y1)
		];
	}
	gridSpan(view, step, [left, top, right, bottom]) {
		const scale = view.ppm * view.k;
		const center = toScreen(view, 0, 0, this.point);
		return [
			Math.ceil((center.y - bottom) / scale / step - 1e-9),
			Math.floor((center.y - top) / scale / step + 1e-9),
			Math.ceil((center.x - right) / scale / step - 1e-9),
			Math.floor((center.x - left) / scale / step + 1e-9)
		];
	}
	drawGridLines(context, view, inputs, theme, step) {
		const scale = view.ppm * view.k;
		const region = this.region(view, inputs);
		const [left, top, right, bottom] = region;
		if (right <= left || bottom <= top) return;
		const [lowX, highX, lowY, highY] = this.gridSpan(view, step, region);
		const center = toScreen(view, 0, 0, this.point);
		context.lineWidth = 1;
		context.setLineDash(SOLID);
		context.strokeStyle = theme.line;
		context.beginPath();
		for (let n = lowX; n <= highX; n++) {
			const y = center.y - n * step * scale;
			context.moveTo(left, y);
			context.lineTo(right, y);
		}
		for (let n = lowY; n <= highY; n++) {
			const x = center.x - n * step * scale;
			context.moveTo(x, top);
			context.lineTo(x, bottom);
		}
		context.stroke();
	}
	gridLabels(context, view, inputs, theme, step) {
		const scale = view.ppm * view.k;
		const region = this.region(view, inputs);
		const [left, top, right, bottom] = region;
		if (right <= left || bottom <= top) return;
		const [lowX, highX, lowY, highY] = this.gridSpan(view, step, region);
		const center = toScreen(view, 0, 0, this.point);
		const column = left + GRID_LABEL_LEFT;
		const row = top + GRID_LABEL_TOP;
		context.textAlign = "left";
		for (let n = lowX; n <= highX; n++) {
			const y = center.y - n * step * scale;
			if (n === 0 || y < row + LABEL_CLEARANCE || y > bottom - GRID_LABEL_TOP) continue;
			this.label(context, metersText(Math.abs(n * step)), column, y, theme);
		}
		context.textAlign = "center";
		for (let n = lowY; n <= highY; n++) {
			const x = center.x - n * step * scale;
			if (n === 0 || x < column + CORNER_WIDTH || x > right - CORNER_WIDTH / 2) continue;
			this.label(context, metersText(Math.abs(n * step)), x, row, theme);
		}
		context.textAlign = "center";
	}
	drawSpokes(context, view, inputs, theme) {
		context.lineWidth = 1;
		context.setLineDash(SOLID);
		context.strokeStyle = theme.line;
		context.beginPath();
		const plot = inputs.overflow === "visible" ? boxPlot(view, this.width, this.height, inputs.plot.range) : inputs.plot;
		for (const { angle, origin } of inputs.spokes) {
			const length = spokeLength(origin, angle, plot);
			if (length <= 0) continue;
			const from = toScreen(view, origin.x, origin.y, this.point);
			context.moveTo(from.x, from.y);
			const end = toScreen(view, origin.x + length * Math.cos(angle), origin.y + length * Math.sin(angle), this.other);
			context.lineTo(end.x, end.y);
		}
		context.stroke();
	}
	drawOutline(context, view, plot, theme) {
		context.lineWidth = 1;
		context.setLineDash(SOLID);
		context.strokeStyle = theme.strong;
		this.plotPath(context, view, plot);
		context.stroke();
	}
	labelStyle(context, theme) {
		context.font = theme.font;
		context.textAlign = "center";
		context.textBaseline = "middle";
		context.lineJoin = "round";
		context.lineWidth = HALO_WIDTH;
	}
	label(context, text, x, y, theme) {
		context.strokeStyle = theme.halo;
		context.strokeText(text, x, y);
		context.fillStyle = theme.text;
		context.fillText(text, x, y);
	}
	drawAreas(context, view, frame, colors, theme) {
		const { grids, lines } = frame;
		const count = grids?.length ?? 0;
		this.grids.length = Math.min(this.grids.length, count);
		for (const layer of ["backing", "tint"]) {
			if (lines && (layer === "tint" || theme.surface)) this.fillPolygons(context, view, lines, layer === "tint" ? colors : null, theme.halo);
			if (!grids) continue;
			context.imageSmoothingEnabled = false;
			for (let i = 0; i < count; i++) {
				const grid = grids[i];
				if (grid.columns <= 0 || grid.rows <= 0 || grid.cells.length < grid.columns * grid.rows) continue;
				const cached = layer === "backing" ? this.gridCanvases(i, grid, colors.of(grid.label), theme.surface) : this.grids[i];
				if (!cached || layer === "backing" && !cached.surface) continue;
				const corner = toScreen(view, grid.x[1], grid.y[1], this.point);
				const opposite = toScreen(view, grid.x[0], grid.y[0], this.other);
				const image = cached[layer];
				context.drawImage(image, corner.x, corner.y, opposite.x - corner.x, opposite.y - corner.y);
			}
			context.imageSmoothingEnabled = true;
		}
	}
	fillPolygons(context, view, lines, colors, surface) {
		const labels = this.areaLabels;
		labels.length = 0;
		for (const line of lines) if (line.fill && line.xy.length >= 6 && !labels.includes(line.label)) labels.push(line.label);
		if (labels.length === 0) return;
		context.globalAlpha = colors ? GRID_ALPHA : 1;
		for (const label of labels) {
			context.beginPath();
			for (const line of lines) {
				if (!line.fill || line.label !== label || line.xy.length < 6) continue;
				this.addPolygon(context, view, line.xy);
			}
			context.fillStyle = colors ? colors.of(label).color : surface;
			context.fill("nonzero");
		}
		context.globalAlpha = 1;
	}
	addPolygon(context, view, xy) {
		const pairs = xy.length >> 1;
		const reversed = signedArea(xy) < 0;
		for (let k = 0; k < pairs; k++) {
			const i = 2 * (reversed ? pairs - 1 - k : k);
			const at = toScreen(view, xy[i], xy[i + 1], this.point);
			if (k === 0) context.moveTo(at.x, at.y);
			else context.lineTo(at.x, at.y);
		}
		context.closePath();
	}
	linePath(context, view, xy, closed) {
		context.beginPath();
		for (let i = 0; i + 1 < xy.length; i += 2) {
			const at = toScreen(view, xy[i], xy[i + 1], this.point);
			if (i === 0) context.moveTo(at.x, at.y);
			else context.lineTo(at.x, at.y);
		}
		if (closed) context.closePath();
	}
	gridCanvases(index, grid, look, surface) {
		let cache = this.grids[index];
		if (!cache) {
			cache = {
				cells: null,
				color: "",
				surface: null,
				tint: this.createCanvas(),
				backing: this.createCanvas()
			};
			this.grids[index] = cache;
		}
		if (cache.cells === grid.cells && cache.color === look.color && sameRgb(cache.surface, surface)) return cache;
		cache.cells = null;
		if (!look.rgb) return null;
		if (!this.paintGrid(cache.tint, grid, look.rgb, .18)) return null;
		if (surface && !this.paintGrid(cache.backing, grid, surface, 1)) return null;
		cache.cells = grid.cells;
		cache.color = look.color;
		cache.surface = surface;
		return cache;
	}
	paintGrid(canvas, grid, [red, green, blue], alpha) {
		canvas.width = grid.columns;
		canvas.height = grid.rows;
		const context = canvas.getContext("2d");
		if (!context) return false;
		const image = context.createImageData(grid.columns, grid.rows);
		const data = image.data;
		const cells = grid.cells;
		for (let i = 0; i < grid.columns * grid.rows; i++) {
			const value = cells[i];
			if (value === 0) continue;
			const o = i * 4;
			data[o] = red * 255;
			data[o + 1] = green * 255;
			data[o + 2] = blue * 255;
			data[o + 3] = value * alpha;
		}
		context.putImageData(image, 0, 0);
		return true;
	}
	drawLines(context, view, frame, colors) {
		const lines = frame.lines;
		if (!lines) return;
		context.lineJoin = "round";
		context.lineCap = "round";
		for (const line of lines) {
			const xy = line.xy;
			if (xy.length < 4 || line.fill) continue;
			const look = colors.of(line.label);
			context.strokeStyle = look.color;
			context.lineWidth = look.width;
			context.setLineDash(dashOf(look.style ?? line.style));
			this.linePath(context, view, xy, line.closed === true);
			context.stroke();
		}
		context.setLineDash(SOLID);
	}
	drawPoints(context, view, frame, colors, inputs) {
		const sets = frame.points;
		if (!sets?.some((set) => set.xy.length >= 2)) return;
		const ratio = this.ratio;
		const [x0, y0, x1, y1] = this.region(view, inputs);
		const left = Math.max(0, Math.floor(x0 * ratio));
		const top = Math.max(0, Math.floor(y0 * ratio));
		const right = Math.min(this.canvas.width, Math.ceil(x1 * ratio));
		const bottom = Math.min(this.canvas.height, Math.ceil(y1 * ratio));
		if (right <= left || bottom <= top) return;
		const pixels = this.pointPixels(right - left, bottom - top);
		if (!pixels) return;
		const { image, words, canvas, context: pointsContext } = pixels;
		const width = image.width;
		const height = image.height;
		words.fill(0);
		const scale = view.ppm * view.k * ratio;
		const ox = (view.tx + view.k * view.cx) * ratio - left;
		const oy = (view.ty + view.k * view.cy) * ratio - top;
		const side = Math.max(1, Math.round(2 * ratio));
		const half = side >> 1;
		for (const set of sets) {
			const xy = set.xy;
			const rgb = colors.of(set.label).rgb;
			if (xy.length < 2 || !rgb) continue;
			const word = packRgb(rgb);
			for (let i = 0; i + 1 < xy.length; i += 2) {
				const x = Math.round(ox - xy[i + 1] * scale) - half;
				const y = Math.round(oy - xy[i] * scale) - half;
				if (x >= width || y >= height || x + side <= 0 || y + side <= 0) continue;
				const x0 = Math.max(0, x);
				const x1 = Math.min(width, x + side);
				const y1 = Math.min(height, y + side);
				for (let row = Math.max(0, y); row < y1; row++) words.fill(word, row * width + x0, row * width + x1);
			}
		}
		pointsContext.putImageData(image, 0, 0);
		context.setTransform(1, 0, 0, 1, 0, 0);
		context.drawImage(canvas, left, top);
		context.setTransform(ratio, 0, 0, ratio, 0, 0);
	}
	pointPixels(width, height) {
		const held = this.points;
		if (held && held.image.width === width && held.image.height === height) return held;
		const canvas = held?.canvas ?? this.createCanvas();
		canvas.width = width;
		canvas.height = height;
		const context = canvas.getContext("2d", { willReadFrequently: true });
		if (!context || width === 0 || height === 0) return null;
		const image = context.createImageData(width, height);
		this.points = {
			canvas,
			context,
			image,
			words: new Uint32Array(image.data.buffer)
		};
		return this.points;
	}
	drawObjects(context, view, frame, colors, hover) {
		const objects = frame.objects;
		if (!objects?.length) return;
		const labels = this.labels;
		labels.length = 0;
		for (const object of objects) if (!labels.includes(object.label)) labels.push(object.label);
		context.lineJoin = "round";
		context.lineCap = "round";
		for (const label of labels) {
			const look = colors.of(label);
			context.beginPath();
			for (const object of objects) if (object.label === label) this.addBox(context, view, object);
			context.fillStyle = look.color;
			context.globalAlpha = OBJECT_FILL_ALPHA;
			context.fill();
			context.globalAlpha = 1;
			context.strokeStyle = look.color;
			context.lineWidth = look.width;
			context.setLineDash(dashOf(look.style));
			context.stroke();
			context.setLineDash(SOLID);
			context.beginPath();
			for (const object of objects) if (object.label === label) this.addHeading(context, view, object);
			context.stroke();
		}
		const hovered = objects[hover];
		if (hovered) {
			const look = colors.of(hovered.label);
			context.beginPath();
			this.addBox(context, view, hovered);
			context.strokeStyle = look.color;
			context.lineWidth = look.width + HOVER_EXTRA;
			context.setLineDash(SOLID);
			context.stroke();
		}
	}
	addBox(context, view, object) {
		const c = objectCorners(object, this.corners);
		for (let k = 0; k < 4; k++) {
			const at = toScreen(view, c[2 * k], c[2 * k + 1], this.point);
			if (k === 0) context.moveTo(at.x, at.y);
			else context.lineTo(at.x, at.y);
		}
		context.closePath();
	}
	addHeading(context, view, object) {
		const c = objectCorners(object, this.corners);
		const center = toScreen(view, object.x, object.y, this.point);
		context.moveTo(center.x, center.y);
		const front = toScreen(view, (c[0] + c[2]) / 2, (c[1] + c[3]) / 2, this.other);
		context.lineTo(front.x, front.y);
	}
	drawEgo(context, view, theme) {
		const at = toScreen(view, 0, 0, this.point);
		context.beginPath();
		context.moveTo(at.x, at.y - MARKER_TIP);
		context.lineTo(at.x - MARKER_BASE, at.y + MARKER_BASE);
		context.lineTo(at.x + MARKER_BASE, at.y + MARKER_BASE);
		context.closePath();
		context.fillStyle = theme.vehicle;
		context.strokeStyle = theme.halo;
		context.lineWidth = 1.5;
		context.setLineDash(SOLID);
		context.fill();
		context.stroke();
	}
};
function signedArea(xy) {
	let sum = 0;
	for (let i = 0, j = xy.length - 2; i + 1 < xy.length; j = i, i += 2) sum += xy[j] * xy[i + 1] - xy[i] * xy[j + 1];
	return sum;
}
function forEachStaticLabel(inputs, visit) {
	for (const layer of [inputs.background, inputs.foreground]) {
		if (!layer) continue;
		for (const line of layer.lines ?? []) visit(line.label);
		for (const set of layer.points ?? []) visit(set.label);
	}
}
function sameRgb(a, b) {
	return a === b || a !== null && b !== null && a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
}
function sameView(a, b) {
	return b !== null && a.cx === b.cx && a.cy === b.cy && a.ppm === b.ppm && a.k === b.k && a.tx === b.tx && a.ty === b.ty;
}
const GAP = 12;
function readoutPlace(x, y, width, height, boxWidth, boxHeight) {
	let left = x + GAP;
	if (left + width > boxWidth) left = x - GAP - width;
	const top = Math.min(Math.max(0, y - GAP - height / 2), Math.max(0, boxHeight - height));
	return {
		left: Math.max(0, left),
		top
	};
}
function distanceText(object) {
	return metersText(Math.hypot(object.x, object.y));
}
var BevReadout = class {
	box;
	name;
	distance;
	text;
	shown = false;
	lines = {
		name: "",
		distance: "",
		text: ""
	};
	constructor(box, name, distance, text) {
		this.box = box;
		this.name = name;
		this.distance = distance;
		this.text = text;
	}
	show(object, x, y, width, height) {
		this.write("name", this.name, object.label);
		this.write("distance", this.distance, distanceText(object));
		this.write("text", this.text, object.text ?? "");
		this.text.hidden = !object.text;
		if (!this.shown) {
			this.shown = true;
			this.box.hidden = false;
		}
		const { left, top } = readoutPlace(x, y, this.box.offsetWidth, this.box.offsetHeight, width, height);
		this.box.style.transform = `translate(${left}px, ${top}px)`;
	}
	hide() {
		if (!this.shown) return;
		this.shown = false;
		this.box.hidden = true;
	}
	write(line, element, value) {
		if (this.lines[line] === value) return;
		this.lines[line] = value;
		element.textContent = value;
	}
};
const SUMMARY_MS = 1e3;
function summaryText(objects, plot) {
	const counts = /* @__PURE__ */ new Map();
	for (const object of objects ?? []) {
		if (!onPlot(plot, object.x, object.y)) continue;
		counts.set(object.label, (counts.get(object.label) ?? 0) + 1);
	}
	const where = plotText(plot);
	if (counts.size === 0) return `Nothing ${where}`;
	return `${[...counts].map(([label, count]) => `${count} ${label}`).join(", ")} ${where}`;
}
function plotText(plot) {
	const { back, front, right, left } = plot;
	if (plot.shape === "round") return `within ${metersText(plot.range)}`;
	if (front === -back && left === -right && front === left) return `within ${metersText(front)}`;
	return `${span(back, front, "behind", "ahead")}, ${side(right, left)}`;
}
function span(low, high, below, above) {
	const m = (value) => metersText(Math.abs(value));
	if (low < 0 && high > 0) return `from ${m(low)} ${below} to ${m(high)} ${above}`;
	if (low >= 0) return `from ${m(low)} to ${m(high)} ${above}`;
	return `from ${m(high)} to ${m(low)} ${below}`;
}
function side(right, left) {
	if (right < 0 && left === -right) return `${metersText(left)} either side`;
	return span(right, left, "right", "left");
}
const ANIMATION_MS = 250;
const PAN_STEP = 48;
const ZOOM_STEP = 1.25;
const CLICK_DISTANCE = 3;
const REDUCED_MOTION = "(prefers-reduced-motion: reduce)";
const PAN_KEYS = {
	ArrowLeft: [PAN_STEP, 0],
	ArrowRight: [-48, 0],
	ArrowUp: [0, PAN_STEP],
	ArrowDown: [0, -48]
};
const ZOOM_KEYS = {
	"+": ZOOM_STEP,
	"=": ZOOM_STEP,
	"-": 1 / ZOOM_STEP
};
const easeInOut = (t) => t < .5 ? 4 * t ** 3 : 1 - (-2 * t + 2) ** 3 / 2;
function isDefault({ k, x, y }) {
	return k === 1 && Math.abs(x) < .5 && Math.abs(y) < .5;
}
var BevZoom = class {
	box;
	onChange;
	behavior;
	selection;
	motion = typeof matchMedia === "function" ? matchMedia(REDUCED_MOTION) : null;
	size = null;
	limits = ZOOM_EXTENT;
	animation = null;
	constructor(box, onChange) {
		this.box = box;
		this.onChange = onChange;
		this.behavior = zoom().scaleExtent([...this.limits]).clickDistance(CLICK_DISTANCE).extent(() => this.extentOf()).translateExtent([[-Infinity, -Infinity], [Infinity, Infinity]]).on("zoom", (event) => {
			if (event.sourceEvent) this.stopAnimation();
			this.onChange(event.transform);
		});
		this.syncDuration();
		this.motion?.addEventListener("change", this.syncDuration);
		this.selection = select(box).call(this.behavior);
		box.addEventListener("keydown", this.keydown);
		box.addEventListener("wheel", this.wheel, { passive: false });
	}
	get transform() {
		return zoomTransform(this.box);
	}
	setBounds(width, height, [[x0, y0], [x1, y1]]) {
		this.size = [width, height];
		this.behavior.translateExtent([[x0, y0], [x1, y1]]);
		const now = this.transform;
		const inside = this.constrained(now);
		if (inside.k !== now.k || inside.x !== now.x || inside.y !== now.y) this.jump(inside);
	}
	setScaleExtent(min, max) {
		if (min === this.limits[0] && max === this.limits[1]) return;
		this.limits = [min, max];
		this.behavior.scaleExtent([min, max]);
		const now = this.transform;
		const k = Math.min(Math.max(now.k, min), max);
		if (k !== now.k) this.jump(this.constrained(this.scaledAboutCenter(now, k / now.k)));
	}
	reset() {
		this.animate(zoomIdentity);
	}
	destroy() {
		this.stopAnimation();
		this.box.removeEventListener("keydown", this.keydown);
		this.box.removeEventListener("wheel", this.wheel);
		this.motion?.removeEventListener("change", this.syncDuration);
		this.selection.on(".zoom", null);
		this.box.style.removeProperty("-webkit-tap-highlight-color");
	}
	extentOf() {
		const [width, height] = this.size ?? [this.box.clientWidth, this.box.clientHeight];
		return [[0, 0], [width, height]];
	}
	translateExtent() {
		return this.behavior.translateExtent();
	}
	jump(to) {
		this.behavior.transform(this.selection, to);
	}
	animate(to) {
		this.stopAnimation();
		if (this.motion?.matches) return this.jump(to);
		const from = this.transform;
		const start = performance.now();
		const step = () => {
			const t = Math.min((performance.now() - start) / ANIMATION_MS, 1);
			if (t === 1) {
				this.animation = null;
				return this.jump(to);
			}
			const e = easeInOut(t);
			const at = (a, b) => a + (b - a) * e;
			this.jump(zoomIdentity.translate(at(from.x, to.x), at(from.y, to.y)).scale(at(from.k, to.k)));
			this.animation = {
				to,
				frame: requestAnimationFrame(step)
			};
		};
		this.animation = {
			to,
			frame: requestAnimationFrame(step)
		};
	}
	stopAnimation() {
		if (this.animation) cancelAnimationFrame(this.animation.frame);
		this.animation = null;
	}
	wheel = (event) => {
		event.preventDefault();
	};
	syncDuration = () => {
		this.behavior.duration(this.motion?.matches ? 0 : ANIMATION_MS);
	};
	keydown = (event) => {
		if (event.target !== this.box || event.ctrlKey || event.metaKey || event.altKey) return;
		const pan = PAN_KEYS[event.key];
		const by = ZOOM_KEYS[event.key];
		if (pan) {
			this.stopAnimation();
			const { k, x, y } = this.transform;
			this.jump(this.constrained(zoomIdentity.translate(x + pan[0], y + pan[1]).scale(k)));
		} else if (by) {
			const from = this.animation?.to ?? this.transform;
			this.animate(this.constrained(this.scaledAboutCenter(from, by)));
		} else if (event.key === "0") this.reset();
		else return;
		event.preventDefault();
	};
	constrained(transform) {
		return this.behavior.constrain()(transform, this.extentOf(), this.translateExtent());
	}
	scaledAboutCenter(from, by) {
		const k = Math.min(Math.max(from.k * by, this.limits[0]), this.limits[1]);
		const [[x0, y0], [x1, y1]] = this.extentOf();
		const center = [(x0 + x1) / 2, (y0 + y1) / 2];
		const [px, py] = from.invert(center);
		return zoomIdentity.translate(center[0] - px * k, center[1] - py * k).scale(k);
	}
};
const HIT_TOLERANCE_PX = 4;
const TOKENS = {
	text: "--muted-foreground",
	vehicle: "--foreground",
	halo: "--neat-surface"
};
var NeatBev = class NeatBev {
	frame = input(null, ...ngDevMode ? [{ debugName: "frame" }] : /* istanbul ignore next */ []);
	background = input(null, ...ngDevMode ? [{ debugName: "background" }] : /* istanbul ignore next */ []);
	foreground = input(null, ...ngDevMode ? [{ debugName: "foreground" }] : /* istanbul ignore next */ []);
	spokes = input(12, ...ngDevMode ? [{ debugName: "spokes" }] : /* istanbul ignore next */ []);
	range = input(60, ...ngDevMode ? [{ debugName: "range" }] : /* istanbul ignore next */ []);
	shape = input("round", ...ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []);
	bounds = input(null, ...ngDevMode ? [{ debugName: "bounds" }] : /* istanbul ignore next */ []);
	outline = input(true, {
		...ngDevMode ? { debugName: "outline" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	overflow = input("clip", ...ngDevMode ? [{ debugName: "overflow" }] : /* istanbul ignore next */ []);
	guides = input("over", ...ngDevMode ? [{ debugName: "guides" }] : /* istanbul ignore next */ []);
	zoom = input(false, {
		...ngDevMode ? { debugName: "zoom" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	panBounds = input(null, ...ngDevMode ? [{ debugName: "panBounds" }] : /* istanbul ignore next */ []);
	zoomExtent = input(ZOOM_EXTENT, ...ngDevMode ? [{ debugName: "zoomExtent" }] : /* istanbul ignore next */ []);
	hovered = model(null, ...ngDevMode ? [{ debugName: "hovered" }] : /* istanbul ignore next */ []);
	activated = output();
	pointerMove = output();
	styles = input([], ...ngDevMode ? [{ debugName: "styles" }] : /* istanbul ignore next */ []);
	label = input("Bird's-eye view", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef).nativeElement;
	document = inject(DOCUMENT);
	zone = inject(NgZone);
	canvasElement = viewChild.required("canvas", ...ngDevMode ? [{ debugName: "canvasElement" }] : /* istanbul ignore next */ []);
	colors = new LabelColors(inject(ɵNeatOverlayColors));
	themeColors = neatThemeColors(TOKENS, () => this.host);
	scheme = inject(ThemeService).scheme;
	theme = computed(() => {
		const colors = this.themeColors();
		const style = getComputedStyle(this.host);
		const fallback = style.color;
		const css = (rgb, alpha = 1) => rgb ? cssColor(rgb, alpha) : fallback;
		return {
			line: css(colors.vehicle, GUIDE_ALPHA),
			strong: css(colors.vehicle, OUTLINE_ALPHA),
			text: css(colors.text),
			vehicle: css(colors.vehicle),
			halo: css(colors.halo),
			surface: colors.halo,
			font: `${style.fontSize} ${style.fontFamily}`
		};
	}, ...ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []);
	inputs = computed(() => ({
		plot: bevPlot(this.shape(), this.range(), this.bounds()),
		background: this.background(),
		foreground: this.foreground(),
		spokes: spokeList(this.spokes()),
		outline: this.outline(),
		overflow: this.overflow(),
		guides: this.guides()
	}), ...ngDevMode ? [{ debugName: "inputs" }] : /* istanbul ignore next */ []);
	aspect = computed(() => `${plotAspect(this.inputs().plot)} / 1`, ...ngDevMode ? [{ debugName: "aspect" }] : /* istanbul ignore next */ []);
	readoutClasses = ɵREADOUT_CLASSES;
	readoutBox = viewChild.required("readout", ...ngDevMode ? [{ debugName: "readoutBox" }] : /* istanbul ignore next */ []);
	readoutColor = signal("", ...ngDevMode ? [{ debugName: "readoutColor" }] : /* istanbul ignore next */ []);
	readoutName = viewChild.required("name", ...ngDevMode ? [{ debugName: "readoutName" }] : /* istanbul ignore next */ []);
	readoutDistance = viewChild.required("distance", ...ngDevMode ? [{ debugName: "readoutDistance" }] : /* istanbul ignore next */ []);
	readoutText = viewChild.required("text", ...ngDevMode ? [{ debugName: "readoutText" }] : /* istanbul ignore next */ []);
	summaryElement = viewChild.required("summary", ...ngDevMode ? [{ debugName: "summaryElement" }] : /* istanbul ignore next */ []);
	zoomed = signal(false, ...ngDevMode ? [{ debugName: "zoomed" }] : /* istanbul ignore next */ []);
	canvas = null;
	readout = null;
	pointer = null;
	hovering = false;
	released = false;
	reported = null;
	drawn = null;
	pressedBy = "";
	summary = "";
	summaryOf = null;
	summaryAt = -Infinity;
	summaryTimer;
	vehiclePoint = {
		x: 0,
		y: 0
	};
	screenPoint = {
		x: 0,
		y: 0
	};
	zoomer = null;
	rendered = false;
	transform = zoomIdentity;
	bounded = null;
	stylesGiven = null;
	width = 0;
	height = 0;
	request = 0;
	destroyed = false;
	constructor() {
		effect(() => {
			const styles = this.styles();
			this.frame();
			this.inputs();
			this.hovered();
			this.panBounds();
			this.zoomExtent();
			this.scheme();
			untracked(() => {
				if (styles !== this.stylesGiven) this.colors.setStyles(this.stylesGiven = styles);
				this.schedule();
			});
		});
		effect(() => {
			const on = this.zoom();
			untracked(() => this.syncZoom(on));
		});
		let observer = null;
		afterNextRender(() => this.zone.runOutsideAngular(() => {
			if (this.destroyed) return;
			this.canvas = new BevCanvas(this.canvasElement().nativeElement);
			this.readout = new BevReadout(this.readoutBox().nativeElement, this.readoutName().nativeElement, this.readoutDistance().nativeElement, this.readoutText().nativeElement);
			this.host.addEventListener("pointermove", this.moved);
			this.host.addEventListener("pointerleave", this.left);
			this.host.addEventListener("pointerdown", this.pointerDown);
			this.host.addEventListener("click", this.click);
			this.host.addEventListener("keydown", this.escape);
			this.rendered = true;
			this.syncZoom(untracked(this.zoom));
			observer = new ResizeObserver((entries) => {
				const box = entries.at(-1)?.borderBoxSize?.[0];
				if (!box) return;
				this.width = box.inlineSize;
				this.height = box.blockSize;
				this.canvas?.size(this.width, this.height);
				this.drawNow();
			});
			observer.observe(this.host);
			this.document.addEventListener("visibilitychange", this.visibility);
			this.schedule();
		}));
		inject(DestroyRef).onDestroy(() => {
			this.destroyed = true;
			if (this.request !== 0) cancelAnimationFrame(this.request);
			this.request = 0;
			observer?.disconnect();
			this.zoomer?.destroy();
			clearTimeout(this.summaryTimer);
			this.host.removeEventListener("pointermove", this.moved);
			this.host.removeEventListener("pointerleave", this.left);
			this.host.removeEventListener("pointerdown", this.pointerDown);
			this.host.removeEventListener("click", this.click);
			this.host.removeEventListener("keydown", this.escape);
			this.document.removeEventListener("visibilitychange", this.visibility);
		});
	}
	colorOf(label) {
		return this.colors.heldColorOf(label, this.styles());
	}
	reset() {
		this.zoomer?.reset();
		this.host.focus();
	}
	syncZoom(on) {
		if (!this.rendered || this.destroyed || on === (this.zoomer !== null)) return;
		if (on) this.zoomer = this.zone.runOutsideAngular(() => new BevZoom(this.host, (transform) => {
			this.transform = transform;
			this.zoomed.set(!isDefault(transform));
			this.schedule();
		}));
		else {
			this.zoomer?.destroy();
			this.zoomer = null;
			this.transform = zoomIdentity;
			this.zoomed.set(false);
		}
		this.bounded = null;
		this.schedule();
	}
	schedule() {
		if (this.request !== 0 || this.destroyed || !this.canvas || this.document.hidden) return;
		this.request = this.zone.runOutsideAngular(() => requestAnimationFrame(this.tick));
	}
	drawNow() {
		if (this.request !== 0) cancelAnimationFrame(this.request);
		this.request = 0;
		if (this.destroyed || !this.canvas || this.document.hidden) return;
		this.tick();
	}
	pointOf(event) {
		const rect = this.host.getBoundingClientRect();
		return {
			x: event.clientX - rect.left,
			y: event.clientY - rect.top
		};
	}
	moved = (event) => {
		if (event.pointerType === "touch") return;
		this.pointer = this.pointOf(event);
		this.hovering = true;
		this.schedule();
	};
	left = (event) => {
		if (event.pointerType === "touch") return;
		this.release();
	};
	release() {
		this.pointer = null;
		this.hovering = false;
		this.released = true;
		this.schedule();
	}
	pointerDown = (event) => {
		this.pressedBy = event.pointerType;
	};
	click = (event) => {
		if (event.target instanceof Element && event.target.closest("button")) return;
		const at = this.pointOf(event);
		if (this.pressedBy === "touch") {
			this.pointer = at;
			this.hovering = false;
			this.schedule();
		}
		const drawn = this.drawn;
		if (!drawn || !(drawn.view.ppm > 0)) return;
		const point = toVehicle(drawn.view, at.x, at.y, {
			x: 0,
			y: 0
		});
		const index = this.hitAt(drawn.view, drawn.inputs, drawn.frame, at);
		const object = index >= 0 ? drawn.frame?.objects?.[index] ?? null : null;
		const id = object ? object.id ?? index : null;
		this.zone.run(() => this.activated.emit({
			object,
			id,
			x: point.x,
			y: point.y,
			event
		}));
	};
	escape = (event) => {
		if (event.key !== "Escape" || this.pointer === null) return;
		this.release();
	};
	visibility = () => {
		if (!this.document.hidden) this.schedule();
	};
	tick = () => {
		this.request = 0;
		if (this.destroyed || !this.canvas || this.width <= 0 || this.height <= 0) return;
		const ratio = typeof devicePixelRatio === "number" && devicePixelRatio > 0 ? devicePixelRatio : 1;
		const inputs = untracked(this.inputs);
		const { plot } = inputs;
		const start = defaultView(this.width, this.height, plot);
		if (this.zoomer) {
			const [min, max] = zoomLimits(untracked(this.zoomExtent));
			this.zoomer.setScaleExtent(min, max);
			const extra = untracked(this.panBounds);
			const pan = panArea(start, plot, inputs.overflow, this.width, this.height, extra);
			if (!sameBounds(this.bounded, this.width, this.height, pan)) {
				this.bounded = {
					width: this.width,
					height: this.height,
					pan
				};
				this.zoomer.setBounds(this.width, this.height, pan);
			}
		}
		const { k, x, y } = this.transform;
		const view = {
			...start,
			k,
			tx: x,
			ty: y
		};
		const frame = untracked(this.frame);
		this.drawn = {
			view,
			inputs,
			frame
		};
		const hover = this.hover(view, inputs, frame);
		this.report(view);
		this.colors.begin(performance.now());
		this.canvas.draw(ratio, view, inputs, untracked(this.theme), this.colors, frame, hover);
		this.summarize(frame, plot);
		const object = hover >= 0 ? frame?.objects?.[hover] : void 0;
		if (object) {
			const at = toScreen(view, object.x, object.y, this.screenPoint);
			const color = this.colors.of(object.label).color;
			this.readoutColor.set(color);
			this.readout?.show(object, at.x, at.y, this.width, this.height);
		} else this.readout?.hide();
	};
	summarize(frame, plot) {
		if (this.summaryOf?.frame === frame && this.summaryOf.plot === plot) return;
		if (this.summaryTimer !== void 0) return;
		const wait = this.summaryAt + SUMMARY_MS - performance.now();
		if (wait > 0) {
			this.summaryTimer = setTimeout(() => {
				this.summaryTimer = void 0;
				if (!this.destroyed) this.summarize(untracked(this.frame), untracked(this.inputs).plot);
			}, wait);
			return;
		}
		this.summaryOf = {
			frame,
			plot
		};
		this.summaryAt = performance.now();
		const text = summaryText(frame?.objects, plot);
		if (text === this.summary) return;
		this.summary = text;
		this.summaryElement().nativeElement.textContent = text;
	}
	hover(view, inputs, frame) {
		const objects = frame?.objects ?? [];
		if (this.pointer) {
			const index = this.hitAt(view, inputs, frame, this.pointer);
			const id = index >= 0 ? objects[index].id ?? index : null;
			this.setHovered(id);
			return index;
		}
		if (this.released) {
			this.released = false;
			this.setHovered(null);
		}
		const index = indexOf(objects, untracked(this.hovered));
		const object = objects[index];
		if (!object || inputs.overflow === "clip" && !onPlot(inputs.plot, object.x, object.y)) return -1;
		return index;
	}
	setHovered(id) {
		if (untracked(this.hovered) === id) return;
		this.zone.run(() => this.hovered.set(id));
	}
	report(view) {
		const pointer = this.hovering ? this.pointer : null;
		let point = null;
		if (pointer && view.ppm > 0) {
			const { x, y } = toVehicle(view, pointer.x, pointer.y, this.vehiclePoint);
			point = {
				x,
				y
			};
		}
		const last = this.reported;
		if (point === last || point && last && point.x === last.x && point.y === last.y) return;
		this.reported = point;
		this.zone.run(() => this.pointerMove.emit(point));
	}
	hitAt(view, inputs, frame, pointer) {
		const objects = frame?.objects;
		if (!objects?.length || !(view.ppm > 0)) return -1;
		const at = toVehicle(view, pointer.x, pointer.y, this.vehiclePoint);
		if (inputs.overflow === "clip" && !onPlot(inputs.plot, at.x, at.y)) return -1;
		return hitObject(objects, at.x, at.y, HIT_TOLERANCE_PX / (view.ppm * view.k));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatBev,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatBev,
		isStandalone: true,
		selector: "neat-bev",
		inputs: {
			frame: {
				classPropertyName: "frame",
				publicName: "frame",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			background: {
				classPropertyName: "background",
				publicName: "background",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			foreground: {
				classPropertyName: "foreground",
				publicName: "foreground",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			spokes: {
				classPropertyName: "spokes",
				publicName: "spokes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			range: {
				classPropertyName: "range",
				publicName: "range",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shape: {
				classPropertyName: "shape",
				publicName: "shape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bounds: {
				classPropertyName: "bounds",
				publicName: "bounds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			outline: {
				classPropertyName: "outline",
				publicName: "outline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overflow: {
				classPropertyName: "overflow",
				publicName: "overflow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			guides: {
				classPropertyName: "guides",
				publicName: "guides",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoom: {
				classPropertyName: "zoom",
				publicName: "zoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			panBounds: {
				classPropertyName: "panBounds",
				publicName: "panBounds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoomExtent: {
				classPropertyName: "zoomExtent",
				publicName: "zoomExtent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hovered: {
				classPropertyName: "hovered",
				publicName: "hovered",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			styles: {
				classPropertyName: "styles",
				publicName: "styles",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			hovered: "hoveredChange",
			activated: "activated",
			pointerMove: "pointerMove"
		},
		host: {
			attributes: { "role": "figure" },
			properties: {
				"attr.aria-label": "label()",
				"attr.tabindex": "zoom() ? 0 : null",
				"style.aspect-ratio": "aspect()"
			}
		},
		viewQueries: [
			{
				propertyName: "canvasElement",
				first: true,
				predicate: ["canvas"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "readoutBox",
				first: true,
				predicate: ["readout"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "readoutName",
				first: true,
				predicate: ["name"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "readoutDistance",
				first: true,
				predicate: ["distance"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "readoutText",
				first: true,
				predicate: ["text"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "summaryElement",
				first: true,
				predicate: ["summary"],
				descendants: true,
				isSignal: true
			}
		],
		ngImport: i0,
		template: `
    <canvas #canvas aria-hidden="true"></canvas>
    <!-- What the picture shows, for a screen reader: written by the frames, at most once a second. -->
    <p #summary class="sr-only"></p>
    @if (zoomed()) {
      <!-- Pressed, it resets: its press is no drag of the view, nor its double-click a zoom. -->
      <button
        neatButton
        class="reset"
        variant="outlined"
        size="small"
        iconOnly
        type="button"
        aria-label="Reset view"
        neatTooltip="Reset view"
        neatTooltipPosition="left"
        (click)="reset()"
        (mousedown)="$event.stopPropagation()"
        (touchstart)="$event.stopPropagation()"
        (dblclick)="$event.stopPropagation()"
      >
        <neat-icon name="fit-all" [size]="16" />
      </button>
    }
    <!-- The object under the pointer; filled and placed by each frame, not by change detection. -->
    <div #readout class="readout" aria-hidden="true" hidden [class]="readoutClasses.box">
      <span [class]="readoutClasses.row"
        ><neat-swatch [color]="readoutColor()" /><span #name></span
      ></span>
      <span #distance [class]="readoutClasses.muted"></span>
      <span #text></span>
    </div>
  `,
		isInline: true,
		styles: [":host{display:block;position:relative;width:100%;aspect-ratio:1;min-width:0;min-height:0;font-size:var(--neat-text-xs)}canvas{position:absolute;inset:0;display:block;width:100%;height:100%}:host(:focus-visible){outline:2px solid var(--ring);outline-offset:2px}.reset{position:absolute;top:var(--neat-space-2);right:var(--neat-space-2)}.readout{position:absolute;top:0;left:0}.readout[hidden]{display:none}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatSwatch,
				selector: "neat-swatch",
				inputs: ["color"]
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatBev,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-bev",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				NeatButton,
				NeatIcon,
				NeatSwatch,
				NeatTooltip
			],
			host: {
				role: "figure",
				"[attr.aria-label]": "label()",
				"[attr.tabindex]": "zoom() ? 0 : null",
				"[style.aspect-ratio]": "aspect()"
			},
			template: `
    <canvas #canvas aria-hidden="true"></canvas>
    <!-- What the picture shows, for a screen reader: written by the frames, at most once a second. -->
    <p #summary class="sr-only"></p>
    @if (zoomed()) {
      <!-- Pressed, it resets: its press is no drag of the view, nor its double-click a zoom. -->
      <button
        neatButton
        class="reset"
        variant="outlined"
        size="small"
        iconOnly
        type="button"
        aria-label="Reset view"
        neatTooltip="Reset view"
        neatTooltipPosition="left"
        (click)="reset()"
        (mousedown)="$event.stopPropagation()"
        (touchstart)="$event.stopPropagation()"
        (dblclick)="$event.stopPropagation()"
      >
        <neat-icon name="fit-all" [size]="16" />
      </button>
    }
    <!-- The object under the pointer; filled and placed by each frame, not by change detection. -->
    <div #readout class="readout" aria-hidden="true" hidden [class]="readoutClasses.box">
      <span [class]="readoutClasses.row"
        ><neat-swatch [color]="readoutColor()" /><span #name></span
      ></span>
      <span #distance [class]="readoutClasses.muted"></span>
      <span #text></span>
    </div>
  `,
			styles: [":host{display:block;position:relative;width:100%;aspect-ratio:1;min-width:0;min-height:0;font-size:var(--neat-text-xs)}canvas{position:absolute;inset:0;display:block;width:100%;height:100%}:host(:focus-visible){outline:2px solid var(--ring);outline-offset:2px}.reset{position:absolute;top:var(--neat-space-2);right:var(--neat-space-2)}.readout{position:absolute;top:0;left:0}.readout[hidden]{display:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		frame: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "frame",
				required: false
			}]
		}],
		background: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "background",
				required: false
			}]
		}],
		foreground: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "foreground",
				required: false
			}]
		}],
		spokes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "spokes",
				required: false
			}]
		}],
		range: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "range",
				required: false
			}]
		}],
		shape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shape",
				required: false
			}]
		}],
		bounds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bounds",
				required: false
			}]
		}],
		outline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "outline",
				required: false
			}]
		}],
		overflow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overflow",
				required: false
			}]
		}],
		guides: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "guides",
				required: false
			}]
		}],
		zoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoom",
				required: false
			}]
		}],
		panBounds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panBounds",
				required: false
			}]
		}],
		zoomExtent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoomExtent",
				required: false
			}]
		}],
		hovered: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hovered",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["hoveredChange"]
		}],
		activated: [{
			type: i0.Output,
			args: ["activated"]
		}],
		pointerMove: [{
			type: i0.Output,
			args: ["pointerMove"]
		}],
		styles: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "styles",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		canvasElement: [{
			type: i0.ViewChild,
			args: ["canvas", { isSignal: true }]
		}],
		readoutBox: [{
			type: i0.ViewChild,
			args: ["readout", { isSignal: true }]
		}],
		readoutName: [{
			type: i0.ViewChild,
			args: ["name", { isSignal: true }]
		}],
		readoutDistance: [{
			type: i0.ViewChild,
			args: ["distance", { isSignal: true }]
		}],
		readoutText: [{
			type: i0.ViewChild,
			args: ["text", { isSignal: true }]
		}],
		summaryElement: [{
			type: i0.ViewChild,
			args: ["summary", { isSignal: true }]
		}]
	}
});
function indexOf(objects, id) {
	if (id === null) return -1;
	const byId = objects.findIndex((object) => object.id === id);
	if (byId >= 0) return byId;
	return typeof id === "number" && objects[id]?.id === void 0 && id in objects ? id : -1;
}
function sameBounds(given, width, height, [[x0, y0], [x1, y1]]) {
	if (!given || given.width !== width || given.height !== height) return false;
	const [[a0, b0], [a1, b1]] = given.pan;
	return a0 === x0 && b0 === y0 && a1 === x1 && b1 === y1;
}
function cssColor([red, green, blue], alpha = 1) {
	const rgb = `${Math.round(red * 255)} ${Math.round(green * 255)} ${Math.round(blue * 255)}`;
	return alpha === 1 ? `rgb(${rgb})` : `rgb(${rgb} / ${alpha})`;
}
export { NeatBev };

//# sourceMappingURL=sima-neat-ui-bev.mjs.map