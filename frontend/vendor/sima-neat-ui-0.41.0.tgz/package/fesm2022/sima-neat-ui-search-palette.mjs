import { Dialog } from "@angular/cdk/dialog";
import { Overlay } from "@angular/cdk/overlay";
import { LocationStrategy } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, booleanAttribute, computed, effect, inject, input, linkedSignal, model, output, signal, untracked, viewChild } from "@angular/core";
import { Router } from "@angular/router";
import { NeatIcon, NeatSearch, NeatShortcut, NeatViewport, ɵPANEL_SURFACE_CLASSES, ɵhlm } from "@sima/neat-ui";
const LABELS = {
	empty: "Type to search.",
	noMatches: "Nothing matches",
	matches: (count) => count === 1 ? "1 result" : `${count} results`,
	allResults: "See all results",
	keys: "↑↓ to move · Enter to open · Esc to close"
};
const BACKDROP_HELM_CLASSES = "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs";
const PANEL_CLASSES = ɵhlm(ɵPANEL_SURFACE_CLASSES, "w-full gap-0 p-0 rounded-xl");
const DEFAULT_LIMIT = 5;
let nextPaletteId = 0;
var NeatSearchPalette = class NeatSearchPalette {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	search = input.required(...ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []);
	allResults = input(...ngDevMode ? [void 0, { debugName: "allResults" }] : /* istanbul ignore next */ []);
	limit = input(DEFAULT_LIMIT, ...ngDevMode ? [{ debugName: "limit" }] : /* istanbul ignore next */ []);
	shortcut = input(true, {
		...ngDevMode ? { debugName: "shortcut" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	labels = input({}, ...ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []);
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	picked = output();
	viewport = inject(NeatViewport);
	dialog = inject(Dialog);
	overlay = inject(Overlay);
	router = inject(Router);
	location = inject(LocationStrategy);
	panel = viewChild.required("panel", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	results = viewChild("results", ...ngDevMode ? [{ debugName: "results" }] : /* istanbul ignore next */ []);
	ref;
	listboxId = `neat-search-palette-${++nextPaletteId}`;
	panelClasses = PANEL_CLASSES;
	text = computed(() => ({
		...LABELS,
		...this.labels()
	}), ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	query = signal("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	shown = computed(() => {
		const query = this.query().trim();
		if (!query) return [];
		let index = 0;
		return this.search()(query).filter((group) => group.items.length).map((group) => ({
			label: group.label,
			rows: group.items.slice(0, this.limit()).map((item) => ({
				item,
				index: index++
			}))
		}));
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	rows = computed(() => this.shown().flatMap((group) => group.rows), ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	active = linkedSignal({
		...ngDevMode ? { debugName: "active" } : /* istanbul ignore next */ {},
		source: this.rows,
		computation: () => 0
	});
	activeId = computed(() => this.rows().length ? this.optionId(this.active()) : null, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	status = computed(() => {
		if (!this.query().trim()) return "";
		const count = this.rows().length;
		return count ? this.text().matches(count) : this.text().noMatches;
	}, ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	allResultsUrl = computed(() => {
		const path = this.allResults();
		const query = this.query().trim();
		if (!path || !query) return null;
		return this.router.serializeUrl(this.router.createUrlTree([path], { queryParams: { q: query } }));
	}, ...ngDevMode ? [{ debugName: "allResultsUrl" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const open = this.open();
			untracked(() => open ? this.show() : this.hide());
		});
		effect(() => {
			const id = this.activeId();
			const box = this.results()?.nativeElement;
			const row = id ? box?.querySelector(`#${CSS.escape(id)}`) : null;
			if (!box || !row) return;
			if (row.offsetTop < box.scrollTop) box.scrollTop = row.offsetTop;
			else if (row.offsetTop + row.offsetHeight > box.scrollTop + box.clientHeight) box.scrollTop = row.offsetTop + row.offsetHeight - box.clientHeight;
		});
		inject(DestroyRef).onDestroy(() => this.hide());
	}
	optionId(index) {
		return `${this.listboxId}-${index}`;
	}
	href(path) {
		return this.location.prepareExternalUrl(path);
	}
	onShortcut(event) {
		if (!this.shortcut() || event.altKey || event.shiftKey) return;
		if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== "k") return;
		event.preventDefault();
		this.open.set(true);
	}
	onKeydown(event) {
		const count = this.rows().length;
		if (event.key === "ArrowDown" || event.key === "ArrowUp") {
			event.preventDefault();
			if (!count) return;
			const step = event.key === "ArrowDown" ? 1 : -1;
			this.active.set((this.active() + step + count) % count);
		} else if (event.key === "Enter") {
			event.preventDefault();
			const row = this.rows()[this.active()];
			const all = this.allResultsUrl();
			if (row) this.go(row.item);
			else if (all) this.goTo(all);
		}
	}
	onClick(event, item) {
		if (opensElsewhere(event)) return;
		event.preventDefault();
		this.go(item);
	}
	onAllResults(event, url) {
		if (opensElsewhere(event)) return;
		event.preventDefault();
		this.goTo(url);
	}
	go(item) {
		this.picked.emit(item);
		this.goTo(item.path);
	}
	goTo(url) {
		this.open.set(false);
		this.router.navigateByUrl(url);
	}
	show() {
		if (this.ref) return;
		this.query.set("");
		const ref = this.dialog.open(this.panel(), {
			ariaLabel: this.label(),
			ariaModal: true,
			hasBackdrop: true,
			backdropClass: BACKDROP_HELM_CLASSES.split(" "),
			positionStrategy: this.overlay.position().global().top("12vh").centerHorizontally(),
			width: "min(40rem, calc(100vw - 2rem))",
			autoFocus: "first-tabbable",
			restoreFocus: true,
			disableClose: true
		});
		this.ref = ref;
		ref.backdropClick.subscribe(() => this.open.set(false));
		ref.keydownEvents.subscribe((event) => {
			if (event.key !== "Escape") return this.onKeydown(event);
			if (event.defaultPrevented) return;
			event.stopPropagation();
			this.open.set(false);
		});
		ref.closed.subscribe(() => {
			if (this.ref === ref) this.ref = void 0;
			this.open.set(false);
		});
	}
	hide() {
		const ref = this.ref;
		this.ref = void 0;
		ref?.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSearchPalette,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSearchPalette,
		isStandalone: true,
		selector: "neat-search-palette",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			search: {
				classPropertyName: "search",
				publicName: "search",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			allResults: {
				classPropertyName: "allResults",
				publicName: "allResults",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			limit: {
				classPropertyName: "limit",
				publicName: "limit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shortcut: {
				classPropertyName: "shortcut",
				publicName: "shortcut",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			open: "openChange",
			picked: "picked"
		},
		host: {
			listeners: { "document:keydown": "onShortcut($event)" },
			properties: { "attr.data-narrow": "viewport.narrow() || null" }
		},
		viewQueries: [{
			propertyName: "panel",
			first: true,
			predicate: ["panel"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "results",
			first: true,
			predicate: ["results"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <button
      #trigger
      type="button"
      class="trigger"
      aria-haspopup="dialog"
      [attr.aria-label]="viewport.narrow() ? label() : null"
      [attr.aria-keyshortcuts]="shortcut() ? 'Control+K Meta+K' : null"
      (click)="open.set(true)"
    >
      <neat-icon name="search" [size]="16" />
      @if (!viewport.narrow()) {
        <span class="label">{{ label() }}</span>
        @if (shortcut()) {
          <neat-shortcut aria-hidden="true" [keys]="['Mod', 'K']" />
        }
      }
    </button>
    <ng-template #panel>
      <div [class]="panelClasses" class="panel">
        <div class="head">
          <neat-search
            variant="underlined"
            size="large"
            [label]="label()"
            [placeholder]="label()"
            [listbox]="listboxId"
            [activeOption]="activeId()"
            [status]="status()"
            [(value)]="query"
          />
        </div>
        <div #results class="results">
          @if (!query().trim()) {
            <p class="note">{{ text().empty }}</p>
          }
          <div role="listbox" [id]="listboxId" [attr.aria-label]="label()">
            @for (group of shown(); track group.label) {
              <div role="group" class="group" [attr.aria-labelledby]="listboxId + '-g' + $index">
                <div class="group-label" [id]="listboxId + '-g' + $index">{{ group.label }}</div>
                @for (row of group.rows; track row.item.id) {
                  <a
                    role="option"
                    class="option"
                    tabindex="-1"
                    [id]="optionId(row.index)"
                    [href]="href(row.item.path)"
                    [attr.aria-selected]="row.index === active()"
                    (pointermove)="active.set(row.index)"
                    (click)="onClick($event, row.item)"
                  >
                    @if (row.item.icon; as icon) {
                      <neat-icon [name]="icon" [size]="16" />
                    }
                    <span class="option-label">{{ row.item.label }}</span>
                    @if (row.item.detail) {
                      <span class="option-detail">{{ row.item.detail }}</span>
                    }
                  </a>
                }
              </div>
            }
          </div>
        </div>
        <div class="foot">
          <span aria-hidden="true">{{ text().keys }}</span>
          @if (allResultsUrl(); as url) {
            <a [href]="href(url)" (click)="onAllResults($event, url)">{{ text().allResults }}</a>
          }
        </div>
      </div>
    </ng-template>
  `,
		isInline: true,
		styles: [":host{display:inline-flex;min-width:0}.trigger{display:inline-flex;align-items:center;gap:var(--neat-space-2);width:16rem;max-width:100%;height:2rem;padding:0 .375rem 0 .75rem;border:1px solid var(--border);border-radius:999px;background:var(--neat-surface, var(--background));color:var(--muted-foreground);font:inherit;font-size:var(--neat-text-sm);cursor:pointer}.trigger:hover{background:var(--accent);color:var(--accent-foreground)}.trigger:focus-visible{outline:2px solid var(--ring);outline-offset:1px}:host([data-narrow]) .trigger{justify-content:center;width:2.25rem;height:2.25rem;padding:0;border-color:transparent;background:transparent;color:var(--foreground)}.label{flex:1;overflow:hidden;text-align:start;text-overflow:ellipsis;white-space:nowrap}.panel{display:flex;flex-direction:column;max-height:min(34rem,80vh);overflow:hidden}.head{padding:var(--neat-space-2) var(--neat-space-4) var(--neat-space-3)}.results{position:relative;flex:1 1 auto;min-height:0;overflow-y:auto;padding:0 var(--neat-space-2) var(--neat-space-2);border-top:1px solid var(--border)}.note{margin:0;padding:var(--neat-space-4) var(--neat-space-2);color:var(--muted-foreground)}.group-label{padding:var(--neat-space-3) var(--neat-space-2) var(--neat-space-2);color:var(--muted-foreground);font-size:var(--neat-text-xs);font-weight:600;letter-spacing:.06em;text-transform:uppercase}.option{display:flex;align-items:center;gap:var(--neat-space-3);min-width:0;padding:var(--neat-space-2);border-radius:calc(var(--radius) - 2px);color:var(--foreground);text-decoration:none;cursor:pointer}.option[aria-selected=true]{background:var(--accent);color:var(--accent-foreground)}.option-label{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.option-detail{flex:0 1 auto;min-width:0;margin-inline-start:auto;overflow:hidden;color:var(--muted-foreground);font-size:var(--neat-text-xs);text-overflow:ellipsis;white-space:nowrap}.foot{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:var(--neat-space-2) var(--neat-space-4);padding:var(--neat-space-2) var(--neat-space-4);border-top:1px solid var(--border);color:var(--muted-foreground);font-size:var(--neat-text-xs)}.foot a{color:inherit;font-weight:500;text-decoration:none}.foot a:hover{text-decoration:underline}.foot a:focus-visible{outline:2px solid var(--ring);outline-offset:2px;border-radius:2px}\n"],
		dependencies: [
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatSearch,
				selector: "neat-search",
				inputs: [
					"label",
					"value",
					"placeholder",
					"variant",
					"size",
					"clearLabel",
					"status",
					"listbox",
					"activeOption"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: NeatShortcut,
				selector: "neat-shortcut",
				inputs: ["keys"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSearchPalette,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-search-palette",
			imports: [
				NeatIcon,
				NeatSearch,
				NeatShortcut
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-narrow]": "viewport.narrow() || null",
				"(document:keydown)": "onShortcut($event)"
			},
			template: `
    <button
      #trigger
      type="button"
      class="trigger"
      aria-haspopup="dialog"
      [attr.aria-label]="viewport.narrow() ? label() : null"
      [attr.aria-keyshortcuts]="shortcut() ? 'Control+K Meta+K' : null"
      (click)="open.set(true)"
    >
      <neat-icon name="search" [size]="16" />
      @if (!viewport.narrow()) {
        <span class="label">{{ label() }}</span>
        @if (shortcut()) {
          <neat-shortcut aria-hidden="true" [keys]="['Mod', 'K']" />
        }
      }
    </button>
    <ng-template #panel>
      <div [class]="panelClasses" class="panel">
        <div class="head">
          <neat-search
            variant="underlined"
            size="large"
            [label]="label()"
            [placeholder]="label()"
            [listbox]="listboxId"
            [activeOption]="activeId()"
            [status]="status()"
            [(value)]="query"
          />
        </div>
        <div #results class="results">
          @if (!query().trim()) {
            <p class="note">{{ text().empty }}</p>
          }
          <div role="listbox" [id]="listboxId" [attr.aria-label]="label()">
            @for (group of shown(); track group.label) {
              <div role="group" class="group" [attr.aria-labelledby]="listboxId + '-g' + $index">
                <div class="group-label" [id]="listboxId + '-g' + $index">{{ group.label }}</div>
                @for (row of group.rows; track row.item.id) {
                  <a
                    role="option"
                    class="option"
                    tabindex="-1"
                    [id]="optionId(row.index)"
                    [href]="href(row.item.path)"
                    [attr.aria-selected]="row.index === active()"
                    (pointermove)="active.set(row.index)"
                    (click)="onClick($event, row.item)"
                  >
                    @if (row.item.icon; as icon) {
                      <neat-icon [name]="icon" [size]="16" />
                    }
                    <span class="option-label">{{ row.item.label }}</span>
                    @if (row.item.detail) {
                      <span class="option-detail">{{ row.item.detail }}</span>
                    }
                  </a>
                }
              </div>
            }
          </div>
        </div>
        <div class="foot">
          <span aria-hidden="true">{{ text().keys }}</span>
          @if (allResultsUrl(); as url) {
            <a [href]="href(url)" (click)="onAllResults($event, url)">{{ text().allResults }}</a>
          }
        </div>
      </div>
    </ng-template>
  `,
			styles: [":host{display:inline-flex;min-width:0}.trigger{display:inline-flex;align-items:center;gap:var(--neat-space-2);width:16rem;max-width:100%;height:2rem;padding:0 .375rem 0 .75rem;border:1px solid var(--border);border-radius:999px;background:var(--neat-surface, var(--background));color:var(--muted-foreground);font:inherit;font-size:var(--neat-text-sm);cursor:pointer}.trigger:hover{background:var(--accent);color:var(--accent-foreground)}.trigger:focus-visible{outline:2px solid var(--ring);outline-offset:1px}:host([data-narrow]) .trigger{justify-content:center;width:2.25rem;height:2.25rem;padding:0;border-color:transparent;background:transparent;color:var(--foreground)}.label{flex:1;overflow:hidden;text-align:start;text-overflow:ellipsis;white-space:nowrap}.panel{display:flex;flex-direction:column;max-height:min(34rem,80vh);overflow:hidden}.head{padding:var(--neat-space-2) var(--neat-space-4) var(--neat-space-3)}.results{position:relative;flex:1 1 auto;min-height:0;overflow-y:auto;padding:0 var(--neat-space-2) var(--neat-space-2);border-top:1px solid var(--border)}.note{margin:0;padding:var(--neat-space-4) var(--neat-space-2);color:var(--muted-foreground)}.group-label{padding:var(--neat-space-3) var(--neat-space-2) var(--neat-space-2);color:var(--muted-foreground);font-size:var(--neat-text-xs);font-weight:600;letter-spacing:.06em;text-transform:uppercase}.option{display:flex;align-items:center;gap:var(--neat-space-3);min-width:0;padding:var(--neat-space-2);border-radius:calc(var(--radius) - 2px);color:var(--foreground);text-decoration:none;cursor:pointer}.option[aria-selected=true]{background:var(--accent);color:var(--accent-foreground)}.option-label{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.option-detail{flex:0 1 auto;min-width:0;margin-inline-start:auto;overflow:hidden;color:var(--muted-foreground);font-size:var(--neat-text-xs);text-overflow:ellipsis;white-space:nowrap}.foot{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:var(--neat-space-2) var(--neat-space-4);padding:var(--neat-space-2) var(--neat-space-4);border-top:1px solid var(--border);color:var(--muted-foreground);font-size:var(--neat-text-xs)}.foot a{color:inherit;font-weight:500;text-decoration:none}.foot a:hover{text-decoration:underline}.foot a:focus-visible{outline:2px solid var(--ring);outline-offset:2px;border-radius:2px}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		search: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "search",
				required: true
			}]
		}],
		allResults: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allResults",
				required: false
			}]
		}],
		limit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "limit",
				required: false
			}]
		}],
		shortcut: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shortcut",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		picked: [{
			type: i0.Output,
			args: ["picked"]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["panel", { isSignal: true }]
		}],
		results: [{
			type: i0.ViewChild,
			args: ["results", { isSignal: true }]
		}]
	}
});
function opensElsewhere(event) {
	return event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey;
}
export { NeatSearchPalette };

//# sourceMappingURL=sima-neat-ui-search-palette.mjs.map