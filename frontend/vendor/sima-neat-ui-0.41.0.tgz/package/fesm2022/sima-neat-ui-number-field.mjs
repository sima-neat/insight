import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, effect, input, output, signal, viewChild } from "@angular/core";
import { NeatIcon, ɵINPUT_CLASSES, ɵINPUT_FRAME_CLASSES, ɵINPUT_IN_FRAME_CLASSES } from "@sima/neat-ui";
const NO_VALUE = "–";
let nextFieldId = 0;
function wholeNumber(text) {
	const typed = text.trim();
	return /^\d+$/.test(typed) ? Number(typed) : NaN;
}
var NeatNumberField = class NeatNumberField {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	accept = input(() => true, ...ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []);
	step = input(null, ...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	min = input(null, ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(null, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	unit = input("", ...ngDevMode ? [{ debugName: "unit" }] : /* istanbul ignore next */ []);
	showLabel = input(true, {
		...ngDevMode ? { debugName: "showLabel" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	commit = output();
	noValue = NO_VALUE;
	fieldClasses = ɵINPUT_CLASSES.small;
	inFrameClasses = ɵINPUT_IN_FRAME_CLASSES;
	frameClasses = ɵINPUT_FRAME_CLASSES;
	inputId = `neat-number-field-${++nextFieldId}`;
	unitId = `${this.inputId}-unit`;
	steps = computed(() => this.step() !== null, ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	framed = computed(() => this.steps() || this.unit() !== "", ...ngDevMode ? [{ debugName: "framed" }] : /* istanbul ignore next */ []);
	floor = computed(() => this.min() ?? 0, ...ngDevMode ? [{ debugName: "floor" }] : /* istanbul ignore next */ []);
	valueText = computed(() => {
		const value = this.value();
		return this.steps() && value !== null && this.unit() ? `${value} ${this.unit()}` : null;
	}, ...ngDevMode ? [{ debugName: "valueText" }] : /* istanbul ignore next */ []);
	draft = signal(null, ...ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []);
	invalid = computed(() => {
		const draft = this.draft();
		return draft !== null && draft.trim() !== "" && !this.takes(wholeNumber(draft));
	}, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	shown = computed(() => {
		const typed = wholeNumber(this.draft() ?? "");
		return this.inBounds(typed) ? typed : this.value();
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	field = viewChild.required("field", ...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			this.value();
			this.draft.set(null);
		});
	}
	focus() {
		const field = this.field().nativeElement;
		field.focus();
		field.select();
	}
	reset() {
		this.showValue(this.field().nativeElement);
	}
	commitFrom(field, force) {
		if (!force && this.draft() === null) return;
		const number = wholeNumber(field.value);
		if (this.takes(number)) this.commitNumber(field, number);
		else this.showValue(field);
	}
	canStep(direction) {
		const from = this.shown();
		return !this.disabled() && from !== null && this.stepped(from, direction) !== from;
	}
	stalled(direction) {
		return !this.disabled() && !this.canStep(direction);
	}
	boxPress(event, field) {
		if (event.target === field) return;
		event.preventDefault();
		if (!event.target.closest(".step")) field.focus();
	}
	arrow(event, direction, field) {
		if (!this.steps()) return;
		event.preventDefault();
		this.stepBy(direction, field);
	}
	stepBy(direction, field) {
		if (!this.canStep(direction)) return;
		const next = this.stepped(this.shown(), direction);
		if (this.takes(next)) this.commitNumber(field, next);
	}
	stepped(from, direction) {
		const next = from + direction * (this.step() ?? 0);
		return Math.min(this.max() ?? Number.POSITIVE_INFINITY, Math.max(this.floor(), next));
	}
	inBounds(number) {
		const max = this.max();
		return Number.isSafeInteger(number) && number >= this.floor() && (max === null || number <= max);
	}
	takes(number) {
		return this.inBounds(number) && this.accept()(number);
	}
	commitNumber(field, number) {
		this.draft.set(null);
		field.value = String(number);
		this.commit.emit(number);
	}
	showValue(field) {
		this.draft.set(null);
		const value = this.value();
		field.value = value === null ? "" : String(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatNumberField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatNumberField,
		isStandalone: true,
		selector: "neat-number-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			unit: {
				classPropertyName: "unit",
				publicName: "unit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showLabel: {
				classPropertyName: "showLabel",
				publicName: "showLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { commit: "commit" },
		viewQueries: [{
			propertyName: "field",
			first: true,
			predicate: ["field"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (showLabel()) {
      <label [for]="inputId">{{ label() }}</label>
    }
    <span
      class="box"
      [class]="framed() ? frameClasses : ''"
      [attr.data-framed]="framed() ? '' : null"
      [attr.data-steps]="steps() ? '' : null"
      (mousedown)="boxPress($event, field)"
    >
      @if (steps()) {
        <button
          type="button"
          class="step"
          tabindex="-1"
          [attr.aria-label]="'Decrease ' + label()"
          [attr.aria-disabled]="stalled(-1) ? 'true' : null"
          [disabled]="disabled()"
          (click)="stepBy(-1, field)"
        >
          <neat-icon name="minus" [size]="16" />
        </button>
      }
      <input
        #field
        data-slot="input"
        inputmode="numeric"
        [id]="inputId"
        [class]="framed() ? inFrameClasses : fieldClasses"
        [attr.aria-label]="label()"
        [attr.role]="steps() ? 'spinbutton' : null"
        [attr.aria-valuenow]="steps() ? value() : null"
        [attr.aria-valuemin]="steps() ? floor() : null"
        [attr.aria-valuemax]="steps() ? max() : null"
        [attr.aria-valuetext]="valueText()"
        [attr.aria-describedby]="unit() && !steps() ? unitId : null"
        [attr.aria-invalid]="invalid() ? 'true' : null"
        [attr.placeholder]="value() === null ? noValue : null"
        [disabled]="disabled()"
        [value]="value()"
        (input)="draft.set(field.value)"
        (keydown.enter)="commitFrom(field, true)"
        (keydown.arrowup)="arrow($event, 1, field)"
        (keydown.arrowdown)="arrow($event, -1, field)"
        (blur)="commitFrom(field, false)"
      />
      @if (unit()) {
        <span class="unit" [id]="unitId">{{ unit() }}</span>
      }
      @if (steps()) {
        <button
          type="button"
          class="step"
          tabindex="-1"
          [attr.aria-label]="'Increase ' + label()"
          [attr.aria-disabled]="stalled(1) ? 'true' : null"
          [disabled]="disabled()"
          (click)="stepBy(1, field)"
        >
          <neat-icon name="plus" [size]="16" />
        </button>
      }
    </span>
    <ng-content select="[neatNumberFieldSuffix]" />
  `,
		isInline: true,
		styles: [":host{display:flex;flex:none;align-items:center;gap:var(--neat-space-2);font-size:var(--neat-text-sm);white-space:nowrap}.box{display:flex;width:3rem}.box[data-framed]{width:auto}.box[data-framed] input{width:2.5rem;padding-inline-start:var(--neat-space-2)}.unit{padding-inline-end:var(--neat-space-2);color:var(--muted-foreground)}.box[data-steps]{min-width:7.5rem}.box[data-steps] input{width:3ch;padding-inline:0;text-align:center}@supports (field-sizing: content){.box[data-steps] input{field-sizing:content;width:auto;min-width:1ch}}.box[data-steps] .unit{padding-inline:.25rem 0}.step{display:inline-flex;flex:none;align-items:center;justify-content:center;width:1.5rem;height:1.5rem;margin-inline:.1875rem;padding:0;border:0;border-radius:calc(var(--radius) - 2px);background:transparent;color:var(--muted-foreground);cursor:pointer}.step:first-child{margin-inline-end:auto}.step:last-child{margin-inline-start:auto}.step:hover:not(:disabled,[aria-disabled=true]){background:var(--accent);color:var(--accent-foreground)}.step[aria-disabled=true]{opacity:.5;cursor:not-allowed}.step:disabled{cursor:inherit}\n"],
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatNumberField,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-number-field",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    @if (showLabel()) {
      <label [for]="inputId">{{ label() }}</label>
    }
    <span
      class="box"
      [class]="framed() ? frameClasses : ''"
      [attr.data-framed]="framed() ? '' : null"
      [attr.data-steps]="steps() ? '' : null"
      (mousedown)="boxPress($event, field)"
    >
      @if (steps()) {
        <button
          type="button"
          class="step"
          tabindex="-1"
          [attr.aria-label]="'Decrease ' + label()"
          [attr.aria-disabled]="stalled(-1) ? 'true' : null"
          [disabled]="disabled()"
          (click)="stepBy(-1, field)"
        >
          <neat-icon name="minus" [size]="16" />
        </button>
      }
      <input
        #field
        data-slot="input"
        inputmode="numeric"
        [id]="inputId"
        [class]="framed() ? inFrameClasses : fieldClasses"
        [attr.aria-label]="label()"
        [attr.role]="steps() ? 'spinbutton' : null"
        [attr.aria-valuenow]="steps() ? value() : null"
        [attr.aria-valuemin]="steps() ? floor() : null"
        [attr.aria-valuemax]="steps() ? max() : null"
        [attr.aria-valuetext]="valueText()"
        [attr.aria-describedby]="unit() && !steps() ? unitId : null"
        [attr.aria-invalid]="invalid() ? 'true' : null"
        [attr.placeholder]="value() === null ? noValue : null"
        [disabled]="disabled()"
        [value]="value()"
        (input)="draft.set(field.value)"
        (keydown.enter)="commitFrom(field, true)"
        (keydown.arrowup)="arrow($event, 1, field)"
        (keydown.arrowdown)="arrow($event, -1, field)"
        (blur)="commitFrom(field, false)"
      />
      @if (unit()) {
        <span class="unit" [id]="unitId">{{ unit() }}</span>
      }
      @if (steps()) {
        <button
          type="button"
          class="step"
          tabindex="-1"
          [attr.aria-label]="'Increase ' + label()"
          [attr.aria-disabled]="stalled(1) ? 'true' : null"
          [disabled]="disabled()"
          (click)="stepBy(1, field)"
        >
          <neat-icon name="plus" [size]="16" />
        </button>
      }
    </span>
    <ng-content select="[neatNumberFieldSuffix]" />
  `,
			styles: [":host{display:flex;flex:none;align-items:center;gap:var(--neat-space-2);font-size:var(--neat-text-sm);white-space:nowrap}.box{display:flex;width:3rem}.box[data-framed]{width:auto}.box[data-framed] input{width:2.5rem;padding-inline-start:var(--neat-space-2)}.unit{padding-inline-end:var(--neat-space-2);color:var(--muted-foreground)}.box[data-steps]{min-width:7.5rem}.box[data-steps] input{width:3ch;padding-inline:0;text-align:center}@supports (field-sizing: content){.box[data-steps] input{field-sizing:content;width:auto;min-width:1ch}}.box[data-steps] .unit{padding-inline:.25rem 0}.step{display:inline-flex;flex:none;align-items:center;justify-content:center;width:1.5rem;height:1.5rem;margin-inline:.1875rem;padding:0;border:0;border-radius:calc(var(--radius) - 2px);background:transparent;color:var(--muted-foreground);cursor:pointer}.step:first-child{margin-inline-end:auto}.step:last-child{margin-inline-start:auto}.step:hover:not(:disabled,[aria-disabled=true]){background:var(--accent);color:var(--accent-foreground)}.step[aria-disabled=true]{opacity:.5;cursor:not-allowed}.step:disabled{cursor:inherit}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		unit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unit",
				required: false
			}]
		}],
		showLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showLabel",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		commit: [{
			type: i0.Output,
			args: ["commit"]
		}],
		field: [{
			type: i0.ViewChild,
			args: ["field", { isSignal: true }]
		}]
	}
});
export { NeatNumberField };

//# sourceMappingURL=sima-neat-ui-number-field.mjs.map