import { Overlay } from "@angular/cdk/overlay";
import { TemplatePortal } from "@angular/cdk/portal";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, NgZone, ViewContainerRef, afterRenderEffect, inject, input, output, untracked, viewChild } from "@angular/core";
import { ɵPANEL_SURFACE_CLASSES, ɵhlm } from "@sima/neat-ui";
function anchorElements(anchor) {
	if (!anchor) return [];
	return (anchor instanceof ElementRef ? [anchor.nativeElement] : Array.isArray(anchor) ? anchor : [anchor]).filter((element) => element.isConnected);
}
function unionBox(boxes) {
	if (!boxes.length) return null;
	const left = Math.min(...boxes.map((box) => box.x));
	const top = Math.min(...boxes.map((box) => box.y));
	const right = Math.max(...boxes.map((box) => box.x + box.width));
	const bottom = Math.max(...boxes.map((box) => box.y + box.height));
	return {
		x: left,
		y: top,
		width: right - left,
		height: bottom - top
	};
}
function tailAt(side, anchor, bubble, inset) {
	const across = side === "top" || side === "bottom";
	const middle = across ? anchor.x + anchor.width / 2 - bubble.x : anchor.y + anchor.height / 2 - bubble.y;
	const length = across ? bubble.width : bubble.height;
	return Math.max(inset, Math.min(length - inset, middle));
}
function trackAnchor(view, anchors, bubble, place, shown) {
	let frame = 0;
	const schedule = () => {
		if (!frame) frame = view.requestAnimationFrame(() => {
			frame = 0;
			place();
		});
	};
	const document = view.document;
	document.addEventListener("scroll", schedule, {
		capture: true,
		passive: true
	});
	view.addEventListener("resize", schedule, { passive: true });
	const resize = view.ResizeObserver ? new view.ResizeObserver(schedule) : void 0;
	resize?.observe(bubble);
	anchors.forEach((anchor) => resize?.observe(anchor));
	const inView = /* @__PURE__ */ new Set();
	const intersect = view.IntersectionObserver ? new view.IntersectionObserver((entries) => {
		for (const entry of entries) if (entry.isIntersecting) inView.add(entry.target);
		else inView.delete(entry.target);
		shown(inView.size > 0);
	}) : void 0;
	anchors.forEach((anchor) => intersect?.observe(anchor));
	return () => {
		document.removeEventListener("scroll", schedule, { capture: true });
		view.removeEventListener("resize", schedule);
		resize?.disconnect();
		intersect?.disconnect();
		if (frame) view.cancelAnimationFrame(frame);
	};
}
const GAP = 10;
const VIEWPORT_MARGIN = 8;
const TAIL_INSET = 16;
const POSITIONS = {
	top: {
		originX: "center",
		originY: "top",
		overlayX: "center",
		overlayY: "bottom",
		offsetY: -10
	},
	bottom: {
		originX: "center",
		originY: "bottom",
		overlayX: "center",
		overlayY: "top",
		offsetY: GAP
	},
	left: {
		originX: "start",
		originY: "center",
		overlayX: "end",
		overlayY: "center",
		offsetX: -10
	},
	right: {
		originX: "end",
		originY: "center",
		overlayX: "start",
		overlayY: "center",
		offsetX: GAP
	}
};
const OPPOSITE = {
	top: "bottom",
	bottom: "top",
	left: "right",
	right: "left"
};
function positionsFor(side) {
	const order = [side, OPPOSITE[side]];
	const rest = [
		"top",
		"bottom",
		"right",
		"left"
	].filter((s) => !order.includes(s));
	return [...order, ...rest].map((s) => POSITIONS[s]);
}
function sideOf(change) {
	const { originX, originY, overlayX, overlayY } = change.connectionPair;
	if (originY === "top" && overlayY === "bottom") return "top";
	if (originY === "bottom" && overlayY === "top") return "bottom";
	if (originX === "start" && overlayX === "end") return "left";
	return "right";
}
const box = (element) => element.getBoundingClientRect();
let nextBubbleId = 0;
var NeatBubble = class NeatBubble {
	anchor = input(null, ...ngDevMode ? [{ debugName: "anchor" }] : /* istanbul ignore next */ []);
	side = input("top", ...ngDevMode ? [{ debugName: "side" }] : /* istanbul ignore next */ []);
	hover = output();
	id = `neat-bubble-${++nextBubbleId}`;
	classes = ɵhlm(ɵPANEL_SURFACE_CLASSES, "w-auto max-w-80 gap-2 p-3");
	panel = viewChild.required("panel", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	overlay = inject(Overlay);
	containers = inject(ViewContainerRef);
	zone = inject(NgZone);
	ref;
	strategy;
	placed = "top";
	stopTracking;
	constructor() {
		afterRenderEffect(() => {
			const anchors = anchorElements(this.anchor());
			const side = this.side();
			untracked(() => this.show(anchors, side));
		});
		inject(DestroyRef).onDestroy(() => this.hide());
	}
	pointer(event, over) {
		if (event.pointerType === "mouse" || event.pointerType === "pen") this.hover.emit(over);
	}
	show(anchors, side) {
		this.stopTracking?.();
		this.stopTracking = void 0;
		if (!anchors.length) {
			this.hide();
			return;
		}
		if (!this.ref || !this.strategy) {
			this.strategy = this.overlay.position().flexibleConnectedTo(unionBox(anchors.map(box)) ?? {
				x: 0,
				y: 0
			}).withPositions(positionsFor(side)).withFlexibleDimensions(false).withPush(true).withViewportMargin(VIEWPORT_MARGIN);
			this.strategy.positionChanges.subscribe((change) => this.placed = sideOf(change));
			this.ref = this.overlay.create({
				positionStrategy: this.strategy,
				scrollStrategy: this.overlay.scrollStrategies.noop()
			});
			this.ref.attach(new TemplatePortal(this.panel(), this.containers));
		} else this.strategy.withPositions(positionsFor(side));
		const ref = this.ref;
		const strategy = this.strategy;
		const bubble = ref.overlayElement.querySelector(".bubble");
		if (!bubble) return;
		const view = bubble.ownerDocument.defaultView;
		const place = () => {
			const anchor = unionBox(anchors.map(box));
			if (!anchor) return;
			strategy.setOrigin(anchor);
			ref.updatePosition();
			bubble.dataset["side"] = this.placed;
			bubble.style.setProperty("--tail-at", `${tailAt(this.placed, anchor, box(bubble), TAIL_INSET)}px`);
		};
		place();
		if (!view) return;
		this.zone.runOutsideAngular(() => {
			this.stopTracking = trackAnchor(view, anchors, bubble, place, (visible) => {
				bubble.toggleAttribute("data-hidden", !visible);
			});
		});
	}
	hide() {
		this.stopTracking?.();
		this.stopTracking = void 0;
		this.ref?.dispose();
		this.ref = void 0;
		this.strategy = void 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatBubble,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatBubble,
		isStandalone: true,
		selector: "neat-bubble",
		inputs: {
			anchor: {
				classPropertyName: "anchor",
				publicName: "anchor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			side: {
				classPropertyName: "side",
				publicName: "side",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { hover: "hover" },
		viewQueries: [{
			propertyName: "panel",
			first: true,
			predicate: ["panel"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #panel>
      <div
        class="bubble"
        [id]="id"
        [class]="classes"
        (pointerenter)="pointer($event, true)"
        (pointerleave)="pointer($event, false)"
      >
        <ng-content />
      </div>
    </ng-template>
  `,
		isInline: true,
		styles: [":host{display:none}.bubble[data-hidden]{visibility:hidden}.bubble:before,.bubble:after{position:absolute;content:\"\"}.bubble:before{background:var(--border)}.bubble:after{background:var(--popover)}.bubble[data-side=top]:before,.bubble[data-side=top]:after,.bubble[data-side=bottom]:before,.bubble[data-side=bottom]:after{left:calc(var(--tail-at, 50%) - 8px);width:16px;height:8px}.bubble[data-side=left]:before,.bubble[data-side=left]:after,.bubble[data-side=right]:before,.bubble[data-side=right]:after{top:calc(var(--tail-at, 50%) - 8px);width:8px;height:16px}.bubble[data-side=top]:before,.bubble[data-side=top]:after{clip-path:polygon(0 0,100% 0,50% 100%)}.bubble[data-side=top]:before{top:calc(100% + 1px)}.bubble[data-side=top]:after{top:100%}.bubble[data-side=bottom]:before,.bubble[data-side=bottom]:after{clip-path:polygon(50% 0,100% 100%,0 100%)}.bubble[data-side=bottom]:before{bottom:calc(100% + 1px)}.bubble[data-side=bottom]:after{bottom:100%}.bubble[data-side=left]:before,.bubble[data-side=left]:after{clip-path:polygon(0 0,100% 50%,0 100%)}.bubble[data-side=left]:before{left:calc(100% + 1px)}.bubble[data-side=left]:after{left:100%}.bubble[data-side=right]:before,.bubble[data-side=right]:after{clip-path:polygon(100% 0,100% 100%,0 50%)}.bubble[data-side=right]:before{right:calc(100% + 1px)}.bubble[data-side=right]:after{right:100%}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatBubble,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-bubble",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <ng-template #panel>
      <div
        class="bubble"
        [id]="id"
        [class]="classes"
        (pointerenter)="pointer($event, true)"
        (pointerleave)="pointer($event, false)"
      >
        <ng-content />
      </div>
    </ng-template>
  `,
			styles: [":host{display:none}.bubble[data-hidden]{visibility:hidden}.bubble:before,.bubble:after{position:absolute;content:\"\"}.bubble:before{background:var(--border)}.bubble:after{background:var(--popover)}.bubble[data-side=top]:before,.bubble[data-side=top]:after,.bubble[data-side=bottom]:before,.bubble[data-side=bottom]:after{left:calc(var(--tail-at, 50%) - 8px);width:16px;height:8px}.bubble[data-side=left]:before,.bubble[data-side=left]:after,.bubble[data-side=right]:before,.bubble[data-side=right]:after{top:calc(var(--tail-at, 50%) - 8px);width:8px;height:16px}.bubble[data-side=top]:before,.bubble[data-side=top]:after{clip-path:polygon(0 0,100% 0,50% 100%)}.bubble[data-side=top]:before{top:calc(100% + 1px)}.bubble[data-side=top]:after{top:100%}.bubble[data-side=bottom]:before,.bubble[data-side=bottom]:after{clip-path:polygon(50% 0,100% 100%,0 100%)}.bubble[data-side=bottom]:before{bottom:calc(100% + 1px)}.bubble[data-side=bottom]:after{bottom:100%}.bubble[data-side=left]:before,.bubble[data-side=left]:after{clip-path:polygon(0 0,100% 50%,0 100%)}.bubble[data-side=left]:before{left:calc(100% + 1px)}.bubble[data-side=left]:after{left:100%}.bubble[data-side=right]:before,.bubble[data-side=right]:after{clip-path:polygon(100% 0,100% 100%,0 50%)}.bubble[data-side=right]:before{right:calc(100% + 1px)}.bubble[data-side=right]:after{right:100%}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		anchor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "anchor",
				required: false
			}]
		}],
		side: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "side",
				required: false
			}]
		}],
		hover: [{
			type: i0.Output,
			args: ["hover"]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["panel", { isSignal: true }]
		}]
	}
});
export { NeatBubble };

//# sourceMappingURL=sima-neat-ui-bubble.mjs.map