import { DestroyRef, NgZone, computed, effect, inject, isSignal, signal, untracked } from "@angular/core";
function parseJpegChunk(data) {
	if (data.byteLength <= 8) return null;
	const view = new DataView(data);
	const index = view.getUint16(4);
	const count = view.getUint16(6);
	if (count === 0 || count > 280 || index >= count) return null;
	return {
		timestamp: view.getUint32(0),
		index,
		count,
		bytes: new Uint8Array(data, 8)
	};
}
var JpegAssembler = class {
	pending = null;
	droppedFrames = 0;
	get dropped() {
		return this.droppedFrames;
	}
	accept(chunk) {
		let pending = this.pending;
		if (pending && (pending.timestamp !== chunk.timestamp || pending.slots.length !== chunk.count)) {
			this.droppedFrames++;
			pending = null;
		}
		pending ??= {
			timestamp: chunk.timestamp,
			slots: new Array(chunk.count),
			filled: 0
		};
		this.pending = pending;
		if (pending.slots[chunk.index] === void 0) {
			pending.slots[chunk.index] = chunk.bytes;
			pending.filled++;
		}
		if (pending.filled < chunk.count) return null;
		this.pending = null;
		const parts = pending.slots;
		return {
			parts,
			timestamp: pending.timestamp,
			byteLength: parts.reduce((sum, part) => sum + part.byteLength, 0)
		};
	}
};
const SOI = 216;
const SOF0 = 192;
const isStandalone = (marker) => marker === 1 || marker >= 208 && marker <= 216;
function jpegSize(bytes) {
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	if (bytes.byteLength < 4 || bytes[0] !== 255 || bytes[1] !== SOI) return null;
	let at = 2;
	while (at + 4 <= bytes.byteLength) {
		if (bytes[at] !== 255) return null;
		const marker = bytes[at + 1];
		if (marker === 255) {
			at++;
			continue;
		}
		if (isStandalone(marker)) {
			at += 2;
			continue;
		}
		if (marker === SOF0) {
			if (at + 9 > bytes.byteLength) return null;
			return {
				height: view.getUint16(at + 5),
				width: view.getUint16(at + 7)
			};
		}
		at += 2 + view.getUint16(at + 2);
	}
	return null;
}
const BACKOFF_MS = [
	1e3,
	2e3,
	5e3,
	1e4
];
const STALL_MS = 5e3;
const HEALTH_INTERVAL_MS = 1e3;
const UNREACHABLE_TEXT = "Insight not reachable";
const WAITING_TEXT = {
	no_video: "Waiting for video",
	codec_changed: "Video format changed",
	insight_unreachable: UNREACHABLE_TEXT,
	negotiation_failed: "Could not connect",
	too_many_viewers: "Too many viewers"
};
const GATEWAY_STATUSES = /* @__PURE__ */ new Set([
	502,
	503,
	504
]);
function openInsightConnection(options, events) {
	const log = options.log ?? (() => void 0);
	let videoBufferMs = options.videoBufferMs;
	let closed = false;
	let peer = null;
	let receiver = null;
	let health = null;
	let failures = 0;
	let checking = false;
	let retryTimer = null;
	let healthTimer = null;
	const clearRetry = () => {
		if (retryTimer !== null) clearTimeout(retryTimer);
		retryTimer = null;
	};
	const dropStream = () => {
		events.stream(null);
		events.frames(null);
	};
	const dropPeer = () => {
		const pc = peer;
		peer = null;
		receiver = null;
		health = null;
		events.videoDelayMs(null);
		events.stats(null);
		pc?.close();
	};
	const close = () => {
		if (closed) return;
		closed = true;
		clearRetry();
		if (healthTimer !== null) clearInterval(healthTimer);
		healthTimer = null;
		dropPeer();
		dropStream();
		events.waiting(null);
		log("closed");
	};
	const fail = (text) => {
		close();
		log("failed", text);
		events.failure(text);
	};
	const retry = (reason) => {
		if (closed) return;
		dropPeer();
		dropStream();
		const delay = BACKOFF_MS[Math.min(failures, BACKOFF_MS.length - 1)];
		failures += 1;
		clearRetry();
		log("retrying", {
			reason,
			inMs: delay
		});
		retryTimer = setTimeout(() => void attempt(), delay);
	};
	const attempt = async () => {
		if (closed) return;
		clearRetry();
		dropPeer();
		const pc = new RTCPeerConnection();
		peer = pc;
		receiver = pc.addTransceiver("video", { direction: "recvonly" }).receiver;
		if (videoBufferMs !== void 0) applyJitterBufferTarget(receiver, videoBufferMs);
		log("connecting", {
			offerUrl: options.offerUrl,
			videoBufferMs
		});
		const metadata = pc.createDataChannel("metadata", {
			ordered: true,
			maxRetransmits: 0
		});
		metadata.onmessage = (event) => {
			if (pc !== peer || typeof event.data !== "string") return;
			events.metadata(event.data, performance.now());
		};
		let streamShown = false;
		let frames = null;
		const assembler = new JpegAssembler();
		const jpeg = pc.createDataChannel("jpeg", {
			ordered: true,
			maxPacketLifeTime: 300
		});
		jpeg.binaryType = "arraybuffer";
		jpeg.onmessage = (event) => {
			const current = health;
			if (pc !== peer || !current || !(event.data instanceof ArrayBuffer)) return;
			const chunk = parseJpegChunk(event.data);
			if (!chunk) return;
			if (frames === null) {
				log("frames");
				events.waiting(null);
				if (streamShown) events.stream(null);
				frames = {
					run: frameRun(),
					counts: newFrameCounts()
				};
				current.frames = frames.counts;
				events.frames(frames.run.frames);
			}
			const { run, counts } = frames;
			counts.bytes += chunk.bytes.byteLength;
			const frame = assembler.accept(chunk);
			if (!frame) return;
			const arrival = performance.now();
			const holdMs = videoBufferMs ?? 0;
			counts.frames += 1;
			counts.holdMs += holdMs;
			counts.latestFirstPart = frame.parts[0];
			run.emit({
				data: new Blob([...frame.parts], { type: "image/jpeg" }),
				rtpTimestamp: frame.timestamp,
				presentAt: arrival + holdMs
			});
		};
		jpeg.onclose = () => {
			if (pc !== peer || closed || frames === null) return;
			retry("frames channel closed");
		};
		pc.ontrack = (event) => {
			if (pc !== peer || event.track.kind !== "video" || frames !== null) return;
			log("track");
			events.waiting(null);
			streamShown = true;
			events.stream(event.streams[0] ?? new MediaStream([event.track]));
		};
		pc.onconnectionstatechange = () => {
			if (pc !== peer) return;
			log("connection state", pc.connectionState);
			if (pc.connectionState === "connected") failures = 0;
			else if (pc.connectionState === "failed" || pc.connectionState === "closed") retry(`connection ${pc.connectionState}`);
		};
		try {
			const offer = await pc.createOffer();
			await pc.setLocalDescription(offer);
			const response = await fetch(options.offerUrl, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					type: offer.type,
					sdp: offer.sdp
				})
			}).catch(() => {
				throw new OfferError(null, {
					code: null,
					message: null
				});
			});
			if (!response.ok) throw new OfferError(response.status, await errorOf(response));
			const answer = await response.json();
			if (closed || pc !== peer) return;
			await pc.setRemoteDescription(answer);
			log("answered");
			health = {
				frames: null,
				framesDecoded: -1,
				progressAt: Date.now(),
				disconnectedSince: null,
				delaySeconds: null,
				emittedCount: 0,
				bytesReceived: null,
				sampledAt: null
			};
		} catch (error) {
			if (pc !== peer) return;
			if (error instanceof OfferError && error.final) fail(error.failureText());
			else {
				events.waiting(error instanceof OfferError ? error.waitingText() : null);
				retry(error instanceof Error ? `offer: ${error.message}` : "offer failed");
			}
		}
	};
	const checkHealth = async () => {
		const pc = peer;
		if (closed || checking || !pc || !health) return;
		checking = true;
		try {
			const current = health;
			const reports = current.frames === null ? await pc.getStats() : null;
			if (pc !== peer || current !== health) return;
			const now = Date.now();
			const connected = pc.connectionState === "connected";
			let stalled = false;
			if (current.frames !== null) {
				const { holdMs, stats } = sampleFrames(current.frames, connected, now);
				events.videoDelayMs(holdMs);
				events.stats(stats);
			} else {
				const inbound = reports === null ? null : inboundVideo(reports);
				const framesDecoded = inbound?.framesDecoded ?? 0;
				if (framesDecoded > current.framesDecoded) {
					current.framesDecoded = framesDecoded;
					current.progressAt = now;
				}
				events.videoDelayMs(sampleDelay(current, connected, inbound));
				events.stats(connected && inbound && reports ? sampleStats(current, inbound, reports) : null);
				stalled = now - current.progressAt >= STALL_MS;
			}
			if (pc.connectionState === "disconnected") current.disconnectedSince ??= now;
			else current.disconnectedSince = null;
			const disconnected = current.disconnectedSince !== null && now - current.disconnectedSince >= STALL_MS;
			if (stalled) retry("no new frame decoded");
			else if (disconnected) retry("disconnected");
		} catch {} finally {
			checking = false;
		}
	};
	if (typeof RTCPeerConnection !== "function") {
		closed = true;
		events.failure("This browser has no WebRTC");
		return {
			close: () => void 0,
			setVideoBufferMs: () => void 0
		};
	}
	healthTimer = setInterval(() => void checkHealth(), HEALTH_INTERVAL_MS);
	attempt();
	return {
		close,
		setVideoBufferMs(ms) {
			videoBufferMs = ms;
			if (receiver !== null && ms !== void 0) applyJitterBufferTarget(receiver, ms);
		}
	};
}
function newFrameCounts() {
	return {
		frames: 0,
		bytes: 0,
		holdMs: 0,
		latestFirstPart: null,
		sampledAt: null
	};
}
function frameRun() {
	const listeners = /* @__PURE__ */ new Set();
	return {
		frames: { onFrame(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		} },
		emit(frame) {
			for (const listener of listeners) try {
				listener(frame);
			} catch (error) {
				reportError(error);
			}
		}
	};
}
function sampleFrames(counts, connected, now) {
	const seconds = counts.sampledAt === null ? 0 : (now - counts.sampledAt) / 1e3;
	const { frames, bytes, holdMs } = counts;
	counts.frames = 0;
	counts.bytes = 0;
	counts.holdMs = 0;
	counts.sampledAt = now;
	if (!connected) return {
		holdMs: null,
		stats: null
	};
	const size = counts.latestFirstPart === null ? null : jpegSize(counts.latestFirstPart);
	return {
		holdMs: frames > 0 ? holdMs / frames : null,
		stats: {
			codec: "JPEG",
			width: size?.width ?? null,
			height: size?.height ?? null,
			framesPerSecond: seconds > 0 ? frames / seconds : null,
			bitsPerSecond: seconds > 0 ? bytes * 8 / seconds : 0
		}
	};
}
function inboundVideo(reports) {
	for (const report of reports.values()) if (report.type === "inbound-rtp" && report.kind === "video") return report;
	return null;
}
function sampleDelay(current, connected, video) {
	const delaySeconds = video?.jitterBufferDelay ?? 0;
	const emittedCount = video?.jitterBufferEmittedCount ?? 0;
	const frames = emittedCount - current.emittedCount;
	const seconds = delaySeconds - (current.delaySeconds ?? 0);
	const hadBaseline = current.delaySeconds !== null;
	current.delaySeconds = delaySeconds;
	current.emittedCount = emittedCount;
	return connected && hadBaseline && frames > 0 ? seconds / frames * 1e3 : null;
}
function sampleStats(current, video, reports) {
	const bytes = video.bytesReceived ?? null;
	const seconds = current.sampledAt === null ? 0 : (video.timestamp - current.sampledAt) / 1e3;
	const bitsPerSecond = seconds > 0 && bytes !== null && current.bytesReceived !== null ? (bytes - current.bytesReceived) * 8 / seconds : 0;
	current.bytesReceived = bytes;
	current.sampledAt = video.timestamp;
	return {
		codec: codecOf(reports, video.codecId),
		width: video.frameWidth ?? null,
		height: video.frameHeight ?? null,
		framesPerSecond: video.framesPerSecond ?? null,
		bitsPerSecond
	};
}
function codecOf(reports, codecId) {
	const mimeType = codecId === void 0 ? void 0 : reports.get(codecId)?.mimeType;
	if (typeof mimeType !== "string") return null;
	return mimeType.split("/")[1] || null;
}
function applyJitterBufferTarget(receiver, ms) {
	if (!("jitterBufferTarget" in receiver)) return;
	try {
		receiver.jitterBufferTarget = ms;
	} catch {}
}
async function errorOf(response) {
	try {
		const { error } = await response.json();
		return {
			code: typeof error?.code === "string" ? error.code : null,
			message: typeof error?.message === "string" ? error.message : null
		};
	} catch {
		return {
			code: null,
			message: null
		};
	}
}
var OfferError = class extends Error {
	status;
	code;
	detail;
	constructor(status, body) {
		super(status === null ? "no answer" : `HTTP ${status}`);
		this.status = status;
		this.code = body.code;
		this.detail = body.message;
	}
	get final() {
		return this.status !== null && this.status >= 400 && this.status < 500;
	}
	failureText() {
		if (this.status === 415) return "Codec not supported by this browser";
		return this.detail ?? `Connection failed: HTTP ${this.status}`;
	}
	waitingText() {
		if (this.code !== null) return Object.hasOwn(WAITING_TEXT, this.code) ? WAITING_TEXT[this.code] : null;
		return this.status === null || GATEWAY_STATUSES.has(this.status) ? UNREACHABLE_TEXT : null;
	}
};
function neatInsightChannel(channel, options = {}) {
	const destroyRef = inject(DestroyRef);
	const zone = inject(NgZone);
	const { offer, videoBufferMs, log } = options;
	const offerUrl = typeof offer === "function" ? offer(channel) : offer ?? `/api/channels/${channel}/offer`;
	const bufferMs = isSignal(videoBufferMs) ? videoBufferMs : () => videoBufferMs;
	const stream = signal(null, ...ngDevMode ? [{ debugName: "stream" }] : /* istanbul ignore next */ []);
	const frames = signal(null, ...ngDevMode ? [{ debugName: "frames" }] : /* istanbul ignore next */ []);
	const waiting = signal(null, ...ngDevMode ? [{ debugName: "waiting" }] : /* istanbul ignore next */ []);
	const failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	const videoDelayMs = signal(null, ...ngDevMode ? [{ debugName: "videoDelayMs" }] : /* istanbul ignore next */ []);
	const stats = signal(null, ...ngDevMode ? [{ debugName: "stats" }] : /* istanbul ignore next */ []);
	const listeners = /* @__PURE__ */ new Set();
	const connection = zone.runOutsideAngular(() => openInsightConnection({
		offerUrl,
		videoBufferMs: untracked(bufferMs),
		log
	}, {
		stream: (value) => stream.set(value),
		frames: (run) => frames.set(run),
		waiting: (text) => waiting.set(text),
		failure: (text) => failure.set(text),
		videoDelayMs: (ms) => videoDelayMs.set(ms),
		stats: (value) => stats.set(value),
		metadata: (text, receivedAt) => {
			for (const listener of listeners) listener(text, receivedAt);
		}
	}));
	if (isSignal(videoBufferMs)) effect(() => {
		const ms = videoBufferMs();
		untracked(() => connection.setVideoBufferMs(ms));
	});
	const canHoldStream = typeof RTCRtpReceiver === "function" && "jitterBufferTarget" in RTCRtpReceiver.prototype;
	const stopOnDestroy = destroyRef.onDestroy(() => connection.close());
	return {
		stream: stream.asReadonly(),
		frames: frames.asReadonly(),
		notice: computed(() => failure() ?? waiting()),
		failure: failure.asReadonly(),
		videoDelayMs: videoDelayMs.asReadonly(),
		stats: stats.asReadonly(),
		videoBufferSupported: computed(() => canHoldStream || frames() !== null),
		onMetadata(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		close() {
			stopOnDestroy();
			connection.close();
		}
	};
}
export { neatInsightChannel };

//# sourceMappingURL=sima-neat-ui-insight.mjs.map