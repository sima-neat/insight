import { NeatTone } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/**
 * How a chip carries its tone: `solid` (the default) or `tinted`.
 *
 * `solid` is on the tone's status fill. `tinted` is the tone's color on a light tint of itself. Use
 * it for chips that label parts of a card, such as a diagram block's, rather than state a status
 * beside a value.
 */
type NeatStatusChipVariant = 'solid' | 'tinted';
/**
 * A short status on a status color, such as Live or Idle.
 *
 * ```html
 * <neat-status-chip tone="success">Live</neat-status-chip>
 * ```
 *
 * Use it for a state in a list's cell or over a panel: Live, Idle, External. Or use it for a fact
 * beside a value, such as a codec that cannot be decoded. The words are the app's. The color
 * repeats them and is never the only way a state is told.
 *
 * `highlight` is for a state that is none of the statuses but should stand out, such as a stream
 * that someone else publishes. A `neat-select-list` row can take the same tone as its chip, with
 * `rowTone`.
 *
 * A chip truncates rather than widen the cell or bar that holds it.
 *
 * `variant="tinted"` softens the chip to its tone's color on a tint. A tinted chip belongs on a
 * card or the page, not on a toned list row, whose selected fill is the same tint.
 */
export declare class NeatStatusChip {
  /** The status the chip states, which sets its colors; `neutral` for a plain label. */
  readonly tone: import("@angular/core").InputSignal<NeatTone>;
  /** `solid` (the default) fills the chip with the tone; `tinted` shows it on a light tint. */
  readonly variant: import("@angular/core").InputSignal<NeatStatusChipVariant>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatStatusChip, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatStatusChip, "neat-status-chip", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * The chip as a button, for a status that opens more about itself.
 *
 * ```html
 * <button neatStatusChip tone="warning" type="button" (click)="showWhy()">Metadata late</button>
 * ```
 *
 * A video tile's "Metadata late", which shows why when pressed, is one. It looks like the chip of
 * its tone, with a pointer and a focus outline. It stays a native button, with its focus, Enter and
 * Space, and `disabled`. Its name is its text.
 */
export declare class NeatStatusChipButton {
  /** The status the chip states, which sets its colors; `neutral` for a plain label. */
  readonly tone: import("@angular/core").InputSignal<NeatTone>;
  /** `solid` (the default) fills the chip with the tone; `tinted` shows it on a light tint. */
  readonly variant: import("@angular/core").InputSignal<NeatStatusChipVariant>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatStatusChipButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatStatusChipButton, "button[neatStatusChip]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type { NeatStatusChipVariant };