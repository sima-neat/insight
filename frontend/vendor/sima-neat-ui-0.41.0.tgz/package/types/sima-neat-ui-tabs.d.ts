import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import * as i1 from "@spartan-ng/brain/tabs";
/**
 * Helm's tabs classes (`lib/ui/tabs`), copied because helm keeps them inline; the list's classes
 * come from helm's exported `listVariants`. tabs.spec checks that each copied string still appears
 * in the vendored helm, so a helm update that changes one fails until this table is reviewed.
 */
declare const TABS_HELM_CLASSES: {
  /** `hlm-tabs.ts` */
  readonly root: "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col";
  /** `hlm-tabs-trigger.ts`, in its four parts: base, line variant, active, and the underline. */
  readonly trigger: "gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0";
  readonly triggerLine: "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent";
  readonly triggerActive: "data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground";
  readonly triggerIndicator: "after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100";
  /** `hlm-tabs-content.ts` */
  readonly content: "flex-1 text-sm outline-none";
};
/**
 * One tab of a `neat-tabs`, its panel in an `<ng-template>`.
 *
 * ```html
 * <neat-tab label="General" value="general">
 *   <ng-template>…</ng-template>
 * </neat-tab>
 * ```
 *
 * The panel's content is created only while the tab is open, and destroyed when another one opens.
 */
export declare class NeatTab {
  /** The text on the tab's trigger, which names the tab. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Identifies the tab in `neat-tabs`' `value`; unique within one `neat-tabs`. */
  readonly value: import("@angular/core").InputSignal<string>;
  /** Turns the tab off: it is shown dimmed and cannot be opened, and the arrow keys skip it. */
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * @internal The panel template, which `neat-tabs` renders while this tab is open; apps never
   * read it.
   */
  readonly content: import("@angular/core").Signal<TemplateRef<any>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTab, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTab, "neat-tab", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["content"], never, true, never>;
}
/**
 * Tabs that show one panel at a time, for views inside one page.
 *
 * ```html
 * <neat-tabs label="Channel settings" [(value)]="tab">
 *   <neat-tab label="Metadata" value="metadata">
 *     <ng-template>…</ng-template>
 *   </neat-tab>
 *   <neat-tab label="General" value="general">
 *     <ng-template>…</ng-template>
 *   </neat-tab>
 * </neat-tabs>
 * ```
 *
 * Use tabs for views that are not addresses, such as a dialog's sections. A page's route-linked
 * views are its rail item's `children` or links in its page nav, never tabs.
 *
 * The open tab is underlined. The tab list is named by `label`. When `value` names no tab, or is
 * unset, the first enabled tab is open, so the list stays reachable.
 *
 * The arrow keys move to the next or previous tab and open it, skipping disabled tabs and wrapping.
 * Home and End jump to the ends. The open tab is the only tab stop.
 *
 * Every tab has a panel element, so each tab's `aria-controls` names one that exists. Only the open
 * tab's panel holds its content: the others are empty and `hidden`.
 *
 * A panel taller than the space it has is for the surrounding page or pane to scroll, which keeps
 * one scroll context. The tab list is the one part that scrolls itself. Tabs that do not fit their
 * container's width, such as an aside's, scroll sideways and never wrap. The open tab is brought
 * into view when it changes.
 *
 * Two tab sets with the same values do not share element ids. A value with spaces ("Board 1")
 * works as any other, so `value` stays in the app's terms.
 */
export declare class NeatTabs {
  /** The open tab's `value`. */
  readonly value: import("@angular/core").ModelSignal<string | undefined>;
  /** The tab list's accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  protected readonly tabs: import("@angular/core").Signal<readonly NeatTab[]>;
  /**
   * The tabs' values in order, as one string. The tab list is drawn once per distinct value of it
   * (a one-item `@for` tracked by it): brain's list builds its key manager from the triggers it
   * has when it starts and never sees tabs added or removed later, so the arrow keys would walk
   * the old set. A new list is a new key manager. A label or `disabled` change keeps the list.
   */
  protected readonly tabSet: import("@angular/core").Signal<string>;
  /** The place of the tab shown open: the one `value` names, else the first enabled one; -1 for none. */
  protected readonly openIndex: import("@angular/core").Signal<number>;
  /** The strip is drawn once per tab set, like the list in it. */
  private readonly strip;
  private readonly triggers;
  protected readonly rootClasses: string;
  protected readonly stripClasses: string;
  protected readonly listClasses: string;
  protected readonly triggerClasses: string;
  protected readonly contentClasses: string;
  private readonly prefix;
  constructor();
  /** The key brain knows a tab by: its place in the list, prefixed per instance. */
  protected key(index: number): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTabs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTabs, "neat-tabs", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, ["tabs"], never, true, [{
    directive: typeof i1.BrnTabs;
    inputs: {};
    outputs: {};
  }]>;
}
export {};