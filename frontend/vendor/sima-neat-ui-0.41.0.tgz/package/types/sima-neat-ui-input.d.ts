import * as i0 from "@angular/core";
import * as i1 from "@spartan-ng/brain/input";
/** `medium` matches the kit's medium button (2.25rem), `small` its small one (2rem). */
type NeatInputSize = 'small' | 'medium';
/**
 * Helm's input classes, re-exported for input.spec's drift check; the primary keeps them with the
 * field's look, which `neat-search` shares.
 */
declare const INPUT_HELM_CLASSES = "dark:bg-input/30 border-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 h-9 rounded-md border bg-transparent px-2.5 py-1 text-base shadow-xs transition-[color,box-shadow] file:h-7 file:text-sm file:font-medium focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 md:text-sm file:text-foreground placeholder:text-muted-foreground w-full min-w-0 outline-none file:inline-flex file:border-0 file:bg-transparent disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50";
/**
 * A text or number field.
 *
 * ```html
 * <input neatInput type="number" inputmode="numeric" min="1" aria-label="Copies" />
 * ```
 *
 * Every native attribute (type, inputmode, min, max, placeholder, id, disabled) keeps its meaning.
 * The kit only styles the field. Name it with a `<label for>` or an `aria-label`.
 *
 * `size` is the kit's height, not the native character width. Bind it (`[size]="'small'"`) or set
 * it as an attribute: the browser ignores it as a width, since it is not a number.
 *
 * An `id` the app sets stays on the element, so a label can point at it.
 *
 * @input id The field's `id`, for a `<label for>` to point at; without one the field gets an id
 * of its own.
 */
export declare class NeatInput {
  /** The field's height, the kit's `medium` (2.25rem) or `small` (2rem); not a character width. */
  readonly size: import("@angular/core").InputSignal<NeatInputSize>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatInput, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatInput, "input[neatInput]", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnInput;
    inputs: {
      "id": "id";
    };
    outputs: {};
  }]>;
}
export type { NeatInputSize };