import { NeatTone } from "@sima/neat-ui";
import * as i0 from "@angular/core";
import { Signal, TemplateRef } from "@angular/core";
import { NeatChartFormat } from "@sima/neat-ui/charts";
/** A side of a node, where edges meet it. */
type NeatDiagramSide = 'left' | 'right' | 'top' | 'bottom';
/**
 * What a node is in the drawing: `group`, `block`, `band` or `bracket`.
 *
 * - `group` holds other nodes. It is drawn behind the edges, with its title and detail top left.
 * - `block` is a card, with a label, a detail and chips.
 * - `band` is a strip such as a cable or a bus, with its label along it.
 * - `bracket` spans a row of siblings below them, as a curly line and a label.
 *
 * `frame` is the old name of `group`, still drawn as one. It is deprecated: use `group`.
 */
type NeatDiagramRole = 'group' | 'block' | 'band' | 'bracket' | 'frame';
/** Whether `node` is a group: `role: 'group'`, or the deprecated `'frame'` it used to be called. */
declare function isGroup(node: {
  readonly role: NeatDiagramRole;
} | undefined): boolean;
/**
 * How a node is drawn within its role: `default`, `accent`, `dashed`, `ghost` or `muted`.
 *
 * - `accent` is the primary tint, such as for the main device.
 * - `dashed` is a dashed group.
 * - `ghost` is dashed, transparent and quiet, for a part that is not running.
 * - `muted` is filled with `--muted`.
 */
type NeatDiagramLook = 'default' | 'accent' | 'dashed' | 'ghost' | 'muted';
/** How an edge ends: plain, with an arrowhead, or with a dot. */
type NeatDiagramMarker = 'none' | 'arrow' | 'dot';
/**
 * The old name of `NeatDiagramMarker`, kept so apps that use it keep working.
 *
 * @deprecated Use `NeatDiagramMarker`; this name goes in a later release.
 */
type NeatDiagramTip = NeatDiagramMarker;
/**
 * What dims the rest of a diagram while the pointer or the keyboard is on a part.
 *
 * - `none` dims nothing.
 * - `edges`: an edge, its two blocks and its notes stay, and the rest dims.
 * - `all`: the same, and for a block too, with the edges that join it.
 */
type NeatDiagramHighlight = 'none' | 'edges' | 'all';
/** Where an edge's label sits at its point: on the line, or beside it. */
type NeatDiagramLabelSide = 'on' | 'above' | 'below' | 'left' | 'right';
/** A part of a diagram as `hovered` and `activated` name it: a block or an edge, by its id. */
interface NeatDiagramPart {
  readonly kind: 'block' | 'edge';
  readonly id: string;
}
/** A click on a part of a diagram: which part, and the click itself, for its modifier keys. */
interface NeatDiagramPick extends NeatDiagramPart {
  readonly event: MouseEvent;
}
/** How an edge's line is drawn. */
type NeatDiagramLine = 'solid' | 'dashed' | 'ghost';
/**
 * A short fact on a block, drawn as the kit's status chip in its tone.
 *
 * Where a part runs is said in one convention, so every diagram reads alike:
 * - `HW`, the hardware decoder, in `success`;
 * - `EV74` in `highlight`;
 * - `MLA` in `info`;
 * - `A65` in `neutral`.
 */
interface NeatDiagramChip {
  readonly label: string;
  readonly tone: NeatTone;
}
/**
 * One node of a diagram level: a group, block, band or bracket, as its `role` says.
 *
 * It is placed by hand at `x`, `y`, with the size `w` by `h`, in diagram units. A node with a
 * `parent` sits inside it, and is placed relative to it. A block with `opens` is a button that
 * opens that level. The kit never reads `data`: it is the app's, handed back to the app's
 * templates.
 */
interface NeatDiagramNode {
  readonly id: string;
  readonly label: string;
  /** A second line: what it is or where it runs. */
  readonly detail?: string;
  /** The node it sits in; `x` and `y` are relative to it. */
  readonly parent?: string;
  readonly x: number;
  readonly y: number;
  readonly w: number;
  readonly h: number;
  readonly role: NeatDiagramRole;
  /** Unset: `default`. */
  readonly look?: NeatDiagramLook;
  readonly chips?: readonly NeatDiagramChip[];
  /**
   * Whether what the card shows is stale, because the node's diagnostics stopped, say.
   *
   * The whole card, with its label, chips and the app's content, takes the look of `[neatStale]`:
   * faded and gray, with no transition. The hidden list says "stale". The app says in words why, in
   * the card's content. Blocks and brackets only.
   */
  readonly stale?: boolean;
  /** The id of the level (`NeatDiagramSet.levels`) this block opens. */
  readonly opens?: string;
  /**
   * The side its incoming (`inSide`) or outgoing (`outSide`) edges meet it on; unset, each edge
   * end goes on the side that faces the other end.
   */
  readonly inSide?: NeatDiagramSide;
  readonly outSide?: NeatDiagramSide;
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/**
 * A line between two nodes of a level, which the kit routes.
 *
 * The app does not place it, and only names the nodes it joins. Its color is a charts series
 * (`series`), its look `line`, and its ends `start` and `end`. It has an optional `label` on it.
 * The kit never reads `data`: it is the app's.
 */
interface NeatDiagramEdge {
  readonly id: string;
  /** The node it leaves. */
  readonly from: string;
  /** The node it enters. */
  readonly to: string;
  /** Its color, the charts' series color 1 to 8; unset, or on a `ghost` line, muted. */
  readonly series?: number;
  /** Unset: `solid`. */
  readonly line?: NeatDiagramLine;
  /** Its marker at `from`; unset, `none`. */
  readonly start?: NeatDiagramMarker;
  /** Its marker at `to`; unset, `arrow`. */
  readonly end?: NeatDiagramMarker;
  /** A short label on the edge, at `labelAt`. */
  readonly label?: string;
  /** Where the label sits along the edge, 0 at `from` to 1 at `to`; unset, 0.5. */
  readonly labelAt?: number;
  /**
   * The side of `from` this edge leaves on, over the node's `outSide`, for this edge only.
   *
   * Unset, it is the node's `outSide`, else the side facing the other end. The route and the label
   * follow it. An end inside a group stays on the group's border nearest the node, as the node's
   * sides do.
   */
  readonly fromSide?: NeatDiagramSide;
  /** The side of `to` this edge enters on, as `fromSide` is for the leaving end (`inSide`). */
  readonly toSide?: NeatDiagramSide;
  /**
   * Where along its side the edge leaves `from`: 0 at the side's start, its top or left, to 1 at
   * its end.
   *
   * Unset, the kit spreads the side's ports itself. The other ports on the side keep their places,
   * so two edges pinned to one place meet there.
   */
  readonly fromAt?: number;
  /** Where along its side the edge enters `to`, as `fromAt` is for the leaving end. */
  readonly toAt?: number;
  /**
   * The corners the edge runs through between its ports, in order.
   *
   * They are in the level's coordinates, as the level's top nodes are placed. The edge is drawn
   * straight from one to the next, with the kit's rounded turns. So corners in line with each other
   * give an axis-parallel route.
   *
   * Unset, the kit routes the edge itself. An edge with `via` is the app's: the kit spreads no
   * corridor or loop for it.
   */
  readonly via?: readonly {
    readonly x: number;
    readonly y: number;
  }[];
  /**
   * Where the label sits at its point (`labelAt`): `on` the line, or beside it.
   *
   * `on`, the default, has the line passing under the label. `above`, `below`, `left` and `right`
   * place it a small gap away, with the line showing past it.
   */
  readonly labelSide?: NeatDiagramLabelSide;
  /** Moves the label further, in diagram units, after `labelSide` has placed it. */
  readonly labelOffset?: {
    readonly x: number;
    readonly y: number;
  };
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/**
 * A box of the app's content, joined by a dotted leader to its anchor.
 *
 * Its content is a template, matched by the note's id or `data`. Its anchor is a point along its
 * edges, or a point of its own.
 *
 * A note anchored by `anchor` alone belongs to no edge, so it is never in focus with one. It dims
 * whenever anything is in focus.
 */
interface NeatDiagramNote {
  readonly id: string;
  /** The edges it is about; the anchor is the mean of their points at `along`. */
  readonly edges?: readonly string[];
  /** Where along its edges the anchor lies, 0 at their start to 1 at their end; unset, 0.5. */
  readonly along?: number;
  /**
   * The anchor as a point instead, such as a node's side, for a note about the node.
   *
   * Without `x`, it takes the edges' mean x, for a leader into the middle of a bundle of parallel
   * edges.
   */
  readonly anchor?: {
    readonly x?: number;
    readonly y: number;
  };
  /** The box's center, per axis; unset, the anchor moved by `dx` and `dy`. */
  readonly x?: number;
  readonly y?: number;
  readonly dx?: number;
  readonly dy?: number;
  /**
   * Where the leader meets the box: its nearest point, or its center.
   *
   * Unset, it meets the box's nearest point, level or upright where it can be. With `center`, it
   * meets the center, under the box, so a slanted leader meets no rounded corner.
   */
  readonly leaderTo?: 'center';
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/** One level: nodes, the edges between them and the notes on them. */
interface NeatDiagram {
  readonly nodes: readonly NeatDiagramNode[];
  readonly edges: readonly NeatDiagramEdge[];
  readonly notes?: readonly NeatDiagramNote[];
}
/**
 * A diagram with its drill-down levels, each placed by hand.
 *
 * A block whose `opens` names a level opens it, and a level may open further levels.
 */
interface NeatDiagramSet {
  readonly overview: NeatDiagram;
  readonly levels?: Readonly<Record<string, NeatDiagram>>;
}
interface Point {
  x: number;
  y: number;
}
/**
 * The corners of the edge from `source` (leaving through `sourceSide`) to `target` (entering
 * through `targetSide`), ends included. One turn when the sides are at right angles (an L), two
 * when they face each other (a Z, its middle run `jog` further along the way than halfway; 0
 * when the ports are level, a straight line), and stubs out of both ports when the target lies
 * behind the source. Edges that share a loop are drawn as parallel offsets of one another (the
 * layout's `spreadLoops`): a U goes `jog` further out than `STUB`, and a route behind its source
 * takes `stubs` more at each end and moves its run across `jog` (in the level's coordinates).
 */
declare function routePoints(source: Point, sourceSide: NeatDiagramSide, target: Point, targetSide: NeatDiagramSide, jog?: number, stubs?: readonly [number, number]): Point[];
/** A piece of a drawn edge: a straight run to `line`, or a turn (cubic bezier) to `curve[2]`. */
type Piece = {
  line: Point;
} | {
  curve: [Point, Point, Point];
};
/**
 * The corners rounded: each turn's legs are `bend` long, at most the shorter of its two runs
 * (half of a run between two turns, so neighboring turns never overlap).
 */
declare function roundCorners(points: Point[], bend?: number): Piece[];
/** The SVG path through a route's corners (`routePoints`), drawn in the rounded shape. */
declare function pathThrough(points: Point[]): string;
/** Points along the pieces from `start` (each turn in `steps` parts): the drawn shape, sampled. */
declare function sampleRoute(start: Point, pieces: Piece[], steps?: number): Point[];
/**
 * The point `t` of the way along the drawn shape of the route through `points` (its corners, as
 * `routePoints` gives them), by length: 0 at its start, 1 at its end, clamped. Measured on the
 * rounded shape rather than on the corners, so an edge label or a note's anchor near a turn sits
 * on the line that is drawn.
 */
declare function pointAlong(points: Point[], t: number): Point;
interface Rect extends Point {
  w: number;
  h: number;
}
/**
 * A box the message dots pass behind: a card, a note or an edge label. `corner` is its corner
 * radius as a share of the cards' (`--radius`); unset, 1.
 */
interface Cover extends Rect {
  readonly corner?: number;
}
/** An edge as drawn: its ports and their sides, and its route in the rounded shape. */
interface EdgeLayout {
  /**
   * Its port on `from`, in the level's coordinates, and the side of `from` it leaves through. An
   * edge between a group and a node inside it has its group end on the border nearest the node and
   * runs inward: that end's side is the way it runs (`top` for a port on the bottom border).
   */
  source: Point;
  sourceSide: NeatDiagramSide;
  /** Its port on `to` and the side of `to` it enters through (for a group, as above). */
  target: Point;
  targetSide: NeatDiagramSide;
  /** The SVG path of its rounded shape. */
  path: string;
  /** Its route's corners, ends included, along which `pointAlong` measures. */
  points: Point[];
}
/**
 * Each node's rectangle in the level's coordinates: its position plus those of the nodes it sits
 * in, however deep. A node whose parent is not on the level, or that lies inside itself, is left
 * out with what sits in it, so the rest of a broken diagram still draws; so is a node whose id an
 * earlier node already has.
 */
declare function absoluteRects(diagram: NeatDiagram): Map<string, Rect>;
/**
 * Per side: `t`, the way its ports are spread (offset grows along it), `n`, the way out of the
 * node.
 */
declare const SIDE_AXES: Record<NeatDiagramSide, {
  t: Point;
  n: Point;
}>;
/**
 * How far from a box's corner a straightened edge meets it at least, so a straight edge never
 * enters a rounded corner; boxes whose overlap leaves no room past their corners keep their Z. It
 * mirrors the theme's `--radius` (0.5 rem, 8 px at zoom 1), which the layout, being plain
 * TypeScript, cannot read: `layout.spec.ts` holds the two together.
 */
declare const CORNER = 8;
/**
 * Each edge as drawn, by id: its ends on the sides that face each other (or that its nodes name),
 * spread along each side so a fan does not cross itself, and its rounded route, Z routes that
 * share a corridor spread apart. An edge with an end that is not a node on the level (or one left
 * out), or whose id an earlier edge already has, is left out.
 */
declare function layoutEdges(diagram: NeatDiagram): Map<string, EdgeLayout>;
/**
 * The pairs of edges (by id) whose straight port-to-port lines cross: a measure of how tangled a
 * level reads (the drawn curves leave and enter their ports the same way).
 */
declare function crossings(diagram: NeatDiagram): [string, string][];
/** True when the segments p1-p2 and p3-p4 cross properly (touching does not count). */
declare function intersect(p1: Point, p2: Point, p3: Point, p4: Point): boolean;
/** A node as drawn. */
interface DrawnNode {
  readonly node: NeatDiagramNode;
  /** In the level's coordinates. */
  readonly rect: Rect;
  readonly look: NeatDiagramLook;
  /** A block whose `opens` names a level that exists: it shows the open affordance. */
  readonly opens: boolean;
  /** A bracket's brace, in its own box (`BRACE_HEIGHT` high); null for the other roles. */
  readonly brace: string | null;
}
/** An edge's marker: an arrowhead (a closed path) or a dot, at the edge's `start` or `end`. */
type DrawnMarker = {
  readonly end: 'start' | 'end';
  readonly shape: 'arrow';
  readonly d: string;
} | {
  readonly end: 'start' | 'end';
  readonly shape: 'dot';
  readonly cx: number;
  readonly cy: number;
  readonly r: number;
};
/** An edge as drawn. */
interface DrawnEdge {
  readonly id: string;
  /** The app's edge, for its tooltip's template and its words. */
  readonly edge: NeatDiagramEdge;
  readonly path: string;
  /** Its route's corners, ends included (`EdgeLayout.points`): what the messages sample. */
  readonly points: readonly Point[];
  /** The CSS color its line and markers take. */
  readonly color: string;
  readonly line: NeatDiagramLine;
  readonly markers: readonly DrawnMarker[];
  /**
   * Its label: the point it stands at (its route's point at `labelAt`, moved `LABEL_GAP` off the
   * line for a side and by `labelOffset`), and which of its edges or its middle is there: the
   * middle for `on`, its bottom edge for `above`, its top for `below`, its right for `left` and
   * its left for `right` (`.edge-label[data-side]`).
   */
  readonly label: {
    readonly text: string;
    readonly at: Point;
    readonly side: NeatDiagramLabelSide;
  } | null;
}
interface DrawnLevel {
  /** Groups and bands, drawn behind the edges; a group after the groups it sits in. */
  readonly behind: readonly DrawnNode[];
  /** Blocks and brackets, drawn in front of the edges. */
  readonly front: readonly DrawnNode[];
  readonly edges: readonly DrawnEdge[];
  /** Each drawn edge's layout, by id, which the notes are placed along. */
  readonly layouts: ReadonlyMap<string, EdgeLayout>;
}
/** How tall a bracket's brace is (diagram units); its label sits below it. */
declare const BRACE_HEIGHT = 18;
/**
 * The color of an edge without a series, or with one the palette lacks: its custom property's
 * name, which the messaging layer's dots resolve too, and the same for CSS.
 */
declare const MUTED_TOKEN = "--muted-foreground";
/**
 * The level as drawn. `levels` are the ids of the levels that exist, which a block's `opens`
 * must name to show the open affordance. A part the layout cannot place (an id that names
 * nothing) is left out, named once in dev mode, and the rest is drawn.
 */
declare function drawLevel(diagram: NeatDiagram, levels: ReadonlySet<string>): DrawnLevel;
/** How far a label beside its line stands off it, in diagram units. */
declare const LABEL_GAP = 4;
/** An edge label's corner radius as a share of the cards' (`.edge-label`: `--radius` / 2). */
declare const LABEL_CORNER = 0.5;
/**
 * The boxes the dots pass behind for the edge labels, in diagram units: each measured label's
 * border box (`sizes`, by edge id; at its point by its side, as `.edge-label[data-side]` is) with
 * the label's own corner radius, so a dot is hidden exactly where the label is drawn, as the edge's
 * line is under it. A label not measured yet has none.
 */
declare function labelCovers(edges: readonly DrawnEdge[], sizes: ReadonlyMap<string, {
  readonly w: number;
  readonly h: number;
}>): Cover[];
/**
 * The color of a line, an edge's or a legend sample's: its series' token, else the muted color.
 * A ghost is muted whatever its series: it is a part that does not run here, and stays quiet
 * beside the edges that do. `part` names what has the line in the dev-mode message.
 */
declare function lineColor(series: number | undefined, line: NeatDiagramLine | undefined, part: string): string;
/**
 * The palette index (from 0, as `NeatSeriesSwatch` and the kit's token rule count) of a diagram
 * series (from 1, as an edge's `series`): the one place the diagram converts between the two.
 * Null for a series that is not 1 to 8, which is named once in dev mode and drawn muted.
 */
declare function seriesIndex(series: number, part: string): number | null;
/** A drawn part in words, for the list that says the picture without it. */
interface DescribedPart {
  readonly id: string;
  readonly text: string;
}
/**
 * The level in words: each node by its label, detail and chips ("Decode, H.264, HW"), each edge
 * by its ends and label ("Camera to Decode, image"). Only what is drawn, so the words and the
 * picture say the same.
 */
declare function describeLevel(level: DrawnLevel): {
  readonly nodes: readonly DescribedPart[];
  readonly edges: readonly DescribedPart[];
};
/** A note as drawn: its box, the point it is about, and its leader (none under the box). */
interface NotePlacement {
  box: Rect;
  anchor: Point;
  /** From the anchor to the box; null while the anchor is under the box. */
  leader: [Point, Point] | null;
}
/**
 * Each note's placement, by id. `edges` are the level's laid-out edges (`layoutEdges`) and
 * `sizes` each note's measured box: a note not measured yet is not placed (the renderer places
 * it once it has its size). A note with nothing to anchor it is left out; an edge it names that
 * is not on its level is ignored, each named once. An edge on the level that the layout left
 * out is ignored quietly: the layout has named it.
 */
declare function placeNotes(diagram: NeatDiagram, edges: ReadonlyMap<string, EdgeLayout>, sizes: ReadonlyMap<string, {
  w: number;
  h: number;
}>): Map<string, NotePlacement>;
/** What the pointer or the keyboard is on. */
interface DiagramFocus {
  readonly kind: 'block' | 'edge';
  readonly id: string;
}
/** The parts that stay as they are while something is in focus; the rest is dimmed. */
interface FocusedParts {
  readonly nodes: ReadonlySet<string>;
  readonly edges: ReadonlySet<string>;
  readonly notes: ReadonlySet<string>;
}
/** The gap between the pointer and its tooltip, px on screen (the demo's). */
declare const TOOLTIP_GAP = 14;
/**
 * What `highlight` lets dim the diagram out of `focus`: nothing for `none`, an edge only for
 * `edges`, anything for `all`. The tooltip of an edge follows the pointer whatever this answers.
 */
declare function highlighted(focus: DiagramFocus | null, highlight: NeatDiagramHighlight): DiagramFocus | null;
/**
 * The parts in focus on `level`: a block with the edges that enter or leave it, an edge with the
 * nodes at its ends; with either, the notes on those edges. Null while nothing is in focus.
 */
declare function focusedParts(level: NeatDiagram, focus: DiagramFocus | null): FocusedParts | null;
/**
 * Where a tooltip of `size` goes for the pointer `at`, in a box of `box` (px from its corner): below
 * and right of the pointer, a gap away; on the other side on an axis where that leaves the box;
 * and pushed into the box where neither side has room, so it is never cut off.
 */
declare function placeTooltip(at: Point, size: {
  readonly w: number;
  readonly h: number;
}, box: {
  readonly w: number;
  readonly h: number;
}): {
  left: number;
  top: number;
};
/**
 * What the pointer and the keyboard put in focus on one diagram's box, found by delegation (the
 * parts' `data-node` and `data-edge`), so no listener runs per part. Created outside the zone; its
 * listeners write a signal only when what is in focus changes.
 */
declare class DiagramHover {
  private readonly box;
  /** The tooltip's element while it is rendered. */
  private readonly tooltip;
  private readonly pointer;
  /** The block whose open button has the focus. */
  private readonly keyboard;
  /** The pointer, px from the box's padding corner, for the tooltip. */
  private at;
  /** The pointer's part, else the keyboard's block. */
  readonly focus: import("@angular/core").Signal<DiagramFocus | null>;
  /** The edge whose tooltip shows: the one under the pointer. */
  readonly tooltipEdge: import("@angular/core").Signal<string | null>;
  constructor(box: HTMLElement,
  /** The tooltip's element while it is rendered. */
  tooltip: () => HTMLElement | undefined);
  /** Puts the tooltip by the pointer, inside the box. Called on each move and once it renders. */
  place(): void;
  /** Nothing is in focus: a new level has other parts. */
  clear(): void;
  destroy(): void;
  /**
   * The part under a mouse or a pen. Touch has no hover, and a held button is a drag of the
   * view, whose parts slide under the pointer: neither puts anything in focus.
   */
  private readonly over;
  private readonly leave;
  /**
   * An open button the keyboard focuses. A press on a block focuses its button too (d3-zoom lets
   * the press through), and after a pan from it the block would stay in focus with the rest
   * dimmed and no ring to say why; `:focus-visible` is the browser's word for the keyboard's.
   */
  private readonly focusIn;
  private readonly focusOut;
  /** `element` if it is one of this box's parts, not an ancestor of the box's. */
  private inBox;
}
/** What a block's template is given: the block. */
interface NeatDiagramBlockContext {
  readonly $implicit: NeatDiagramNode;
}
/** What the edge tooltip's template is given: the edge. */
interface NeatDiagramEdgeTooltipContext {
  readonly $implicit: NeatDiagramEdge;
}
/** What a note's template is given: the note. */
interface NeatDiagramNoteContext {
  readonly $implicit: NeatDiagramNote;
}
/**
 * The body of the diagram's blocks, below each block's label (the demo's live figures):
 *
 * ```html
 * <ng-template neatDiagramBlock let-node>
 *   @if (node.id === 'decode') { <span>{{ fps() }} fps</span> }
 * </ng-template>
 * ```
 *
 * The card keeps the node's size, so the app sizes the node's `h`, and `w`, for the body. A block
 * it renders nothing for keeps its card as it is.
 *
 * A bracket renders it too, after its label and detail, for the stage's live time over a row of
 * blocks, say. `node.role` tells the two apart, and a template that matches by id never meets the
 * other.
 */
export declare class NeatDiagramBlockTemplate {
  /**
   * @internal The template the diagram renders; apps never read it.
   */
  readonly template: TemplateRef<NeatDiagramBlockContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramBlockTemplate, context: unknown): context is NeatDiagramBlockContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramBlockTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramBlockTemplate, "ng-template[neatDiagramBlock]", never, {}, {}, never, never, true, never>;
}
/**
 * The content of the diagram's notes, in a box joined to its anchor by a dotted leader:
 *
 * ```html
 * <ng-template neatDiagramNote let-note>
 *   @if (note.id === 'rate') { <b>Camera → Decode</b> {{ rate() }} msg/s }
 * </ng-template>
 * ```
 *
 * A note it renders nothing for is not drawn, nor its leader; without the template no note is. A
 * note anchored by `anchor` alone belongs to no edge, so it dims whenever anything is in focus.
 */
export declare class NeatDiagramNoteTemplate {
  /**
   * @internal The template the diagram renders; apps never read it.
   */
  readonly template: TemplateRef<NeatDiagramNoteContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramNoteTemplate, context: unknown): context is NeatDiagramNoteContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramNoteTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramNoteTemplate, "ng-template[neatDiagramNote]", never, {}, {}, never, never, true, never>;
}
/**
 * The tooltip of the edge under the pointer, shown by the pointer.
 *
 * ```html
 * <ng-template neatDiagramEdgeTooltip let-edge>
 *   <b>{{ edge.label }}</b> {{ rate(edge.id) }} msg/s
 * </ng-template>
 * ```
 *
 * It is in the popover's colors, and kept inside the diagram's box. It follows a mouse or a pen,
 * never touch, which has no hover. An edge it renders nothing for shows no tooltip.
 *
 * It is hidden from assistive technology: the diagram's hidden list says each edge in words. So a
 * tooltip must not hold anything a reader needs that the list or a note does not say.
 */
export declare class NeatDiagramEdgeTooltipTemplate {
  /**
   * @internal The template the diagram renders; apps never read it.
   */
  readonly template: TemplateRef<NeatDiagramEdgeTooltipContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramEdgeTooltipTemplate, context: unknown): context is NeatDiagramEdgeTooltipContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramEdgeTooltipTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramEdgeTooltipTemplate, "ng-template[neatDiagramEdgeTooltip], ng-template[neatDiagramEdgeTip]", never, {}, {}, never, never, true, never>;
}
/**
 * The old name of `NeatDiagramEdgeTooltipTemplate`, kept so apps that import it keep working.
 *
 * @deprecated Use `NeatDiagramEdgeTooltipTemplate`; this name goes in a later release.
 */
export declare const NeatDiagramEdgeTipTemplate: typeof NeatDiagramEdgeTooltipTemplate;
/** @deprecated Use `NeatDiagramEdgeTooltipTemplate`; this name goes in a later release. */
export type NeatDiagramEdgeTipTemplate = NeatDiagramEdgeTooltipTemplate;
/**
 * A hand-placed diagram in the kit's look:
 *
 * ```html
 * <neat-diagram [diagram]="system" label="The demo's system" [(level)]="level">
 *   <ng-template neatDiagramNote let-note>…</ng-template>
 * </neat-diagram>
 * ```
 *
 * The app places every node. The kit routes the edges between them, and draws the whole.
 *
 * Groups and bands are drawn behind one SVG of edges. Blocks, brackets, edge labels and notes are
 * drawn in front of it. All of them sit in one container, which is what pan and zoom move.
 *
 * Every part is keyed by its id. So a new diagram object with the same content, from an app that
 * recomputes it on every poll, changes nothing in the DOM. A moved node is the same element, moved.
 * A part whose ids name nothing is left out and named once in dev mode. The rest is drawn.
 *
 * The host is a `figure` named by `label`. It fills the box the app gives it, and clips what lies
 * outside. Give it a bounded box: without a height it shows nothing.
 *
 * Chips are the kit's status chips. A block's body, the notes' content and the tooltip of the edge
 * under the pointer are the app's templates: `neatDiagramBlock`, `neatDiagramNote` and
 * `neatDiagramEdgeTooltip`. A visually hidden list after the drawing says the level's nodes and
 * edges in words.
 *
 * With `highlight` set, a part in focus stays as it is with what it is joined to, and the rest is
 * dimmed. The part is a block or an edge under the pointer, or a block whose open button has the
 * focus.
 *
 * `hovered` is that part, both ways, as the kit's rule for widget interaction has it. The diagram
 * sets it while the pointer or the keyboard is on a part, and null once they leave. The app may set
 * it, so a list beside the diagram can put a block in focus, shown as `highlight` allows.
 *
 * `activated` reports a click on a block or an edge. A block that opens a level is a button that
 * opens it, and the click opens it too.
 *
 * `level` is the path of open levels, which an app can bind to its route. The bar over the drawing
 * goes back and shows the path. A path that leads nowhere, such as a stale route, is cut to the
 * part that does, and the model is set to it. So render the diagram once its data is there: a
 * routed path is checked against the diagram given, a placeholder too.
 *
 * The user pans and zooms it by drag, wheel, pinch and double-click. With the box focused, the
 * arrow keys, `+`, `-` and `0` do too. It fits its level to the box by itself until the user pans
 * or zooms, and `fit()` fits it again.
 *
 * It takes the wheel and touch over its box (`touch-action: none`). So give it a bounded box, not
 * a long stretch of a scrolling page.
 *
 * A `neat-diagram-messages` projected into it draws the messages moving along its edges, over the
 * drawing. The diagram gives it the level, its edges, and the pan and zoom it draws by.
 */
export declare class NeatDiagramView {
  /** The overview and its drill-down levels. */
  readonly diagram: import("@angular/core").InputSignal<NeatDiagramSet>;
  /** The figure's accessible name: what the diagram shows. */
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * The path of open levels, ids of `diagram().levels`, each opened by a block of the level before
   * it; `[]` for the overview. Set by the open buttons, the back button and the breadcrumbs.
   */
  readonly level: import("@angular/core").ModelSignal<string[]>;
  /**
   * What dims the rest while something is under the pointer: `none`, `edges` or `all`.
   *
   * - `none`, the default, dims nothing. Dimming without a reason to look is noise that every pass
   *   of the pointer over the drawing makes.
   * - `edges` is for a drawing whose links are what the reader follows. The dim then says which
   *   blocks a link joins.
   * - `all` is for when a block's links are worth tracing too.
   *
   * An edge's tooltip shows whatever this is.
   */
  readonly highlight: import("@angular/core").InputSignal<NeatDiagramHighlight>;
  /**
   * The part in focus.
   *
   * It is the pointer's block or edge, or the keyboard's block, while they are on one, and null
   * once they leave. While they are on none, it is one the app sets.
   */
  readonly hovered: import("@angular/core").ModelSignal<NeatDiagramPart | null>;
  /** A click on a block or an edge (not a drag of the view): which part. */
  readonly activated: import("@angular/core").OutputEmitterRef<NeatDiagramPick>;
  protected readonly blockTemplate: import("@angular/core").Signal<NeatDiagramBlockTemplate | undefined>;
  protected readonly noteTemplate: import("@angular/core").Signal<NeatDiagramNoteTemplate | undefined>;
  private readonly edgeTooltipTemplate;
  private readonly noteSizes;
  private readonly labelSizes;
  private readonly content;
  private readonly edges;
  private readonly tooltipBox;
  private readonly bar;
  private readonly host;
  private readonly injector;
  private readonly zone;
  private zoom;
  /** The messaging layer's listeners for a new transform (`DiagramMessagesContext`). */
  private readonly transformListeners;
  private readonly hover;
  protected readonly BRACE_HEIGHT = 18;
  /** The look of `[neatStale]`, for a node with `stale`. */
  protected readonly staleClasses = "opacity-55 grayscale";
  private readonly walked;
  /** The path as far as it leads: the levels shown. */
  private readonly path;
  /** The level shown: the one at the end of the path. */
  private readonly shown;
  /**
   * Each level of the path as a crumb, named by the block that opens it: its label, and on the
   * last crumb (where the user is) its detail, muted.
   */
  protected readonly crumbs: import("@angular/core").Signal<{
    label: string;
    detail: string | undefined;
  }[]>;
  /** What the back button goes to: the level before this one, or the overview. */
  protected readonly backTo: import("@angular/core").Signal<string>;
  protected readonly drawn: import("@angular/core").Signal<DrawnLevel>;
  /** The level's notes, each drawn (and measured) only while the app has a note template. */
  protected readonly notes: import("@angular/core").Signal<import("@sima/neat-ui/diagram").NeatDiagramNote[]>;
  /** Where each measured note goes, by id. */
  protected readonly placements: import("@angular/core").Signal<Map<string, NotePlacement>>;
  /** What a fit frames: the level's nodes, edges and placed notes. */
  private readonly extent;
  /** The parts in focus while something is (the rest is dimmed); null while nothing is. */
  protected readonly focused: import("@angular/core").Signal<FocusedParts | null>;
  /** The tooltip of the edge under the pointer, while the app has a tooltip template. */
  protected readonly edgeTooltip: import("@angular/core").Signal<{
    template: import("@angular/core").TemplateRef<NeatDiagramEdgeTooltipContext>;
    edge: import("@sima/neat-ui/diagram").NeatDiagramEdge;
  } | null>;
  /** The level in words, for the hidden list. */
  protected readonly described: import("@angular/core").Signal<{
    readonly nodes: readonly DescribedPart[];
    readonly edges: readonly DescribedPart[];
  }>;
  constructor();
  /** Fits the level to the box, animated unless reduced motion; it then fits by itself again. */
  fit(): void;
  /**
   * What a messaging layer projected into the diagram draws by: the level shown (another path is
   * another level), its blocks, placed notes and edge labels as the cards dots pass behind (the
   * canvas lies over the whole drawing, so a dot would otherwise run through a label's text),
   * every edge id of the set, the edges in focus, and the transform with a hook for each change.
   */
  private messagesContext;
  /** A click on a block or an edge (d3-zoom swallows a drag's) reports it to the app. */
  protected onClick(event: MouseEvent): void;
  /** Opens the level `block` opens, one deeper than the level shown. */
  protected open(block: NeatDiagramNode): void;
  /** Goes back to the level before this one. */
  protected back(): void;
  /** Goes to the level at `index` of the path (a breadcrumb). */
  protected goTo(index: number): void;
  /**
   * The control pressed may leave with its level (an open button, the last level's breadcrumb,
   * the bar on the way to the overview); the focus then stays in the diagram, on its box, instead
   * of falling to the page.
   */
  private go;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramView, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramView, "neat-diagram", never, {
    "diagram": {
      "alias": "diagram";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "level": {
      "alias": "level";
      "required": false;
      "isSignal": true;
    };
    "highlight": {
      "alias": "highlight";
      "required": false;
      "isSignal": true;
    };
    "hovered": {
      "alias": "hovered";
      "required": false;
      "isSignal": true;
    };
  }, {
    "level": "levelChange";
    "hovered": "hoveredChange";
    "activated": "activated";
  }, ["blockTemplate", "noteTemplate", "edgeTooltipTemplate"], ["neat-diagram-messages"], true, never>;
}
/**
 * A labeled figure for a note of the diagram, such as a count or a time:
 *
 * ```html
 * <ng-template neatDiagramNote let-note>
 *   <neat-diagram-figure-card label="Active tracks" unit="alive" [value]="tracks()"
 *     [history]="trackHistory()" />
 * </ng-template>
 * ```
 *
 * It shows:
 * - the label;
 * - the value with its unit, and the caption at the end of that line;
 * - the history, as a sparkline, when it has one.
 *
 * Use it for a figure that is not an edge's rate. An edge's messages per second go in a
 * `NeatDiagramRateCard`, which looks the same, so a diagram's notes read as one set.
 *
 * The value eases to each new one as `NeatEasedNumber` does, in tabular digits, and "–" stands in
 * while there is none. The caption is words the app has already worded: "237 per second".
 *
 * The sparkline is named by the label and words its samples with the value's digits and unit:
 * "Active tracks: 30 recent samples, 2 alive to 8 alive". An empty history still draws its box, so
 * the card does not jump when the first samples arrive.
 *
 * The note supplies the card's box, with its border, fill and padding, so the card has none. Its
 * content is 11.5 rem wide.
 */
export declare class NeatDiagramFigureCard {
  /** What the figure is: "Active tracks", "MLA benchmark". */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The figure; null or undefined while there is none, which shows as "–". */
  readonly value: import("@angular/core").InputSignal<number | null | undefined>;
  /** Digits after the decimal point, for the value and the sparkline's words. */
  readonly digits: import("@angular/core").InputSignal<number>;
  /** The value's unit, after it: "alive", "ms per call". None by default. */
  readonly unit: import("@angular/core").InputSignal<string>;
  /** Words at the end of the value's line, muted: "237 per second". None by default. */
  readonly caption: import("@angular/core").InputSignal<string>;
  /**
   * The figure's recent values, oldest first, for a sparkline under the value; `null` for one that
   * was not taken. Without a history the card has no sparkline.
   */
  readonly history: import("@angular/core").InputSignal<readonly (number | null)[] | null | undefined>;
  /** A sample in the sparkline's words: the value's digits and its unit. */
  protected readonly format: import("@angular/core").Signal<NeatChartFormat>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramFigureCard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramFigureCard, "neat-diagram-figure-card", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "digits": {
      "alias": "digits";
      "required": false;
      "isSignal": true;
    };
    "unit": {
      "alias": "unit";
      "required": false;
      "isSignal": true;
    };
    "caption": {
      "alias": "caption";
      "required": false;
      "isSignal": true;
    };
    "history": {
      "alias": "history";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** One entry of a diagram's legend: what a series color or a line look stands for. */
interface NeatDiagramLegendItem {
  /** The series (1 to 8) whose color it names, as an edge's `series`; unset, muted. */
  readonly series?: number;
  /** The line look it names, as an edge's `line`; unset, the series' swatch instead. */
  readonly line?: NeatDiagramLine;
  readonly label: string;
}
/**
 * What a diagram's colors and lines stand for, as the Autoware demo's legend chip.
 *
 * ```html
 * <neat-diagram-legend [items]="[
 *   { series: 1, label: 'image' },
 *   { series: 4, label: 'results' },
 *   { line: 'ghost', label: 'not run here' },
 * ]" />
 * ```
 *
 * A series without a `line` shows the kit's `NeatSeriesSwatch` for it, as the charts' legends do.
 * Any other item shows a short sample of its line, solid when unset. The sample is drawn by the
 * edges' own rules, in the color its edges take. It is muted for a ghost, without a series, or for
 * a series that is not 1 to 8.
 *
 * Samples and swatches are `aria-hidden`: the label names what they stand for, and a color alone
 * is not a name.
 */
export declare class NeatDiagramLegend {
  /** The entries, in the order shown. */
  readonly items: import("@angular/core").InputSignal<readonly NeatDiagramLegendItem[]>;
  protected readonly drawn: import("@angular/core").Signal<{
    label: string;
    swatch: number | null;
    line: NeatDiagramLine;
    color: string | null;
  }[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramLegend, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramLegend, "neat-diagram-legend", never, {
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The level a block opens, placed from a diagram that holds the block's insides.
 *
 * ```ts
 * const set = { overview, levels: { detector: neatDrillDownLevel(pipeline, 'detector') } };
 * ```
 *
 * The block becomes the level's group, at the origin, sized to its children with a padding.
 * Everything inside the block, however deep, stays as placed: positions are relative to the
 * parent, so nothing moves.
 *
 * The nodes that the edges from inside reach go in a column left of the group (senders) and right
 * of it (receivers), centered on it vertically. A node that both sends and receives goes in the
 * senders' column only, so it is on the level once. The level holds the edges with an end inside.
 *
 * The outside nodes and the group get their sides afresh, since an overview's `inSide` and
 * `outSide` suit its placement, not this one. The group opens nothing: it is the level. The
 * diagram's notes are left behind, since they are placed for it.
 *
 * A block that is not on the diagram, or holds nothing, gives an empty level, named once.
 */
export declare function neatDrillDownLevel(diagram: NeatDiagram, blockId: string): NeatDiagram;
/**
 * How long a dot takes along an edge without a time of its own (`DotModel.travelMs`). Edges with a
 * length take length / speed (`travelTime`), so every dot moves at the same speed: the real
 * latency is a number, not the motion.
 */
declare const TRAVEL_MS = 1200;
/**
 * The shortest and longest time a dot takes along an edge: a tiny edge's dot stays visible long
 * enough to see; the longest is only a guard and must stay above every edge's length / speed, or
 * long edges run faster than the rest (the demo's 3 s cap made its widest edges 1.5x too fast).
 */
declare const MIN_TRAVEL_MS = 120;
declare const MAX_TRAVEL_MS = 20000;
/** How long a dot takes along an edge of `length` (diagram units) at `speed` (units per second). */
declare function travelTime(length: number, speed: number): number;
/** A dot's radius by its message's size: 2 up to 1 kB, +1.5 per tenfold, at most 7. */
declare function dotRadius(bytes: number): number;
/** A dot on its way this frame. The objects are the model's own and reused: read, do not keep. */
interface Dot {
  edge: string;
  /** How far along its edge, 0 to 1. */
  t: number;
  /** Its radius in diagram units. */
  r: number;
  /**
   * The caller's color, passed on to the step dots it starts: a whole number from 0 to 255, since
   * the pool keeps it in a byte (the layer's series 1 to 8 fit).
   */
  color: number;
}
/** Told every dot spawned (step dots too), with the time it starts and its message's bytes. */
type SpawnListener = (edge: string, atMs: number, bytes: number) => void;
/**
 * How many dots the model holds, on their way and waiting to start. A drill-down at 4 s travel
 * holds about 72 msg/s · 4 s · (1 + 2 + … + 6) ≈ 6000 (each step's dot waits for those before
 * it); the cap is what keeps a burst (thousands of pushes in one tick) from growing memory.
 */
declare const MAX_DOTS = 16384;
/**
 * How many dots one message may place, itself and its step dots together: a guard against steps
 * that loop, and against steps that fan out and loop, whose placements grow with every round. A
 * chain of the demo's size (six steps) is far inside it.
 */
declare const MAX_CHAIN = 32;
/**
 * A fixed pool of dots. `spawn` places a dot that starts at `atMs` (now, or soon: a batch spreads
 * its messages, see `neatBatchTimes`), `advance` gives the dots on their way at a time and forgets
 * those that arrived. A full pool drops its oldest dot and counts it in `dropped`: the newest
 * messages are the ones worth showing, and the listener still hears every spawn, so the rates
 * stay exact however many dots are dropped.
 *
 * The pool is a ring in placement order, so dropping the oldest is one step, not a shift of every
 * dot.
 *
 * Step dots (`setChain`): a dot on an edge that leads into a node's steps starts a dot on each
 * following step once it has arrived and that step's time has passed, and so on along the chain,
 * so the dots inside a node follow the real input's rhythm and the measured stage times. They are
 * placed at once, with their later start times, from the stage times of that moment.
 */
declare class DotModel {
  readonly capacity: number;
  private readonly onSpawn?;
  private readonly edges;
  private readonly starts;
  private readonly radii;
  private readonly colors;
  private readonly shown;
  private readonly out;
  private readonly frame;
  /** Where the oldest dot is in the ring. */
  private head;
  private count;
  /** How many of those are `shown` (placed with `visible`). */
  private shownCount;
  /** What the message being placed may still place, step dots included. */
  private budget;
  private next;
  private delayOf;
  private travel;
  /** Dots dropped, the oldest first, because the pool was full. */
  dropped: number;
  /** Dots placed with `visible`, step dots included. */
  spawned: number;
  /** How long a dot takes along an edge without an entry in `setTravel`. */
  travelMs: number;
  constructor(capacity?: number, onSpawn?: SpawnListener | undefined);
  /** Dots placed and not yet arrived, those still to start included. */
  get size(): number;
  /**
   * Dots placed with `visible` and not yet arrived, those still to start included: what a frame
   * is for. Dots placed hidden (`DotEvery`) are in `size` and not here.
   */
  get visibleSize(): number;
  /**
   * The step dots: `next` maps an edge id to the steps that follow it (`chainOf`), `delayMs` gives
   * a step's stage time, read when the dot before it is spawned.
   */
  setChain(next: ReadonlyMap<string, readonly string[]>, delayMs: (edge: string) => number): void;
  /** Each edge's travel time (ms, by edge id); applies to the dots on their way too. */
  setTravel(travel: ReadonlyMap<string, number>): void;
  /**
   * A message on `edge` that starts at `atMs`. A message whose time is not a finite number gets
   * no dot and is not told to the listener: it could never arrive, so it would hold a slot until
   * the pool dropped it, and no rate window holds it. With `visible` false (a message that gets
   * no dot, see `DotEvery`) it is placed all the same, with its step dots, so the listener counts
   * it, but `advance` does not return it.
   */
  spawn(edge: string, atMs: number, bytes: number, color?: number, visible?: boolean): void;
  /**
   * The dots on their way at `nowMs`, in the order they were placed (on one edge, the order they
   * started: the first is the furthest along); arrived ones are forgotten. Allocates nothing: the
   * array and its dots are the model's own, rewritten on the next call.
   */
  advance(nowMs: number): readonly Dot[];
  clear(): void;
  /** The ring position of the `k`th oldest dot. */
  private slot;
  /** The `n`th reused dot object, made the first time a frame holds that many. */
  private dotAt;
  private travelOf;
  private place;
}
/**
 * An edge drawn inside a block's drill-down, whose dots no message feeds.
 *
 * Its dots follow the dots that enter the step's `from` side, timed by a measured stage. The
 * layer's `steps` input maps an edge id to one of these.
 */
interface NeatDiagramMessageStep {
  /** The node whose stage times this step (the id the app passes to `stageMs`). */
  readonly from: string;
  /** The stage of `from` whose time a dot waits before it starts along this step. */
  readonly stage: string;
  /**
   * How many steps share the stage's time, each taking an even part, when one measured stage spans
   * several steps one after another. Unset: this step takes the whole stage.
   */
  readonly shares?: number;
}
/**
 * Which steps follow each edge, by edge id: an edge (fed or a step) is followed by the steps that
 * leave the node it enters. Edges that lead to no step are not in the
 * map; a step whose id is not among `edges` (a stale config) is not followed.
 */
declare function chainOf(edges: readonly Pick<NeatDiagramEdge, 'id' | 'from' | 'to'>[], steps: Readonly<Record<string, NeatDiagramMessageStep>>): Map<string, string[]>;
/**
 * The most a batch may spread its messages over. A batch is messages the app received together
 * that happened over a short time (the demo's gateway sent one every 50 ms); a stalled source's
 * batch spreads no wider than this, so its dots do not trail behind for seconds.
 */
declare const BATCH_SPREAD_MS = 200;
/**
 * The start times of a batch's messages, for an app whose transport delivers messages in batches.
 *
 * Pass each time as the `atMs` of its `push`, with `performance.now()` as the arrival:
 *
 * ```ts
 * const at = neatBatchTimes(batch.map((m) => m.sourceMs), performance.now());
 * batch.forEach((m, i) => messages.push(m.edge, m.bytes, at[i]));
 * ```
 *
 * The earliest message starts at the batch's arrival (`arrivalMs`). The others start after it, as
 * far apart as their own times (`offsetsMs`, on any clock in ms) say, at most 200 ms. A message
 * without a finite time of its own starts at the arrival.
 */
export declare function neatBatchTimes(offsetsMs: readonly number[], arrivalMs: number): number[];
/**
 * Which messages get a dot ("messages per dot", N): on each edge, every Nth message does, counted
 * per edge, so it is deterministic and one busy edge does not decide for the others. The first
 * message after a start or a change of N gets one, so a quiet edge shows a dot at once. The
 * messages in between still count in the rates (`DotModel.spawn` with `visible` false).
 */
declare class DotEvery {
  private every;
  private readonly seen;
  /** Sets N (a whole number, at least 1); a change starts every edge's count again. */
  set(n: number): void;
  /** Counts a message on `edge`; true when it gets a dot. */
  take(edge: string): boolean;
}
/** How the layer animates its dots: tuning only, the numbers count every message regardless. */
interface NeatDiagramMessageSettings {
  /** How fast a dot moves along any edge, in diagram units per second: a long edge takes longer. */
  readonly speed: number;
  /** A factor on each dot's radius (which grows with its message's size). */
  readonly size: number;
  /**
   * Messages per dot, a whole number.
   *
   * Each edge shows a dot for every Nth message on it, and 1 is every message. So a busy edge shows
   * gaps instead of a solid band.
   */
  readonly every: number;
}
/** The demo's settings: its median overview edge takes about 1.2 s at this speed. */
export declare const NEAT_DIAGRAM_MESSAGE_DEFAULTS: NeatDiagramMessageSettings;
/** An edge's messages and bytes per second over the last second, and its messages per second. */
interface NeatDiagramEdgeRate {
  readonly msgsPerSec: number;
  readonly bytesPerSec: number;
  /** Messages in each whole second before this one, oldest first, at most the last 60. */
  readonly history: readonly number[];
}
/** How long a message's mark shows at its edge's end under reduced motion. */
declare const MARK_MS = 400;
/**
 * The messages moving through a diagram, projected into it:
 *
 * ```html
 * <neat-diagram [diagram]="system" label="The demo's system">
 *   <neat-diagram-messages [steps]="steps" [settings]="settings()" />
 * </neat-diagram>
 * ```
 *
 * The app feeds it by id: `push(edgeId, bytes)` for each message on an edge, and
 * `stageMs(nodeId, stage, ms)` for the stage times its step dots take.
 *
 * A message on an edge drawn now is a dot along it, sized by its bytes. It takes as long on its
 * way as the edge's length at `speed`. With `every`, only every Nth message gets a dot. Its color
 * is its edge's, and `colors` picks another series.
 *
 * A step (`steps`, keyed by edge id) is an edge inside a block that no message feeds. A dot
 * arriving at its start goes on along it once the stage's time has passed, and so on along the
 * chain. So the dots inside a block follow its real input and its measured stages. The edges in
 * `passive`, fed edges or steps, end their messages where they enter, and start no steps.
 *
 * `rate(edgeId)` is the edge's messages and bytes per second, and its history, for the notes an
 * app fills. `rate(['a', 'b'])` is their sum, for a note over several edges. It is refreshed at
 * 12 Hz while something reads it.
 *
 * A push counts on any edge of any level, drawn or not, so a level opens with its numbers. The step
 * edges are the exception. They count only while their level is drawn and the page is visible,
 * since it is their dots that count them. An id that is no edge of the diagram is ignored, so the
 * rates' memory stays bounded by the diagram's edges.
 *
 * At most 16 384 dots exist at once, and the oldest are dropped past that. The rates still count
 * every message. A burst, such as 10 000 pushes in one tick, costs the cap's worth of dots, not the
 * burst's. So an app pushes each message as it arrives, and does not sample or drop any to protect
 * the page.
 *
 * All dots are drawn on one canvas over the drawing, at the device's pixel ratio. The canvas is
 * sized to this element's box, which fills the diagram's. The dots scale with the zoom, and lie
 * behind the cards and the edge labels. Dots of edges out of focus fade with them.
 *
 * The frames run only while a dot is on its way. They stop while the page is hidden, and its
 * messages then still count, without dots. Under reduced motion no dot travels: each message shows
 * as a brief mark at its edge's end.
 */
export declare class NeatDiagramMessages {
  /** The steps, keyed by edge id: whose stage times each and what follows it. */
  readonly steps: import("@angular/core").InputSignal<Readonly<Record<string, NeatDiagramMessageStep>>>;
  /**
   * Edges whose messages end where they enter, starting no step dots (a side input): fed edges
   * and steps alike.
   */
  readonly passive: import("@angular/core").InputSignal<readonly string[]>;
  /** A series (1 to 8) per edge id for its dots, in place of the edge's own color. */
  readonly colors: import("@angular/core").InputSignal<Readonly<Record<string, number>>>;
  /**
   * The British spelling of `colors`, kept so apps that bind it keep working; `colors` wins for an
   * edge both name.
   *
   * @deprecated Use `colors`; this name goes in a later release.
   */
  readonly colours: import("@angular/core").InputSignal<Readonly<Record<string, number>>>;
  /**
   * How the dots animate: speed, size, messages per dot and whether they follow the steps. The
   * rates and counts do not depend on it. Defaults to `NEAT_DIAGRAM_MESSAGE_DEFAULTS`; give the
   * `neat-diagram-animation-settings` panel's model to let the user tune it.
   */
  readonly settings: import("@angular/core").InputSignal<NeatDiagramMessageSettings>;
  private readonly diagram;
  private readonly probe;
  private readonly host;
  private readonly document;
  private readonly zone;
  private readonly canvasElement;
  /** Read again on a scheme change, so the next frame paints the new colors. */
  private readonly theme;
  private readonly palette;
  /** Read by the canvas once it has a box to draw in: resolving the colors draws on a canvas. */
  private readonly readPalette;
  private readonly rates;
  /** The rates hear every dot placed, step dots and dots the pool drops included. */
  private readonly model;
  /** When the push under way was made, for the rates: its step dots start later than that. */
  private pushedAt;
  private readonly every;
  /** The latest stage times, by node and stage. */
  private readonly stages;
  /**
   * Under reduced motion, each drawn edge's latest message, shown at its end: by edge, and in a
   * list for the frames (an array's for-of is optimized away; a Map's iterator would be an object
   * per frame).
   */
  private readonly marks;
  private readonly markList;
  private marksUntil;
  /** Its `matches` is read at each frame, so a setting changed on an open page applies. */
  private readonly motion;
  private canvas;
  private frame;
  /** The latest time drawn for, so a frame never goes back. */
  private lastNow;
  private destroyed;
  /** What the model was last given: the level's key, its chain and travel times. */
  private levelKey;
  private chainGiven;
  private travelGiven;
  /** Ticks at 12 Hz while the rates are read (`rate`); each rate signal reads it. */
  private readonly numbers;
  private numbersTimer;
  /** Whether a rate signal was read since the last tick. */
  private numbersRead;
  private readonly rateSignals;
  /** Each drawn edge's shape, sampled once per layout (a new level value). */
  private readonly geometry;
  private readonly speed;
  private readonly travel;
  /** What follows each drawn edge: the steps leaving the node it enters, unless it is passive. */
  private readonly chain;
  private readonly edgeColors;
  constructor();
  /**
   * A message of `bytes` on `edgeId`, starting at `atMs`.
   *
   * `atMs` is on the `performance.now()` clock: now by default, or a little later to spread a batch
   * received together. The message counts in the edge's rate, and is drawn as a dot while the edge
   * is drawn. A push for a level not drawn only counts.
   *
   * A size that is not a number counts as no bytes. An id that is no edge of the diagram is
   * ignored.
   */
  push(edgeId: string, bytes: number, atMs?: number): void;
  /**
   * The time `stage` of `nodeId` takes now, in ms: what a step dot timed by it waits before it
   * starts (`steps`). A time that is not a number, or below 0, forgets the stage's time.
   */
  stageMs(nodeId: string, stage: string, ms: number): void;
  /**
   * `edgeIds`' messages and bytes per second over the last second, and their history.
   *
   * It is refreshed at 12 Hz while something reads it, such as a template or an effect. It is the
   * same signal for the same id or list of ids.
   *
   * Several ids give the sum: the rates added, and the histories added second by second from the
   * newest. So an edge whose messages began later adds nothing before its first second. An id twice
   * counts once. An id that is no edge counts nothing.
   */
  rate(edgeIds: string | readonly string[]): Signal<NeatDiagramEdgeRate>;
  /**
   * Keeps the 12 Hz tick going while the rates are read. A tick nobody read since the last stops
   * it; the tick left the signals stale, so the next read computes afresh and starts it again.
   */
  private numbersWanted;
  /**
   * Gives the model what the level and the inputs say, when they have changed: another level
   * clears the dots (its edges are other edges), the chain and the travel times follow the
   * layout and the settings. Answers the drawn edges' shapes. Called by each push and frame, so
   * a push right after a change of level already goes by the new one.
   */
  private sync;
  /** A step's wait: its stage's latest time, split evenly over the steps that share it. */
  private readonly stageDelay;
  private mark;
  private clear;
  /** Read at each push and frame, so a setting changed on an open page applies. */
  private reduced;
  /**
   * Whether a dot or a mark still has to be drawn after `now`. Dots the model holds for the rates
   * only (messages without a dot, see `every`) draw nothing, so only its visible ones count. Under
   * reduced motion only marks are: the model's dots are placed all the same (the rates hear them,
   * step dots included), but nothing draws them, so they keep no frames running; the first frame
   * with motion again forgets those that have arrived since.
   */
  private busy;
  private cancel;
  /** A frame, unless one is coming, the page is hidden or the layer is gone. */
  private request;
  /** A new transform or box: drawn again in the next frame, if anything is on the canvas. */
  private readonly wake;
  private readonly visibility;
  private readonly tick;
  /** This frame's dots or marks; null while there is nothing to draw on. */
  private draw;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramMessages, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramMessages, "neat-diagram-messages", never, {
    "steps": {
      "alias": "steps";
      "required": false;
      "isSignal": true;
    };
    "passive": {
      "alias": "passive";
      "required": false;
      "isSignal": true;
    };
    "colors": {
      "alias": "colors";
      "required": false;
      "isSignal": true;
    };
    "colours": {
      "alias": "colours";
      "required": false;
      "isSignal": true;
    };
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * `raw` as message settings, for the parse of an app's `neatStoredSignal`.
 *
 * ```ts
 * readonly settings = neatStoredSignal('app.dots', NEAT_DIAGRAM_MESSAGE_DEFAULTS,
 *   neatParseMessageSettings);
 * ```
 *
 * It keeps the known keys of the right type, and clamps the numbers to the sliders' range, with
 * `every` rounded to a whole number. The rest take `defaults`, the kit's unless the app gives its
 * own. So a stored signal reads whatever an older version wrote.
 *
 * An app with defaults of its own gives them here too, as it gives them to the panel's
 * `defaults`:
 *
 * ```ts
 * const DOTS = { ...NEAT_DIAGRAM_MESSAGE_DEFAULTS, speed: 140 };
 * readonly settings = neatStoredSignal('app.dots', DOTS, (raw) =>
 *   neatParseMessageSettings(raw, DOTS));
 * ```
 */
export declare function neatParseMessageSettings(raw: unknown, defaults?: NeatDiagramMessageSettings): NeatDiagramMessageSettings;
/**
 * The Animation panel for `neat-diagram-messages`: sliders for the dots, behind an icon button.
 *
 * ```html
 * <neat-diagram-animation-settings [(settings)]="dots" />
 * <neat-diagram-messages [settings]="dots()" />
 * ```
 *
 * The sliders set the dots' speed, size and messages per dot, and a reset returns them to
 * `defaults`. Dots always go on through the blocks' steps, where a diagram has them.
 *
 * `settings` is the model both ways, and changes apply as the sliders move. The panel keeps
 * nothing. An app that remembers the choice per browser makes the model a `neatStoredSignal`,
 * parsed by `neatParseMessageSettings`. Place it in a toolbar or beside the diagram.
 *
 * An app whose dots start otherwise than the kit's gives its starting settings as `defaults`, so
 * a reset returns to them:
 *
 * ```html
 * <neat-diagram-animation-settings [(settings)]="dots" [defaults]="calm" />
 * ```
 */
export declare class NeatDiagramAnimationSettings {
  /** The dots' tuning; what the sliders write, and the layer's `settings`. */
  readonly settings: import("@angular/core").ModelSignal<NeatDiagramMessageSettings>;
  /**
   * What the reset returns to: the app's starting settings, `NEAT_DIAGRAM_MESSAGE_DEFAULTS` unless
   * it gives its own.
   */
  readonly defaults: import("@angular/core").InputSignal<NeatDiagramMessageSettings>;
  protected readonly limits: {
    readonly speed: {
      readonly min: 50;
      readonly max: 1000;
      readonly step: 10;
    };
    readonly size: {
      readonly min: 0.5;
      readonly max: 2;
      readonly step: 0.1;
    };
    readonly every: {
      readonly min: 1;
      readonly max: 10;
      readonly step: 1;
    };
  };
  protected set(change: Partial<NeatDiagramMessageSettings>): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramAnimationSettings, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramAnimationSettings, "neat-diagram-animation-settings", never, {
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
    "defaults": {
      "alias": "defaults";
      "required": false;
      "isSignal": true;
    };
  }, {
    "settings": "settingsChange";
  }, never, never, true, never>;
}
/**
 * An edge's live numbers, for a note of the diagram:
 *
 * ```html
 * <ng-template neatDiagramNote let-note>
 *   <neat-diagram-rate-card label="Tracker → Gateway" [rate]="messages.rate('tracker-gateway')()"
 *   />
 * </ng-template>
 * ```
 *
 * It shows:
 * - the label;
 * - the messages per second, whole;
 * - the megabytes per second, to two decimals, from the bytes in units of 10 kB;
 * - the history, as a sparkline named for its messages per second.
 *
 * Give it `rate(['a', 'b'])` for a note over several edges: the card shows their sum.
 *
 * `showBytes` false leaves the megabytes out, for an app that pushes no sizes. Its messages all
 * count 0 bytes, which would read "0.00 MB/s". The messages and the sparkline stay.
 *
 * `stageMs`, a block step's stage time, swaps the megabytes and the sparkline for the time in
 * milliseconds, to a tenth. The dots of a step are made up, so they have no sizes. The stage line
 * says "Stage". An app that wants the stage's name in it puts the name in `label`.
 *
 * Anything an app wants between the label and the numbers goes in the `[neatRateCardThumbnails]`
 * slot, which the app lays out itself. The latest image of a camera is one.
 *
 * A figure that is not a rate, such as a count or a time, goes in a `NeatDiagramFigureCard`. The
 * two cards look the same, so a diagram's notes read as one set.
 *
 * The note supplies the card's box, with its border, fill and padding, so the card has none. Its
 * content is 11.5 rem wide, or as wide as its stage line needs when it shows one.
 */
export declare class NeatDiagramRateCard {
  /** What the numbers are of: the edge's or the step's name. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The edge's rate, or the sum over several: `NeatDiagramMessages.rate(edgeIds)`'s value. */
  readonly rate: import("@angular/core").InputSignal<NeatDiagramEdgeRate>;
  /**
   * The stage time of a step, in ms: the card then shows it in place of the megabytes and the
   * sparkline. A value that is not a number, or below 0, is no stage time.
   */
  readonly stageMs: import("@angular/core").InputSignal<number | undefined>;
  /**
   * Whether the megabytes per second show. False for an app that pushes no sizes, so the card
   * does not say "0.00 MB/s". A step's stage time shows in place of the megabytes either way.
   */
  readonly showBytes: import("@angular/core").InputSignal<boolean>;
  protected readonly perSecond: (value: number) => string;
  protected readonly msgs: import("@angular/core").Signal<string>;
  /** Bytes per second as megabytes, in hundredths: units of 10 kB, as the demo shows them. */
  protected readonly megabytes: import("@angular/core").Signal<string>;
  /** The stage time as shown, or null while the card has none. */
  protected readonly stage: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramRateCard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramRateCard, "neat-diagram-rate-card", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "rate": {
      "alias": "rate";
      "required": true;
      "isSignal": true;
    };
    "stageMs": {
      "alias": "stageMs";
      "required": false;
      "isSignal": true;
    };
    "showBytes": {
      "alias": "showBytes";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[neatRateCardThumbnails]"], true, never>;
}
export type { NeatDiagram, NeatDiagramChip, NeatDiagramEdge, NeatDiagramEdgeRate, NeatDiagramHighlight, NeatDiagramLabelSide, NeatDiagramLegendItem, NeatDiagramLine, NeatDiagramLook, NeatDiagramMarker, NeatDiagramMessageSettings, NeatDiagramMessageStep, NeatDiagramNode, NeatDiagramNote, NeatDiagramPart, NeatDiagramPick, NeatDiagramRole, NeatDiagramSet, NeatDiagramSide, NeatDiagramTip };