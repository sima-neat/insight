import * as i0 from "@angular/core";
/**
 * A data table's look, on a native `table` whose rows and cells the app writes.
 *
 * ```html
 * <table neatTable aria-label="Metrics of the run">
 *   <thead>
 *     <tr><th scope="col">Metric</th><th scope="col" neatNumeric>Mean</th></tr>
 *   </thead>
 *   <tbody>
 *     <tr><th scope="row">Power</th><td neatNumeric>12.5 W</td></tr>
 *   </tbody>
 * </table>
 * ```
 *
 * The table is full width, with a rule under every row and its column headings muted and small.
 *
 * It sets the look only. The columns and what a cell holds are the app's. So is how a table gives
 * up a column when its container is narrow: the kit cannot know the container, or which columns
 * matter.
 * The table's name for assistive technology is the app's too (`aria-label`).
 */
export declare class NeatTable {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTable, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTable, "table[neatTable]", never, {}, {}, never, never, true, never>;
}
/**
 * A figure's cell or heading in a `neatTable`, on one line with tabular digits, not end-aligned.
 *
 * Put it on a `th` or `td`. The figures of a column line up, and the cell starts where any cell
 * does. Use it where the figures cannot end-align, such as a cell that holds something after the
 * figure. Otherwise use `neatNumeric`.
 *
 * It only marks the cell. The look is the table's, which is why the cell does nothing outside one.
 */
export declare class NeatFigure {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatFigure, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatFigure, "td[neatFigure], th[neatFigure]", never, {}, {}, never, never, true, never>;
}
/**
 * A figure's cell or heading as `neatFigure`, end-aligned as well. Put it on a column's heading
 * as well as on its cells so that the heading sits over the figures. It marks the cell as a
 * figure itself, so the cell needs no `neatFigure` beside it.
 */
export declare class NeatNumeric {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNumeric, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatNumeric, "td[neatNumeric], th[neatNumeric]", never, {}, {}, never, never, true, never>;
}