import * as i0 from "@angular/core";
import { ElementRef } from "@angular/core";
/**
 * What a bubble points at: an element, an `ElementRef` (a template reference to a component), or
 * several elements, which it treats as the one box around them all (the lines of a passage).
 */
type NeatBubbleAnchor = Element | ElementRef<Element> | readonly Element[];
/** A box in the viewport's coordinates, as CDK's overlay takes an origin. */
interface ViewportBox {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}
/** The elements of `anchor` that are in the document, none for no anchor. */
declare function anchorElements(anchor: NeatBubbleAnchor | null | undefined): readonly Element[];
/** The smallest box around `boxes`, null for none. */
declare function unionBox(boxes: readonly ViewportBox[]): ViewportBox | null;
/** Where a bubble's tail sits: the side of the anchor the bubble is on. */
type TailSide = 'top' | 'right' | 'bottom' | 'left';
/**
 * Where along the bubble's edge its tail points, in px from the edge's start: at the anchor's
 * middle, kept `inset` from the bubble's ends so the tail stays clear of its rounded corners.
 */
declare function tailAt(side: TailSide, anchor: ViewportBox, bubble: ViewportBox, inset: number): number;
/** The side of its anchor a bubble prefers: it takes another where this one has no room. */
type NeatBubbleSide = TailSide;
/**
 * A speech bubble that points at what it explains: the content inside the element, on the panel
 * surface of a popover, with a tail toward its `anchor`.
 *
 * ```html
 * <button #help neatButton type="button" (click)="open.set(!open())">What is a pipeline?</button>
 * <neat-bubble [anchor]="open() ? help : null" side="right">
 *   A pipeline is the chain of nodes a frame runs through.
 * </neat-bubble>
 * ```
 *
 * For a note on a part of the page: a step of a walk through code, a remark on a figure, a pointer
 * to a control. It shows while it has an anchor: null hides it, so the app decides when, and it
 * may move to another anchor while it shows. It is not a tooltip, which repeats a control's name
 * in the inverted look while the control is hovered or focused, nor a popover, which a trigger
 * opens and which holds controls.
 *
 * It sits beside its anchor, on the `side` it prefers (`top` by default), and takes the side across
 * from it, then another, where that has no room. It stays in the window, and its tail moves along
 * its edge to keep pointing at the anchor's middle. An anchor of several elements is the one box
 * around them. It follows its anchor as the page scrolls or a box around the anchor does, and hides
 * while the anchor is scrolled out of view.
 *
 * It is drawn in the overlay above the page, not where the element stands, so a card or a scrolling
 * box does not clip it. A screen reader meets it there, at the end of the page: point at it from
 * what it explains with `aria-describedby` and its `id` where that takes the focus. `hover` says
 * when a mouse or a pen comes onto it and leaves it, for a bubble shown on hover that should stay
 * while the pointer moves onto it.
 */
export declare class NeatBubble {
  /** What the bubble points at, a `NeatBubbleAnchor`: it shows while there is one. */
  readonly anchor: import("@angular/core").InputSignal<NeatBubbleAnchor | null>;
  /** The side of the anchor the bubble prefers, a `NeatBubbleSide`. */
  readonly side: import("@angular/core").InputSignal<TailSide>;
  /** Whether a mouse or a pen is over the bubble, each time that changes. */
  readonly hover: import("@angular/core").OutputEmitterRef<boolean>;
  /** The bubble's id, for an `aria-describedby` on what it explains. */
  readonly id: string;
  protected readonly classes: string;
  private readonly panel;
  private readonly overlay;
  private readonly containers;
  private readonly zone;
  private ref;
  private strategy;
  private placed;
  private stopTracking;
  constructor();
  protected pointer(event: PointerEvent, over: boolean): void;
  private show;
  private hide;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatBubble, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatBubble, "neat-bubble", never, {
    "anchor": {
      "alias": "anchor";
      "required": false;
      "isSignal": true;
    };
    "side": {
      "alias": "side";
      "required": false;
      "isSignal": true;
    };
  }, {
    "hover": "hover";
  }, never, ["*"], true, never>;
}
export type { NeatBubbleAnchor, NeatBubbleSide };