import { Signal } from "@angular/core";
import { NeatEncodedFrames, NeatTileSource } from "@sima/neat-ui/video";
/** Where the connection posts its offer, how long the browser holds the video, and its log. */
interface InsightConnectionOptions {
  /** The address the offer is posted to, as is. */
  readonly offerUrl: string;
  /**
   * The receiver's `jitterBufferTarget` in ms, and the hold of each JPEG frame; unset leaves the
   * receiver alone and holds no frame.
   */
  readonly videoBufferMs?: number;
  /** Told each step of the connection, for an app's debug log; unset logs nothing. */
  readonly log?: (event: string, details?: unknown) => void;
}
/**
 * What arrives on a connected channel, sampled once a second.
 *
 * For a channel Insight sends as JPEG frames, the codec is "JPEG", the size is the latest whole
 * frame's (from its JPEG header), the rate counts whole frames received, and the bitrate counts
 * every chunk's bytes received, those of frames that never complete included.
 */
interface NeatInsightVideoStats {
  /**
   * The video's codec as the browser names it ("H264", "H265", "VP8"), "JPEG" for frames, or null
   * before it says.
   */
  readonly codec: string | null;
  /**
   * The frame's size in pixels, or null before the browser reports it (for frames, before the
   * first whole frame).
   */
  readonly width: number | null;
  readonly height: number | null;
  /** Decoded frames (or whole frames received) per second, or null before there is a rate. */
  readonly framesPerSecond: number | null;
  /** The video's bitrate over the last second, in bits per second. */
  readonly bitsPerSecond: number;
}
/** What the connection reports, each call a change (or the same value again). */
interface InsightConnectionEvents {
  /** The channel's video once a track arrives, null when the connection is dropped. */
  stream(stream: MediaStream | null): void;
  /**
   * A new run of the channel's frames on the connection's first `jpeg` chunk, null when the
   * connection is dropped.
   */
  frames(frames: NeatEncodedFrames | null): void;
  /** While retrying after an answer that says why, a short text saying so; null otherwise. */
  waiting(text: string | null): void;
  /** Why the connection stopped for good; called once, after which nothing else is reported. */
  failure(text: string): void;
  /** The mean jitter-buffer delay per frame, or the frames' mean hold, over the last second, or null. */
  videoDelayMs(ms: number | null): void;
  /** What arrives, once a second while connected; null without a connected peer. */
  stats(stats: NeatInsightVideoStats | null): void;
  /** A text message of the `metadata` data channel, `receivedAt` on `performance.now()`. */
  metadata(text: string, receivedAt: number): void;
}
/** An open connection: closed for good with `close`, its video buffer changed at any time. */
interface InsightConnection {
  /** Closes the connection for good; calling it again does nothing. */
  close(): void;
  /** Holds the video for `ms` from now on, this connection and the ones that replace it. */
  setVideoBufferMs(ms: number | undefined): void;
}
/** Starts connecting at once. */
declare function openInsightConnection(options: InsightConnectionOptions, events: InsightConnectionEvents): InsightConnection;
/** Where a `neatInsightChannel` posts its offer, how long the browser holds the video, its log. */
interface NeatInsightChannelOptions {
  /**
   * Where the browser's WebRTC offer is posted: Insight's own route,
   * `/api/channels/{channel}/offer`, by default.
   *
   * That default fits a page Insight serves itself. Insight refuses an offer that a page of
   * another origin sends, so an app served by its own server relays the offer through it and gives
   * that address here. A string is posted to as it is; a function gets the channel:
   *
   * ```ts
   * neatInsightChannel(0, { offer: (channel) => `/api/offer?channel=${channel}` });
   * ```
   *
   * The relay posts the offer to Insight's route and answers with Insight's answer, its errors
   * included.
   */
  readonly offer?: string | ((channel: number) => string);
  /**
   * How long the video is held before it shows a frame, in ms, so each frame's metadata has
   * arrived when it is drawn.
   *
   * For a stream it sets the receiver's `jitterBufferTarget`. A signal is followed while the
   * channel is open, so a setting can change it without a new connection. Unset, or in a browser
   * without `jitterBufferTarget` (Firefox, see `videoBufferSupported`), the browser shows each
   * stream frame as soon as it can. A channel that arrives as JPEG frames is held by the kit
   * itself, in every browser: each frame's `presentAt` is its arrival plus this, and a change
   * applies to the frames that arrive after it.
   */
  readonly videoBufferMs?: number | Signal<number>;
  /**
   * Told each step of the connection (connecting, answered, track, frames (the first chunk: a JPEG channel), a connection state, a
   * retry and why, a failure, closed), with its details, for an app's debug log. Unset logs nothing.
   *
   * It is called outside Angular, so it should only log.
   */
  readonly log?: (event: string, details?: unknown) => void;
}
/**
 * One Insight channel's video and metadata over WebRTC, as `neatInsightChannel` gives it: a
 * `NeatTileSource` with what an app shows about the connection.
 */
interface NeatInsightChannel extends NeatTileSource {
  /**
   * What keeps the channel from showing, in a few words, or null while all is well. For the
   * tile's `notice`.
   *
   * While it retries after an answer that says why, it says so: "Waiting for video" (the channel
   * has none yet), "Video format changed", "Insight not reachable" or "Could not connect". Once
   * the offer is refused for good it is `failure`.
   */
  readonly notice: Signal<string | null>;
  /**
   * Null while the channel is connected or still trying; why it stopped once the offer was
   * refused for good.
   *
   * A 4xx answer is final: "Codec not supported by this browser" for a 415, else the answer's own
   * message, or "Connection failed: HTTP 404" when it has none. A browser without WebRTC fails at
   * once. Show it in the page's text as well, such as in a callout: the tile does not announce
   * its notice.
   */
  readonly failure: Signal<string | null>;
  /**
   * The mean time in ms each frame was held over the last second: in the browser's jitter buffer
   * for a stream, and for JPEG frames the hold the kit gave them (`videoBufferMs`, measured).
   *
   * It is measured once a second. It is null without a connection or without new frames in that
   * second.
   */
  readonly videoDelayMs: Signal<number | null>;
  /**
   * What arrives on the channel (`NeatInsightVideoStats`: codec, frame size, frame rate,
   * bitrate), measured once a second while it is connected; null while it is not.
   *
   * For JPEG frames the codec is "JPEG", the size is the latest whole frame's (null before the
   * first whole frame), the rate counts whole frames, and the bitrate counts every chunk received,
   * those of frames that never complete too.
   */
  readonly stats: Signal<NeatInsightVideoStats | null>;
  /**
   * The channel's pictures as JPEG frames: a new run when the connection's first chunk arrives,
   * null when the connection is dropped, as `stream` is.
   *
   * A connection plays one or the other: once a chunk has arrived, an earlier stream is withdrawn
   * and a later track is not shown, so `stream` and `frames` are never both set, also against an
   * upstream Insight that answers the video with a track that carries nothing.
   */
  readonly frames: Signal<NeatEncodedFrames | null>;
  /**
   * Whether the video can be held for `videoBufferMs`: true where the browser has the receiver's
   * `jitterBufferTarget` (not Firefox), and while the channel plays frames, which the kit holds
   * itself in every browser. False otherwise, where each frame shows as soon as it can.
   */
  readonly videoBufferSupported: Signal<boolean>;
  /**
   * Closes the connection for good, before its injection context is destroyed, such as to open
   * another channel in its place. Calling it again does nothing.
   */
  close(): void;
}
/**
 * One Insight channel's video and metadata over WebRTC, as a source for `neat-video-tile`.
 *
 * ```ts
 * protected readonly camera = neatInsightChannel(0);
 * ```
 *
 * ```html
 * <neat-video-tile [source]="camera" [notice]="camera.notice()" />
 * ```
 *
 * Call it in an injection context. It starts connecting at once and closes the connection when
 * that context is destroyed, with the component that created it. To open a channel later, such
 * as once a setting is read, call it inside `runInInjectionContext` with the component's
 * injector, and `close` the one it replaces.
 *
 * The connection is the one Insight's own viewer makes. The browser posts its offer to `offer`
 * and applies the answer. It receives the video and the `metadata` data channel, whose messages
 * the tile draws. A channel Insight sends as JPEG arrives on the `jpeg` data channel, as
 * chunks of whole frames, which the connection joins and gives as `frames`. The connection runs
 * outside Angular, and only its signals reach the page.
 *
 * It keeps trying until it is closed. A failed post, or a connection that fails, is tried again
 * after 1, 2 and 5 s, then every 10 s, and a connection that comes up starts that count again.
 * A connection that decodes no new frame for 5 s, or stays disconnected that long, is made anew.
 * This is how it recovers when the pipeline restarts. A 4xx answer is final, and `failure` says
 * why. Once frames arrived, the `jpeg` data channel closing is a failed connection too and is
 * tried again the same way. The stall rule applies to a stream: a connection playing frames needs no decoder, so its
 * silence rebuilds nothing, and only 5 s of "disconnected" does.
 */
export declare function neatInsightChannel(channel: number, options?: NeatInsightChannelOptions): NeatInsightChannel;
export type { NeatInsightChannel, NeatInsightChannelOptions, NeatInsightVideoStats };