import { NeatIconName } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/** One choice of a `neat-segmented`: its value, its label and an optional icon before the label. */
interface NeatSegmentedOption<T> {
  readonly value: T;
  readonly label: string;
  readonly icon?: NeatIconName;
}
/**
 * A row of mutually exclusive choices, such as a tile shape.
 *
 * ```html
 * <neat-segmented label="Tile shape" [options]="shapes" [(value)]="shape" />
 * ```
 *
 * It is a radio group named by `label`, with one tab stop: the checked option, else the first. The
 * arrow keys move the choice and wrap, and Home and End jump to the ends. A click on the checked
 * option keeps it checked.
 *
 * It is drawn as an iOS-style switch: a track with a raised thumb that slides under the chosen
 * label. Its width does not move with the choice: every column is as wide as the widest label
 * needs, in semibold.
 *
 * It never gives up width to its neighbors. In a flex row too narrow for everything in it, the
 * control keeps its labels whole and the text beside it gives way. That text needs `min-width: 0`
 * to shrink.
 *
 * It is never wider than its container, though. In one narrower than its labels, such as an aside
 * dragged narrow, the options shrink together and stay equal. Each label then ends in an ellipsis.
 * Its full text is still the option's name, and shows as a tooltip on hover.
 */
export declare class NeatSegmented<T> {
  /**
   * The checked option's value, matched with `===`; bind it two-way, `[(value)]`. A value that is
   * none of the options leaves nothing checked.
   */
  readonly value: import("@angular/core").ModelSignal<T>;
  /** The segments in the order shown, each a value with the label (and icon) it carries. */
  readonly options: import("@angular/core").InputSignal<readonly NeatSegmentedOption<T>[]>;
  /** The group's accessible name; each option is named by its own label. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Turns every segment off at once; there is no per-option disabling. */
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly groupClasses = "relative isolate inline-grid grid-flow-col auto-cols-fr rounded-lg bg-neat-segmented-track p-0.5 aria-disabled:opacity-50";
  protected readonly thumbClasses = "pointer-events-none absolute inset-y-0.5 left-0.5 z-0 w-[calc((100%-4px)/var(--neat-segmented-count))] translate-x-[calc(var(--neat-segmented-index)*100%)] rounded-md bg-neat-segmented-thumb shadow-sm ring-1 ring-neat-segmented-thumb-edge transition-transform duration-280 ease-[cubic-bezier(.3,.7,.2,1)] motion-reduce:transition-none";
  protected readonly itemClasses = "relative z-10 inline-flex h-7 cursor-pointer items-center justify-center gap-1.5 rounded-md bg-transparent px-3.5 text-sm font-medium whitespace-nowrap text-foreground outline-none transition-colors duration-200 motion-reduce:transition-none disabled:pointer-events-none focus-visible:z-20 focus-visible:ring-[3px] focus-visible:ring-ring data-[state=on]:font-semibold data-[state=on]:text-primary before:absolute before:inset-y-1.5 before:left-0 before:w-px before:bg-muted-foreground/40 before:transition-opacity before:duration-200 motion-reduce:before:transition-none first-of-type:before:hidden data-[state=on]:before:opacity-0 [[data-state=on]+&]:before:opacity-0";
  /** The index of the checked option, or -1 when the value is none of the options. */
  protected readonly chosen: import("@angular/core").Signal<number>;
  /**
   * The option keyboard focus enters on: the checked one, else the first. It is also the thumb's
   * index: the thumb is drawn only while an option is checked, and then the two are the same.
   */
  protected readonly tabStop: import("@angular/core").Signal<number>;
  private readonly segments;
  /** Focuses the control's tab stop, the checked option (else the first): where Tab enters it. */
  focus(): void;
  /** Moves the choice from the segment at `current` (the one with focus) as the key says. */
  protected move(event: KeyboardEvent, current: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSegmented<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSegmented<any>, "neat-segmented", never, {
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
export type { NeatSegmentedOption };