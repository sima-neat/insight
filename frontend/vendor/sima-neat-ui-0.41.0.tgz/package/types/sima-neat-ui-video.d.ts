import * as i1 from "@sima/neat-ui";
import { NeatExpand, NeatTone, ɵColorAllocator as ColorAllocator } from "@sima/neat-ui";
import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
/**
 * One metadata message from the stream's data channel. `_insight.rtp_timestamp` identifies the
 * video frame the message describes; messages without it can only be matched by arrival order.
 */
interface NeatMetadataMessage {
  type: string;
  timestamp?: number;
  frame_id?: unknown;
  data?: unknown;
  _insight?: {
    rtp_timestamp?: number;
  };
}
/**
 * Parses a data-channel text message. Returns null for anything that is not a JSON object with a
 * string `type`, so a caller can drop it without reasoning about the payload. Everything else,
 * `data` and `_insight` included, is kept exactly as received.
 */
declare function parseMetadataMessage(text: string): NeatMetadataMessage | null;
/** A message with the time it arrived, as the queue stores and returns it. */
interface NeatMetadataItem {
  receivedAt: number;
  data: NeatMetadataMessage;
}
/** An item as returned for drawing; `held` marks one redrawn from an earlier frame. */
type NeatDrawableMetadataItem = NeatMetadataItem & {
  held?: true;
};
/** The last item of each metadata type, kept by `holdOverlays` between frames. */
type NeatHeldOverlays = Map<string, {
  item: NeatMetadataItem;
  matchedAt: number;
}>;
/** Cumulative counters; they survive `resetLatenessWindow`. */
interface NeatMetadataQueueStats {
  timestampMatches: number;
  arrivalFallbacks: number;
  frameMisses: number;
  expired: number;
  evicted: number;
  untimestampedReceived: number;
  late: number;
}
/**
 * What a tile's metadata queue holds and how late it has been, from `NeatVideoTile.snapshot`.
 *
 * It holds the cumulative counters and the messages still waiting for a frame. Then it holds the
 * lateness of the last five seconds, which the app's lateness notice reads. The `recent` figures
 * are `null` while the window has too little to say.
 */
interface NeatMetadataSnapshot extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  /** Null until the window holds enough messages for a share to mean anything. */
  recentLateShare: number | null;
  /** Null while the window holds no late message whose frame is still remembered. */
  recentLatenessMedianMs: number | null;
  recentLatenessP90Ms: number | null;
  recentLatenessMaxMs: number | null;
}
/**
 * The per-stream queue. Create it with `createMetadataQueue` and pass it to this module's
 * functions; `metadataQueueSnapshot` reports what it holds. Its contents are not accessible.
 */
interface NeatMetadataQueue {
  readonly __neatMetadataQueue: never;
}
declare function createMetadataQueue(): NeatMetadataQueue;
declare function enqueueMetadata(handle: NeatMetadataQueue, message: NeatMetadataMessage, receivedAt: number): void;
/**
 * The metadata to draw on a frame the browser is presenting. `rtpTimestamp` is the frame's RTP
 * timestamp, or null when the browser does not report one. A retention of 0 never expires.
 */
declare function takeMetadataForFrame(handle: NeatMetadataQueue, rtpTimestamp: number | null, metadataRetentionMs: number, now: number): NeatMetadataItem[];
declare const OVERLAY_HOLD_MS = 200;
declare function holdOverlays(held: NeatHeldOverlays, overlays: NeatMetadataItem[], now: number): NeatDrawableMetadataItem[];
declare function metadataQueueSnapshot(handle: NeatMetadataQueue): NeatMetadataSnapshot;
declare function resetLatenessWindow(handle: NeatMetadataQueue): void;
/** The part of a queue snapshot that the late notice reads. */
type NeatLatenessSnapshot = Pick<NeatMetadataSnapshot, 'recentLateShare' | 'recentLatenessMedianMs' | 'recentLatenessP90Ms'>;
/**
 * Why no buffer is suggested: the browser cannot set one, the window has no lateness sample, or
 * the suggestion would pass the maximum.
 */
type NeatLateNoticeBlocker = 'unsupported' | 'unmeasured' | 'maximum';
/**
 * The notice's second button: `raise` or `follow`.
 *
 * `raise` lifts the value the channels follow to the suggestion. `follow` only lets this channel
 * adopt the followed value, which already covers it.
 */
interface NeatGlobalBufferAction {
  kind: 'raise' | 'follow';
  valueMs: number;
}
/**
 * What an app's "metadata late" notice shows and offers, from `lateNoticeDetails`.
 *
 * It holds:
 * - how late the metadata is, as the median in ms and the share of messages in percent;
 * - the video sync buffer in use, and the suggested one;
 * - why none is suggested, if so;
 * - the action for the global setting.
 */
interface NeatLateNoticeDetails {
  latenessMs: number | null;
  latePercent: number | null;
  bufferMs: number;
  suggestedBufferMs: number | null;
  blockedBy: NeatLateNoticeBlocker | null;
  globalAction: NeatGlobalBufferAction | null;
}
/**
 * Whether the late-metadata warning is on after this sample.
 *
 * It follows from whether the warning was on before, and the recent late share. The share is 0 to
 * 1, or `null` when unknown, which changes nothing.
 *
 * The warning turns on at half the messages late, and off below a tenth. In between it stays as it
 * was, so a share hovering around one value does not make the chip blink.
 */
export declare function nextWarningActive(active: boolean, recentLateShare: number | null): boolean;
declare function suggestedBufferMs(currentBufferMs: number, p90LatenessMs: number | null): number | null;
/**
 * How long, in ms, to keep the late warning off after the video sync buffer changes.
 *
 * The buffer changes from `previousBufferMs` to `nextBufferMs`. A browser moves to a raised jitter
 * buffer target gradually, roughly 100 ms per second of video. What is measured until it has
 * arrived still describes the old buffer.
 *
 * The answer is a second, plus ten times the raise. A lowered buffer gets a second.
 */
export declare function bufferSettleMs(previousBufferMs: number, nextBufferMs: number): number;
/**
 * What the "metadata late" notice says and offers, from the lateness figures and the sync buffer.
 *
 * ```ts
 * const notice = lateNoticeDetails(snapshot, bufferMs, bufferSupported, followedBufferMs);
 * ```
 *
 * `snapshot` is the lateness window, `NeatMetadataSnapshot`'s `recent` figures. `currentBufferMs`
 * is the video sync buffer. `bufferSupported` is whether the browser can set a buffer at all.
 *
 * `followedBufferMs` is the value the app's channels follow, if it has one. It decides whether the
 * second button raises it, or only lets this channel adopt it.
 *
 * The suggested buffer covers the slowest tenth of the messages (the 90th percentile) plus a
 * margin. It goes in steps of 50 ms, up to the 4000 ms maximum.
 */
export declare function lateNoticeDetails(snapshot: NeatLatenessSnapshot, currentBufferMs: number, bufferSupported: boolean, followedBufferMs?: number | null): NeatLateNoticeDetails;
/** The dark plate behind track and pose labels, so the label reads in its identity color. */
declare const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
/**
 * ROI polygons, unlike the identity colors, use the kit's own green and danger red: the user
 * draws them, so they belong to the app's chrome rather than to the footage's labels. A faint fill
 * keeps the video visible under them and a full-strength 2px outline marks the edge; a highlighted
 * polygon (the one under the pointer, or the app's pick) takes `fillActive`, the same hue three
 * times as strong, so it stands out from its neighbors while the video still shows through.
 */
declare const OVERLAY_ROI_COLORS: {
  readonly inclusion: {
    readonly fill: string;
    readonly fillActive: string;
    readonly stroke: "#2A9C4F";
  };
  readonly exclusion: {
    readonly fill: string;
    readonly fillActive: string;
    readonly stroke: "#C8372D";
  };
};
/** The color a class style row resolves to when its stored color is missing or not a string. */
export declare const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
/** How a class's boxes and outlines are stroked. */
type NeatOverlayLineStyle = 'solid' | 'dashed' | 'dotted';
/**
 * A class style row: overlays whose label equals `label` draw in `color` with this line. The row
 * labeled `default` applies to every label without a row of its own.
 */
interface NeatOverlayClassStyle {
  readonly label: string;
  readonly color: string;
  readonly style: NeatOverlayLineStyle;
  /** Line width in CSS pixels: thin (1) or thick (3). It overrides `general.lineWidth`. */
  readonly width: 1 | 3;
}
/**
 * A region of interest. Coordinates are normalized to 0..1 of the video frame, so a polygon fits
 * any resolution the stream is sent at.
 */
interface NeatRoiPolygon {
  readonly type: 'inclusion' | 'exclusion';
  readonly points: readonly {
    readonly x: number;
    readonly y: number;
  }[];
}
/**
 * The resolved overlay settings for one channel. The app resolves them once per change (defaults,
 * global values, the channel's own values); drawing reads them every frame and never parses or
 * validates them.
 */
interface NeatOverlaySettings {
  readonly general: {
    /** Line width in CSS pixels for every overlay line a class row does not override. */
    readonly lineWidth: number;
    /** Draw the ROI polygons under the detection, segmentation and tracking overlays. */
    readonly showRoi: boolean;
    /** Hide detections, segments and tracks whose box center falls outside the ROI. */
    readonly applyRoiFiltering: boolean;
  };
  readonly types: {
    readonly 'object-detection': {
      readonly visible: boolean;
      /** 0..1; an object without a confidence always passes. */
      readonly confidenceThreshold: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly segmentation: {
      readonly visible: boolean;
      /** 0..1; a segment without a confidence counts as fully confident. */
      readonly confidenceThreshold: number;
      /** 0..1, the alpha of mask fills. */
      readonly maskOpacity: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly tracking: {
      readonly visible: boolean;
      readonly confidenceThreshold: number;
      readonly history: {
        /** Draw each track's recent center positions as a trail. */
        readonly enabled: boolean;
        /** Positions kept per track. */
        readonly trailLength: number;
        /** How long the trail of a track that left the frame stays, in milliseconds. */
        readonly lostTrackTtlMs: number;
      };
    };
    readonly 'pose-estimation': {
      readonly visible: boolean;
      /** Dots on the joints. */
      readonly showKeypoints: boolean;
      /** Joint names next to the dots. */
      readonly showKeypointLabels: boolean;
      /** The box and label plate around each pose. */
      readonly showBoxes: boolean;
      /**
       * Color, line and width by the pose's label (`person`, `hand`); a pose without a row keeps
       * its identity color.
       */
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly classification: {
      readonly visible: boolean;
    };
  };
  readonly roi: readonly NeatRoiPolygon[];
}
/** The settings a channel draws with when nothing is stored. */
export declare const NEAT_OVERLAY_DEFAULTS: NeatOverlaySettings;
/** An overlay type the tile draws, as a metadata message's `type` names it. */
type NeatOverlayType = keyof NeatOverlaySettings['types'];
/**
 * An item of an overlay's message, by what its color goes by: its `id` and its `label`.
 *
 * A track, a detection or a pose from the message fits as it is. So does an app's own row with
 * the same fields, such as `{ id: 7 }` for a track or `{ label: 'car' }` for a detection.
 */
interface NeatOverlayIdentity {
  /** The track's or the pose's id. */
  readonly id?: unknown;
  /** The class label of a detection, a segment or a classification; a pose's label (`hand`). */
  readonly label?: unknown;
}
/**
 * The color to draw `item` of `type` in, recording that it was drawn at `now`: its label's style
 * row (`overrides`, from the type's rows), else the color of its identity.
 */
declare function resolveItemColor(allocator: ColorAllocator, channel: number, type: NeatOverlayType, item: NeatOverlayIdentity, overrides: Readonly<Record<string, string>> | undefined, now: number): string;
/**
 * The color `resolveItemColor` gives `item` with the type's rows in `settings`, without recording
 * a draw; null while its identity holds no color. A computed or a template that calls it follows
 * the colors as they are given and taken back.
 */
declare function heldItemColor(allocator: ColorAllocator, channel: number, settings: NeatOverlaySettings, type: NeatOverlayType, item: NeatOverlayIdentity): string | null;
/** The box tiles are laid out in, in CSS pixels (`NeatTileGrid` measures it from its host). */
interface NeatTileArea {
  readonly width: number;
  readonly height: number;
}
/** How tiles of one size fill an area: the grid they form and the size each tile gets. */
interface NeatTilePack {
  readonly columns: number;
  readonly rows: number;
  /** How many tiles fit at once: `columns * rows`. */
  readonly perPage: number;
  /** The tile size actually used; below the requested width only when one tile did not fit. */
  readonly tileWidth: number;
  readonly tileHeight: number;
}
/**
 * The narrowest tile the kit lays out, in CSS pixels. Below this a tile is a postage stamp, so with
 * very many items in a small area the page pages instead of shrinking tiles further. Only an area
 * smaller than this makes a tile narrower (it then shrinks to the area).
 */
export declare const NEAT_MIN_TILE_WIDTH = 64;
/**
 * How many tiles of `tileWidth` fit into `area` with `gap` between them (and none around the
 * outside), in columns and rows. The gap counts only between tiles, which is why the area is
 * widened by one gap before dividing: `n` tiles take `n * tile + (n - 1) * gap`.
 *
 * `tileWidth` is raised to `NEAT_MIN_TILE_WIDTH` (a NaN, zero or negative one too). If even one
 * tile does not fit, it shrinks to the area while keeping 16:9, to whole CSS pixels so it
 * never rounds past the edge; that rule wins over the minimum. A tile is at least 1 px, so an
 * empty area (before the first measurement) still yields one tile.
 */
declare function packTiles(area: NeatTileArea, tileWidth: number, gap: number): NeatTilePack;
/**
 * The widest tile, in whole CSS pixels, at which `count` tiles fit into `area` on one page.
 *
 * For each column count from 1 to `count`, the rows follow (`ceil(count / columns)`). The tile is
 * bounded by both the width and the height of the area. The column count with the widest tile
 * wins. The width is in whole pixels, rounded down, so a floating-point edge can never make the
 * grid drop a row that this function counted on.
 *
 * Never below `NEAT_MIN_TILE_WIDTH`: when `count` tiles would need narrower ones, the result is
 * the minimum and the caller pages. A count that is not a finite number of at least 1 is one tile;
 * a fractional count is rounded down.
 */
export declare function fitAllTileWidth(area: NeatTileArea, count: number, gap: number): number;
/**
 * What the grid reports: the packing, the gap it used between tiles and the content box it was
 * packed into.
 *
 * A page that sizes tiles itself, to fit a count say, needs the gap the grid used. It may be the
 * kit's token rather than a number the page chose.
 */
interface NeatTileLayout extends NeatTilePack {
  /** Space between tiles in CSS pixels. */
  readonly gap: number;
  readonly areaWidth: number;
  readonly areaHeight: number;
}
/**
 * Lays video tiles out as 16:9 tiles of one width, as many as fit its box without scrolling. It
 * is made for `neat-video-tile`s, a wall of channels; a page's other content has a layout of its
 * own.
 *
 * ```html
 * <neat-tile-grid [tileWidth]="tileWidth()" [count]="shown().length" (layout)="layout.set($event)">
 *   @for (channel of shown(); track channel.id) {
 *     <neat-video-tile [source]="channel.source" [label]="channel.name" />
 *   }
 * </neat-tile-grid>
 * ```
 *
 * The grid is centered. The tile width comes from the page, from a slider say. The grid works out
 * the columns, rows and tiles per page, and reports them through `layout`, so the page can slice
 * its items to `perPage`. The grid never pages itself.
 *
 * It fills its parent and measures its own box, never the shell's, so it repacks when the parent
 * changes size for any reason. `layout` is emitted when a value of it changes, not on every
 * resize notification.
 *
 * `count` is the number of projected items. When fewer than a row's worth are shown, they form a
 * centered block of their own width. They do not hug the left edge of a full-width row.
 *
 * The gap defaults to the kit's `--neat-space-2` token, read once when the grid initializes; an
 * explicit `gap` (in CSS pixels) overrides it.
 */
export declare class NeatTileGrid {
  /** Tile width in CSS pixels; a tile wider than the area shrinks to it. */
  readonly tileWidth: import("@angular/core").InputSignal<number>;
  /** Space between tiles in CSS pixels; the kit's `--neat-space-2` when unset. */
  readonly gap: import("@angular/core").InputSignal<number | undefined>;
  /** The number of projected items. */
  readonly count: import("@angular/core").InputSignal<number>;
  /**
   * The packed grid: columns, rows, tiles per page and the tile size. Emitted once the box is
   * measured and again whenever a value of it changes; slice your items to `perPage`.
   */
  readonly layout: import("@angular/core").OutputEmitterRef<NeatTileLayout>;
  private readonly gridElement;
  private readonly area;
  /** The token's gap, known once the grid has rendered and its stylesheet can be read. */
  private readonly tokenGap;
  /**
   * The gap in use. It waits for the token to be read even when `gap` is set, so the read never
   * sees a gap this component applied itself.
   */
  protected readonly gapPx: import("@angular/core").Signal<number | null>;
  private readonly packed;
  /** What the template draws: the packed tiles, in as many columns as there are items to show. */
  protected readonly view: import("@angular/core").Signal<{
    columns: number;
    gap: number;
    areaWidth: number;
    areaHeight: number;
    rows: number;
    perPage: number;
    tileWidth: number;
    tileHeight: number;
  } | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTileGrid, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTileGrid, "neat-tile-grid", never, {
    "tileWidth": {
      "alias": "tileWidth";
      "required": true;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": true;
      "isSignal": true;
    };
  }, {
    "layout": "layout";
  }, never, ["*"], true, never>;
}
/**
 * Where a `neat-video-tile` gets its video and metadata: a stream or encoded frames. The tile knows
 * nothing about how they arrive (WebRTC, a file, a canvas); the app implements this for its
 * transport.
 */
interface NeatTileSource {
  /** The channel's video, or null while connecting or when it has none. */
  readonly stream: Signal<MediaStream | null>;
  /**
   * The channel's pictures as encoded frames, for video the browser cannot play as a stream
   * (RTP/JPEG), or null while it has none. At most one of `stream` and `frames` is set at a time. If both are set, the tile plays the
   * stream and says so once in dev mode.
   * A new value is a new run of frames, as a new `MediaStream` is a new stream: the tile forgets
   * the old run's metadata and overlays. Leave it out for a source that only has streams.
   */
  readonly frames?: Signal<NeatEncodedFrames | null>;
  /**
   * Registers a listener for raw metadata text; returns the unsubscribe function. `receivedAt` is
   * on the `performance.now()` clock, the one presented frames are timed with.
   */
  onMetadata(listener: (text: string, receivedAt: number) => void): () => void;
}
/**
 * One run of encoded frames. `onFrame` registers a listener for each frame that arrives from now
 * on and returns the unsubscribe function. Several tiles may listen to one run; each decodes the
 * frames itself.
 */
interface NeatEncodedFrames {
  onFrame(listener: (frame: NeatEncodedFrame) => void): () => void;
}
/** One picture of a run of encoded frames, with the time the tile may show it. */
interface NeatEncodedFrame {
  /** The picture, in a format `createImageBitmap` decodes: JPEG from Insight. */
  readonly data: Blob;
  /**
   * The RTP timestamp its metadata carries as `_insight.rtp_timestamp`, so the tile draws each
   * frame with the metadata that describes it, in every browser. Null matches metadata by
   * arrival, as a stream without timestamps does.
   */
  readonly rtpTimestamp: number | null;
  /**
   * The earliest time the tile may show it, on the `performance.now()` clock: its arrival plus
   * the source's hold, so its metadata has arrived when it is drawn. The arrival time itself
   * shows it at once.
   */
  readonly presentAt: number;
}
/** A tile whose stream presents no frame for this long has stopped. */
declare const NEAT_STREAM_STALE_MS = 1800;
/**
 * Where the tile's stream is: `empty`, `playing` or `stopped`.
 *
 * It is `empty` until the stream, or the run of encoded frames, presents its first frame, and
 * `playing` while frames arrive. It is `stopped` once none has arrived for the stale timeout, about
 * 1.8 s. It plays again when frames return.
 */
type NeatTileState = 'empty' | 'playing' | 'stopped';
/**
 * Where the shown image sits inside the tile, in CSS pixels from the tile's top-left corner.
 *
 * It is the picture without the letterbox bars that `object-fit: contain` leaves around it.
 */
interface NeatVideoBox {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}
/**
 * What the overlay drew for one presented frame.
 *
 * It holds the messages matched to the frame. It also holds the ones held over from an earlier
 * frame because this frame had none of their type, marked `held`.
 */
interface NeatTileFrame {
  /** When the frame was presented, on the `performance.now()` clock. */
  readonly now: number;
  /** One message per type at most; empty when nothing matched and nothing is held. */
  readonly messages: readonly {
    readonly message: NeatMetadataMessage;
    readonly held: boolean;
  }[];
}
/**
 * Called once for each frame the tile presents, after the overlay is drawn, outside Angular.
 *
 * It runs up to the video's frame rate. So it must be cheap, and should not touch Angular state
 * per call: write a signal at most when its value changes.
 */
type NeatTileFrameListener = (frame: NeatTileFrame) => void;
/**
 * The tile's frame-sync counters and video state, as the app reports them (the `synchronization`
 * and `video` groups of vf's browser egress report). Counters are cumulative for the current
 * stream. Every count and pixel size is a whole number: vf parses them as integers and drops a
 * report with a fraction in one.
 */
interface NeatFrameStats extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  recentLatenessMedianMs: number | null;
  recentLatenessMaxMs: number | null;
  /** Valid metadata messages received in the last second. */
  metadataMessagesPerSecond: number;
  /**
   * The picture's state when the stats were taken: the video element's, or, while the tile draws
   * encoded frames, the frames canvas's: `readyState` is 4 once a frame is drawn and 0 before,
   * `paused` is false, `currentTime` is 0, and `videoWidth` and `videoHeight` are the picture's.
   */
  video: {
    /** `HTMLMediaElement.readyState`, 0 to 4. */
    readyState: number;
    paused: boolean;
    /** Seconds, fractional. */
    currentTime: number;
    videoWidth: number;
    videoHeight: number;
    /** Whole milliseconds since the stream's last presented frame; null before its first. */
    lastFrameAgeMs: number | null;
    /** Whether the tile is `playing`. */
    active: boolean;
  };
}
/**
 * Plays a source's video, with its metadata drawn over it as overlays.
 *
 * ```html
 * <neat-video-tile [source]="source" label="1" status="640×360 · 30 fps" />
 * ```
 *
 * Each frame is drawn with the metadata that describes it. The tile fills the box it is given.
 *
 * It plays a source's stream, or draws its encoded frames (`NeatTileSource.frames`) for video the
 * browser cannot play as a stream: each frame is decoded and drawn on a canvas in the video's
 * place, under the overlays. The app sets nothing for it; the source says which it has.
 *
 * With `bars` on, a bar along the bottom shows `label`, `status` and the chips projected with
 * `neatTileChip`, and a tile without video says so. With `bars` off it is only video and overlay.
 *
 * `notice` says what keeps the stream from showing as it should, with or without bars:
 *
 * ```html
 * <neat-video-tile [source]="source" [bars]="false" [notice]="trouble()" />
 * ```
 *
 * Without video it is centered over the tile, in place of the no-video note, in the same look.
 * While video plays it is a status chip in the picture's top-right corner.
 *
 * Content projected with `neatTileOverlay` fills a layer over the tile, above the overlay canvas
 * and below the bar. `videoBox` says where the image is inside it, and `barHeight` how tall the
 * bar is.
 *
 * Without video, the layer stays above what covers the image and below the no-video note, which
 * lets pointer input through. The layer itself catches no pointer input, so the video under it
 * keeps its hits. Its content takes them only where it sets `pointer-events: auto`.
 *
 * With `expandControl` on, a button in the tile's top-left corner shows it over the whole window
 * and puts it back (`NeatExpand`, which the tile carries itself). It shows while the pointer is
 * over the tile or the button has the keyboard's focus, and always while the tile is expanded:
 *
 * ```html
 * <neat-video-tile [source]="source" label="Camera 1" expandControl />
 * ```
 *
 * The tile's own `expanded` model is that state, so an app can open the tile from a control of its
 * own and follow it: `[(expanded)]="large"`. Do not put `neatExpand` on a tile as well: Angular
 * refuses a directive twice on one element in dev mode. The same live tile is shown, so the video plays on and
 * the overlays take the new size.
 *
 * The frame loop, and for encoded frames their decoding, runs outside Angular and touches no
 * signal. Per frame, it matches the queued metadata to the presented frame, holds a type that is
 * missing for a moment, and draws. The component sees a state change and, at most once a second,
 * `frameStats`. Inputs the loop needs are copied into fields when they change, so a frame never
 * reads an input or resolves settings.
 *
 * @input expanded Whether the tile is shown over the whole window (`NeatExpand`), false by default.
 * Bind it two-way to open the tile from the app's own control and follow it: the tile's button and
 * Escape change it too. `expandControl` gives the tile a button of its own.
 */
export declare class NeatVideoTile {
  /**
   * Where the video and its metadata come from; `null` (the default) leaves the tile `empty`.
   * Give it the channel's source once it has one: the tile plays its stream or draws its encoded
   * frames, and draws its metadata.
   */
  readonly source: import("@angular/core").InputSignal<NeatTileSource | null>;
  /** The channel's resolved overlay settings; a new object for each change. */
  readonly settings: import("@angular/core").InputSignal<NeatOverlaySettings>;
  /** How long metadata waits for its frame, in milliseconds; 0 waits indefinitely. */
  readonly retentionMs: import("@angular/core").InputSignal<number>;
  /** The number overlay warnings name the tile by, such as the app's channel. */
  readonly channel: import("@angular/core").InputSignal<number>;
  /** The bar's left text, such as the channel number. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The bar's status text. */
  readonly status: import("@angular/core").InputSignal<string | null>;
  /**
   * Whether the bar along the bottom (`label`, `status`, chips) and the no-video note show. A
   * `notice` shows either way.
   */
  readonly bars: import("@angular/core").InputSignal<boolean>;
  /**
   * What keeps the stream from showing as it should, in words, or null (the default) while all is
   * well: a failure, a server out of reach, a stream being waited for.
   *
   * Without video, the tile says it centered over itself, under a "no video" icon and with no
   * card behind it, in place of the no-video note. It does so with or without `bars`, so a tile
   * without bars can say "No signal".
   *
   * While video plays, it is a status chip of `noticeTone` in the picture's top-right corner,
   * where it covers little of the picture. It sits above the `neatTileOverlay` layer and lets
   * pointer input through. The tile does not announce it: say a change that matters in the page's
   * text as well, such as a callout.
   */
  readonly notice: import("@angular/core").InputSignal<string | null>;
  /**
   * The tone of the notice's chip while video plays: `warning` by default, since a notice says
   * that something is not as it should be. Without video the notice has no chip, and its
   * words say it.
   */
  readonly noticeTone: import("@angular/core").InputSignal<NeatTone>;
  /** Draws the kit's focus ring around the tile, for the tile the app has chosen. */
  readonly selected: import("@angular/core").InputSignal<boolean>;
  /**
   * Shows the picture as in a mirror, for a selfie view.
   *
   * The video and every overlay flip horizontally, while overlay text, such as labels and plates,
   * still reads left to right. Together with `flipVertical` it is the picture turned 180°. The
   * bar, the no-video note and the `neatTileOverlay` layer are not flipped. Content projected there
   * reads the app's own `mirror` value to follow. `videoBox` is the same with and without it. The
   * region-of-interest editor does not follow `mirror`: it works in the unflipped picture.
   */
  readonly mirror: import("@angular/core").InputSignal<boolean>;
  /**
   * Shows the picture flipped top to bottom, for a camera mounted upside down.
   *
   * The video and every overlay flip vertically, while overlay text, such as labels and plates,
   * stays upright: a box's label stands above the box as it shows on screen. Together with
   * `mirror` it is the picture turned 180°. The bar, the no-video note and the `neatTileOverlay`
   * layer are not flipped. Content projected there reads the app's own `flipVertical` value to
   * follow. `videoBox` is the same with and without it. The region-of-interest editor does not
   * follow `flipVertical`: it works in the unflipped picture.
   */
  readonly flipVertical: import("@angular/core").InputSignal<boolean>;
  /**
   * Called once for each presented frame, with what the overlay drew (`NeatTileFrame`).
   *
   * It is for an app that acts on a frame's metadata in step with the picture, such as counting
   * poses. It runs outside Angular. A listener that throws is logged once per tile, and the frames
   * keep drawing.
   */
  readonly frameListener: import("@angular/core").InputSignal<NeatTileFrameListener | null>;
  /**
   * Gives the tile a button that shows it over the whole window and puts it back, off by default.
   *
   * The button sits in the tile's top-left corner. It shows while the pointer is over the tile or
   * the button has the keyboard's focus, and always while the tile is expanded. It is named
   * "Expand" and the tile's `label` ("Expand Camera 1") while the tile is in its place, and "Close"
   * while it is expanded. Escape closes the tile too.
   */
  readonly expandControl: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The tile's state each time it changes: `empty`, `playing` or `stopped`. */
  readonly stateChange: import("@angular/core").OutputEmitterRef<NeatTileState>;
  /** The frame-sync counters, once a second while there is a stream or a run of encoded frames. */
  readonly frameStats: import("@angular/core").OutputEmitterRef<NeatFrameStats>;
  protected readonly state: import("@angular/core").WritableSignal<NeatTileState>;
  /** Whether the tile draws encoded frames rather than playing a stream. */
  protected readonly playsFrames: import("@angular/core").WritableSignal<boolean>;
  /** The tile's own `NeatExpand`, which `expandControl`'s button drives. */
  protected readonly expand: NeatExpand;
  protected readonly expandLabel: Signal<string>;
  /** What the tile says without video: the notice, else the no-video note with bars. */
  protected readonly noVideoText: Signal<string | null>;
  private readonly box;
  /**
   * Where the shown image sits in the tile.
   *
   * It is non-null only while the tile is `playing` and the video and the tile have a size. Before
   * the first frame, the surface covers the video. Once the stream is `stopped`, the frozen frame
   * is blurred and scaled up. So no box describes either.
   *
   * It is a signal, for overlays that follow the image. It is written only when the tile's state or
   * the tile's or the picture's size changes, never per frame. An unchanged box does not notify.
   */
  readonly videoBox: Signal<NeatVideoBox | null>;
  private readonly barSize;
  /**
   * The height in CSS pixels of the bar along the bottom as laid out, 0 while `bars` is off. For
   * content projected with `neatTileOverlay` that keeps clear of the bar without copying its
   * styling. It changes only when the bar's size does, never per frame.
   */
  readonly barHeight: Signal<number>;
  private readonly videoElement;
  private readonly canvasElement;
  private readonly framesElement;
  private readonly barElement;
  private readonly colors;
  /** A new state per channel starts with no tracks, track colors or warnings of its own. */
  private readonly overlay;
  private readonly zone;
  private readonly document;
  private frameSettings;
  private frameRetentionMs;
  private frameListenerFn;
  private overlayState;
  private currentState;
  private canvas;
  private context;
  /** The frames canvas's context, taken on the first run of encoded frames. */
  private framesContext;
  /**
   * The shown picture's size in either mode, 0 before it is known: the video's, or the last drawn
   * frame's.
   */
  private pictureWidth;
  private pictureHeight;
  /** The canvas's CSS size and pixel ratio; the video size is filled in per frame. */
  private readonly view;
  /** What plays: the source and its stream or its run of frames, the other null. */
  private playing;
  private queue;
  private readonly held;
  /** When the current stream last presented a frame; null until its first. */
  private lastFrameAt;
  private staleTimer;
  /** The last stale check found the tab hidden, so the frame time it would judge is from before. */
  private staleCheckSawHidden;
  private messagesThisSecond;
  private warnedUnreadable;
  private warnedPlayback;
  private warnedBoth;
  private warnedDecode;
  private warnedListener;
  private destroyed;
  constructor();
  /**
   * The color the overlay draws `item` of `type` in, for a swatch beside the video; null while it
   * has none.
   *
   * ```html
   * <neat-video-tile #tile [source]="source" />
   * @for (track of tracks(); track track.id) {
   *   @if (tile.colorOf('tracking', track); as color) {
   *     <neat-swatch [color]="color" />
   *   }
   *   #{{ track.id }}
   * }
   * ```
   *
   * It follows the overlay's own rule. A track goes by its id. A detection, a segment or a
   * classification goes by its label's style row, else its class. A pose goes by its label's style
   * row, else its id.
   *
   * A class has one color on every tile of the page, and in the bird's-eye view. A track's and a
   * pose's color belong to this tile.
   *
   * It is null for an item the overlay has not drawn yet, and for one it has forgotten. A track
   * gone for about 5 s may give its color to another, and a stopped stream forgets its tracks. A
   * style row's color it gives at once.
   *
   * It reads signals, so a template or a `computed` that calls it updates when a color is given or
   * taken back, and when `settings` change. Asking records no draw, so it keeps no color alive.
   */
  colorOf(type: NeatOverlayType, item: NeatOverlayIdentity): string | null;
  /** The metadata queue's counters and lateness window, for the app's lateness notice. */
  snapshot(): NeatMetadataSnapshot;
  /**
   * Forgets the lateness measured so far, as after the app changes the video sync buffer: what was
   * measured belongs to the old buffer. The cumulative counters stay.
   */
  resetLatenessWindow(): void;
  /**
   * Plays the source's stream or its run of frames; any change stops what played (the tile goes
   * `empty`, the overlays are cleared and the metadata queue starts anew) and starts the other.
   */
  private play;
  /** Plays `stream` in the video element; returns what stops it. */
  private playStream;
  /** Draws `run`'s frames on the frames canvas as they are decoded; returns what stops it. */
  private playFrames;
  /** A frame that does not decode is skipped and the next one is decoded; the first is said. */
  private warnDecode;
  private setPictureSize;
  /**
   * Draws a decoded frame and presents it, synchronously: the scheduler closes the bitmap once this
   * returns. The canvas's backing store is the picture's own size, set only when that changes.
   */
  private drawPicture;
  /**
   * Muted autoplay is allowed everywhere, so a rejection is either an AbortError (a newer stream or
   * a pause interrupted it, which is expected) or a real refusal that would leave the tile empty for
   * good, such as NotAllowedError or NotSupportedError. Those are logged, once per tile.
   */
  private startPlayback;
  private stop;
  private receive;
  /** Matches and draws the overlays for a frame of the picture that was just shown. */
  private present;
  private notifyListener;
  /**
   * One timer at a time, re-armed for the remainder instead of on every frame, so a stream that
   * plays costs one timeout per stale period. A hidden tab presents no frames, so the check waits
   * there instead of stopping a stream that is still running. The first check after the tab
   * returns waits a full period too: the last frame time is from before the tab was hidden, and a
   * check right after the return, before the first new frame, would stop a live stream. A dead one
   * stops a period later.
   */
  private checkStale;
  /** Forgets what was drawn: the canvas, held overlays, track trails and track colors. */
  private clearOverlays;
  private setState;
  /**
   * The `video` group of the stats: the element's own state for a stream; for frames, which have no
   * element to ask, what the tile knows (`NeatFrameStats`).
   */
  private pictureStats;
  private reportFrameStats;
  /**
   * Called when the tile or the picture changes size or the tile's state changes, never per frame.
   */
  private updateVideoBox;
  private sizeCanvas;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatVideoTile, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatVideoTile, "neat-video-tile", never, {
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
    "retentionMs": {
      "alias": "retentionMs";
      "required": false;
      "isSignal": true;
    };
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "bars": {
      "alias": "bars";
      "required": false;
      "isSignal": true;
    };
    "notice": {
      "alias": "notice";
      "required": false;
      "isSignal": true;
    };
    "noticeTone": {
      "alias": "noticeTone";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "mirror": {
      "alias": "mirror";
      "required": false;
      "isSignal": true;
    };
    "flipVertical": {
      "alias": "flipVertical";
      "required": false;
      "isSignal": true;
    };
    "frameListener": {
      "alias": "frameListener";
      "required": false;
      "isSignal": true;
    };
    "expandControl": {
      "alias": "expandControl";
      "required": false;
      "isSignal": true;
    };
  }, {
    "stateChange": "stateChange";
    "frameStats": "frameStats";
  }, never, ["[neatTileOverlay]", "[neatTileChip]"], true, [{
    directive: typeof i1.NeatExpand;
    inputs: {
      "expanded": "expanded";
    };
    outputs: {
      "expandedChange": "expandedChange";
    };
  }]>;
}
/** What a click does: nothing, or places points of an inclusion or an exclusion polygon. */
type NeatRoiDrawMode = 'off' | 'inclusion' | 'exclusion';
/**
 * Draws regions of interest on a video tile's image, and lets the user add regions by clicking.
 *
 * Project it into the `neat-video-tile` with `neatTileOverlay`:
 *
 * ```html
 * <neat-video-tile>
 *   <neat-roi-editor
 *     neatTileOverlay
 *     [regions]="regions"
 *     [mode]="mode"
 *     [(highlighted)]="highlighted"
 *     (regionsChange)="…"
 *   />
 * </neat-video-tile>
 * ```
 *
 * While the tile plays, the editor sits on the tile's video box. So a point is a position on the
 * image, not on the letterbox, and it stays there when the tile resizes.
 *
 * Without video, none yet or stopped, it uses the tile's full box instead. So regions can be seen
 * and drawn before a stream plays. Points are normalized to whichever box was used, which is exact
 * for a stream of the tile's shape. Until it knows either box, it draws nothing and takes no input.
 *
 * The full box is meant for a tile with `bars` off. With bars on, the no-video note and the bar
 * paint above the editor and cover what lies under them.
 *
 * With a `mode` of `inclusion` or `exclusion`, each click adds a point:
 * - A click within 10 px of the first point closes the polygon once it has three. So does a
 *   double-click. The second click of a double-click (`detail` 2 or more) is ignored, so a
 *   double-click is its first click plus a close.
 * - `regionsChange` emits when a polygon closes, with it appended to `regions`. The editor never
 *   changes `regions` itself.
 * - A right-click or Backspace removes the open polygon's last point, and the polygon with its only
 *   point.
 * - Escape cancels the whole polygon. So does a new `mode` or `regions` from outside, or the box it
 *   is drawn on changing between the image and the tile.
 *
 * Drawing is pointer-only. The polygon is open on the host, which takes focus on the first point,
 * so Backspace and Escape reach it.
 *
 * In every mode, `off` included, the regions themselves take the pointer:
 * - Hovering one sets `highlighted` to its index in `regions`, and leaving it sets null. Where
 *   regions overlap, it is the one drawn last, on top. A highlighted region has a stronger fill and
 *   outline.
 * - An app binds the same index to its region list, so either side can highlight.
 * - A right-click on one, while no polygon is open, opens a small bubble there with a Delete
 *   button. The button emits `regionsChange` without that region, and takes focus. Escape, a press
 *   outside the bubble, focus leaving it or new `regions` close it.
 * - The bubble is a shortcut for the pointer. An app still offers the keyboard its own way to
 *   remove regions, such as its list.
 *
 * Elsewhere, the editor leaves mode `off` to what is under it.
 */
export declare class NeatRoiEditor {
  /** The regions to draw. One being drawn is not part of it until `regionsChange` brings it. */
  readonly regions: import("@angular/core").InputSignal<readonly NeatRoiPolygon[]>;
  /** What a click does; `off` leaves the tile to what is under the editor, but for the regions. */
  readonly mode: import("@angular/core").InputSignal<NeatRoiDrawMode>;
  /** A new region appended to `regions`, or `regions` without a deleted one, in a new array. */
  readonly regionsChange: import("@angular/core").OutputEmitterRef<readonly NeatRoiPolygon[]>;
  /** The index in `regions` of the region to highlight, as the pointer or the app set it. */
  readonly highlighted: import("@angular/core").ModelSignal<number | null>;
  private readonly host;
  private readonly injector;
  private readonly renderer;
  private readonly document;
  private readonly videoBox;
  private readonly menuElement;
  /**
   * The editor's own size, which is the tile's: its host fills the tile's overlay layer. Measured
   * here rather than asked of the tile because it is exactly the area whose clicks `locate` maps,
   * and the tile keeps its own measure in a plain field for its frame loop, not in a signal.
   */
  private readonly size;
  private readonly boxSource;
  protected readonly box: import("@angular/core").Signal<NeatVideoBox | null>;
  /**
   * The open polygon's points, normalized to the box. A box that only changes size leaves it
   * alone (that is why it is normalized); anything that changes what a click would mean, or what
   * the polygon is drawn among, starts over.
   */
  private readonly open;
  /** The last place the pointer was, normalized; the open polyline runs to it. */
  private readonly pointer;
  /**
   * The open Delete bubble. New regions close it, since its index may name another region by
   * then, and so does a change of box, which moves the region it was opened on.
   */
  private readonly menu;
  /** What had focus when the bubble opened, given focus back when Escape or Delete closes it. */
  private focusBeforeMenu;
  protected readonly drawing: import("@angular/core").Signal<boolean>;
  protected readonly placed: import("@angular/core").Signal<{
    index: number;
    points: string;
    fill: string;
    stroke: "#2A9C4F" | "#C8372D";
    strokeWidth: number;
  }[]>;
  protected readonly draft: import("@angular/core").Signal<{
    line: string;
    stroke: "#2A9C4F" | "#C8372D";
    startX: number;
    startY: number;
  } | null>;
  /**
   * The Delete button's name, the region named as an app's list names it: "Delete Inclusion 2".
   * None for an index past the list, which `openMenu` already refuses.
   */
  protected readonly menuLabel: import("@angular/core").Signal<string | null>;
  constructor();
  protected onClick(event: MouseEvent): void;
  protected onDoubleClick(event: MouseEvent): void;
  protected cancelOnEscape(event: Event): void;
  protected undoOnBackspace(event: Event): void;
  protected undoOnRightClick(event: MouseEvent): void;
  /** Opens the Delete bubble for the region at `index` at the pointer, instead of the browser's. */
  protected openMenu(event: MouseEvent, index: number): void;
  protected deleteFromMenu(): void;
  protected closeMenuOnEscape(event: Event): void;
  protected closeMenuOnFocusOut(event: FocusEvent): void;
  /** Closes the bubble; `restoreFocus` when focus was in it and would otherwise fall to the page. */
  private closeMenu;
  /** Moves the bubble in from the tile's edges as far as its size needs, and focuses Delete. */
  private placeMenu;
  private inMenu;
  /** Drops the open polygon's last point; the polygon is gone with its only one. */
  private undoPoint;
  private close;
  /**
   * Where the pointer is on the box, 0..1 on each axis and clamped, with the box it was measured
   * against; null without a box to measure. The host fills the tile's overlay layer, so its corner
   * is the tile's.
   */
  private locate;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRoiEditor, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatRoiEditor, "neat-roi-editor", never, {
    "regions": {
      "alias": "regions";
      "required": true;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "highlighted": {
      "alias": "highlighted";
      "required": false;
      "isSignal": true;
    };
  }, {
    "regionsChange": "regionsChange";
    "highlighted": "highlightedChange";
  }, never, never, true, never>;
}
/**
 * The name of each region, in the order given: its type, numbered per type in list order
 * ("Inclusion 1", "Exclusion 1", "Exclusion 2", "Inclusion 2"). Every region counts, drawable or
 * not, so an app's region list and `neat-roi-editor`'s Delete bubble name the same region alike.
 */
export declare function neatRoiNames(regions: readonly NeatRoiPolygon[]): string[];
/**
 * A dot in the outline color of a region type, as `neat-roi-editor` draws it on the video.
 *
 * ```html
 * <neat-roi-swatch [type]="region.type" /> {{ region.name }}
 * ```
 *
 * Put it before a region's name in a list, so the list and the image read alike. It is decoration,
 * hidden from assistive technology, so the name next to it must say the type.
 */
export declare class NeatRoiSwatch {
  /** The region type whose outline color the dot takes: `inclusion` or `exclusion`. */
  readonly type: import("@angular/core").InputSignal<"inclusion" | "exclusion">;
  protected readonly color: import("@angular/core").Signal<"#2A9C4F" | "#C8372D">;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRoiSwatch, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatRoiSwatch, "neat-roi-swatch", never, {
    "type": {
      "alias": "type";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type { NeatEncodedFrame, NeatEncodedFrames, NeatFrameStats, NeatGlobalBufferAction, NeatLateNoticeBlocker, NeatLateNoticeDetails, NeatLatenessSnapshot, NeatMetadataMessage, NeatMetadataQueueStats, NeatMetadataSnapshot, NeatOverlayClassStyle, NeatOverlayIdentity, NeatOverlayLineStyle, NeatOverlaySettings, NeatOverlayType, NeatRoiDrawMode, NeatRoiPolygon, NeatTileArea, NeatTileFrame, NeatTileFrameListener, NeatTileLayout, NeatTilePack, NeatTileSource, NeatTileState, NeatVideoBox };