import * as i0 from "@angular/core";
/**
 * Facts about the selected thing, as an aside shows them, on a native description list.
 *
 * ```html
 * <dl neatDetails>
 *   <dt>Stream</dt><dd>{{ status.stream }}</dd>
 *   @if (source(); as source) {
 *     <dt>Source</dt><dd><code>{{ source }}</code></dd>
 *   }
 * </dl>
 * ```
 *
 * It sets the look only. The pairs, their words and what a value holds are the app's, such as a
 * code span, or an inline button beside a URL. Write each `dt` and `dd` as a direct child of the
 * list, one value per term: the two columns are the list's grid.
 *
 * The terms are muted, and as wide as the widest. The values sit beside them and take the rest of
 * the width. They wrap anywhere when long, and keep their figures aligned.
 *
 * Several lists line up on one term column when an ancestor sets `--neat-details-term-width`, a
 * length such as `7rem`. A term wider than that column breaks inside the word.
 */
export declare class NeatDetails {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDetails, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDetails, "dl[neatDetails]", never, {}, {}, never, never, true, never>;
}