import { NeatOverlayClassStyle, NeatOverlayLineStyle } from "@sima/neat-ui/video";
import * as i0 from "@angular/core";
/**
 * An object seen around the vehicle, such as a detection or a track.
 *
 * It is a box centered on `x`, `y`: `length` long along its heading `yaw`, and `width` across it.
 * It is drawn as a rotated rectangle, filled and outlined in its label's color. A line runs from
 * its center to the middle of its front edge.
 */
interface NeatBevObject {
  /**
   * What identifies it from frame to frame (a track's id), for `hovered` and `activated`. Give
   * every object an id, or none: without one an object is known by its index in `objects`.
   */
  readonly id?: NeatBevObjectId;
  /** Its center, meters forward of the vehicle. */
  readonly x: number;
  /** Its center, meters to the left of the vehicle. */
  readonly y: number;
  /** Meters along its heading. */
  readonly length: number;
  /** Meters across its heading. */
  readonly width: number;
  /** Its heading, radians counter-clockwise from the vehicle's forward axis. */
  readonly yaw: number;
  /** Its class ("car"): what picks its color, and what the readout and the summary name. */
  readonly label: string;
  /** More for the readout, after the label and the distance (a score, a speed). */
  readonly text?: string;
}
/** What identifies an object across frames: its `id`, or its index in `objects` without one. */
type NeatBevObjectId = string | number;
/** A point around the vehicle, meters: x forward, y to the left. */
interface NeatBevPoint {
  readonly x: number;
  readonly y: number;
}
/** A click or tap on the view (not a drag): what it hit, and where. */
interface NeatBevPick extends NeatBevPoint {
  /** The object under it, or null for none. */
  readonly object: NeatBevObject | null;
  /** That object's id (its index without one), or null. */
  readonly id: NeatBevObjectId | null;
  /** The click itself, for its modifier keys. */
  readonly event: MouseEvent;
}
/**
 * Points in one label's color, such as radar or lidar returns.
 *
 * `xy` holds x, y pairs in meters. So a large cloud stays one typed array, and nothing is allocated
 * to draw it.
 */
interface NeatBevPoints {
  /** What picks the points' color, and what the summary counts them as. */
  readonly label: string;
  /** x, y pairs in meters: x forward, y left. */
  readonly xy: Float32Array;
}
/**
 * A polyline in one label's color, such as a planned path, a lane or a boundary.
 *
 * With `fill` it is a polygon, such as a road, a zone, or free space from a model. A polygon is an
 * area, filled as a grid is: a light tint over the surface that covers what lies under it, without
 * an outline.
 *
 * A label's polygons fill as one area, so a road network given as overlapping pieces shows no
 * darker joins. For an outline, give the same points again as a line without `fill`.
 */
interface NeatBevLine {
  /** What picks its color. */
  readonly label: string;
  /** x, y pairs in meters: x forward, y left. */
  readonly xy: Float32Array;
  /** Whether the last point joins the first. */
  readonly closed?: boolean;
  /** Whether it is a polygon filled as an area, as a grid is, without an outline; it is closed. */
  readonly fill?: boolean;
  /** Its dash, as the video overlays' lines have it; a label's style row wins. Solid by default. */
  readonly style?: NeatOverlayLineStyle;
}
/**
 * A grid of cells over a rectangle, such as a drivable area or an occupancy map.
 *
 * It is drawn in its label's color. Each cell's value, 0 to 255, scales the grid's opacity, and 0
 * leaves the cell clear.
 *
 * `cells` is row-major in screen order, so the array reads like the picture. Row 0 is the forward
 * edge (`x[1]`), and column 0 the left edge (`y[1]`).
 *
 * Give a new array for new cells. The grid is redrawn when its `cells` array changes, not when the
 * same array is written to.
 */
interface NeatBevGrid {
  /** What picks its color. */
  readonly label: string;
  /** `columns` × `rows` values, 0 to 255, row 0 forward and column 0 left. */
  readonly cells: Uint8Array;
  readonly columns: number;
  readonly rows: number;
  /** The rectangle's back and front edges, meters forward of the vehicle. */
  readonly x: readonly [min: number, max: number];
  /** The rectangle's right and left edges, meters to the left of the vehicle. */
  readonly y: readonly [min: number, max: number];
}
/** What `neat-bev` draws at one moment. Every part is optional. */
interface NeatBevFrame {
  readonly objects?: readonly NeatBevObject[];
  readonly points?: readonly NeatBevPoints[];
  readonly lines?: readonly NeatBevLine[];
  readonly grids?: readonly NeatBevGrid[];
}
/**
 * What the app draws besides a frame, under the data (`background`) or over it (`foreground`).
 *
 * It holds lines, polygons and points, in their labels' colors. Its polygons are lines with `fill`,
 * and see-through here.
 *
 * It is drawn with the view's cached layers, so it is for what changes rarely: a map's lanes, a
 * camera's field of view, a zone around the vehicle. Give a new object when it changes.
 */
interface NeatBevLayer {
  readonly lines?: readonly NeatBevLine[];
  readonly points?: readonly NeatBevPoints[];
}
/**
 * A line out to the plot's edge: from `origin` (the vehicle's center by default) at `angle`,
 * radians counter-clockwise from forward.
 */
interface NeatBevSpoke {
  readonly angle: number;
  readonly origin?: {
    readonly x: number;
    readonly y: number;
  };
}
/**
 * The plot's shape: `'round'` or `'rect'`.
 *
 * `'round'` is the circle of the view's range around the vehicle, with rings, as a radar shows it.
 * `'rect'` is a rectangle (`bounds`) with a metric grid.
 */
type NeatBevShape = 'round' | 'rect';
/**
 * A rectangle around the vehicle in meters, as `NeatBevGrid` sets one.
 *
 * `x` is its back and front edges, in meters forward. `y` is its right and left edges, in meters to
 * the left.
 */
interface NeatBevBounds {
  readonly x: readonly [min: number, max: number];
  readonly y: readonly [min: number, max: number];
}
/**
 * What lies outside the shape: `'clip'` or `'visible'`.
 *
 * `'clip'` cuts the data and the guides at the shape's edge. `'visible'` draws both over the whole
 * box, the rings and grid lines running on to its edges.
 */
type NeatBevOverflow = 'clip' | 'visible';
/**
 * Where the guides (rings or grid lines, spokes, sensors' edges, the outline) are drawn: `'over'`
 * the data or `'under'` it. Their labels and the vehicle's marker are always on top.
 */
type NeatBevGuides = 'over' | 'under';
/**
 * A bird's-eye view: what a vehicle sees around it, drawn from above.
 *
 * ```html
 * <neat-bev [frame]="frame()" [background]="map" [range]="60" zoom />
 * ```
 *
 * It draws three things:
 * - what the vehicle sees, `frame`: objects, points, lines and grids;
 * - what the app draws under it and over it, `background` and `foreground`;
 * - guides to read distances by, `shape`: rings in a circle, or a metric grid in a rectangle.
 *
 * Positions are in the vehicle's own frame: meters, x forward and y to the left. Forward is up on
 * the screen. Give the view a height, or it takes the shape's proportions.
 *
 * The data and the guides stop at the shape's edge, or run on over the whole box with `overflow`.
 * The guides lie over the data, or under it with `guides`.
 *
 * Labels take their colors from the page's class colors, as the video overlays' classes do. So
 * "car" has one color in the view and in every tile. `styles` sets a label's color and line, as
 * the tiles' class rows do.
 *
 * Hovering an object, or tapping it, reads it out beside it: its label, its distance from the
 * vehicle and its `text`.
 *
 * With `zoom`, the wheel, a pinch and a drag zoom and pan the view, the shape and all. The zoom
 * stays within `zoomExtent`, up to four times the default view unless it says otherwise. Panning
 * stays within what the default view shows and `panBounds`. With focus, the arrow keys pan, `+` and
 * `-` zoom, and `0` resets, as the reset button does while the view is zoomed.
 *
 * A screen reader hears the view as a figure named by `label`, with a summary of what it shows:
 * "18 car, 51 pedestrian within 60 m". The summary changes at most once a second.
 *
 * It draws on one canvas, outside change detection: at the next animation frame after anything
 * changes, and never while the page is hidden.
 */
export declare class NeatBev {
  /** What to draw now; null draws only the plot. Give a new object for each moment. */
  readonly frame: import("@angular/core").InputSignal<NeatBevFrame | null>;
  /**
   * Lines, polygons and points drawn under the data, which change rarely: a map's lanes, a
   * camera's field of view. Give a new object when it changes.
   */
  readonly background: import("@angular/core").InputSignal<NeatBevLayer | null>;
  /** The same, drawn over the data (and the guides): a zone around the vehicle, say. */
  readonly foreground: import("@angular/core").InputSignal<NeatBevLayer | null>;
  /**
   * The spokes: a number of them spaced evenly, or a list that places each one.
   *
   * A number spaces that many evenly from straight ahead: 12, every 30°, by default, and 0 for
   * none. A list places each one, from its own origin if it has one. That draws a rig's seams
   * between its cameras, say, or lines from where the cameras are mounted.
   */
  readonly spokes: import("@angular/core").InputSignal<number | readonly NeatBevSpoke[]>;
  /** Meters from the vehicle to the circle, and to the rectangle's edges without `bounds`. */
  readonly range: import("@angular/core").InputSignal<number>;
  /** The circle of `range` with rings (`'round'`), or the rectangle `bounds` with a grid. */
  readonly shape: import("@angular/core").InputSignal<NeatBevShape>;
  /** The rectangle in meters (`'rect'`), as a grid sets one; null is ±`range`. */
  readonly bounds: import("@angular/core").InputSignal<NeatBevBounds | null>;
  /** Whether the shape's edge is drawn. */
  readonly outline: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Whether the data and the guides stop at the shape (`'clip'`) or run on over the box. */
  readonly overflow: import("@angular/core").InputSignal<NeatBevOverflow>;
  /** Whether rings or grid lines, spokes and the outline lie over the data. */
  readonly guides: import("@angular/core").InputSignal<NeatBevGuides>;
  /** Whether wheel, pinch, drag and keys zoom and pan the view; off, the page scrolls over it. */
  readonly zoom: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * A rectangle in meters the view may also pan over, besides what the default view shows.
   *
   * With a smaller `range`, it makes a view that starts zoomed in and still reaches further out.
   */
  readonly panBounds: import("@angular/core").InputSignal<NeatBevBounds | null>;
  /**
   * How far the view zooms out and in, relative to the default view (1).
   *
   * By default it zooms in up to four times, and not out. A min below 1 zooms out beyond the
   * default view. The extent always takes in 1.
   */
  readonly zoomExtent: import("@angular/core").InputSignal<readonly [min: number, max: number]>;
  /**
   * The object outlined and read out, by its `id`, or its index without one.
   *
   * It is the one under the pointer while the pointer is over the view, and null once it leaves.
   * Otherwise it is the one the app sets. It changes when another object comes under the pointer,
   * not with every frame.
   */
  readonly hovered: import("@angular/core").ModelSignal<NeatBevObjectId | null>;
  /** A click or tap on the view that is no drag: the object it hit (or null) and the point. */
  readonly activated: import("@angular/core").OutputEmitterRef<NeatBevPick>;
  /**
   * Where a mouse or pen is over the view, in meters; null when it leaves.
   *
   * It emits at most once a frame, and only when the point changed. A zoom moves it too.
   */
  readonly pointerMove: import("@angular/core").OutputEmitterRef<NeatBevPoint | null>;
  /** A label's color, line and width, as the video overlays' class rows set them for the tiles. */
  readonly styles: import("@angular/core").InputSignal<readonly NeatOverlayClassStyle[]>;
  /** The plot's accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  private readonly host;
  private readonly document;
  private readonly zone;
  private readonly canvasElement;
  private readonly colors;
  private readonly themeColors;
  private readonly scheme;
  /** The plot's own colors and font, as the canvas takes them; a new object for a new theme. */
  private readonly theme;
  private readonly inputs;
  /** The host's proportions without a height of the app's: the shape's. */
  protected readonly aspect: import("@angular/core").Signal<string>;
  protected readonly readoutClasses: {
    readonly box: "z-1 flex flex-col gap-0.5 p-(--neat-space-2) border border-border rounded-(--radius) bg-popover text-popover-foreground text-(length:--neat-text-xs) tabular-nums whitespace-nowrap pointer-events-none";
    readonly muted: "text-muted-foreground";
    readonly row: "inline-flex items-center gap-(--neat-space-2)";
  };
  private readonly readoutBox;
  /** The color of the object read out, for its swatch: it changes only with another object. */
  protected readonly readoutColor: import("@angular/core").WritableSignal<string>;
  private readonly readoutName;
  private readonly readoutDistance;
  private readonly readoutText;
  private readonly summaryElement;
  /** Whether the view is zoomed or panned away from the whole range: the reset button shows. */
  protected readonly zoomed: import("@angular/core").WritableSignal<boolean>;
  private canvas;
  private readout;
  /** Where the pointer is over the box (CSS px), or the last tap; null for neither. */
  private pointer;
  /** Whether `pointer` is a mouse or pen over the box, not a tap: what `pointerMove` reports. */
  private hovering;
  /** Whether the pointer has left, or the readout was put away: the hover goes back to null. */
  private released;
  /** The point `pointerMove` last reported. */
  private reported;
  /** The view, the inputs and the frame last drawn: what a click is tested against. */
  private drawn;
  /** The kind of the last press: a touch reads out by a tap, a mouse or pen by hovering. */
  private pressedBy;
  /** The summary written, the frame and plot it was made from, when, and the one waiting. */
  private summary;
  private summaryOf;
  private summaryAt;
  private summaryTimer;
  private readonly vehiclePoint;
  private readonly screenPoint;
  /** The pan and zoom, while `zoom` is on and the view is rendered. */
  private zoomer;
  /** Whether the view has rendered: the zoom is made from then on. */
  private rendered;
  /** The pan and zoom on top of the default view. */
  private transform;
  /** The box and the pan bounds the zoom was last given, so a frame gives it only new ones. */
  private bounded;
  /** The style rows the colors were last given. */
  private stylesGiven;
  private width;
  private height;
  private request;
  private destroyed;
  constructor();
  /**
   * The color the view draws `label` in, for a swatch in a list beside it; null while it has none.
   *
   * ```html
   * <neat-bev #view [frame]="frame()" />
   * @if (view.colorOf('car'); as color) {
   *   <neat-swatch [color]="color" />
   * }
   * car
   * ```
   *
   * It is the label's row in `styles`, else its class color. A class has the same color in every
   * video tile of the page, so this is the color a tile's `colorOf` gives a detection of that
   * label without a style row.
   *
   * It is null for a label the page has not drawn yet, or no longer holds a color for: a class
   * gone for about 5 s may give its color to another. A style row's color it gives at once.
   *
   * It reads signals, so a template or a `computed` that calls it updates when a class color is
   * given or taken back, and when `styles` change. Asking records no draw, so it keeps no color
   * alive.
   */
  colorOf(label: string): string | null;
  /** Back to the default view. */
  protected reset(): void;
  /**
   * Makes the zoom when it turns on (once the view has rendered), outside change detection, or
   * takes it away when it turns off, the view back at the default.
   */
  private syncZoom;
  /** A frame, unless one is coming, the page is hidden, there is no canvas yet or it is gone. */
  private schedule;
  /**
   * Draws at once, in place of a frame that may be coming: from a `ResizeObserver`'s callback,
   * which runs after layout and before the paint, so the canvas is the new size when it is shown.
   */
  private drawNow;
  /** Where `event` is over the box, CSS px. */
  private pointOf;
  /** A mouse or pen over the box reads out what it hovers; a finger does by tapping. */
  private readonly moved;
  private readonly left;
  /** No pointer any more: the hover goes back to null at the next frame. */
  private release;
  private readonly pointerDown;
  /**
   * A click or tap that is no drag (d3-zoom swallows those) and not on the reset button: the app
   * hears what it hit; a tap also reads out what it lands on, or puts the readout away.
   */
  private readonly click;
  private readonly escape;
  private readonly visibility;
  private readonly tick;
  /**
   * Says what a new frame or range shows, at most once every `SUMMARY_MS`: one sooner waits for
   * its turn, and the newest frame by then is the one summed up.
   */
  private summarize;
  /**
   * The index of the object to outline and read out. While a pointer is over the view, the one
   * under it, and `hovered` follows when that is another object; otherwise the one `hovered`
   * names, as the app may have set it (null once the pointer has left).
   */
  private hover;
  /** Sets `hovered` when it changes, in the zone, so that an app's listener runs as any other. */
  private setHovered;
  /** Reports where a mouse or pen is, meters, when that changed; null once it has gone. */
  private report;
  /** The index of the object at `pointer` (CSS px), where the view shows objects; -1 for none. */
  private hitAt;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatBev, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatBev, "neat-bev", never, {
    "frame": {
      "alias": "frame";
      "required": false;
      "isSignal": true;
    };
    "background": {
      "alias": "background";
      "required": false;
      "isSignal": true;
    };
    "foreground": {
      "alias": "foreground";
      "required": false;
      "isSignal": true;
    };
    "spokes": {
      "alias": "spokes";
      "required": false;
      "isSignal": true;
    };
    "range": {
      "alias": "range";
      "required": false;
      "isSignal": true;
    };
    "shape": {
      "alias": "shape";
      "required": false;
      "isSignal": true;
    };
    "bounds": {
      "alias": "bounds";
      "required": false;
      "isSignal": true;
    };
    "outline": {
      "alias": "outline";
      "required": false;
      "isSignal": true;
    };
    "overflow": {
      "alias": "overflow";
      "required": false;
      "isSignal": true;
    };
    "guides": {
      "alias": "guides";
      "required": false;
      "isSignal": true;
    };
    "zoom": {
      "alias": "zoom";
      "required": false;
      "isSignal": true;
    };
    "panBounds": {
      "alias": "panBounds";
      "required": false;
      "isSignal": true;
    };
    "zoomExtent": {
      "alias": "zoomExtent";
      "required": false;
      "isSignal": true;
    };
    "hovered": {
      "alias": "hovered";
      "required": false;
      "isSignal": true;
    };
    "styles": {
      "alias": "styles";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {
    "hovered": "hoveredChange";
    "activated": "activated";
    "pointerMove": "pointerMove";
  }, never, never, true, never>;
}
export type { NeatBevBounds, NeatBevFrame, NeatBevGrid, NeatBevGuides, NeatBevLayer, NeatBevLine, NeatBevObject, NeatBevObjectId, NeatBevOverflow, NeatBevPick, NeatBevPoint, NeatBevPoints, NeatBevShape, NeatBevSpoke };