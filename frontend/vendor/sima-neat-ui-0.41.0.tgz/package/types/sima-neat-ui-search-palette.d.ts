import { NeatIconGlyph, NeatIconName, NeatViewport } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/** One result: what it is called, where it is, and the address it opens. */
interface NeatSearchItem {
  /** Stable across searches, so the list keeps its rows. */
  readonly id: string;
  readonly label: string;
  /** Where it is, shown muted at the row's end ("Components › Forms"). */
  readonly detail?: string;
  /** A name of the kit's icons, or a Lucide glyph, before the label. */
  readonly icon?: NeatIconName | NeatIconGlyph;
  /** The app's address it opens, with any query and fragment (`/components/forms/search#api-NeatSearch`). */
  readonly path: string;
}
/** Results of one kind, under a heading ("Topics", "API"). */
interface NeatSearchGroup {
  readonly label: string;
  readonly items: readonly NeatSearchItem[];
}
/** What the palette says beside the results; each has a default. */
interface NeatSearchPaletteLabels {
  /** Before anything is typed. */
  readonly empty: string;
  /** The status when nothing matches. */
  readonly noMatches: string;
  /** The status counting what matched, given the count. */
  readonly matches: (count: number) => string;
  /** The link to the app's page of every result. */
  readonly allResults: string;
  /** The keys, at the palette's foot. */
  readonly keys: string;
}
/**
 * Helm's dialog backdrop (`lib/ui/dialog/src/lib/hlm-dialog-overlay.ts`), copied because helm keeps
 * it inline, as `NeatDialog` and `NeatConfirm` do; search-palette.spec checks that it is still
 * there, so a helm update that changes it fails until this is reviewed.
 */
declare const BACKDROP_HELM_CLASSES = "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs";
/**
 * A search over the whole app: a trigger that looks like a search field, for the top bar, and the
 * palette it opens, a dialog with a field over the results in groups.
 *
 * ```html
 * <neat-search-palette neatTopbarEnd label="Search docs" [search]="search" allResults="/search" />
 * ```
 *
 * `search` is the app's: a function from what was typed to groups of results
 * (`NeatSearchGroup`), each item a label, where it is, an icon and the address it opens. The
 * palette shows the first `limit` of each group. The arrow keys move through them, Enter or a click
 * opens one and closes the palette, and with `allResults` (the address of the app's page of every
 * result, which gets the search as `q`) a link at its foot, and Enter while nothing is picked, go
 * there. Each result is a link, so a middle click or Ctrl-click opens it in a new tab.
 *
 * Ctrl K (⌘K on a Mac) opens it from anywhere on the page, unless `shortcut` is off; the trigger
 * shows the keys as a `NeatShortcut` and names them in `aria-keyshortcuts`. On a narrow screen the
 * trigger is an icon-only button. Escape clears the field, then closes the palette; a click beside
 * it closes it too. Closing puts the focus back where it was.
 *
 * `open` is the palette's state, which the app may also set. `picked` tells which result was
 * opened. The field is a `neat-search` acting as a combobox over the results' listbox, and the
 * count of matches is its status, announced politely.
 */
export declare class NeatSearchPalette {
  /** The search's name: the trigger's text, and the field's name and hint ("Search docs"). */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The app's search: what was typed, to groups of results. Called as the user types. */
  readonly search: import("@angular/core").InputSignal<(query: string) => readonly NeatSearchGroup[]>;
  /**
   * The address of the app's page of every result, which gets the search as its `q` query
   * parameter (`/search`); no such link without it.
   */
  readonly allResults: import("@angular/core").InputSignal<string | undefined>;
  /** How many results of each group the palette shows. */
  readonly limit: import("@angular/core").InputSignal<number>;
  /** Whether Ctrl K (⌘K on a Mac) opens the palette from anywhere on the page. */
  readonly shortcut: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** What the palette says beside the results, where an app words it differently. */
  readonly labels: import("@angular/core").InputSignal<Partial<NeatSearchPaletteLabels>>;
  /** Whether the palette is open; the trigger and the shortcut open it, the app may too. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  /** The result that was opened, by a click, a tap or Enter. */
  readonly picked: import("@angular/core").OutputEmitterRef<NeatSearchItem>;
  protected readonly viewport: NeatViewport;
  private readonly dialog;
  private readonly overlay;
  private readonly router;
  private readonly location;
  private readonly panel;
  private readonly results;
  private ref;
  protected readonly listboxId: string;
  protected readonly panelClasses: string;
  protected readonly text: import("@angular/core").Signal<{
    empty: string;
    noMatches: string;
    matches: (count: number) => string;
    allResults: string;
    keys: string;
  }>;
  protected readonly query: import("@angular/core").WritableSignal<string>;
  /** The groups to show, each cut to `limit`, each row numbered in the order the keys move. */
  protected readonly shown: import("@angular/core").Signal<{
    label: string;
    rows: {
      item: NeatSearchItem;
      index: number;
    }[];
  }[]>;
  private readonly rows;
  /** The row the keys are on: the first, again, whenever the results change. */
  protected readonly active: import("@angular/core").WritableSignal<number>;
  protected readonly activeId: import("@angular/core").Signal<string | null>;
  protected readonly status: import("@angular/core").Signal<string>;
  protected readonly allResultsUrl: import("@angular/core").Signal<string | null>;
  constructor();
  protected optionId(index: number): string;
  /** An app address as the link's `href`, with the app's base. */
  protected href(path: string): string;
  /** Ctrl K or ⌘K, from anywhere on the page. */
  protected onShortcut(event: KeyboardEvent): void;
  /** The arrow keys and Enter, from anywhere in the palette (the field has the focus). */
  private onKeydown;
  /** A plain click opens the result here; a click that asks for a new tab is the browser's. */
  protected onClick(event: MouseEvent, item: NeatSearchItem): void;
  protected onAllResults(event: MouseEvent, url: string): void;
  private go;
  private goTo;
  private show;
  private hide;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSearchPalette, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSearchPalette, "neat-search-palette", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "search": {
      "alias": "search";
      "required": true;
      "isSignal": true;
    };
    "allResults": {
      "alias": "allResults";
      "required": false;
      "isSignal": true;
    };
    "limit": {
      "alias": "limit";
      "required": false;
      "isSignal": true;
    };
    "shortcut": {
      "alias": "shortcut";
      "required": false;
      "isSignal": true;
    };
    "labels": {
      "alias": "labels";
      "required": false;
      "isSignal": true;
    };
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
    "picked": "picked";
  }, never, never, true, never>;
}
export type { NeatSearchGroup, NeatSearchItem, NeatSearchPaletteLabels };