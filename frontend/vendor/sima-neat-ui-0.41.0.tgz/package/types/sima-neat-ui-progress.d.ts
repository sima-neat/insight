import * as i0 from "@angular/core";
/**
 * Helm's progress classes (`lib/ui/progress/src/lib/hlm-progress.ts` and
 * `hlm-progress-indicator.ts`), copied because helm keeps them inline. progress.spec checks that
 * each string still appears in the vendored helm, so a helm update that changes one fails until
 * this table is reviewed.
 */
declare const PROGRESS_HELM_CLASSES: {
  readonly track: "bg-muted h-1.5 rounded-full relative inline-flex w-full overflow-hidden";
  readonly indicator: "bg-primary h-full w-full flex-1 transition-all";
};
/**
 * A horizontal progress bar.
 *
 * ```html
 * <neat-progress label="Uploading clip.mp4" [value]="percent" />
 * ```
 *
 * `value` is 0 to 100, or `null` while the work cannot say how far along it is. The bar then moves
 * on its own. Under a reduced-motion setting it is a still bar of stripes.
 *
 * A value outside the range is held to it, and one that is not a number counts as unknown. So a
 * sloppy caller gets a bar, not an error.
 *
 * With a `heading` it is a titled readout, for work the user watches: an import, an encode, a
 * progress toast. It shows the heading with the whole percent at its line's end, the `detail`
 * under it, then the bar. The detail is one line, cut with its full text as a tooltip, and left out
 * while empty. The progress toast of `NeatToasts` renders through it:
 *
 * ```html
 * <neat-progress heading="Uploading 3 files" [detail]="'clip.mp4 · file 1 of 3'" [value]="41" />
 * ```
 *
 * The heading is a polite `role="status"`. A screen reader hears it when it changes, from
 * "Uploading" to "Preparing" say. It does not hear the percent or the detail, which change too
 * often to be read out. The input is named `heading` rather than `title`, so that a static
 * attribute does not also become the native tooltip of the whole element.
 *
 * `label` is the bar's accessible name, the heading by default. The bar is `role="progressbar"`,
 * with `aria-valuenow` (left out while unknown), `aria-valuemin` and `aria-valuemax`, and a percent
 * as `aria-valuetext`. A bar alone announces nothing as it changes, which is a progressbar's way.
 * So give a bar without a heading a `label`.
 *
 * It fills the width its container gives it, from the left: the kit has no right-to-left layout.
 */
export declare class NeatProgress {
  /** 0 to 100, or `null` while unknown. */
  readonly value: import("@angular/core").InputSignal<number | null>;
  /** The bar's accessible name, announced with the value; the heading by default. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Shown over the bar with the percent: a titled readout. None while empty. */
  readonly heading: import("@angular/core").InputSignal<string>;
  /** A line under the heading: what is being worked on now. None while empty. */
  readonly detail: import("@angular/core").InputSignal<string>;
  protected readonly trackClasses: string;
  protected readonly readoutClasses = "flex flex-col gap-(--neat-space-2) text-(length:--neat-text-sm)";
  protected readonly titleClasses = "m-0 flex justify-between gap-(--neat-space-3) font-medium tabular-nums";
  protected readonly detailClasses = "m-0 truncate text-muted-foreground tabular-nums text-(length:--neat-text-xs)";
  /** The value the bar shows: within the range, or `null` when unknown. */
  protected readonly shown: import("@angular/core").Signal<number | null>;
  /** The whole percent the readout shows; `null` while unknown. */
  protected readonly percent: import("@angular/core").Signal<number | null>;
  protected readonly indicatorClasses: import("@angular/core").Signal<string>;
  /**
   * The fill is as wide as the track and pushed out of it by the part that is not done. This and
   * the unknown state's class switch re-implement helm's `HlmProgressIndicator`; the drift spec
   * covers helm's class strings only, so a change to its logic needs a look at this by hand.
   */
  protected readonly transform: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatProgress, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatProgress, "neat-progress", never, {
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "heading": {
      "alias": "heading";
      "required": false;
      "isSignal": true;
    };
    "detail": {
      "alias": "detail";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export {};