import * as i0 from "@angular/core";
/**
 * A small field for one whole number, for jumping to a number such as a page or a channel, or for
 * a setting stepped up and down such as a frame rate.
 *
 * ```html
 * <neat-number-field label="Page" [value]="page" [accept]="inRange" (commit)="goTo($event)">
 *   <span neatNumberFieldSuffix>of 9</span>
 * </neat-number-field>
 * ```
 *
 * Its label sits before it; `showLabel` false hides it where a heading already names the field,
 * and it stays the input's accessible name. Content marked `neatNumberFieldSuffix` follows the
 * field, such as "of 9". A `unit` ("fps") sits inside the field's box, after the number.
 *
 * The field shows `value`, or an empty field with "–" while `value` is null. Typing changes nothing
 * outside until the user commits, with Enter or by leaving the field. `commit` then carries the
 * number if it is whole digits within `min` and `max` that `accept` takes. It does so even when the
 * number equals `value`, so an owner can treat a number the user typed as a choice. Anything else
 * puts `value` back in the field and emits nothing; while it is typed, the input is
 * `aria-invalid`.
 *
 * Leaving a field that was not typed in emits nothing, so tabbing past it chooses nothing. Enter
 * always commits what is shown.
 *
 * With `step`, a − button at the box's start and a + button at its end commit the number one step
 * down or up at once, held to `min` and `max` (3 less a step of 5 is 1 with `min` 1). They step
 * from what was typed when it is whole digits within the bounds, else from `value`, so + and −
 * always move the number shown the way they say. A button that cannot step (at a bound, or with no
 * number shown) is `aria-disabled` and does nothing. Holding a button steps once. The input is then
 * a spinbutton (WAI-ARIA): ArrowUp and ArrowDown step as the buttons do, and the buttons are for
 * the pointer only (no tab stops), so the field stays one tab stop.
 *
 * ```html
 * <neat-number-field label="Frames per second" [showLabel]="false" [value]="rate" [step]="5"
 *   [min]="1" unit="fps" (commit)="setRate($event)" />
 * ```
 *
 * The owner is expected to take what it accepted: after a commit, the field shows that number until
 * `value` changes. An owner that refuses a committed number, and so keeps `value` as it was, calls
 * `reset()` to show `value` again.
 */
export declare class NeatNumberField {
  /** Shown before the input unless `showLabel` is false, and its accessible name either way. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The number the field shows; null while there is none, shown as an empty field with "–". */
  readonly value: import("@angular/core").InputSignal<number | null>;
  /** Whether the owner takes a whole number within `min` and `max`; the default takes any. */
  readonly accept: import("@angular/core").InputSignal<(n: number) => boolean>;
  /**
   * How far the − and + buttons and the arrow keys move the number, a positive whole number; null
   * (the default) for a field without steps.
   */
  readonly step: import("@angular/core").InputSignal<number | null>;
  /**
   * The least number the field takes, typed or stepped; null (the default) for 0, the least whole
   * number.
   */
  readonly min: import("@angular/core").InputSignal<number | null>;
  /** The greatest number the field takes, typed or stepped; null (the default) for no limit. */
  readonly max: import("@angular/core").InputSignal<number | null>;
  /** What the number counts ("fps"), shown inside the box after it; none by default. */
  readonly unit: import("@angular/core").InputSignal<string>;
  /** Whether the label is shown before the field; false where a heading names it already. */
  readonly showLabel: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Turns the field off: the input and both buttons are disabled and nothing commits. */
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** A whole number the user committed, by typing or by a step, that the field and `accept` took. */
  readonly commit: import("@angular/core").OutputEmitterRef<number>;
  protected readonly noValue = "–";
  /** The kit's small text field, or, in a frame, the input inside it and the frame's look. */
  protected readonly fieldClasses: string;
  protected readonly inFrameClasses: string;
  protected readonly frameClasses: string;
  protected readonly inputId: string;
  protected readonly unitId: string;
  /** Whether the field has steps, which make the input a spinbutton. */
  protected readonly steps: import("@angular/core").Signal<boolean>;
  /** Whether the box draws the field's look around the input and the parts beside it. */
  protected readonly framed: import("@angular/core").Signal<boolean>;
  /** The least number the field takes. */
  protected readonly floor: import("@angular/core").Signal<number>;
  protected readonly valueText: import("@angular/core").Signal<string | null>;
  /** What the user typed since the field last showed `value` or committed; null if nothing. */
  protected readonly draft: import("@angular/core").WritableSignal<string | null>;
  /** Whether what is typed is a number the field will not take; an emptied field is not. */
  protected readonly invalid: import("@angular/core").Signal<boolean>;
  /**
   * The number the steps start from: what was typed when it is whole digits within the bounds, else
   * `value`.
   */
  private readonly shown;
  private readonly field;
  constructor();
  /**
   * Focuses the input with its number selected, so what the user types replaces it.
   *
   * Call it from a shortcut that jumps to the field, such as "g" for the page.
   */
  focus(): void;
  /**
   * Shows `value` again and drops what was typed, with its invalid mark.
   *
   * For an owner that refused a number the field committed (a server that will not take 500 fps):
   * its `value` stays as it was, so the field would keep showing the refused number until `value`
   * changes.
   */
  reset(): void;
  /**
   * Reads the field on Enter (`force`) or on leaving it: commits a number it takes, else shows
   * `value` again. Leaving an untouched field does nothing.
   */
  protected commitFrom(field: HTMLInputElement, force: boolean): void;
  /**
   * Whether the button or arrow key for `direction` steps: the field is on, it shows a number (typed
   * or `value`), and that number is not at the bound.
   */
  protected canStep(direction: 1 | -1): boolean;
  /**
   * Whether a step button is `aria-disabled`: it cannot step while the field is on. A disabled
   * field's buttons are `disabled`, which dims them with the frame, so they carry no mark.
   */
  protected stalled(direction: 1 | -1): boolean;
  /**
   * A press on the box that is not on the input focuses the input, so the unit, the padding and the
   * room beside the number act as the field they look like. The default is kept from moving the
   * focus elsewhere, which a step button also needs: it steps without taking the focus.
   */
  protected boxPress(event: MouseEvent, field: HTMLInputElement): void;
  protected arrow(event: Event, direction: 1 | -1, field: HTMLInputElement): void;
  /** Commits the number a step from what was typed, if whole digits, else from `value`. */
  protected stepBy(direction: 1 | -1, field: HTMLInputElement): void;
  /** `from` a step in `direction`, held to the field's bounds. */
  private stepped;
  /** Whether `number` is a whole number within the field's bounds. */
  private inBounds;
  /** Whether the field takes `number`: a whole number within its bounds that `accept` takes. */
  private takes;
  private commitNumber;
  private showValue;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNumberField, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatNumberField, "neat-number-field", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "unit": {
      "alias": "unit";
      "required": false;
      "isSignal": true;
    };
    "showLabel": {
      "alias": "showLabel";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "commit": "commit";
  }, never, ["[neatNumberFieldSuffix]"], true, never>;
}