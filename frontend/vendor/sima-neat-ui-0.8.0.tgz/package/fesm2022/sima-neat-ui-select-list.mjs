import { NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, TemplateRef, afterRenderEffect, booleanAttribute, computed, contentChildren, inject, input, model, output, signal, viewChild } from "@angular/core";
import { NeatIcon } from "@sima/neat-ui";
const HEADER_CLASSES = "shrink-0 overflow-y-hidden border-b border-border text-xs font-medium text-muted-foreground [scrollbar-gutter:stable]";
const SCROLLER_CLASSES = "min-h-0 flex-1 overflow-x-hidden overflow-y-auto [scrollbar-gutter:stable] has-[[role=listbox]:focus-visible]:outline-2 has-[[role=listbox]:focus-visible]:-outline-offset-2 has-[[role=listbox]:focus-visible]:outline-ring";
const LINE_CLASSES = "grid grid-cols-(--neat-select-list-columns) items-center gap-x-(--neat-space-3) border-s-2 border-transparent px-(--neat-space-3)";
const ROW_CLASSES = `${LINE_CLASSES} min-h-9 cursor-default py-1 text-sm hover:bg-accent data-active:border-primary data-active:bg-accent`;
const HEADER_LINE_CLASSES = `${LINE_CLASSES} py-1`;
const CHECK_CLASSES = "flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-sm border border-input data-checked:border-primary data-checked:bg-primary";
const CHECK_TRACK = "1rem";
const MOVES = {
	ArrowDown: (index, count) => Math.min(index + 1, count - 1),
	ArrowUp: (index, count) => index < 0 ? count - 1 : Math.max(index - 1, 0),
	Home: () => 0,
	End: (_, count) => count - 1
};
const INTERACTIVE = "button, a[href], input, select, textarea, summary, [role=\"button\"], [contenteditable], [tabindex]";
const NONE = Symbol("none");
var NeatColumn = class NeatColumn {
	key = input.required({
		...ngDevMode ? { debugName: "key" } : /* istanbul ignore next */ {},
		alias: "neatColumn"
	});
	header = input("", ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	width = input("1fr", ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	hideBelow = input(...ngDevMode ? [void 0, { debugName: "hideBelow" }] : /* istanbul ignore next */ []);
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatColumn,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatColumn,
		isStandalone: true,
		selector: "ng-template[neatColumn]",
		inputs: {
			key: {
				classPropertyName: "key",
				publicName: "neatColumn",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideBelow: {
				classPropertyName: "hideBelow",
				publicName: "hideBelow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatColumn,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatColumn]" }]
	}],
	propDecorators: {
		key: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "neatColumn",
				required: true
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		hideBelow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideBelow",
				required: false
			}]
		}]
	}
});
const sameColumns = (a, b) => a.length === b.length && a.every((column, index) => column === b[index]);
let nextListId = 0;
var NeatSelectList = class NeatSelectList {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	items = input.required(...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	trackBy = input.required(...ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []);
	selected = model(null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	checkable = input(false, {
		...ngDevMode ? { debugName: "checkable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	checked = model([], ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	canCheck = input(() => true, ...ngDevMode ? [{ debugName: "canCheck" }] : /* istanbul ignore next */ []);
	emptyLabel = input("", ...ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []);
	hint = input("", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	activated = output();
	headerClasses = HEADER_CLASSES;
	headerLineClasses = HEADER_LINE_CLASSES;
	scrollerClasses = SCROLLER_CLASSES;
	rowClasses = ROW_CLASSES;
	checkClasses = CHECK_CLASSES;
	id = ++nextListId;
	emptyId = `neat-select-list-${this.id}-empty`;
	hintId = `neat-select-list-${this.id}-hint`;
	columns = contentChildren(NeatColumn, {
		...ngDevMode ? { debugName: "columns" } : /* istanbul ignore next */ {},
		descendants: true
	});
	listbox = viewChild.required("listbox", ...ngDevMode ? [{ debugName: "listbox" }] : /* istanbul ignore next */ []);
	scroller = viewChild.required("scroller", ...ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []);
	width = signal(null, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	hidesColumns = computed(() => this.columns().some((column) => column.hideBelow() !== void 0), ...ngDevMode ? [{ debugName: "hidesColumns" }] : /* istanbul ignore next */ []);
	visibleColumns = computed(() => {
		const width = this.width();
		return this.columns().filter((column) => {
			const hideBelow = column.hideBelow();
			return hideBelow === void 0 || width === null || width >= hideBelow;
		});
	}, {
		...ngDevMode ? { debugName: "visibleColumns" } : /* istanbul ignore next */ {},
		equal: sameColumns
	});
	hasHeader = computed(() => this.visibleColumns().some((column) => column.header()), ...ngDevMode ? [{ debugName: "hasHeader" }] : /* istanbul ignore next */ []);
	gridColumns = computed(() => [...this.checkable() ? [CHECK_TRACK] : [], ...this.visibleColumns().map((column) => column.width())].join(" "), ...ngDevMode ? [{ debugName: "gridColumns" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const keyOf = this.trackBy();
		const canCheck = this.checkable() ? this.canCheck() : () => false;
		return this.items().map((item, index) => ({
			item,
			key: keyOf(item),
			checkable: canCheck(item),
			id: `neat-select-list-${this.id}-${index}`,
			context: { $implicit: item }
		}));
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	checkedKeys = computed(() => new Set(this.checked()), ...ngDevMode ? [{ debugName: "checkedKeys" }] : /* istanbul ignore next */ []);
	isEmpty = computed(() => this.rows().length === 0 && !!this.emptyLabel(), ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => [this.isEmpty() ? this.emptyId : "", this.hint() ? this.hintId : ""].filter(Boolean).join(" ") || null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	selectedKey = computed(() => {
		const selected = this.selected();
		return selected === null ? NONE : this.trackBy()(selected);
	}, ...ngDevMode ? [{ debugName: "selectedKey" }] : /* istanbul ignore next */ []);
	selectedIndex = computed(() => {
		const key = this.selectedKey();
		return this.rows().findIndex((row) => row.key === key);
	}, ...ngDevMode ? [{ debugName: "selectedIndex" }] : /* istanbul ignore next */ []);
	activeId = computed(() => this.rows()[this.selectedIndex()]?.id ?? null, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	revealed = NONE;
	constructor() {
		afterRenderEffect(() => this.revealSelected());
		this.watchWidthWhileNeeded();
	}
	watchWidthWhileNeeded() {
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		const setWidth = (width) => this.width.set(width > 0 ? width : null);
		let observer;
		afterRenderEffect(() => {
			if (observer || !this.hidesColumns()) return;
			setWidth(host.getBoundingClientRect().width);
			observer = new ResizeObserver((entries) => setWidth(entries[entries.length - 1].contentRect.width));
			observer.observe(host);
		});
		destroyRef.onDestroy(() => observer?.disconnect());
	}
	revealSelected() {
		const index = this.selectedIndex();
		if (index < 0) {
			this.revealed = NONE;
			return;
		}
		const key = this.rows()[index].key;
		if (key === this.revealed) return;
		this.revealed = key;
		this.listbox().nativeElement.children[index]?.scrollIntoView?.({ block: "nearest" });
	}
	resetScroll() {
		this.scroller().nativeElement.scrollTop = 0;
		this.revealed = NONE;
		this.revealSelected();
	}
	focus() {
		this.listbox().nativeElement.focus();
	}
	onKeydown(event) {
		if (event.target !== event.currentTarget) return;
		if (event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
		if (event.key === " ") {
			event.preventDefault();
			const row = this.rows()[this.selectedIndex()];
			if (row) this.toggle(row);
			return;
		}
		const rows = this.rows();
		if (rows.length === 0) return;
		if (event.key === "Enter") {
			const row = rows[this.selectedIndex()];
			if (!row) return;
			event.preventDefault();
			this.activated.emit(row.item);
			return;
		}
		const move = MOVES[event.key];
		if (!move) return;
		event.preventDefault();
		this.selected.set(rows[move(this.selectedIndex(), rows.length)].item);
	}
	onClick(event) {
		const target = event.target;
		const option = target.closest("[role=\"option\"]");
		if (!option) return;
		const control = target.closest(INTERACTIVE);
		if (control && control !== option && option.contains(control)) return;
		const row = this.rows()[Array.prototype.indexOf.call(option.parentElement.children, option)];
		if (target.closest("[data-slot=\"select-list-check\"]")) {
			this.toggle(row);
			return;
		}
		this.selected.set(row.item);
		this.activated.emit(row.item);
	}
	toggle(row) {
		if (!row.checkable) return;
		this.checked.update((keys) => keys.includes(row.key) ? keys.filter((key) => key !== row.key) : [...keys, row.key]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSelectList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSelectList,
		isStandalone: true,
		selector: "neat-select-list",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			trackBy: {
				classPropertyName: "trackBy",
				publicName: "trackBy",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checkable: {
				classPropertyName: "checkable",
				publicName: "checkable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checked: {
				classPropertyName: "checked",
				publicName: "checked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canCheck: {
				classPropertyName: "canCheck",
				publicName: "canCheck",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyLabel: {
				classPropertyName: "emptyLabel",
				publicName: "emptyLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selectedChange",
			checked: "checkedChange",
			activated: "activated"
		},
		host: {
			properties: { "style.--neat-select-list-columns": "gridColumns()" },
			classAttribute: "flex h-full min-h-0 flex-col"
		},
		queries: [{
			propertyName: "columns",
			predicate: NeatColumn,
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "listbox",
			first: true,
			predicate: ["listbox"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "scroller",
			first: true,
			predicate: ["scroller"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (hasHeader()) {
      <div data-slot="select-list-header" aria-hidden="true" [class]="headerClasses">
        <div [class]="headerLineClasses">
          @if (checkable()) {
            <span></span>
          }
          @for (column of visibleColumns(); track column) {
            <span class="min-w-0 truncate">{{ column.header() }}</span>
          }
        </div>
      </div>
    }
    <div #scroller [class]="scrollerClasses">
      @if (hint()) {
        <span class="sr-only" [id]="hintId">{{ hint() }}</span>
      }
      <div
        #listbox
        role="listbox"
        tabindex="0"
        class="outline-none"
        [attr.aria-label]="label()"
        [attr.aria-multiselectable]="checkable() || null"
        [attr.aria-activedescendant]="activeId()"
        [attr.aria-describedby]="describedBy()"
        (keydown)="onKeydown($event)"
        (click)="onClick($event)"
      >
        @for (row of rows(); track row.key) {
          <div
            role="option"
            [id]="row.id"
            [class]="rowClasses"
            [attr.data-active]="row.key === selectedKey() ? '' : null"
            [attr.aria-selected]="
              checkable()
                ? row.checkable
                  ? checkedKeys().has(row.key)
                  : null
                : row.key === selectedKey()
            "
          >
            @if (checkable()) {
              <div class="flex">
                @if (row.checkable) {
                  <span
                    data-slot="select-list-check"
                    aria-hidden="true"
                    [class]="checkClasses"
                    [attr.data-checked]="checkedKeys().has(row.key) ? '' : null"
                  >
                    @if (checkedKeys().has(row.key)) {
                      <neat-icon name="check" [size]="12" class="text-primary-foreground" />
                    }
                  </span>
                }
              </div>
            }
            @for (column of visibleColumns(); track column) {
              <div class="min-w-0">
                <ng-container
                  [ngTemplateOutlet]="column.template"
                  [ngTemplateOutletContext]="row.context"
                />
              </div>
            }
          </div>
        }
      </div>
      @if (isEmpty()) {
        <p
          data-slot="select-list-empty"
          class="px-(--neat-space-3) py-(--neat-space-2) text-sm text-muted-foreground"
          [id]="emptyId"
        >
          {{ emptyLabel() }}
        </p>
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}, {
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSelectList,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-select-list",
			imports: [NeatIcon, NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "flex h-full min-h-0 flex-col",
				"[style.--neat-select-list-columns]": "gridColumns()"
			},
			template: `
    @if (hasHeader()) {
      <div data-slot="select-list-header" aria-hidden="true" [class]="headerClasses">
        <div [class]="headerLineClasses">
          @if (checkable()) {
            <span></span>
          }
          @for (column of visibleColumns(); track column) {
            <span class="min-w-0 truncate">{{ column.header() }}</span>
          }
        </div>
      </div>
    }
    <div #scroller [class]="scrollerClasses">
      @if (hint()) {
        <span class="sr-only" [id]="hintId">{{ hint() }}</span>
      }
      <div
        #listbox
        role="listbox"
        tabindex="0"
        class="outline-none"
        [attr.aria-label]="label()"
        [attr.aria-multiselectable]="checkable() || null"
        [attr.aria-activedescendant]="activeId()"
        [attr.aria-describedby]="describedBy()"
        (keydown)="onKeydown($event)"
        (click)="onClick($event)"
      >
        @for (row of rows(); track row.key) {
          <div
            role="option"
            [id]="row.id"
            [class]="rowClasses"
            [attr.data-active]="row.key === selectedKey() ? '' : null"
            [attr.aria-selected]="
              checkable()
                ? row.checkable
                  ? checkedKeys().has(row.key)
                  : null
                : row.key === selectedKey()
            "
          >
            @if (checkable()) {
              <div class="flex">
                @if (row.checkable) {
                  <span
                    data-slot="select-list-check"
                    aria-hidden="true"
                    [class]="checkClasses"
                    [attr.data-checked]="checkedKeys().has(row.key) ? '' : null"
                  >
                    @if (checkedKeys().has(row.key)) {
                      <neat-icon name="check" [size]="12" class="text-primary-foreground" />
                    }
                  </span>
                }
              </div>
            }
            @for (column of visibleColumns(); track column) {
              <div class="min-w-0">
                <ng-container
                  [ngTemplateOutlet]="column.template"
                  [ngTemplateOutletContext]="row.context"
                />
              </div>
            }
          </div>
        }
      </div>
      @if (isEmpty()) {
        <p
          data-slot="select-list-empty"
          class="px-(--neat-space-3) py-(--neat-space-2) text-sm text-muted-foreground"
          [id]="emptyId"
        >
          {{ emptyLabel() }}
        </p>
      }
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: true
			}]
		}],
		trackBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trackBy",
				required: true
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		checkable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checkable",
				required: false
			}]
		}],
		checked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checked",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedChange"]
		}],
		canCheck: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canCheck",
				required: false
			}]
		}],
		emptyLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyLabel",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		activated: [{
			type: i0.Output,
			args: ["activated"]
		}],
		columns: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => NeatColumn), {
				descendants: true,
				isSignal: true
			}]
		}],
		listbox: [{
			type: i0.ViewChild,
			args: ["listbox", { isSignal: true }]
		}],
		scroller: [{
			type: i0.ViewChild,
			args: ["scroller", { isSignal: true }]
		}]
	}
});
export { NeatColumn, NeatSelectList };

//# sourceMappingURL=sima-neat-ui-select-list.mjs.map