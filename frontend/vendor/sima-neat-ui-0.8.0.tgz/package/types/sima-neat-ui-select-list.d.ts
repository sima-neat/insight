import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
/** Stands for "no selection" in key comparisons; no item's key can be it. */
declare const NONE: unique symbol;
/**
 * One column of a `neat-select-list`, as a template for the cells in it:
 *
 * ```html
 * <ng-template neatColumn="state" header="State" width="6rem" let-slot>{{ slot.state }}</ng-template>
 * ```
 *
 * The key names the column, `header` is the label over it (no label on any column: no header row),
 * and `width` is its CSS track size in the row's grid, `1fr` by default. The template gets the
 * item as its implicit context. A cell is a block that may shrink to nothing (`min-width: 0`), so
 * it does not push the next column out; it does not cut its content, though. A long text wraps,
 * and an unbroken one overflows into the next cell, unless the template truncates it (an element
 * with `overflow: hidden`, `text-overflow: ellipsis` and `white-space: nowrap`).
 *
 * `hideBelow` is a width of the list in CSS pixels: while the list is narrower, the column and its
 * header leave the layout entirely, as if the template were not there. For columns that matter
 * less than the others on a narrow screen: `[hideBelow]="720"`.
 */
export declare class NeatColumn {
  readonly key: import("@angular/core").InputSignal<string>;
  readonly header: import("@angular/core").InputSignal<string>;
  readonly width: import("@angular/core").InputSignal<string>;
  /** The list's width in CSS pixels below which the column is not shown; always shown if unset. */
  readonly hideBelow: import("@angular/core").InputSignal<number | undefined>;
  readonly template: TemplateRef<unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatColumn, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatColumn, "ng-template[neatColumn]", never, {
    "key": {
      "alias": "neatColumn";
      "required": true;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "hideBelow": {
      "alias": "hideBelow";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A row: the item, its key, whether it can be checked, the element id the listbox points at, and
 * its cells' context.
 */
interface Row<T, K> {
  readonly item: T;
  readonly key: K;
  readonly checkable: boolean;
  readonly id: string;
  readonly context: {
    readonly $implicit: T;
  };
}
/**
 * A list of items, one row each, in columns that the app lays out with templates; one row is
 * selected:
 *
 * ```html
 * <neat-select-list label="Streaming slots" [items]="slots()" [trackBy]="slotId" [(selected)]="slot">
 *   <ng-template neatColumn="name" header="Slot" let-slot>{{ slot.name }}</ng-template>
 *   <ng-template neatColumn="state" header="State" width="6rem" let-slot>…</ng-template>
 * </neat-select-list>
 * ```
 *
 * It fills its container (the container needs a height) and scrolls its rows inside, under a header
 * that stays put. `trackBy` gives an item's identity, unique in the list: the selection follows
 * the item with the same key when `items` is replaced by new objects (a poll's answer), and rows,
 * with the state in their cells, are kept rather than rebuilt. It is called once per item whenever
 * `items` changes, never while the list is only checked or the selection moves.
 *
 * It is a single-select `listbox` named by `label`, whose `option` rows are `aria-selected`.
 * Selection follows focus: the listbox is the one tab stop, holds the focus, and names the
 * selected row in `aria-activedescendant`; ArrowDown and ArrowUp move the selection (the first
 * press picks the first or last row when nothing is selected), Home and End jump to the ends, and
 * the selected row scrolls into view. Enter, and a click on a row, tell `activated` with the row's
 * item. A click on a control in a cell, and every key pressed while one has the focus, are that
 * control's: they neither select nor activate. Controls in cells are ordinary tab stops after
 * the listbox.
 *
 * The header repeats the columns' labels for the eye and is hidden from assistive technology: the
 * rows read as the text of their cells in order, as a listbox's options do (a listbox cannot
 * name its columns).
 *
 * `hint` is read as the listbox's description, for keys the app adds on top of these.
 *
 * **Checked mode** (`checkable`) is for acting on several rows: each row that `canCheck` allows
 * has a box before its cells, and `checked` holds the keys (`trackBy`'s) of the checked rows. It
 * holds keys rather than items, and keeps the keys of rows it does not list (a file in another
 * folder, a type a filter hides): a newly checked key is appended, an unchecked one removed, the
 * rest left as they are. The listbox is then multi-selectable, and a checkable row is
 * `aria-selected` while it is checked (as the WAI-ARIA multi-select listbox has it); a row that
 * cannot be checked has no `aria-selected`. The selection that follows the arrow keys (`selected`)
 * stays: it is the row the keyboard is on, named in `aria-activedescendant` and drawn with the bar.
 * Space checks or unchecks that row; a click on a row's box checks or unchecks it and does nothing
 * else, and a click elsewhere on the row selects and activates it as in the single mode. The boxes
 * are not tab stops. The multi-selectable listbox says what checking is, so a checked list needs
 * no `hint` of its own.
 *
 * Typing a letter to jump to a row, Page Up and Page Down, a range of rows checked with Shift and
 * a disabled row are not offered; none is needed yet.
 */
export declare class NeatSelectList<T, K = unknown> {
  /** The accessible name of the list. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly items: import("@angular/core").InputSignal<readonly T[]>;
  /** An item's identity, unique in the list. */
  readonly trackBy: import("@angular/core").InputSignal<(item: T) => K>;
  /** The selected item: the row the keyboard is on; `null` while there is none. */
  readonly selected: import("@angular/core").ModelSignal<T | null>;
  /** Checked mode: a box on each row that `canCheck` allows, for acting on several rows. */
  readonly checkable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** In checked mode, the keys of the checked rows, including rows the list does not show. */
  readonly checked: import("@angular/core").ModelSignal<readonly K[]>;
  /** In checked mode, whether an item's row has a box; called once per item as `items` change. */
  readonly canCheck: import("@angular/core").InputSignal<(item: T) => boolean>;
  /** What to say, in place of rows, while there are no items. */
  readonly emptyLabel: import("@angular/core").InputSignal<string>;
  /**
   * Text for assistive technology that says what keys an app adds beyond the listbox's own (such
   * as Delete on a row); it describes the listbox, and is not shown.
   */
  readonly hint: import("@angular/core").InputSignal<string>;
  /** The item of the row that was clicked or that had Enter pressed on it. */
  readonly activated: import("@angular/core").OutputEmitterRef<T>;
  protected readonly headerClasses = "shrink-0 overflow-y-hidden border-b border-border text-xs font-medium text-muted-foreground [scrollbar-gutter:stable]";
  protected readonly headerLineClasses = "grid grid-cols-(--neat-select-list-columns) items-center gap-x-(--neat-space-3) border-s-2 border-transparent px-(--neat-space-3) py-1";
  protected readonly scrollerClasses = "min-h-0 flex-1 overflow-x-hidden overflow-y-auto [scrollbar-gutter:stable] has-[[role=listbox]:focus-visible]:outline-2 has-[[role=listbox]:focus-visible]:-outline-offset-2 has-[[role=listbox]:focus-visible]:outline-ring";
  protected readonly rowClasses = "grid grid-cols-(--neat-select-list-columns) items-center gap-x-(--neat-space-3) border-s-2 border-transparent px-(--neat-space-3) min-h-9 cursor-default py-1 text-sm hover:bg-accent data-active:border-primary data-active:bg-accent";
  protected readonly checkClasses = "flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-sm border border-input data-checked:border-primary data-checked:bg-primary";
  private readonly id;
  protected readonly emptyId: string;
  protected readonly hintId: string;
  private readonly columns;
  private readonly listbox;
  private readonly scroller;
  /**
   * The list's own width in CSS pixels, watched only while a column has `hideBelow`; `null` until
   * then and while the list has no width (not laid out: hidden, or not in a document), when every
   * column shows.
   */
  private readonly width;
  private readonly hidesColumns;
  /** The columns shown at the list's width; a new list only when one comes or goes. */
  protected readonly visibleColumns: import("@angular/core").Signal<NeatColumn[]>;
  protected readonly hasHeader: import("@angular/core").Signal<boolean>;
  protected readonly gridColumns: import("@angular/core").Signal<string>;
  /**
   * Everything a row needs, worked out once per `items`: the key and, in checked mode, whether it
   * has a box (calls of the app's functions), the id and the cells' context. Change detection then
   * reads these and calls nothing.
   */
  protected readonly rows: import("@angular/core").Signal<readonly Row<T, K>[]>;
  protected readonly checkedKeys: import("@angular/core").Signal<Set<unknown>>;
  protected readonly isEmpty: import("@angular/core").Signal<boolean>;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  protected readonly selectedKey: import("@angular/core").Signal<typeof NONE | K>;
  private readonly selectedIndex;
  protected readonly activeId: import("@angular/core").Signal<string>;
  /** The key of the row last scrolled to, so that a row that only moved is not scrolled to again. */
  private revealed;
  constructor();
  /**
   * Watches the list's width once a column has `hideBelow`, and never for a list without one. The
   * first width is read as soon as the list is rendered, so the first frame is laid out at it; a
   * resize then reports each change. The list is zoneless: setting the signal schedules the
   * render, and only a column coming or going changes what is drawn.
   */
  private watchWidthWhileNeeded;
  /** Scrolls the selected row into view unless that row was the last one scrolled to. */
  private revealSelected;
  /**
   * Scrolls back to the top, as a different set of rows (another folder) needs, or to the selected
   * row when there is one in the list. Call it once the new rows are rendered.
   */
  resetScroll(): void;
  /** Puts the keyboard focus on the list, where the arrow keys work. */
  focus(): void;
  protected onKeydown(event: KeyboardEvent): void;
  /** One listener on the listbox serves every row: the rows are found from the event's target. */
  protected onClick(event: MouseEvent): void;
  /** Checks or unchecks a row that has a box; does nothing for one that has none. */
  private toggle;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSelectList<any, any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSelectList<any, any>, "neat-select-list", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
    "trackBy": {
      "alias": "trackBy";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "checkable": {
      "alias": "checkable";
      "required": false;
      "isSignal": true;
    };
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "canCheck": {
      "alias": "canCheck";
      "required": false;
      "isSignal": true;
    };
    "emptyLabel": {
      "alias": "emptyLabel";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "checked": "checkedChange";
    "activated": "activated";
  }, ["columns"], never, true, never>;
}
export {};