import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, TemplateRef, afterRenderEffect, booleanAttribute, computed, contentChild, contentChildren, inject, input, model } from "@angular/core";
import { NgTemplateOutlet } from "@angular/common";
import * as i1 from "@spartan-ng/brain/tabs";
import { BrnTabs, BrnTabsContent, BrnTabsList, BrnTabsTrigger } from "@spartan-ng/brain/tabs";
import { ɵhlm, ɵlistVariants } from "@sima/neat-ui";
const TABS_HELM_CLASSES = {
	root: "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col",
	trigger: "gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0",
	triggerLine: "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
	triggerActive: "data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground",
	triggerIndicator: "after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100",
	content: "flex-1 text-sm outline-none"
};
const LIST_CLASSES = ɵlistVariants({ variant: "line" });
const TRIGGER_CLASSES = ɵhlm(TABS_HELM_CLASSES.trigger, TABS_HELM_CLASSES.triggerLine, TABS_HELM_CLASSES.triggerActive, TABS_HELM_CLASSES.triggerIndicator, "focus-visible:ring-ring");
var NeatTab = class NeatTab {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	content = contentChild.required(TemplateRef, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatTab,
		isStandalone: true,
		selector: "neat-tab",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		queries: [{
			propertyName: "content",
			first: true,
			predicate: TemplateRef,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTab,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tab",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: ""
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		content: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => TemplateRef), { isSignal: true }]
		}]
	}
});
let nextTabsId = 0;
var NeatTabs = class NeatTabs {
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	tabs = contentChildren(NeatTab, ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	tabSet = computed(() => JSON.stringify(this.tabs().map((tab) => tab.value())), ...ngDevMode ? [{ debugName: "tabSet" }] : /* istanbul ignore next */ []);
	openIndex = computed(() => {
		const tabs = this.tabs();
		const named = tabs.findIndex((tab) => tab.value() === this.value());
		return named >= 0 ? named : tabs.findIndex((tab) => !tab.disabled());
	}, ...ngDevMode ? [{ debugName: "openIndex" }] : /* istanbul ignore next */ []);
	rootClasses = TABS_HELM_CLASSES.root;
	listClasses = LIST_CLASSES;
	triggerClasses = TRIGGER_CLASSES;
	contentClasses = TABS_HELM_CLASSES.content;
	prefix = `neat-tabs-${++nextTabsId}-`;
	constructor() {
		const tabs = inject(BrnTabs);
		afterRenderEffect(() => {
			const open = this.openIndex();
			tabs.activeTab.set(open < 0 ? void 0 : this.key(open));
		});
		tabs.tabActivated.subscribe((key) => {
			const tab = this.tabs()[Number(key.slice(this.prefix.length))];
			if (tab) this.value.set(tab.value());
		});
	}
	key(index) {
		return this.prefix + index;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatTabs,
		isStandalone: true,
		selector: "neat-tabs",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { properties: { "class": "rootClasses" } },
		queries: [{
			propertyName: "tabs",
			predicate: NeatTab,
			isSignal: true
		}],
		hostDirectives: [{ directive: i1.BrnTabs }],
		ngImport: i0,
		template: `
    @for (set of [tabSet()]; track set) {
      <div brnTabsList data-variant="line" [attr.aria-label]="label()" [class]="listClasses">
        @for (tab of tabs(); track tab.value(); let index = $index) {
          <button
            [brnTabsTrigger]="key(index)"
            [disabled]="tab.disabled()"
            [class]="triggerClasses"
          >
            {{ tab.label() }}
          </button>
        }
      </div>
    }
    @for (tab of tabs(); track tab.value(); let index = $index) {
      <div [brnTabsContent]="key(index)" [class]="contentClasses">
        @if (index === openIndex()) {
          <ng-container [ngTemplateOutlet]="tab.content()" />
        }
      </div>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnTabsList,
				selector: "[brnTabsList]",
				exportAs: ["brnTabsList"]
			},
			{
				kind: "directive",
				type: BrnTabsTrigger,
				selector: "button[brnTabsTrigger]",
				inputs: ["brnTabsTrigger", "disabled"],
				exportAs: ["brnTabsTrigger"]
			},
			{
				kind: "directive",
				type: BrnTabsContent,
				selector: "[brnTabsContent]",
				inputs: ["brnTabsContent"],
				exportAs: ["brnTabsContent"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTabs,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tabs",
			imports: [
				BrnTabsList,
				BrnTabsTrigger,
				BrnTabsContent,
				NgTemplateOutlet
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			hostDirectives: [BrnTabs],
			host: { "[class]": "rootClasses" },
			template: `
    @for (set of [tabSet()]; track set) {
      <div brnTabsList data-variant="line" [attr.aria-label]="label()" [class]="listClasses">
        @for (tab of tabs(); track tab.value(); let index = $index) {
          <button
            [brnTabsTrigger]="key(index)"
            [disabled]="tab.disabled()"
            [class]="triggerClasses"
          >
            {{ tab.label() }}
          </button>
        }
      </div>
    }
    @for (tab of tabs(); track tab.value(); let index = $index) {
      <div [brnTabsContent]="key(index)" [class]="contentClasses">
        @if (index === openIndex()) {
          <ng-container [ngTemplateOutlet]="tab.content()" />
        }
      </div>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		tabs: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => NeatTab), { isSignal: true }]
		}]
	}
});
export { NeatTab, NeatTabs };

//# sourceMappingURL=sima-neat-ui-tabs.mjs.map