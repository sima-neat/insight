import * as i0 from "@angular/core";
/**
 * A card for a metric and its chart:
 *
 * ```html
 * <neat-chart-card heading="MLA temperature" value="62.4" unit="°C" caption="Hottest of 8 sensors"
 *   selectable [selected]="open() === 'mla'" (activate)="open.set('mla')">
 *   <neat-status-chip neatChartCardChip tone="warning">Warning</neat-status-chip>
 *   <neat-sparkline … />
 * </neat-chart-card>
 * ```
 *
 * Top to bottom: the heading with the `[neatChartCardChip]` content beside it at the end, the value
 * (large, with its unit smaller and muted after it), the caption, and the default content, the
 * chart. The value and the caption are left out while they are empty.
 *
 * With `selectable`, the card is one choice among its siblings: the heading is a button (so it is
 * the keyboard's way in, and `aria-current` marks it while `selected`) and a click anywhere on the
 * card emits `activate` as well, its chart's plot included: the plot reads out a sample as the
 * pointer moves over it, so a click there takes nothing from the readout, and the plot is most of
 * the card. The plot's keys stay the chart's (they move the readout and choose nothing). A control
 * in the content (a button, a link, a form field) handles its own click and leaves the card alone.
 * Not selectable, the heading is text and the card handles no clicks.
 *
 * The card is the fill of `--card`, so it sets `--neat-surface` to it for the charts' label halos.
 * It does not clip its content or make a stacking context: a readout can hang below its plot.
 */
export declare class NeatChartCard {
  /** What the card is about: "MLA temperature". */
  readonly heading: import("@angular/core").InputSignal<string>;
  /** The current value, already worded: "62.4". */
  readonly value: import("@angular/core").InputSignal<string>;
  /** The value's unit, after it: "°C". */
  readonly unit: import("@angular/core").InputSignal<string>;
  /** A line under the value: what it is the value of. */
  readonly caption: import("@angular/core").InputSignal<string>;
  /** Whether the card can be chosen: its heading is a button, and a click on the card activates it. */
  readonly selectable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Whether this is the chosen card; only a selectable card shows it. */
  readonly selected: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The card was chosen, by its heading or a click on it. */
  readonly activate: import("@angular/core").OutputEmitterRef<void>;
  private readonly host;
  protected onClick(event: MouseEvent): void;
  /**
   * Whether a click landed in a control of the content, which acts on it itself. The heading's own
   * button is the card's, so its click (from the pointer, Enter or Space) activates it. A chart's
   * plot is a tab stop but no control: it is a group that reads out by pointer and keys.
   */
  private inControl;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatChartCard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatChartCard, "neat-chart-card", never, {
    "heading": {
      "alias": "heading";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "unit": {
      "alias": "unit";
      "required": false;
      "isSignal": true;
    };
    "caption": {
      "alias": "caption";
      "required": false;
      "isSignal": true;
    };
    "selectable": {
      "alias": "selectable";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activate": "activate";
  }, never, ["[neatChartCardChip]", "*"], true, never>;
}
/**
 * What a time chart's x axis counts: `recent` back from the newest sample ("−8 min … now"), for a
 * live window, or `elapsed` forward from the first ("0 s … 33.9 s"), for a run read from its start.
 */
type NeatChartAxis = 'recent' | 'elapsed';
/** How a chart draws its line: the default colour, or a threshold's. */
type NeatChartTone = 'default' | 'warning' | 'danger';
/** One line or band of a chart. A `null` is a sample that was not taken, which breaks the line. */
interface NeatSeries {
  readonly key: string;
  readonly label: string;
  readonly values: readonly (number | null)[];
}
/** A level the chart marks as a warning or a danger. */
interface NeatThreshold {
  readonly value: number;
  readonly tone: 'warning' | 'danger';
  readonly label: string;
}
/** A level the chart marks that is neither, such as a limit or a target. */
interface NeatReference {
  readonly value: number;
  readonly label: string;
}
/** How a chart words a value: the app's unit and precision, which the charts know nothing of. */
type NeatChartFormat = (value: number) => string;
/** What a readout shows for a sample that was not taken. */
declare const MISSING = "—";
/** A value as the chart's `format` words it, or "—" when the sample was not taken. */
declare function describe(value: number | null | undefined, format: NeatChartFormat): string;
/**
 * When the sample at `index` was taken, or null when the times do not say: how long before the
 * newest sample (the last of `length`), as the kit words it ("2 min ago"), or, on the elapsed
 * axis, how long after the first ("at 17 s"). Both are the same distance, counted from the other
 * end of the window.
 */
declare function whenText(times: readonly (number | null)[], length: number, index: number, axis?: NeatChartAxis): string | null;
/** Where a pointer is across `element`, 0 to 1, or null while the element has no width. */
declare function fractionAcross(event: MouseEvent, element: HTMLElement): number | null;
/** One line of a time-based readout. */
interface ReadoutRow {
  readonly key: string;
  readonly label: string;
  readonly value: string;
  /**
   * The index of the series whose swatch the row shows, or null for a row without one: a total,
   * or a chart's only line, which its tone colours and no swatch is needed to tell apart.
   */
  readonly series: number | null;
}
/** What a chart with a crosshair shows at the sample the cursor is on. */
interface Readout {
  /** The sample's place across the plot, 0 to 1. */
  readonly at: number;
  /** When the sample was taken ("2 min ago", "at 17 s"), when the times say. */
  readonly when: string | null;
  readonly rows: readonly ReadoutRow[];
  /** The readout as one sentence, for the live region. */
  readonly spoken: string;
}
declare function readoutAt(at: number, when: string | null, rows: readonly ReadoutRow[]): Readout;
/**
 * The sample a key moves a cursor over `length` samples to, or null for a key the chart does not
 * use. `current` is null while the readout is hidden, and any arrow then brings it up at the
 * newest sample.
 */
declare function sampleAfter(key: string, current: number | null, length: number): number | null;
/**
 * How a chart tells its cursor about its data. `P` is where a pointer is (kept as a place, not a
 * cell, so the cursor follows data that shifts under it) and `C` is what the cursor points at.
 */
interface CursorShape<P, C> {
  /** What the pointer is over, or null when there is nothing there. */
  under(pointer: P): C | null;
  /** A cursor a key chose, held to the data as it is now, or null when nothing is left. */
  fit(cursor: C): C | null;
  /** Where focus puts the cursor when nothing is shown, or null without data. */
  start(): C | null;
  /** Where a key moves the cursor (null: it is hidden), or null for a key the chart does not use. */
  after(key: string, current: C | null): C | null;
  /** The readout of a cursor as one sentence, for the live region. */
  spoken(cursor: C): string;
}
/**
 * The cursor of a chart whose readout reads one sample across its plot, the time chart's and the
 * stacked chart's: a sample is the cursor, and the pointer is a place across the plot (0 to 1),
 * so the readout follows data that shifts under it. `fractions` place the samples, as
 * `timeFractions` does.
 */
declare function sampleCursor(chart: {
  length: () => number;
  fractions: () => readonly number[];
  spoken: (index: number) => string;
}): ReadoutCursor<number, number>;
/**
 * The cursor a chart's readout reads. The pointer shows it while it is over the chart; with focus
 * it shows the newest, and the keys move it. A key takes it over from the pointer and a pointer
 * move gives it back. Escape hides it, but only a readout that is there: otherwise Escape belongs
 * to whatever holds the chart, such as a dialog.
 *
 * Each key press, and only a key press, writes `announcement`, which the chart renders in a polite
 * live region: a pointer move announced at every pixel would be noise, and focus alone lands on
 * the chart without a sentence in the reader's ear.
 */
declare class ReadoutCursor<P, C> {
  private readonly shape;
  private readonly pointer;
  /** The cursor as the last key left it. */
  private readonly keyed;
  /** The readout as of the last key press: the live region's text. */
  readonly announcement: import("@angular/core").WritableSignal<string>;
  /** What the readout reads, or null while it is hidden. */
  readonly active: import("@angular/core").Signal<C | null>;
  constructor(shape: CursorShape<P, C>);
  pointerTo(pointer: P): void;
  /** The pointer leaving hides what the pointer showed; a cell a key chose stays. */
  pointerLeave(): void;
  focus(): void;
  blur(): void;
  keydown(event: KeyboardEvent): void;
}
/** One row of a heatmap: its samples become the cells, and `end` is the figure beside them. */
interface NeatHeatmapRow {
  readonly key: string;
  /** Names the row on screen and in the readout. */
  readonly label: string;
  /** The row's samples, oldest first, each as long as `times`; `null` for one that was not taken. */
  readonly values: readonly (number | null)[];
  /** The figure at the row's end as the app words it, such as a one-minute average. */
  readonly end: string;
  /** The colour of `end`: the foreground, or the warning or danger line colour (text strength in both). */
  readonly endTone: NeatChartTone;
}
/** A cell the cursor can be on: a row, and a column of that row's cells. */
interface Cell {
  readonly row: number;
  readonly column: number;
}
/** The cell under the pointer, kept as the row it is over and a place across it, not a column. */
interface Pointer {
  readonly row: number;
  readonly fraction: number;
}
/** What a cell reads out: its row, how long ago, and its mean, as the readout shows and says them. */
interface CellReadout extends Cell {
  /** The cell's place across its row, 0 to 1, for the readout to stand beside. */
  readonly at: number;
  readonly head: string;
  readonly value: string;
}
/**
 * Several metrics over time as rows of coloured cells, such as the load of each core:
 *
 * ```html
 * <neat-heatmap
 *   label="Per-core CPU"
 *   headline="34%"
 *   [rows]="cores"
 *   [times]="times"
 *   [format]="percent"
 * />
 * ```
 *
 * A row's samples are split into at most 48 columns of time, each cell the mean of its samples;
 * `times` (ms, oldest first) place them, so a pause in the polling stays an empty stretch, and a
 * history shorter than the columns gets one column per sampling interval. A cell mixes
 * `--neat-heat-low` and `--neat-heat-high` by where its value lies in `domain` (0 to 100 by
 * default, clamped); an empty cell is transparent. A ramp in the head shows the domain's two
 * ends, worded by `format`. A row is 1.5 rem tall, with its label before the cells and `end`,
 * in the colour of its tone, after them.
 *
 * The grid is one tab stop named "<label>: <headline>, over the last <window>". Its readout,
 * which the pointer shows over a cell and the keys over the cursor's, reads "<row label> · <how
 * long ago the column's newest sample was>: <mean> average". The arrow keys move the cursor
 * (Left and Right by column, Up and Down by row), Home and End go to the ends of its row, and
 * Escape hides the readout. Like the time chart's, each key press, and only a key press, is
 * repeated in a polite live region.
 */
export declare class NeatHeatmap {
  /** The heatmap's title, which also names it for assistive technology. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The overall value as the app words it, beside the title and in the accessible name. */
  readonly headline: import("@angular/core").InputSignal<string>;
  /** The rows, top first. */
  readonly rows: import("@angular/core").InputSignal<readonly NeatHeatmapRow[]>;
  /** When each sample was taken, in ms, oldest first; `null` for one without a time. */
  readonly times: import("@angular/core").InputSignal<readonly (number | null)[]>;
  /** The values the colour ramp spans, lowest and highest: fixed by the app, so a colour keeps its meaning. */
  readonly domain: import("@angular/core").InputSignal<readonly [number, number]>;
  /** Words a value with its unit, for the ramp's ends and the readout. */
  readonly format: import("@angular/core").InputSignal<NeatChartFormat>;
  /** Each row's cells: the mean of every column, and the fill that mean's place in the domain gives. */
  private readonly cells;
  protected readonly shown: import("@angular/core").Signal<{
    key: string;
    label: string;
    end: string;
    tone: string;
    fills: string[];
  }[]>;
  /** The widest row's columns: the rows share the grid's tracks. */
  protected readonly columns: import("@angular/core").Signal<number>;
  /** The samples in the longest row, which is how much of `times` the heatmap shows. */
  private readonly length;
  protected readonly scaleStart: import("@angular/core").Signal<string>;
  protected readonly scaleEnd: import("@angular/core").Signal<string>;
  protected readonly axis: import("@angular/core").Signal<{
    at: number;
    text: string;
  }[]>;
  protected readonly name: import("@angular/core").Signal<string>;
  protected readonly cursor: ReadoutCursor<Pointer, Cell>;
  protected readonly readout: import("@angular/core").Signal<CellReadout | null>;
  /** The newest cell of a row, or null while it has none. */
  private newestOf;
  /**
   * Where a key moves the cursor, or null for a key the heatmap does not use. Hidden, an arrow
   * brings the cursor up at the newest cell of the first row, and Home and End go to that row's ends.
   */
  private cellAfter;
  /** One step of an arrow key from `from`, stopping at the edges. */
  private step;
  private readoutFor;
  protected onPointerMove(event: MouseEvent, row: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatHeatmap, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatHeatmap, "neat-heatmap", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "headline": {
      "alias": "headline";
      "required": false;
      "isSignal": true;
    };
    "rows": {
      "alias": "rows";
      "required": true;
      "isSignal": true;
    };
    "times": {
      "alias": "times";
      "required": false;
      "isSignal": true;
    };
    "domain": {
      "alias": "domain";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The colour of a chart series as a small square, for a label that stands for that series outside
 * the chart (a run's chip, a summary row, a heading over a per-metric chart):
 *
 * ```html
 * <neat-series-swatch [index]="i" /> {{ run.name }}
 * ```
 *
 * `index` is the series' place in the chart's `series`, from 0, and the swatch takes the colour the
 * chart draws that series in when it has several (`--neat-series-1` to `-8`, through the charts'
 * one rule, `seriesToken`), so a label and its line match in either theme. A chart folds a ninth
 * series and beyond into "Other" (index 7), so an index past 7 names no colour. A lone series is
 * drawn in its tone's colour instead and needs no swatch.
 *
 * The time and stacked charts draw their own legends' and readouts' swatches with it, so its size,
 * shape and colour are stated here once. It is `aria-hidden`: the text beside it names the series,
 * and a colour alone is not a name.
 */
export declare class NeatSeriesSwatch {
  /** The series' place in the chart's `series`, from 0. */
  readonly index: import("@angular/core").InputSignal<number>;
  protected readonly color: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSeriesSwatch, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSeriesSwatch, "neat-series-swatch", never, {
    "index": {
      "alias": "index";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A metric's recent samples as a small line, for a card:
 *
 * ```html
 * <neat-sparkline [values]="temperatures" label="MLA RTSN-0" [format]="celsius" tone="warning" />
 * ```
 *
 * The samples are spread evenly, the lowest at the bottom of the box and the highest at the top,
 * so the line shows the shape of the last minutes and not a level (the card says the value). A
 * `null` is a sample that was not taken and splits the line. Fewer than two numbers draw nothing
 * but the box keeps its size, so a card does not jump when its first samples arrive.
 *
 * The box fills the width it is given and is 1.75 rem high. The host is an image named by
 * `label` and, in words, by how many samples there are and their range, worded by `format`.
 * The stroke is `--neat-line`, or `--neat-line-warning` and `--neat-line-danger` by `tone`.
 */
export declare class NeatSparkline {
  /** The samples, oldest first; `null` for one that was not taken. */
  readonly values: import("@angular/core").InputSignal<readonly (number | null)[]>;
  /** What the samples measure, for the image's name: "MLA RTSN-0". */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Words a value for the description, with its unit. */
  readonly format: import("@angular/core").InputSignal<NeatChartFormat>;
  /** The stroke: the line colour, or a threshold's. */
  readonly tone: import("@angular/core").InputSignal<NeatChartTone>;
  /** The numbers among the samples; a sparkline needs two of them to draw anything. */
  private readonly numbers;
  protected readonly stroke: import("@angular/core").Signal<string>;
  protected readonly path: import("@angular/core").Signal<string>;
  protected readonly description: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSparkline, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSparkline, "neat-sparkline", never, {
    "values": {
      "alias": "values";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The plot's height in rem by size, set as `--plot-height` so the labels' room is worked out from it. */
declare const PLOT_REM: {
  readonly compact: 3.5;
  readonly medium: 6;
  readonly large: 9.5;
};
/** A label whose line is within this much of the top (in the box's 0 to 100) sits below the line. */
declare const FLIP_BELOW = 14;
/** A stretch of the box, from its top to its bottom in the box's 0 to 100. */
type LabelSpan = readonly [number, number];
/**
 * The stretch of the box a label on the line at `y` takes in a plot of `size`: above its line, or
 * below it near the top (`FLIP_BELOW`), as `plot.css` places the `.tag`.
 */
declare function labelSpan(y: number, size: keyof typeof PLOT_REM): LabelSpan;
/**
 * The grid marks whose labels have room, from the bottom of the domain up: none that would sit on
 * a label in `taken` (a level's, which says more), nor on the grid label kept below it (near the
 * top, where the top label flips below its line, the two would print one over the other). Every
 * grid line stays; only labels are left out.
 */
declare function roomyGridMarks(marks: readonly GridMark[], size: keyof typeof PLOT_REM, taken?: readonly LabelSpan[]): GridMark[];
/** A grid line across the plot with its label: `y` is 0 (the top of the domain) to 100. */
interface GridMark {
  readonly value: number;
  readonly y: number;
  readonly text: string;
}
declare function gridMarks(domain: readonly [number, number]): GridMark[];
/**
 * The time axis: the start, middle and end of the span, counted back from the newest sample
 * (`recent`) or forward from the first (`elapsed`). Without a span there is nothing to measure.
 */
declare function timeAxis(times: readonly (number | null)[], length: number, axis?: NeatChartAxis): {
  at: number;
  text: string;
}[];
/**
 * A chart's accessible name: "<label>: <current>, over the last <window>", or "over <span>" on
 * the elapsed axis.
 */
declare function chartName(label: string, current: string, times: readonly (number | null)[], length: number, axis?: NeatChartAxis): string;
/**
 * A total split into its parts over time, as bands stacked into one area:
 *
 * ```html
 * <neat-stacked-chart
 *   label="Board power"
 *   headline="11.4 W"
 *   [series]="rails"
 *   [times]="times"
 *   [domain]="[0, 16]"
 *   [format]="watts"
 * />
 * ```
 *
 * The series stack bottom first in the order given, each band in `--neat-series-1` to `-8` at
 * 0.85 opacity with a hairline in `--neat-surface` between them, so inside a card set that to the
 * card's fill. More than eight fold into "Other", as on the time chart. A sample where any band is
 * missing breaks the whole stack: a partial sum would draw a total that was never measured.
 * `times`, `domain`, `format`, `size`, `headless` and `valueLabels` are as on the time chart,
 * and `domain` must reach the largest total or the top of the stack is cut off.
 *
 * The legend lists each band with its current value and its share of the current total, as a
 * whole percent; the share is "—" while the total is unknown (a band has no current sample) or
 * nothing. The colours alone do not tell eight bands apart, which is what the legend is for.
 *
 * The plot is a tab stop that reads out like the time chart's: "Total", then each band, at the
 * sample the pointer or the keys chose, with the same keys and the same announcements.
 */
export declare class NeatStackedChart {
  /** The chart's title, which also names it for assistive technology. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The current total as the app words it, beside the title and in the accessible name. */
  readonly headline: import("@angular/core").InputSignal<string>;
  /** The bands, bottom first, each as long as `times`; more than eight fold into "Other". */
  readonly series: import("@angular/core").InputSignal<readonly NeatSeries[]>;
  /** When each sample was taken, in ms, oldest first; `null` for one without a time. */
  readonly times: import("@angular/core").InputSignal<readonly (number | null)[]>;
  /** The values the box spans, bottom and top: fixed by the app, so the stack never rescales. */
  readonly domain: import("@angular/core").InputSignal<readonly [number, number]>;
  /** The plot's height: 3.5, 6 or 9.5 rem. Compact also leaves out the labels and the time axis. */
  readonly size: import("@angular/core").InputSignal<"compact" | "medium" | "large">;
  /** Leaves out the title row, for a chart under a heading of its own. */
  readonly headless: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Whether the grid lines carry their values; the lines, the time axis and the readout stay. */
  readonly valueLabels: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Words a value with its unit, for the legend, the readout and the accessible name. */
  readonly format: import("@angular/core").InputSignal<NeatChartFormat>;
  private readonly plot;
  protected readonly flipBelow = 14;
  /** Compact leaves the labels out: a row of charts has no room for them. */
  protected readonly labelled: import("@angular/core").Signal<boolean>;
  private readonly lines;
  private readonly length;
  private readonly fractions;
  protected readonly bands: import("@angular/core").Signal<{
    key: string;
    color: string;
    path: string;
  }[]>;
  /** The sum of the bands at a sample, or null where any of them has none. */
  private totalAt;
  protected readonly legend: import("@angular/core").Signal<{
    key: string;
    label: string;
    index: number;
    value: string;
    share: string;
  }[]>;
  protected readonly plotHeight: import("@angular/core").Signal<string>;
  protected readonly grid: import("@angular/core").Signal<GridMark[]>;
  /** The grid labels that do not sit on the one below them. */
  protected readonly gridLabels: import("@angular/core").Signal<GridMark[]>;
  protected readonly axis: import("@angular/core").Signal<{
    at: number;
    text: string;
  }[]>;
  protected readonly name: import("@angular/core").Signal<string>;
  protected readonly cursor: ReadoutCursor<number, number>;
  protected readonly readout: import("@angular/core").Signal<Readout | null>;
  private readoutFor;
  protected onPointerMove(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatStackedChart, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatStackedChart, "neat-stacked-chart", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "headline": {
      "alias": "headline";
      "required": false;
      "isSignal": true;
    };
    "series": {
      "alias": "series";
      "required": true;
      "isSignal": true;
    };
    "times": {
      "alias": "times";
      "required": true;
      "isSignal": true;
    };
    "domain": {
      "alias": "domain";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "headless": {
      "alias": "headless";
      "required": false;
      "isSignal": true;
    };
    "valueLabels": {
      "alias": "valueLabels";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** A line across the plot at `y` (0 to 100 from the top) and, when the chart has room, its label. */
interface Level {
  readonly y: number;
  readonly color: string;
  readonly label: string;
  readonly side: 'start' | 'end';
}
/**
 * A metric over time as a line chart with a hover and keyboard readout:
 *
 * ```html
 * <neat-time-chart
 *   label="CPU usage"
 *   headline="34%"
 *   [series]="[{ key: 'cpu', label: 'CPU', values: cpu }]"
 *   [times]="times"
 *   [domain]="[0, 100]"
 *   [thresholds]="[{ value: 85, tone: 'danger', label: 'Critical 85%' }]"
 *   [format]="percent"
 * />
 * ```
 *
 * `times` (ms, oldest first) place the samples, so a delayed poll shows as a gap; without usable
 * times they are spaced evenly. `domain` is the value range the box shows, and the app picks it
 * (a percentage is 0 to 100, a temperature a fixed range), so the line never rescales under the
 * reader. `format` words a value with its unit; the chart knows no units.
 *
 * One series strokes in `--neat-line`, or `--neat-line-warning` and `--neat-line-danger` by `tone`,
 * with a faint area under it. Several take `--neat-series-1` to `-8` in order, and are listed in a
 * legend with their current values; a ninth series and beyond fold into "Other". A `null` is a
 * sample that was not taken and breaks the line. The newest sample has a dot. Thresholds and the
 * reference are dashed lines, drawn while their value lies in the domain.
 *
 * The labels are drawn over the lines with a halo in `--neat-surface`, so inside a card set that
 * to the card's fill, as the select list's sticky header asks.
 *
 * `size` sets the plot's height (3.5, 6 or 9.5 rem). `compact` leaves out every label and the time
 * axis, which suits a row among others; `fill` is labelled as `medium` and makes the host a flex
 * column whose plot takes the height left after the title, legend and axis, never under medium's
 * 6 rem, so the app gives the host its height (a grid item that a row stretches, say);
 * `[valueLabels]="false"` leaves out only the grid's values and the levels' labels, keeping their
 * lines and the time axis, which suits a card in a grid; `headless` leaves out the title and
 * headline, for a chart that sits under a heading of its own.
 * None changes the accessible name or the readout. A grid label that would sit on a level's label
 * or on the grid label below it is left out.
 *
 * The plot is a group in the tab order named "<label>: <headline, or the current values>, over
 * the last <window>" ("over <span>" on the elapsed axis). The readout follows the pointer; with
 * focus it shows the newest sample, and the arrow keys, Home and End move it and Escape hides it.
 * Each key press is repeated in a polite live region, so a screen reader hears the sample;
 * pointer moves are not.
 */
export declare class NeatTimeChart {
  /** The chart's title, which also names it for assistive technology. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The current value as the app words it, beside the title and in the accessible name. */
  readonly headline: import("@angular/core").InputSignal<string>;
  /** The lines, each as long as `times`; more than eight fold into "Other". */
  readonly series: import("@angular/core").InputSignal<readonly NeatSeries[]>;
  /** When each sample was taken, in ms, oldest first; `null` for one without a time. */
  readonly times: import("@angular/core").InputSignal<readonly (number | null)[]>;
  /** The values the box spans, bottom and top: fixed by the app, so the line never rescales. */
  readonly domain: import("@angular/core").InputSignal<readonly [number, number]>;
  /** Levels drawn dashed in a warning or danger colour while they lie inside the domain. */
  readonly thresholds: import("@angular/core").InputSignal<readonly NeatThreshold[]>;
  /** A level that is neither, such as an average or a limit. */
  readonly reference: import("@angular/core").InputSignal<NeatReference | null>;
  /** The stroke of a single series; several series take the palette's colours instead. */
  readonly tone: import("@angular/core").InputSignal<NeatChartTone>;
  /**
   * The plot's height: 3.5, 6 or 9.5 rem. Compact also leaves out the labels and the time axis.
   * `fill` is labelled as medium, with the plot taking the height the app gives the host.
   */
  readonly size: import("@angular/core").InputSignal<"fill" | "compact" | "medium" | "large">;
  /**
   * What the x axis, the readout and the accessible name count: `recent` back from the newest
   * sample ("−8 min … now", "2 min ago"), for a live window, or `elapsed` forward from the first
   * ("0 s … 33.9 s", "at 17 s"), for a run read from its start or several laid over each other.
   */
  readonly axis: import("@angular/core").InputSignal<NeatChartAxis>;
  /** Leaves out the title row, for a chart under a heading of its own. */
  readonly headless: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * Whether the grid lines and the levels carry their values. Without them the lines, the time
   * axis, the readout and the accessible name stay: for a small chart among others, such as a
   * card's, where the labels would crowd the plot.
   */
  readonly valueLabels: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Words a value with its unit, for the legend, the readout and the accessible name. */
  readonly format: import("@angular/core").InputSignal<NeatChartFormat>;
  private readonly plot;
  protected readonly flipBelow = 14;
  /** The size the labels are laid out for: a filling plot is at least medium's, so it is medium. */
  private readonly frameSize;
  /** Compact leaves the labels out: a row of charts has no room for them. */
  protected readonly labelled: import("@angular/core").Signal<boolean>;
  /** The grid's values and the levels' labels, which `valueLabels` can leave out on their own. */
  protected readonly valueLabelled: import("@angular/core").Signal<boolean>;
  private readonly lines;
  private readonly length;
  private readonly fractions;
  /**
   * Whether the chart draws several lines, the one rule for what that changes: the palette's
   * colours instead of the tone's, no area, a legend, and a swatch on each readout row.
   */
  private readonly several;
  /** Each line's colour: its tone when it is alone, else its place in the palette. */
  private readonly colors;
  protected readonly drawn: import("@angular/core").Signal<{
    key: string;
    color: string;
    line: string;
    area: string;
    last: {
      x: number;
      y: number;
    } | null;
  }[]>;
  protected readonly legend: import("@angular/core").Signal<{
    key: string;
    label: string;
    index: number;
    value: string;
  }[]>;
  protected readonly plotHeight: import("@angular/core").Signal<string>;
  protected readonly grid: import("@angular/core").Signal<GridMark[]>;
  /**
   * The grid labels that do not sit on a threshold or reference label, nor on the grid label below
   * them. Levels and grid labels start at the plot's left edge, so a level near a grid line (a
   * warning at 80 under the top label) would print one over the other; the level's label stays,
   * since it says more, and the grid line stays too. Labels at the end do not meet them.
   */
  protected readonly gridLabels: import("@angular/core").Signal<GridMark[]>;
  /** The thresholds and the reference inside the domain, edges included (Inv-S §13.27). */
  protected readonly levels: import("@angular/core").Signal<Level[]>;
  protected readonly timeTicks: import("@angular/core").Signal<{
    at: number;
    text: string;
  }[]>;
  protected readonly name: import("@angular/core").Signal<string>;
  protected readonly cursor: ReadoutCursor<number, number>;
  protected readonly readout: import("@angular/core").Signal<Readout | null>;
  private readoutFor;
  protected onPointerMove(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTimeChart, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTimeChart, "neat-time-chart", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "headline": {
      "alias": "headline";
      "required": false;
      "isSignal": true;
    };
    "series": {
      "alias": "series";
      "required": true;
      "isSignal": true;
    };
    "times": {
      "alias": "times";
      "required": true;
      "isSignal": true;
    };
    "domain": {
      "alias": "domain";
      "required": true;
      "isSignal": true;
    };
    "thresholds": {
      "alias": "thresholds";
      "required": false;
      "isSignal": true;
    };
    "reference": {
      "alias": "reference";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "axis": {
      "alias": "axis";
      "required": false;
      "isSignal": true;
    };
    "headless": {
      "alias": "headless";
      "required": false;
      "isSignal": true;
    };
    "valueLabels": {
      "alias": "valueLabels";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type { NeatChartAxis, NeatChartFormat, NeatChartTone, NeatHeatmapRow, NeatReference, NeatSeries, NeatThreshold };