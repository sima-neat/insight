import * as i0 from "@angular/core";
import { AfterViewInit, ElementRef, EnvironmentProviders, InjectionToken, Injector, OnInit, Signal, WritableSignal } from "@angular/core";
import { LucideIconData } from "@lucide/angular";
import { IconNode } from "lucide";
import { IsActiveMatchOptions } from "@angular/router";
import * as i1$2 from "@spartan-ng/brain/tooltip";
import { TemplatePortal } from "@angular/cdk/portal";
import * as i1$1 from "@spartan-ng/brain/button";
import * as i1 from "@spartan-ng/brain/tabs";
import { BrnPaginatedTabHeaderItem, BrnTabsPaginatedList, BrnTabsTrigger } from "@spartan-ng/brain/tabs";
import { ClassValue } from "clsx";
import { Observable } from "rxjs";
/**
 * A step of a ramp, named as Tailwind names its shades: 50 the lightest through 950 the darkest.
 * Step 0 exists only in a surface ramp, where it is white.
 */
type ColorStep = 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950;
/** A colour ramp: a hex colour for each step from 50 to 950, as `buildColorScale` makes it. */
type ColorScale = Record<Exclude<ColorStep, 0>, string>;
/** A ramp of surface colours, white at step 0 to the darkest at 950, from the surface builders. */
type SurfaceScale = Record<ColorStep, string>;
/** Builds a 50-950 ramp in OKLCH around `base`, which becomes step 500 unchanged. */
export declare function buildColorScale(base: string): ColorScale;
/**
 * Builds the brand surface ramp: white, the two palette backgrounds and the palette text as
 * anchors, with 200-900 interpolated in OKLab between the alternate background and the text. The
 * light scheme's surfaces.
 */
export declare function buildSurfaceScale(): SurfaceScale;
/**
 * Builds the neutral surface ramp: the brand ramp's construction in greys only, from greys as light
 * as the two palette backgrounds down to the near-black (`NEAT_NEAR_BLACK`). The dark scheme's
 * surfaces, which carry no hue of their own.
 */
export declare function buildNeutralSurfaceScale(): SurfaceScale;
/**
 * Colour maths for the theme: hex <-> linear sRGB <-> OKLab/OKLCH, and WCAG 2.x contrast.
 * OKLab matrices from Björn Ottosson, "A perceptual color space for image processing" (2020).
 */
/** OKLCH: lightness 0..1, chroma >= 0, hue in degrees. */
interface Oklch {
  l: number;
  c: number;
  h: number;
}
/** Three channels: gamma-encoded or linear sRGB, or OKLab `[L, a, b]`. */
type Vec3 = readonly [number, number, number];
/** Validates `#RRGGBB` in either case and returns it in upper case. */
declare function normalizeHex(hex: string): string;
/** Converts `#RRGGBB` (either case) to OKLab `[L, a, b]`. */
declare function hexToOklab(hex: string): Vec3;
/** Converts OKLab `[L, a, b]` to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklabToHex(lab: Vec3): string;
/** Converts `#RRGGBB` (either case) to OKLCH. */
declare function hexToOklch(hex: string): Oklch;
/** Converts OKLCH to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklchToHex(color: Oklch): string;
/** Whether an OKLCH colour can be shown in sRGB without clamping. */
declare function isInSrgbGamut(color: Oklch): boolean;
/**
 * `foreground` at `alpha` (0 to 1) over an opaque `background`, blended per channel in
 * gamma-encoded sRGB as browsers composite a translucent fill such as Tailwind's `bg-x/10`.
 */
declare function composite(foreground: string, alpha: number, background: string): string;
/**
 * `color` mixed into an opaque `background` by `share` (0 to 1), in OKLab, as CSS
 * `color-mix(in oklab, color <share>, background)` does: a perceptually even step from the
 * background towards the colour, for an opaque tint.
 */
declare function mixOklab(color: string, share: number, background: string): string;
/**
 * `color` with an alpha channel, as `#RRGGBBAA`, for a translucent token such as a scrim. The alpha
 * is rounded to the nearest of the 256 values the hex byte can hold.
 */
declare function withAlpha(color: string, alpha: number): string;
/** WCAG 2.x relative luminance of `#RRGGBB`. */
declare function relativeLuminance(hex: string): number;
/**
 * WCAG 2.x contrast ratio (1 to 21) between two `#RRGGBB` colours, in either order; AA for normal
 * text asks for 4.5:1.
 */
export declare function contrastRatio(a: string, b: string): number;
/** The fixed SiMa.ai brand palette (identical to the Slides/PowerPoint theme). */
export declare const SIMA_PALETTE: {
  readonly text: "#010F0E";
  readonly background: "#F3F4F5";
  readonly backgroundAlt: "#E8E9EB";
  readonly white: "#FFFFFF";
  readonly orange: "#D26728";
  readonly purple: "#D1CEE6";
  readonly blue: "#5998DD";
  readonly mint: "#C0E8DB";
  readonly green: "#2A9C4F";
  readonly lime: "#A4CC2D";
};
/** Base of the primary scale. Swapping it (for example to the palette blue) re-derives the whole primary ramp. */
export declare const NEAT_PRIMARY_BASE: string;
/** Functional colours outside the palette, which has no red or amber but errors and warnings need them. */
export declare const NEAT_DANGER_BASE = "#C8372D";
/** Used unchanged as the warning fill (step 500 of its scale), with palette text colour on it. */
export declare const NEAT_WARN_BASE = "#E9A23B";
/**
 * The hue of the highlight tone, which marks a distinct state that is none of the statuses: the
 * palette purple's hue (291° in OKLCH) at about three times its chroma. The palette purple itself is
 * too pale to work from: a row tint of 10% of it on white is #FAFAFD, no tint at all, and no step
 * of its scale is a fill that white text reads on and that still looks purple.
 */
export declare const NEAT_HIGHLIGHT_BASE = "#9D93D6";
/**
 * Base of the series teal: the teal of Justin's colours mockup, a hue the palette lacks. Chart
 * series need a fourth hue next to blue, purple and orange that is not a status colour (green,
 * amber and red stay free to mean status).
 */
export declare const NEAT_SERIES_TEAL_BASE = "#2A8C9A";
/**
 * The dark scheme's darkest surface, its page: a neutral near-black. The dark surfaces are greys
 * from here up (`buildNeutralSurfaceScale`) rather than steps towards the palette text, whose teal
 * made a whole dark page read green.
 */
export declare const NEAT_NEAR_BLACK = "#101010";
/**
 * What a status colour says: nothing in particular (`neutral`), it went well, take note, it
 * failed, for information, or a distinct state that is none of these (`highlight`, the brand
 * purple). A status chip's fill and a select-list row's tint both take it, so that a row and its
 * chip, given the same tone, say the same.
 */
type NeatTone = 'neutral' | 'success' | 'warning' | 'danger' | 'info' | 'highlight';
/**
 * The kit's start-up in one call: it applies the stored colour scheme before the first render.
 * The colours themselves come from the kit stylesheet (`@sima/neat-ui/styles/neat-ui.css`).
 */
export declare function provideNeatUi(): EnvironmentProviders;
/** The two colour schemes the kit has, which `ThemeService` switches between. */
type NeatColorScheme = 'light' | 'dark';
/** The dark theme's selector: tokens.generated.css and the `dark` variant in neat-ui.tailwind.css. */
declare const NEAT_DARK_CLASS = "neat-dark";
/**
 * Light/dark switch for the kit. Light is the default regardless of the OS preference (which is
 * deliberately never read); dark is opt-in and persisted.
 */
export declare class ThemeService {
  private readonly root;
  private readonly current;
  readonly scheme: Signal<NeatColorScheme>;
  constructor();
  /**
   * Applies `scheme` and, unless `persist` is false, stores it for later page loads. Without
   * storing, the scheme holds for this page load only, as a URL parameter that themes a shared
   * link needs: the user's stored choice stays, and a later toggle stores as usual.
   */
  setScheme(scheme: NeatColorScheme, { persist }?: {
    persist?: boolean;
  }): void;
  /** Switches to the other scheme and stores the choice, as the shell's theme item does. */
  toggle(): void;
  private apply;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** A colour as sRGB red, green and blue, each from 0 to 1, as WebGL and canvas code take it. */
type NeatRgb = readonly [red: number, green: number, blue: number];
/**
 * The 1×1 2D context colours are resolved on, made on first use (null where there is no canvas).
 * Internal: specs put a fake in its place, since jsdom has no canvas.
 */
declare const colorProbe: {
  context?: CanvasRenderingContext2D | null;
};
/**
 * A CSS colour in any notation the browser knows (hex, `rgb()`, `oklch()`, a name) as sRGB
 * channels from 0 to 1, resolved by drawing it on a 1×1 canvas and reading the pixel back, so the
 * kit parses no colour syntax of its own. Null where there is no canvas or the colour does not
 * parse. For code that draws outside CSS (three.js, a canvas) in the theme's colours or any other
 * colour an app holds, which such code takes as numbers. Alpha is ignored, so a token with alpha
 * (a scrim) is not a fit.
 */
export declare function neatResolveColor(css: string): NeatRgb | null;
/**
 * The theme's colours for code that draws outside CSS: `tokens` maps the app's names to custom
 * properties (`{ line: '--neat-line', grid: '--border' }`), and the signal answers each resolved
 * (`neatResolveColor`), or null where the property is not set or not a colour. They are read from
 * `element` (the document element by default, or while it answers undefined) and read again when
 * the colour scheme changes, which `ThemeService` applies before the signal is read again. Call in
 * an injection context.
 */
export declare function neatThemeColors<K extends string>(tokens: Record<K, string>, element?: () => Element | undefined): Signal<Record<K, NeatRgb | null>>;
/**
 * An icon: a name from the kit's curated set, or where no name fits a glyph from
 * `@sima/neat-ui/lucide`. Decorative by default (hidden from assistive technology);
 * give it a `label` when it carries meaning on its own. It takes its colour from the surrounding
 * text. The `spinner` turns (see `icon.css`), still for a user who asked for reduced motion; it
 * says nothing of waiting, so the control it sits in does (an `aria-busy`, a held state).
 */
export declare class NeatIcon {
  /**
   * Which glyph to draw: a name of the kit's set (`NEAT_ICON_NAMES` lists them all) first, and
   * only where none fits a glyph imported from `@sima/neat-ui/lucide`.
   */
  readonly name: import("@angular/core").InputSignal<"warning" | "info" | "search" | "copy" | "media" | import("lucide").IconNode | "streaming" | "viewer" | "peripherals" | "camera" | "microphone" | "lidar" | "device" | "stats" | "board" | "sun" | "moon" | "kiosk-enter" | "kiosk-exit" | "rail-expand" | "rail-collapse" | "side-panel" | "palette" | "shapes" | "blocks" | "document" | "previous" | "next" | "close" | "check" | "expand" | "collapse" | "aspect-wide" | "aspect-square" | "more" | "fit-all" | "upload" | "folder" | "file" | "error" | "refresh" | "spinner" | "terminal" | "pause" | "play" | "stop">;
  /** Edge length in pixels. */
  readonly size: import("@angular/core").InputSignal<number>;
  /** Accessible name; leave unset for a decorative icon. */
  readonly label: import("@angular/core").InputSignal<string | undefined>;
  /** The kit's name, null for a glyph given as a drawing; the stylesheet's hook is by name. */
  protected readonly kitName: import("@angular/core").Signal<"warning" | "info" | "search" | "copy" | "media" | "streaming" | "viewer" | "peripherals" | "camera" | "microphone" | "lidar" | "device" | "stats" | "board" | "sun" | "moon" | "kiosk-enter" | "kiosk-exit" | "rail-expand" | "rail-collapse" | "side-panel" | "palette" | "shapes" | "blocks" | "document" | "previous" | "next" | "close" | "check" | "expand" | "collapse" | "aspect-wide" | "aspect-square" | "more" | "fit-all" | "upload" | "folder" | "file" | "error" | "refresh" | "spinner" | "terminal" | "pause" | "play" | "stop" | null>;
  protected readonly glyph: import("@angular/core").Signal<LucideIconData>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatIcon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatIcon, "neat-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
declare const NEAT_ICONS: {
  media: LucideIconData;
  streaming: LucideIconData;
  viewer: LucideIconData;
  peripherals: LucideIconData;
  camera: LucideIconData;
  microphone: LucideIconData;
  lidar: LucideIconData;
  device: LucideIconData;
  stats: LucideIconData;
  board: LucideIconData;
  info: LucideIconData;
  sun: LucideIconData;
  moon: LucideIconData;
  'kiosk-enter': LucideIconData;
  'kiosk-exit': LucideIconData;
  'rail-expand': LucideIconData;
  'rail-collapse': LucideIconData;
  'side-panel': LucideIconData;
  palette: LucideIconData;
  shapes: LucideIconData;
  blocks: LucideIconData;
  document: LucideIconData;
  previous: LucideIconData;
  next: LucideIconData;
  close: LucideIconData;
  check: LucideIconData;
  copy: LucideIconData;
  expand: LucideIconData;
  collapse: LucideIconData;
  'aspect-wide': LucideIconData;
  'aspect-square': LucideIconData;
  search: LucideIconData;
  more: LucideIconData;
  'fit-all': LucideIconData;
  upload: LucideIconData;
  folder: LucideIconData;
  file: LucideIconData;
  error: LucideIconData;
  warning: LucideIconData;
  refresh: LucideIconData;
  spinner: LucideIconData;
  terminal: LucideIconData;
  pause: LucideIconData;
  play: LucideIconData;
  stop: LucideIconData;
};
/** The name of a glyph in the kit's curated icon set, what `neat-icon`'s `name` takes. */
type NeatIconName = keyof typeof NEAT_ICONS;
/**
 * A Lucide drawing (what `@sima/neat-ui/lucide` exports for each glyph), what `neat-icon`'s `name`
 * takes where no name of the kit's set fits.
 */
type NeatIconGlyph = IconNode;
/**
 * Every name in the registry, in registry order, for galleries and pickers. Play, pause and stop
 * are the only filled glyphs, since media controls are solid by convention; every other name is an
 * outline.
 */
export declare const NEAT_ICON_NAMES: readonly NeatIconName[];
/**
 * One sub-page of a page in the shell's rail. It has no icon: sub-pages are rows of text under
 * their page, which carries the icon.
 */
interface NeatNavChild {
  /** Shown as the link's name and, while it is open, the page title. */
  label: string;
  /**
   * Absolute app path, for example `/theme/colours`. It is open on its own path and every route
   * nested under it, whatever the query; a child whose path is its page's own (a first view at
   * `/stats`, beside `/stats/runs`) is open on that path only, so it is not open on its siblings'
   * routes. Where two children match, the one with the longer path is open.
   */
  path: string;
}
/** One page in the shell's rail. */
interface NeatNavItem {
  /** Shown as the link's name, its tooltip and, while the page is active, the page title. */
  label: string;
  icon: NeatIconName;
  /** Absolute app path, for example `/media`; the item stays active on routes nested under it. */
  path: string;
  /**
   * The page's sub-pages, the only second level of the rail's navigation (more than a few, or
   * deeper levels, belong in the page's own side list). They unfold under the item while the page
   * is active and the rail shows its labels; the open one carries `aria-current="page"` and the
   * item then does not. The item's link still goes to `path`: the app routes it to the first
   * sub-page, or gives the first sub-page the page's own path. The kit does not redirect.
   * Collapsed, a press on the item goes to `path` as well, and hovering it with a mouse or
   * focusing it with the keyboard shows them as a menu beside the rail.
   */
  children?: readonly NeatNavChild[];
}
/** How long the pointer must rest before `KioskService.pointerIdle` turns true. */
export declare const KIOSK_POINTER_IDLE_MS = 2500;
/**
 * Kiosk mode for expos: the shell hides its rail and top bar, and pages can hide their own chrome
 * while the pointer rests (`pointerIdle`). Kiosk keeps the current colour scheme and is not
 * persisted; it comes from the button or from a `?kiosk` URL parameter read once at start.
 *
 * `enter()` also asks for browser fullscreen. The URL parameter does not, because browsers refuse
 * fullscreen without a user gesture; booth machines use the browser's own kiosk flag instead.
 * If fullscreen was obtained by `enter()`, leaving it (Esc) leaves kiosk mode too.
 *
 * A component whose UI lives outside the floating chrome but belongs to it (a popover opened from
 * the page toolbar) holds the toolbar with `holdToolbar()`, so the chrome does not fade under it.
 *
 * The document listeners are plain DOM listeners outside change detection; signals change only
 * when the state does, so pointer movement does not cause renders.
 */
export declare class KioskService {
  private readonly document;
  private readonly isActive;
  private readonly isPointerIdle;
  /** Whether the current fullscreen is the one `enter()` asked for. */
  private ownsFullscreen;
  /** Unreleased `holdToolbar()` calls; the pointer never counts as idle while there are any. */
  private holds;
  private idleTimer;
  readonly active: Signal<boolean>;
  /**
   * True once the pointer has rested for `KIOSK_POINTER_IDLE_MS`; false again on pointer or touch
   * input, and false throughout a `holdToolbar()`.
   */
  readonly pointerIdle: Signal<boolean>;
  constructor();
  /** Turns kiosk on and asks for fullscreen; kiosk stays on if fullscreen is refused. */
  enter(): Promise<void>;
  /** Turns kiosk off, leaving fullscreen only if `enter()` obtained it. */
  exit(): Promise<void>;
  toggle(): Promise<void>;
  /**
   * Keeps `pointerIdle` false, so the kiosk chrome stays shown, until the returned function is
   * called. Holds stack: the pointer can go idle again only once every hold is released, and then
   * only after resting a full `KIOSK_POINTER_IDLE_MS`. Releasing twice counts once.
   */
  holdToolbar(): () => void;
  private onFullscreenChange;
  private onActivity;
  /** Starts the countdown to idle over; while the toolbar is held there is nothing to count. */
  private restartIdleTimer;
  static ɵfac: i0.ɵɵFactoryDeclaration<KioskService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Whether the screen is narrow, a phone's width. `narrow` follows the browser's media query live,
 * so turning a phone or resizing a window changes it at once; where the browser has no
 * `matchMedia` (a test environment) it stays `false`, a wide screen.
 *
 * Inject it rather than asking the browser, so the kit and the app share one answer and a test
 * can provide `{ narrow: signal(true) }` in its place.
 */
export declare class NeatViewport {
  private readonly state;
  /** `true` while the viewport is narrower than 48rem. */
  readonly narrow: import("@angular/core").Signal<boolean>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatViewport, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The app frame: the top bar, which is the page's, across the full width at the top, and below it
 * the rail on the left, which is the app's, and the content area for the routed page. The top bar
 * comes first in the DOM, so the tab order is the visual one: top bar, rail, content. It fills the
 * viewport, or the bounded box it is placed in; the content area gives its page the remaining space
 * and never scrolls itself, so pages own their scrolling (see `neat-page`).
 *
 * The rail holds the pages (`navItems`) and, at its bottom below a divider, the app's own items
 * (elements marked `neatRailEnd`: `neatRailItem`s, and `neatRailDivider`s between groups of them),
 * then the kit's theme item, then the rail's control. Expanded, its items show icon and label;
 * collapsed, the icon with the label as a tooltip and as hidden text. The theme item and the
 * control are actions named for what a click does: "Dark theme" or "Light theme", "Show labels" or
 * "Collapse".
 *
 * A page with `children` unfolds them under its item while it is the active page and the rail shows
 * its labels (expanded, or floating open on a narrow screen): rows of text, indented under a thin
 * line, the open one in the rail's current-page look. The item then keeps its label in full text
 * colour at weight 500 without the fill, so one row alone reads as current, and only that row
 * carries `aria-current="page"`. Only the active page's children show, so the rail does not grow
 * with every page's sub-pages.
 *
 * Collapsed, the rail has no room for them: its item for a page with `children` stays a link to the
 * page's `path`, and a press just navigates, as on any rail item. The menu of the sub-pages beside
 * the rail is a companion of mouse hover and keyboard focus only (Tab steps from the item into its
 * links, Escape closes it); a tap shows none, as the rail can be expanded. The item keeps the
 * current-page look while the route belongs to the page. The menu's heading is the page's label,
 * which is why that item has no tooltip.
 *
 * The top bar holds the logo, the app name and the page title, then at its right the active page's
 * tools (`*neatPageToolbar`), elements marked `neatTopbarEnd`, the kiosk button (the one app
 * control there, since it changes how the page is shown), and last, at the right edge above the
 * side panel, the page's side-panel toggle (`neat-aside-toggle`) when the page has one. The page
 * title is the matching nav item's label, else the route's `title`; on a page with sub-pages it is
 * the open sub-page's label with the page's label beside it, muted, or, on a route deeper than the
 * sub-page whose own `title` is set (not an ancestor's), that title with "page › sub-page" beside
 * it. The default slot is the content area (usually a `<router-outlet />`).
 *
 * Kiosk mode (`KioskService`, entered from the top bar or with `?kiosk`) drops the rail and the
 * top bar, gives the content area the whole viewport and floats an exit control over its top
 * right corner while the pointer moves; the page toolbar, then the side-panel toggle, float beside
 * it on the same terms. Their views are re-created on entering and leaving kiosk mode, so the page
 * keeps their state.
 *
 * On a narrow screen (`NeatViewport`, below 48rem) the app name and the page title are visually
 * hidden but stay for screen readers (the title as the page's `h1`; the name beside the logo,
 * which is also named "SiMa.ai"). The logo, the end slot, the kiosk button and the side-panel
 * toggle share the first row, the end slot growing from a zero basis and the toggle last, and the
 * page toolbar takes its own full-width second row. An expanded rail floats over the content,
 * below the top bar, instead of squeezing it, starts collapsed without touching the remembered
 * choice, and collapses when one of its links is followed. The host's `data-narrow` says which,
 * and the CSS reacts to that, never to a second `@media`.
 */
export declare class NeatShell {
  /**
   * The app's name, shown in the top bar beside the logo on a wide screen; on a narrow one it is
   * read out only.
   */
  readonly appName: import("@angular/core").InputSignal<string>;
  /** The pages the rail links to, in order: each an icon, a label and an absolute path. */
  readonly navItems: import("@angular/core").InputSignal<NeatNavItem[]>;
  protected readonly theme: ThemeService;
  protected readonly kiosk: KioskService;
  protected readonly viewport: NeatViewport;
  protected readonly pageToolbar: import("@angular/core").Signal<import("@angular/cdk/portal").TemplatePortal<any> | null>;
  protected readonly asideToggle: import("@angular/core").Signal<import("@angular/cdk/portal").TemplatePortal<any> | null>;
  protected readonly toolbarLabel = "Page tools";
  private readonly router;
  private readonly injector;
  protected readonly activeMatch: IsActiveMatchOptions;
  private readonly rail;
  protected readonly railExpanded: import("@angular/core").Signal<boolean>;
  private readonly kioskExit;
  private readonly kioskButton;
  /**
   * The nav item the current route belongs to (the first match wins) and, when it has sub-pages,
   * the open one with whether the route is deeper than it.
   */
  private readonly active;
  /** The nav item whose sub-pages show in the rail, with its open one; none while collapsed. */
  protected readonly unfolded: import("@angular/core").Signal<{
    item: NeatNavItem;
    child: NeatNavChild | undefined;
    url: import("@angular/router").UrlTree;
  } | undefined>;
  /**
   * The title's text and, beside it, the muted page it belongs to. A nav item's label wins over a
   * route's `title` because it is what the rail shows as the current page, and nested routes under
   * one item keep its name whatever their titles say; a page with sub-pages is the one exception,
   * where the open sub-page names the route, and a route deeper than it (a level-3 topic, a
   * compare view) names itself when it has a title, so the title says where the person is. Without
   * a nav item the route's own `title` is all there is, so a board's page or a detail view still
   * has a heading.
   */
  protected readonly pageTitle: import("@angular/core").Signal<{
    text: string;
    context?: string;
  }>;
  /** Whether the item's open sub-page is showing, which then carries the current-page state. */
  protected holdsOpenChild(item: NeatNavItem): boolean;
  /** Whether the route belongs to the page, for the item that opens its menu while collapsed. */
  protected isActivePage(item: NeatNavItem): boolean;
  /** The page's open sub-page, which the collapsed rail's menu marks. */
  protected currentChild(item: NeatNavItem): NeatNavChild | undefined;
  /** Whether `child` is the open sub-page of the unfolded page, for the link's current state. */
  protected isOpen(child: NeatNavChild): boolean;
  private routeTitle;
  private segmentCount;
  constructor();
  /**
   * The mirror of entering: leaving kiosk mode with the exit control removes it, which drops focus
   * to <body>; hand focus to the top-bar kiosk button that comes back, where kiosk mode was entered.
   * Not when kiosk mode ends otherwise (Esc leaving fullscreen, for example), when focus may be on
   * the page and must stay there.
   */
  protected focusKioskButtonAfterExit(): void;
  protected toggleRail(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatShell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatShell, "neat-shell", never, {
    "appName": {
      "alias": "appName";
      "required": true;
      "isSignal": true;
    };
    "navItems": {
      "alias": "navItems";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["[neatTopbarEnd]", "[neatRailEnd]", "*"], true, never>;
}
/**
 * Whether the shell's rail shows its labels. Internal to the kit: `neat-shell` provides it to its
 * own template and to the content an app projects into it, which is how a rail item knows.
 *
 * On a wide screen it is the remembered choice; on a narrow one, where the rail floats over the
 * content, a transient flag that starts collapsed and never overwrites the wide screen's choice
 * (the rule of a page's side panel, `neatAsideOpen`).
 */
declare class RailState {
  private readonly viewport;
  private readonly remembered;
  private readonly state;
  readonly expanded: import("@angular/core").Signal<boolean>;
  set(expanded: boolean): void;
  /** A floating rail covers the page it just opened, so following a link puts it away. */
  collapseWhenNarrow(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RailState, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Provided by an item that shows a menu of sub-pages (`RailMenu`), which `NeatRailItem` reads to
 * leave its
 * tooltip off: the menu's heading says the label. Internal to the kit.
 */
declare const RAIL_ITEM_HAS_MENU: InjectionToken<true>;
/**
 * An item of the shell's rail, the one look of the page links, the theme item, the rail's own
 * control and an app's items at the bottom of the rail (`[neatRailEnd]`):
 *
 * ```html
 * <button neatRailEnd neatRailItem type="button" label="System information" (click)="…">
 *   <neat-icon name="info" />
 * </button>
 * ```
 *
 * The content is the icon. `label` is the visible text while the rail is expanded; collapsed, it
 * stays as the item's visually hidden text, so the name is kept, and shows as a tooltip on the
 * right.
 *
 * An item with a state (a board, a connection) says it with the kit's inputs:
 *
 * ```html
 * <button neatRailEnd neatRailItem type="button" label="DevKit, 192.168.100.2, connected"
 *         text="DevKit" detail="192.168.100.2" tone="success" (click)="…">
 *   <neat-icon name="board" />
 * </button>
 * ```
 *
 * `tone` puts a dot on the icon's corner, `text` is the visible first line (the label by default)
 * and `detail` a smaller second line in the tone's colour, both cut with an ellipsis and hidden
 * with the label while the rail is collapsed. `label` stays the tooltip and the name, so it is the
 * whole sentence, with the state the dot alone shows: brain's tooltip takes its text from the
 * template only, so the kit cannot compose it from the lines. While the lines say other than
 * `label`, they are `aria-hidden` and the label is visually hidden text beside them, so the name
 * still comes from the content and an `aria-label` the app sets still wins (a kit `aria-label`
 * binding would remove the app's).
 *
 * Visible text the inputs cannot say goes in an element marked `neatRailItemLabel`, which takes
 * the label's place; `label` stays the tooltip, so it should say at least what that text says. Its
 * name is then that text, unless the app gives an `aria-label`. The lines of such an element are
 * the app's, which the kit's stylesheet cannot reach: each ellipsizes itself (`min-width: 0`,
 * `overflow: hidden`, `white-space: nowrap`, `text-overflow: ellipsis`).
 *
 * An item is an action, never a toggle: its label says what a click does ("Dark theme" while
 * light, "Light theme" while dark), so it has no pressed state, and the rail's selection fill means
 * only "the current page" (`aria-current="page"`).
 *
 * The host stays the native button or link, with its own click, focus and `routerLink`. A link
 * followed on a narrow screen puts the floating rail away; a button leaves it, since its action
 * may want the rail (a theme switch) or open a dialog over it.
 *
 * Brain's tooltip is a host directive here, not `neatTooltip`, because the item names its own
 * tooltip from `label`: a host directive's inputs come from the template that uses the element,
 * and `label` feeds both the item and the tooltip. It is switched off while the labels show, and
 * on the shell's items that show a menu of sub-pages on hover and focus (a collapsed page with
 * `children`), whose menu names the page itself.
 */
export declare class NeatRailItem {
  /**
   * The item's name and tooltip, and its visible text while the rail is expanded unless `text` or
   * `detail` say otherwise.
   */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The visible first line, when it says less than `label` (a board's name, its state aside). */
  readonly text: import("@angular/core").InputSignal<string | undefined>;
  /** A smaller second line under the first (an address, a state), in the tone's colour. */
  readonly detail: import("@angular/core").InputSignal<string | undefined>;
  /** The state a dot on the icon's corner shows; no dot without it. */
  readonly tone: import("@angular/core").InputSignal<NeatTone | undefined>;
  /** Whether the item shows lines that say other than `label`, which then names it unseen. */
  protected readonly showsLines: import("@angular/core").Signal<boolean>;
  private readonly rail;
  private readonly isLink;
  constructor();
  protected expanded(): boolean;
  protected followed(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRailItem, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatRailItem, "button[neatRailItem], a[neatRailItem]", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "detail": {
      "alias": "detail";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[neatRailItemLabel]"], true, [{
    directive: typeof i1$2.BrnTooltip;
    inputs: {
      "brnTooltip": "label";
    };
    outputs: {};
  }]>;
}
/**
 * A line between groups of the rail's bottom items: `<hr neatRailEnd neatRailDivider />` among an
 * app's `[neatRailEnd]` items (below a board block, for example). The shell draws the line above
 * the whole group with the same element, so the look is stated once: 1px of `--sidebar-border`, a
 * quarter step of margin above and below, which with the group's quarter-step gap leaves half a
 * step to the items around it. Decorative (`aria-hidden`): the items' names say what they are, and
 * a separator announced between them would only be noise.
 */
export declare class NeatRailDivider {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRailDivider, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatRailDivider, "hr[neatRailDivider]", never, {}, {}, never, never, true, never>;
}
/**
 * Titles the document `<appName> · <route title>`, or `<appName>` alone on a route without a
 * title, so every app's browser tabs read the same way: `provideNeatTitles('Neat Insight')` beside
 * `provideRouter` in the app's providers. The page title in the shell's top bar is the shell's own
 * and does not come from here.
 */
export declare function provideNeatTitles(appName: string): EnvironmentProviders;
/**
 * A place in the shell that the active page fills with a template of its own: the page toolbar
 * (`*neatPageToolbar`) and the side-panel toggle (`neat-aside-toggle`). Internal to the kit: the
 * page side registers a portal, the shell renders `portal`, and the content stays the page's
 * (bindings, injection).
 */
declare class ShellSlot {
  private readonly secondError;
  private readonly current;
  /** The registered portal, or null when the active page fills nothing here. */
  readonly portal: Signal<TemplatePortal | null>;
  /** @param secondError what a second registration throws in dev mode */
  constructor(secondError: string);
  register(portal: TemplatePortal): void;
  unregister(portal: TemplatePortal): void;
}
/**
 * True for content rendered inside the page toolbar, in the top bar or the kiosk bar alike.
 * Internal to the kit: a popover reads it to hold the kiosk bar open while it is open.
 */
declare const IN_PAGE_TOOLBAR: InjectionToken<boolean>;
/**
 * Where the active page's toolbar is handed to the shell. Internal to the kit: pages use
 * `*neatPageToolbar`, the shell renders `portal`.
 */
declare class PageToolbarSlot extends ShellSlot {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<PageToolbarSlot, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The page's toolbar: `<div *neatPageToolbar>…</div>` on a page renders that content in the
 * shell's top bar, at its right end just before the end slot and the kiosk button, while the page
 * exists. In kiosk mode, where the top bar is hidden, it renders in a floating bar beside the exit
 * control that shows while the pointer moves. The content stays the page's: its bindings and
 * injection context are those of the page's template.
 *
 * One page toolbar at a time; a second one throws in dev mode.
 */
export declare class NeatPageToolbar {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPageToolbar, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPageToolbar, "[neatPageToolbar]", never, {}, {}, never, never, true, never>;
}
/**
 * A page in the shell's content area. It fills its parent and owns at most one scroll context:
 * with `scroll="body"` (the default) its body is the single scroll container; with
 * `scroll="none"` nothing scrolls and the content sizes itself to the page (for example a grid
 * that fits the screen). The content takes its size from the page and neither measures the shell
 * nor sets a height, so the same page works in a small window, on a wall display and in kiosk
 * mode, where the rail and the top bar are gone and the page gets the whole viewport.
 *
 * With `padding="page"` (the default) the content keeps the kit's page inset from the content
 * area's edges, so every app's pages line up; `padding="none"` lets full-bleed content (a video
 * grid, a map) reach the edges.
 *
 * A `nav[neatPageNav]` (see `NeatPageNav`) as a direct child is the page's side list: the body's
 * start column, as high as the page and scrolling on its own whatever `scroll` says, with the
 * side panel at the other end; on a narrow screen a closed section above the body, under which
 * the floating panel opens. Without one, the body starts at the page's edge.
 *
 * Elements marked `neatPageAside` form the page's side panel (an inspector, say), shown on the
 * right while `aside="open"`. The panel is `--neat-aside-width` wide and scrolls on its own; the
 * body narrows beside it rather than being covered, keeping its own scroll setting. The aside and
 * the side list are the supported other scroll contexts of a page: a page that needs another
 * region of its own that scrolls independently is a kit change, so that the layout becomes a
 * supported component, not a workaround. Closed, the panel and its content are out of the DOM,
 * but projected content is still instantiated (content projection always creates it): gate
 * expensive content with an `@if` of your own.
 *
 * On a narrow screen (`NeatViewport`) the panel floats over the right of the page instead,
 * `--neat-aside-width` wide but never wider than the page, and the body keeps the whole width.
 * There is no scrim and no Escape handling: the page owns the open state, and the toolbar's
 * `neat-aside-toggle` closes it. A page that keeps its panel's state should use `neatAsideOpen`,
 * which starts the panel closed on a narrow screen without overwriting the choice remembered
 * for a wide one.
 *
 * Beside the body the panel can be resized: a separator on its inline-start edge is dragged with
 * a pointer, or moved with the arrow keys (left widens, 16 px a step), Home and End; a double
 * click returns to the default. `asideWidth` is the width in pixels, `null` for the default
 * `--neat-aside-width`. The page only exposes the model, so an app that wants the width kept
 * binds `[(asideWidth)]` and stores it where it likes; a drag writes it on release, a key press
 * at once. The panel is shown between 18rem and the page's width less 20rem, which leaves the
 * body 20rem; a width outside that is shown clamped and the model left alone, so a remembered
 * width returns when the window is wide enough again.
 */
export declare class NeatPage {
  protected readonly viewport: NeatViewport;
  /**
   * Which part scrolls: `body` (the default) makes the body the page's one scroll container;
   * `none` clips it, for content that sizes itself to the page.
   */
  readonly scroll: import("@angular/core").InputSignal<"body" | "none">;
  /**
   * The inset around the content: `page` (the default) keeps the kit's page padding, which scrolls
   * with the content; `none` lets full-bleed content reach the edges.
   */
  readonly padding: import("@angular/core").InputSignal<"none" | "page">;
  /**
   * Whether the side panel (the elements marked `neatPageAside`) is shown: `closed` (the default)
   * or `open`. The page owns no state: bind it to yours, or to `neatAsideOpen`.
   */
  readonly aside: import("@angular/core").InputSignal<"open" | "closed">;
  /** The panel's width in pixels, `null` for the default `--neat-aside-width`. */
  readonly asideWidth: import("@angular/core").ModelSignal<number | null>;
  private readonly page;
  private readonly panel;
  private readonly pageWidth;
  private readonly panelWidth;
  private readonly rem;
  /** The width a drag in progress asks for, until the pointer is released. */
  protected readonly dragWidth: import("@angular/core").WritableSignal<number | null>;
  private dragStart;
  protected readonly bounds: import("@angular/core").Signal<{
    min: number;
    max: number | null;
  }>;
  /** The width asked for, by a drag or the model; `null` when the default applies. */
  protected readonly requested: import("@angular/core").Signal<number | null>;
  /** The width the separator announces: what was asked for, clamped, or the default as laid out. */
  protected readonly width: import("@angular/core").Signal<number | null>;
  constructor();
  protected step(event: KeyboardEvent): void;
  protected startDrag(event: PointerEvent): void;
  protected drag(event: PointerEvent): void;
  protected endDrag(): void;
  protected cancelDrag(): void;
  /** The width now, from the panel itself while the observer has not reported yet. */
  private current;
  private clamp;
  private measure;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPage, "neat-page", never, {
    "scroll": {
      "alias": "scroll";
      "required": false;
      "isSignal": true;
    };
    "padding": {
      "alias": "padding";
      "required": false;
      "isSignal": true;
    };
    "aside": {
      "alias": "aside";
      "required": false;
      "isSignal": true;
    };
    "asideWidth": {
      "alias": "asideWidth";
      "required": false;
      "isSignal": true;
    };
  }, {
    "asideWidth": "asideWidthChange";
  }, never, ["[neatPageNav]", "*", "[neatPageAside]"], true, never>;
}
/** One link of the page's side list. */
interface NeatPageNavLink {
  /** The link's text, which the filter matches. */
  label: string;
  /**
   * Absolute app path, for example `/settings/network`. The link is the open one on this path and
   * every route nested under it, whatever the query and fragment; where two links match, the one
   * with the longer path is.
   */
  path: string;
}
/** A group of the side list's links, under a heading when it has a `label`. */
interface NeatPageNavGroup {
  /** The group's heading; a group without one shows its links with no heading above them. */
  label?: string;
  items: readonly NeatPageNavLink[];
}
/**
 * The page's side list, the third level of the kit's navigation: pages are rail items, a page's
 * sub-pages its item's `children`, and anything more (more than a few links, groups of them, or a
 * level below a sub-page) is this list, as a direct child of `neat-page`:
 *
 * ```html
 * <neat-page>
 *   <nav neatPageNav aria-label="Components" [groups]="groups" filterLabel="Filter"></nav>
 *   …
 * </neat-page>
 * ```
 *
 * `groups` is data, not content: each group's links under its heading (none for a group without
 * a `label`). The open link is the one whose `path` the URL is under (the query and fragment are
 * never judged, and the longest such path wins); it carries `aria-current="page"` and has the
 * rail's current-page look in the page's tokens, the accent fill and weight, where the other links
 * are muted until hovered. With `filterLabel`, a search field at the top, named and hinted by that
 * text, keeps the links whose label holds what was typed, ignoring case, and a group's heading
 * while any of its links is kept; when none is, it says "Nothing matches".
 *
 * The landmark is the app's: a screen reader hears a navigation landmark of links, so it needs a
 * name, which only the app knows. A nav without an `aria-label` (or `aria-labelledby`) throws in
 * dev mode. The name is read once, when the list is first drawn.
 *
 * On a wide screen the page draws it as its body's start column, as high as the page, with the
 * side panel at the other end. It scrolls on its own whatever the page's `scroll`, so it stays in
 * view while the body scrolls, with the filter fixed at its top; it scrolls itself, never with
 * `scrollIntoView` (which would scroll the page around it too), to show the open link whenever a
 * navigation leaves that link out of view. On a narrow screen (`NeatViewport`) it is a closed
 * section above the body instead, with the look of `NeatCollapsible`: the landmark's name as its
 * label and the open link as its summary. Opened, its list scrolls inside it up to the page's
 * height, and choosing a link closes it with the focus on its button, as a link followed puts the
 * floating rail away.
 */
export declare class NeatPageNav implements AfterViewInit {
  /** The links, in groups, in the order they are listed. */
  readonly groups: import("@angular/core").InputSignal<readonly NeatPageNavGroup[]>;
  /**
   * The name and placeholder of a filter over the links' labels at the top of the list ("Filter
   * components"); no filter without it.
   */
  readonly filterLabel: import("@angular/core").InputSignal<string | undefined>;
  protected readonly viewport: NeatViewport;
  private readonly router;
  private readonly document;
  private readonly host;
  private readonly trigger;
  private readonly list;
  protected readonly id: string;
  protected readonly collapsible: {
    readonly trigger: "group flex w-full min-w-0 cursor-pointer items-center gap-(--neat-space-2) rounded-(--radius) py-1 text-start text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring";
    readonly chevron: "shrink-0 text-muted-foreground transition-transform duration-(--neat-transition-duration) group-hover:text-foreground motion-reduce:transition-none";
    readonly label: "shrink-0 font-medium";
    readonly summary: "min-w-0 truncate text-muted-foreground";
    readonly content: "pt-(--neat-space-2) data-closed:hidden";
  };
  protected readonly field: string;
  /** Whether the narrow screen's section is open. */
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  /** The landmark's name, the narrow screen's section label. */
  protected readonly name: import("@angular/core").WritableSignal<string>;
  protected readonly filter: import("@angular/core").WritableSignal<string>;
  protected readonly query: import("@angular/core").Signal<string>;
  /** The groups with the links the filter keeps; a group with none left is left out. */
  protected readonly shown: import("@angular/core").Signal<readonly NeatPageNavGroup[]>;
  /**
   * The open link: of those whose path the URL is under, the longest. The router's last
   * navigation is a signal, so back and forward move it too.
   */
  protected readonly current: import("@angular/core").Signal<NeatPageNavLink | undefined>;
  constructor();
  ngAfterViewInit(): void;
  /**
   * A link was chosen. On a narrow screen the open section covers the body, so it closes, and the
   * focus, which was on a link it hides, goes to its button rather than to nothing.
   */
  protected chosen(): void;
  /**
   * Scrolls `box` so the open link shows, centred, when it does not already. The box is the links'
   * offset parent (`position: relative` in the stylesheet).
   */
  private reveal;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPageNav, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPageNav, "nav[neatPageNav]", never, {
    "groups": {
      "alias": "groups";
      "required": true;
      "isSignal": true;
    };
    "filterLabel": {
      "alias": "filterLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The state of a page's side panel, as `neatAsideOpen` keeps it. */
interface NeatAsideOpen {
  /** Whether the panel is open now: bind it to the page's `aside` and the toggle's `open`. */
  readonly open: Signal<boolean>;
  /** Opens or closes the panel; the toggle's `(openChange)` and the page's own openings go here. */
  set(open: boolean): void;
}
/**
 * The open state of a page's side panel, for a page that remembers the choice (`remembered`, with
 * `remember` writing it where the page keeps it, such as local storage). Call it in an injection
 * context.
 *
 * On a wide screen the panel is the remembered choice and `set` remembers. On a narrow screen the
 * panel floats over the page and starts closed, whatever was remembered, and `set` changes a
 * transient flag only: a phone's opening and closing must not overwrite the choice made on a wide
 * screen. The flag resets to closed whenever `narrow` changes, so each time the viewport becomes
 * narrow it starts closed, and going wide shows the remembered choice again.
 */
export declare function neatAsideOpen(remembered: Signal<boolean>, remember: (open: boolean) => void): NeatAsideOpen;
/**
 * Where the active page's side-panel toggle is handed to the shell, which draws it at the top
 * bar's right edge (or in kiosk mode's floating bar). Internal to the kit: pages declare
 * `neat-aside-toggle`, the shell renders `portal`.
 */
declare class AsideToggleSlot extends ShellSlot {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AsideToggleSlot, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The button that opens and closes the page's side panel, which the shell draws at the top bar's
 * right edge, after the kiosk button and above the panel:
 *
 * ```html
 * <div *neatPageToolbar>…</div>
 * <neat-aside-toggle [(open)]="asideOpen" />
 * <neat-page [aside]="asideOpen() ? 'open' : 'closed'">…</neat-page>
 * ```
 *
 * The page declares it anywhere in its template except inside `*neatPageToolbar` (which throws in
 * dev mode: the toggle has a place of its own, and the toolbar's view is re-created by the shell);
 * it renders nothing where it is declared, and its button, a template of its own, goes to the
 * shell while the page exists, as the page toolbar does. On a narrow screen it is the last item of
 * the top bar's first row; in kiosk mode it floats with the page's tools, after them. One toggle
 * at a time; a second throws in dev mode.
 *
 * One look on every page: the top bar's edge control, as the kiosk button beside it (a large,
 * round, text, icon-only `neatButton`), with the `side-panel` icon (not `info`, which is left for
 * an information action), whose pressed state is the panel's. `label` names it and is its tooltip
 * ("Side panel" unless the page says otherwise). `open` is a model the page owns, so the page
 * decides where it is remembered; the toggle only flips it. `focus()` puts the focus on the button,
 * for a page whose panel closes from inside (Escape, a close button) and must not leave the focus
 * on nothing.
 */
export declare class NeatAsideToggle implements OnInit {
  /** The button's name and tooltip. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Whether the page's side panel is open. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  private readonly slot;
  private readonly viewContainer;
  private readonly destroyRef;
  private readonly template;
  private readonly button;
  constructor();
  ngOnInit(): void;
  /** Puts the focus on the button. */
  focus(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideToggle, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatAsideToggle, "neat-aside-toggle", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, never, true, never>;
}
/**
 * The column of a side panel's content, on the element the page marks `neatPageAside` (or its
 * root inside): its parts stacked one gap apart (`--neat-space-3`). The aside gives it its width,
 * inset and scrolling.
 */
export declare class NeatAsidePanel {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsidePanel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsidePanel, "[neatAsidePanel]", never, {}, {}, never, never, true, never>;
}
/** What the panel is about, as its first line: `<h2 neatAsideTitle>src3</h2>`. */
export declare class NeatAsideTitle {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideTitle, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsideTitle, "[neatAsideTitle]", never, {}, {}, never, never, true, never>;
}
/**
 * The heading of a section of the panel: `<h3 neatAsideHeading>Source</h3>`. It sits nearer to the
 * section it names than to the one before (a gap above it on top of the panel's), except as the
 * panel's first part.
 */
export declare class NeatAsideHeading {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideHeading, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsideHeading, "[neatAsideHeading]", never, {}, {}, never, never, true, never>;
}
/** A row of the panel's buttons, which wraps when the panel is narrow. */
export declare class NeatAsideActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideActions, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsideActions, "[neatAsideActions]", never, {}, {}, never, never, true, never>;
}
/**
 * A URL, a path or a name in running text: `<code neatCode>rtsp://…/src3</code>`. Monospace runs
 * wide, so it is the kit's small size, and it has no spaces to break at, so it wraps anywhere.
 */
export declare class NeatCode {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCode, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatCode, "code[neatCode]", never, {}, {}, never, never, true, never>;
}
/**
 * The button's look, by what the action does: `primary` the page's main action (the app's
 * accent), `secondary` a quieter filled one and the neutral choice, `outlined` a bordered one,
 * `text` no fill and no border (for actions among others), `danger` a solid red for what stops or
 * discards something (Stop recording), `danger-text` that red as text for a destructive action
 * among text buttons, and `success` a solid green for what starts something (Start recording).
 *
 * `success` and `danger` pair with the filled `play` and `stop` icons. `danger-text` hovers as the
 * text buttons beside it do, its label kept red, and focuses with danger's red ring.
 */
type NeatButtonVariant = 'primary' | 'secondary' | 'outlined' | 'text' | 'danger' | 'danger-text' | 'success';
/** `touch` is a 3rem (48px) target, above the 44px minimum, for kiosk and touch screens. */
type NeatButtonSize = 'small' | 'medium' | 'large' | 'touch';
/**
 * A button or link styled as a kit button. Content is the label and/or a `neat-icon`; an
 * icon-only button needs an `aria-label` (and usually a `neatTooltip` with the same text).
 *
 * Built from Spartan's brain primitive and helm's class map rather than on helm's directive:
 * every host directive of a public directive becomes public API, and helm stays internal.
 * The classes go through Angular's `[class]` binding, not helm's `classes()`, which rewrites
 * `className` and can drop a `[class.x]` binding that changes in the same render.
 *
 * A toggle button binds `pressed`: it sets `aria-pressed` and the pressed look. Leave it undefined
 * on a button that is not a toggle, since `aria-pressed="false"` would announce one.
 *
 * `[attr.aria-disabled]="true"` dims the button with a not-allowed cursor while it stays focusable
 * and its tooltip still opens on hover, for a button that waits and must not drop the focus. The
 * kit only styles it: a click, Enter and Space all still fire `click`, so the handler ignores
 * presses while it waits.
 *
 * @input disabled Turns the button off: dimmed, out of the Tab order and not clickable (a link
 * gets no `disabled` attribute but the same look and `tabindex="-1"`). It loses the focus; use
 * `aria-disabled` for a button that waits.
 */
export declare class NeatButton {
  /** The look of the button, by the kind of action it starts; `primary` is the main one. */
  readonly variant: import("@angular/core").InputSignal<NeatButtonVariant>;
  /** The button's height: `small`, `medium`, `large` or `touch` (3rem), for touch screens. */
  readonly size: import("@angular/core").InputSignal<NeatButtonSize>;
  /** Square (or, with `rounded`, circular) and sized for a single icon. */
  readonly iconOnly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Fully rounded ends: a pill, or a circle when `iconOnly`. */
  readonly rounded: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * A toggle's state: `aria-pressed` and the pressed look. Undefined for a button that is not a
   * toggle. Only for `button[neatButton]`: `aria-pressed` is not valid on a link. The primary,
   * success and danger variants are solid fills already, so their pressed look is the least
   * distinct (primary 2.78:1 against its resting fill in dark; success 2.86:1 in light and 2.0:1
   * in dark; danger 2.87:1 in light and 2.48:1 in dark); put toggles on the other variants.
   */
  readonly pressed: import("@angular/core").InputSignal<boolean | undefined>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatButton, "button[neatButton], a[neatButton]", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "iconOnly": {
      "alias": "iconOnly";
      "required": false;
      "isSignal": true;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
      "isSignal": true;
    };
    "pressed": {
      "alias": "pressed";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$1.BrnButton;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
/**
 * A text action set into a line of text, such as "Use global" at the end of a list line: medium
 * weight and underlined on hover, as tall as its text, in the font size and colour of its parent.
 * Its label does not wrap, so keep it to a few words. Use `neatButton` for actions that stand on
 * their own; this one is for dense lines where a `neatButton`'s 2rem height would set the line
 * height. Keep lines at least 1.5rem high (`min-block-size`) when several sit in a column, so the
 * targets stay apart (WCAG 2.5.8).
 *
 * @input disabled Turns the action off: dimmed, out of the Tab order and not clickable (a link
 * gets no `disabled` attribute but the same look and `tabindex="-1"`).
 */
export declare class NeatInlineButton {
  protected readonly classes: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatInlineButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatInlineButton, "button[neatInlineButton], a[neatInlineButton]", never, {}, {}, never, never, true, [{
    directive: typeof i1$1.BrnButton;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
/** A place on the way to where the user is: its name and, for the last, an optional detail. */
interface NeatBreadcrumb {
  readonly label: string;
  /** Muted after the label; shown on the last crumb only, the place the user is at. */
  readonly detail?: string;
}
/**
 * Where the user is and the way back, as the kit's one breadcrumb (the file browser's folders, the
 * diagram's levels):
 *
 * ```html
 * <neat-breadcrumbs label="Current folder" [crumbs]="crumbs()" (go)="open($event)" />
 * ```
 *
 * A `nav` named by `label` around an ordered list. Each crumb but the last is an inline button
 * that emits its index on `go`; the last is plain text marked as the location
 * (`aria-current="location"`), with its detail muted after it. A decorative "›" sits between
 * crumbs. A long path wraps onto further lines rather than scrolling. A pressed crumb is usually
 * gone once the app goes there (it becomes the last), so the app moves the focus where the user's
 * next step is.
 */
export declare class NeatBreadcrumbs {
  /** The landmark's accessible name ("Current folder", "Levels"). */
  readonly label: import("@angular/core").InputSignal<string>;
  /** From the first place to the one the user is at. */
  readonly crumbs: import("@angular/core").InputSignal<readonly NeatBreadcrumb[]>;
  /** The index of the crumb pressed. */
  readonly go: import("@angular/core").OutputEmitterRef<number>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatBreadcrumbs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatBreadcrumbs, "neat-breadcrumbs", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "crumbs": {
      "alias": "crumbs";
      "required": true;
      "isSignal": true;
    };
  }, {
    "go": "go";
  }, never, never, true, never>;
}
/**
 * A small red dot that says something is live or recording, as `<neat-live-dot pulse />` before
 * the words "Recording 0:34". Hidden from assistive technology: the text beside it carries the
 * meaning, so give it text. With `pulse` the dot beats and a ring grows out of it and fades, once
 * in 1.6 s; without it, or under a reduced-motion setting, it is a still dot. The ring is drawn
 * outside the dot's 0.625rem box and does not move the layout, but an ancestor that clips its
 * overflow clips the ring too. The colour is the theme's `--neat-live`, a red that reads at 3:1 on
 * the page and on the video scrim (over black to mid-grey video), so a badge over video can use it.
 */
export declare class NeatLiveDot {
  /** Beat and send out a ring, for a state that is running now. */
  readonly pulse: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatLiveDot, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatLiveDot, "neat-live-dot", never, {
    "pulse": {
      "alias": "pulse";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The name of the custom property that holds the series at `index` (from 0): `--neat-series-1`
 * to `-8`. The kit's one rule from a series to its token: `seriesToken` wraps it for CSS, and code
 * that resolves colours itself (`neatThemeColors`, the diagram's dots on a canvas) takes the name.
 */
declare function seriesTokenName(index: number): string;
/**
 * The palette colour of the series at `index` (from 0), for CSS. The charts colour their lines and
 * bands by it and the diagram its edges (whose `series` counts from 1, converted in one place
 * there), so a swatch matches what it names.
 */
declare function seriesToken(index: number): string;
/**
 * The colour of a series as a small square, for a label that stands for that series outside the
 * drawing that uses it (a run's chip, a summary row, a chart's or a diagram's legend):
 *
 * ```html
 * <neat-series-swatch [index]="i" /> {{ run.name }}
 * ```
 *
 * `index` is the series' place in the chart's `series`, from 0, and the swatch takes the colour
 * that series is drawn in (`--neat-series-1` to `-8`), so a label and its line match in either
 * theme. A chart folds a ninth series and beyond into "Other" (index 7), so
 * an index past 7 names no colour. A chart's lone series is drawn in its tone's colour instead and
 * needs no swatch.
 *
 * In the primary, not in `charts`, so the diagram's legend shows it without the charts' d3 (and
 * `@sima/neat-ui/charts` still exports it for the apps that import it from there). The time and
 * stacked charts draw their legends' and readouts' swatches with it, and so does
 * `neat-diagram-legend`, so its size, shape and colour are stated here once. It is
 * `aria-hidden`: the text beside it names the series, and a colour alone is not a name.
 */
export declare class NeatSeriesSwatch {
  /** The series' place in the chart's `series`, from 0. */
  readonly index: import("@angular/core").InputSignal<number>;
  protected readonly color: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSeriesSwatch, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSeriesSwatch, "neat-series-swatch", never, {
    "index": {
      "alias": "index";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A short note under a control or a heading: no margin, in the muted text colour and the small
 * text size, as `<p neatNote>Applies to every channel without its own value.</p>`. It sets the look
 * only; the words, and any role, are the app's. A `neatInlineButton` inside takes the note's size
 * and colour, so an action set into the note ("Show", "Use global") reads like the words around it.
 */
export declare class NeatNote {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNote, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatNote, "[neatNote]", never, {}, {}, never, never, true, never>;
}
declare const STALE_CLASSES = "opacity-55 grayscale";
/**
 * Shows that what the host shows is stale (a figure from before a connection dropped, a frame of
 * a stream that stopped): `<span [neatStale]="lost()">12.4 fps</span>`. While true the host is
 * faded and grey; once fresh it is shown as it is. The change is instant, with no transition, so a
 * value that comes back is never shown half-faded as if still in doubt. It is the look only: the
 * app says in words why the value is stale, since grey alone tells no one what happened.
 */
export declare class NeatStale {
  /** Whether what the host shows is stale. */
  readonly neatStale: import("@angular/core").InputSignal<boolean>;
  protected readonly classes: import("@angular/core").Signal<"" | "opacity-55 grayscale">;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatStale, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatStale, "[neatStale]", never, {
    "neatStale": {
      "alias": "neatStale";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * How long ago something was, said in the kit's one relative-time style: "just now" under 10 s,
 * then "12 s ago", "3 min ago", "2 h ago" and "4 d ago", each cut to whole units (a minute is 60
 * whole seconds, an hour 60 minutes). `seconds` is first rounded to a whole second; a time ahead of
 * now (a clock that stepped back) reads as "just now".
 *
 * This is the one place the words and thresholds live, so a page that parses a timestamp and the
 * charts' readout cannot say the same age two ways.
 */
export declare function neatSecondsAgo(seconds: number): string;
/** The kit's named easing curves: a progress `t` from 0 to 1 in, the eased share out. */
type NeatEasingName = 'ease-in-out' | 'ease-out' | 'ease-in' | 'linear';
/**
 * A curve for `neatEased`: a catalog name, or a function from `t` to the eased share (0 at 0, 1 at
 * 1) for the rare motion no name fits. Prefer a name, so every app moves the same way.
 */
type NeatEasing = NeatEasingName | ((t: number) => number);
/** The catalog: cubic curves, so they differ in where they hurry and where they settle. */
export declare const NEAT_EASINGS: Readonly<Record<NeatEasingName, (t: number) => number>>;
/**
 * The clock and the frames an eased value moves by: the browser's in the kit, a spec's that it
 * steps by hand in a test, so easing is checked frame by frame without real time. Internal.
 */
interface FrameClock {
  now(): number;
  request(callback: () => void): number;
  cancel(handle: number): void;
}
/** The browser's clock and frames; the label timeline's smooth mode runs on them too. Internal. */
declare const BROWSER_CLOCK: FrameClock;
/**
 * Read when a value changes, so a setting changed while the page is open applies to the next.
 * Shared with the label timeline's smooth mode. Internal.
 */
declare function reducedMotion(): boolean;
/**
 * A number that eases toward `source`'s latest value over 400 ms (`durationMs`) instead of jumping,
 * so a figure that updates twice a second reads as moving rather than flickering. The curve is
 * `easing`, `'ease-in-out'` unless told otherwise: a catalog name comes first, one motion
 * language across apps, a function only where no name fits; a signal of either may switch the
 * curve while a value is moving, and the next frame follows the new one. A curve that overshoots
 * shows more than the target on the way; the last frame shows the target exactly. The first value,
 * and a value that follows none (null or undefined), appears at once; null and undefined pass
 * through as they are. Under a reduced-motion setting it follows `source` at once. Frames are
 * asked for only while it moves and cancelled when its injector is destroyed. Call in an
 * injection context.
 */
export declare function neatEased(source: Signal<number | null | undefined>, options?: {
  durationMs?: number;
  easing?: NeatEasing | Signal<NeatEasing>;
}): Signal<number | null | undefined>;
/** `neatEased` on the given clock. Internal: specs drive it with a clock of their own. */
declare function easedBy(clock: FrameClock, source: Signal<number | null | undefined>, { durationMs, easing }?: {
  durationMs?: number;
  easing?: NeatEasing | Signal<NeatEasing>;
}): Signal<number | null | undefined>;
/**
 * A figure that eases to each new value (`neatEased`) instead of jumping, as
 * `<neat-eased-number [value]="fps()" [digits]="1" /> fps`: its first value shows at once, and
 * "–" stands in while there is none. Its digits are tabular, so a moving value keeps its width.
 * It is the number only: the unit and the words around it are the app's.
 */
export declare class NeatEasedNumber {
  /** The value to show; null or undefined while there is none. */
  readonly value: import("@angular/core").InputSignal<number | null | undefined>;
  /** Digits after the decimal point. */
  readonly digits: import("@angular/core").InputSignal<number>;
  /** The curve it moves by; a catalog name, or a function where none fits. */
  readonly easing: import("@angular/core").InputSignal<NeatEasing>;
  private readonly shown;
  protected readonly text: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatEasedNumber, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatEasedNumber, "neat-eased-number", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "digits": {
      "alias": "digits";
      "required": false;
      "isSignal": true;
    };
    "easing": {
      "alias": "easing";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A signal kept in localStorage under `key`, for a setting an app remembers per browser (a panel's
 * choices, a view's options). It starts at what is stored, as `parse` accepts it: `parse` gets the
 * stored JSON, of any shape an older version of the app may have written, and answers the value
 * or undefined to refuse it. Nothing stored, text that is not JSON, or a refusal starts it at
 * `initial`. `set` and `update` store the new value as JSON. Storage that is missing, refuses or
 * cannot hold the value never throws: the signal then holds its value for this page load only.
 * Needs no injection context.
 */
export declare function neatStoredSignal<T>(key: string, initial: T, parse: (stored: unknown) => T | undefined): WritableSignal<T>;
/** The side of its host a tooltip opens on. */
type NeatTooltipPosition = 'top' | 'right' | 'bottom' | 'left';
/**
 * The kit's tooltip look, as brain's default options, for every element that hosts brain's
 * tooltip: `NeatTooltip`, and the rail item, which hosts it directly because it names its own
 * tooltip. Internal to the kit. `position` is the side the host prefers when its template does not
 * bind one.
 */
declare function provideNeatTooltipOptions(position?: NeatTooltipPosition): import("@angular/core").ValueProvider;
/**
 * A short text label shown on mouse or pen hover and on keyboard focus, hidden on leave, blur and
 * Escape; the host carries `aria-describedby` while it is shown. It never opens on touch (a tap
 * would trigger the host's action too), so it must not carry anything the host's accessible name
 * does not.
 *
 * `neatTooltip` takes a string only. Its declared type is brain's (`string | TemplateRef | null`)
 * because a host-directive alias keeps the primitive's input type; templates are not supported.
 *
 * Built like helm's tooltip (brain primitive plus helm's classes) rather than on top of it: a host
 * directive cannot re-expose inputs of its own host directives, and every host directive of a
 * public directive becomes public API.
 *
 * @input neatTooltip The text to show, which also names the directive: `neatTooltip="Delete"`. A
 * string only; empty shows nothing.
 * @input neatTooltipPosition The side of the host the tooltip prefers, `top` by default; it goes
 * to another side when it has no room there.
 * @input neatTooltipDisabled Turns the tooltip off, for a host that needs none at the moment. An
 * attribute alone means true.
 */
export declare class NeatTooltip {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTooltip, "[neatTooltip]", never, {}, {}, never, never, true, [{
    directive: typeof i1$2.BrnTooltip;
    inputs: {
      "brnTooltip": "neatTooltip";
      "position": "neatTooltipPosition";
      "tooltipDisabled": "neatTooltipDisabled";
    };
    outputs: {};
  }]>;
}
declare const COLLAPSIBLE_CLASSES: {
  /**
   * The trigger: a full-width text button, its chevron, label and summary on one line. It draws
   * the kit's focus outline at full `--ring` (held to 3:1 by the theme). Hovering it brings the
   * chevron from the muted colour to the text's, the only hover cue a button with no fill has.
   */
  readonly trigger: "group flex w-full min-w-0 cursor-pointer items-center gap-(--neat-space-2) rounded-(--radius) py-1 text-start text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring";
  /**
   * The chevron: turned a quarter while open (`rotate-90`, which the trigger's owner sets), by a
   * transform the kit's transition duration times and that a reduced-motion setting turns into a
   * jump, as the kit's other motion is.
   */
  readonly chevron: "shrink-0 text-muted-foreground transition-transform duration-(--neat-transition-duration) group-hover:text-foreground motion-reduce:transition-none";
  /** The label, which names the section and never gives way to the summary. */
  readonly label: "shrink-0 font-medium";
  /** The summary, shown while closed, muted, and the part that truncates. */
  readonly summary: "min-w-0 truncate text-muted-foreground";
  /**
   * The content. Brain makes it `inert` while closed (no focus, no clicks) but leaves it shown,
   * so the kit hides it: `data-state` is brain's, and the one variant is the content's only
   * display statement (a `div` is a block already), so no class has to lose to it.
   */
  readonly content: "pt-(--neat-space-2) data-closed:hidden";
};
declare const FIELD_LABEL_CLASSES: {
  /** The column that holds the name and, under it, the control. */
  readonly stack: "flex flex-col gap-2";
  /** The name. */
  readonly label: "text-sm font-medium";
};
/**
 * Helm's input classes (`lib/ui/input/src/lib/hlm-input.ts`), copied because helm keeps them
 * inline. input.spec checks that the string still appears in the vendored helm, so a helm update
 * that changes it fails until this is reviewed.
 */
declare const INPUT_HELM_CLASSES = "dark:bg-input/30 border-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 h-9 rounded-md border bg-transparent px-2.5 py-1 text-base shadow-xs transition-[color,box-shadow] file:h-7 file:text-sm file:font-medium focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 md:text-sm file:text-foreground placeholder:text-muted-foreground w-full min-w-0 outline-none file:inline-flex file:border-0 file:bg-transparent disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50";
/**
 * The field at each of the kit's heights: `medium` is helm's `h-9` (2.25rem, the kit's medium
 * button), `small` is `h-8` (2rem, its small one).
 */
declare const INPUT_CLASSES: {
  readonly medium: string;
  readonly small: string;
};
/**
 * The focus rules of a panel opened from a trigger and rendered in CDK's overlay container, at the
 * end of the document: `neat-popover` and the collapsed rail's menu share them, through
 * `ɵOverlayFocus`, so there is one place for them. Internal to the kit; create it in an injection
 * context.
 *
 * The browser's Tab order does not pass from the trigger through such a panel, so the kit carries
 * it across by hand (`carryTabOrder`), and closes the panel when focus lands anywhere outside the
 * trigger and the panel (`watchOutsideFocus`).
 */
declare class OverlayFocus {
  private readonly trigger;
  private readonly close;
  private readonly overlayContainer;
  private readonly interactivity;
  private readonly document;
  /**
   * @param trigger The element the panel opened from, which holds the Tab order's place.
   * @param close Puts the panel away.
   */
  constructor(trigger: () => HTMLElement, close: () => void);
  /**
   * Carries the Tab order across `panel`: Tab from its last tabbable control would leave the
   * document, and Shift+Tab from its first would land on the last control of the page. So both
   * close the panel and move focus where it would go if the panel sat after the trigger: the first
   * tabbable after the trigger, or the trigger itself. With nothing tabbable after the trigger, the
   * browser's own Tab is left to run.
   */
  carryTabOrder(event: KeyboardEvent, panel: HTMLElement): void;
  /**
   * A safety net for every way focus can arrive outside the panel. It listens for where focus
   * lands, not where it left: Tab from the panel's last control can leave the document, and focus
   * then comes back on the page's first element with no `focusout` naming it. A `focusout` with
   * no target (another window took focus) is not a move, so it is deliberately not heard. Returns
   * what stops listening.
   */
  watchOutsideFocus(): () => void;
  /**
   * Whether focus on `node` leaves the panel as it is: the trigger, and CDK's overlay container.
   * The container holds the panel and every other overlay, apart from the panel's own DOM, so an
   * element's ancestry cannot tell an overlay opened from the panel (a `NeatConfirm`) from any
   * other. None takes focus on its own while the panel is open, and another trigger lies outside
   * the container, so the container is the narrowest test that keeps the dialogs a panel's
   * controls open.
   */
  holdsFocus(node: Node): boolean;
  /**
   * Moves focus to the first enabled control under `panel`. CDK's `isTabbable` only reads
   * `tabIndex`, which a disabled button has too, so a disabled control is skipped here and in every
   * walk of this class. With none, the focus stays where it is.
   */
  focusFirstControl(panel: HTMLElement | null): void;
  /**
   * The tabbable elements under `root` in document order, as CDK's focus trap judges them
   * (`InteractivityChecker`): it knows tabindex, disabled and hidden elements, which a selector
   * list would get wrong. The overlay container's subtree is left out when `root` holds it.
   */
  tabbablesIn(root: Node): HTMLElement[];
  /** The first tabbable element after the trigger in the page, outside the overlay container. */
  private tabbableAfterTrigger;
  /** A walker over `root`'s tabbable elements that does not enter `excluded`. */
  private tabbableWalker;
}
/**
 * Helm's popover classes (`lib/ui/popover`), copied because helm keeps them inline. popover.spec
 * checks that the string still appears in the vendored helm, so a helm update that changes it
 * fails until this table is reviewed. Internal to the kit; `neat-popover` re-exports it for that
 * spec.
 */
declare const POPOVER_HELM_CLASSES: {
  /** `hlm-popover-content.ts`: the panel. */
  readonly content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 gap-4 rounded-md p-4 text-sm shadow-md ring-1 duration-100 relative flex w-72 flex-col outline-none";
};
/**
 * The surface of a panel in the CDK overlay, which `neat-popover` and the collapsed rail's menu
 * share: helm's, outlined in `--border`, the theme's colour for card outlines and dividers, where
 * helm draws the text colour at 10%. It sets `--neat-surface` to its fill, `--popover`: what the
 * content sits on, so that a part that covers what scrolls under it (a select list's sticky
 * header) fills with the panel's colour, not the page's. Each panel states its own size, padding
 * and gap after it. Internal to the kit; `ɵPANEL_SURFACE_CLASSES` for the secondary entries.
 */
declare const PANEL_SURFACE_CLASSES: string;
declare class HlmTabs {
  readonly tab: import("@angular/core").InputSignal<string>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabs, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabs, "[hlmTabs],hlm-tabs", ["hlmTabs"], {
    "tab": {
      "alias": "tab";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnTabs;
    inputs: {
      "orientation": "orientation";
      "activationMode": "activationMode";
      "brnTabs": "tab";
    };
    outputs: {
      "tabActivated": "tabActivated";
    };
  }]>;
}
declare class HlmTabsContent {
  readonly contentFor: import("@angular/core").InputSignal<string>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsContent, "[hlmTabsContent]", ["hlmTabsContent"], {
    "contentFor": {
      "alias": "hlmTabsContent";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnTabsContent;
    inputs: {
      "brnTabsContent": "hlmTabsContent";
    };
    outputs: {};
  }]>;
}
declare class HlmTabsContentLazy {
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsContentLazy, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsContentLazy, "ng-template[hlmTabsContentLazy]", ["hlmTabsContentLazy"], {}, {}, never, never, true, [{
    directive: typeof i1.BrnTabsContentLazy;
    inputs: {};
    outputs: {};
  }]>;
}
declare const listVariants: (props?: ({
  variant?: "default" | "line" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
declare class HlmTabsList {
  readonly variant: import("@angular/core").InputSignal<"default" | "line" | null | undefined>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsList, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsList, "[hlmTabsList],hlm-tabs-list", ["hlmTabsList"], {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnTabsList;
    inputs: {};
    outputs: {};
  }]>;
}
declare class HlmTabsPaginatedList extends BrnTabsPaginatedList {
  constructor();
  readonly items: import("@angular/core").Signal<readonly BrnTabsTrigger[]>;
  /** Explicitly annotating type to avoid non-portable inferred type */
  readonly itemsChanges: Observable<ReadonlyArray<BrnPaginatedTabHeaderItem>>;
  readonly tabListContainer: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly tabList: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly tabListInner: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly nextPaginator: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly previousPaginator: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly tabListClass: import("@angular/core").InputSignal<ClassValue>;
  protected readonly _tabListClass: import("@angular/core").Signal<string>;
  readonly paginationButtonClass: import("@angular/core").InputSignal<ClassValue>;
  protected readonly _paginationButtonClass: import("@angular/core").Signal<string>;
  protected _itemSelected(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsPaginatedList, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HlmTabsPaginatedList, "hlm-paginated-tabs-list", ["hlmTabsPaginatedList"], {
    "tabListClass": {
      "alias": "tabListClass";
      "required": false;
      "isSignal": true;
    };
    "paginationButtonClass": {
      "alias": "paginationButtonClass";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["items"], ["*"], true, never>;
}
declare class HlmTabsTrigger {
  readonly triggerFor: import("@angular/core").InputSignal<string>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsTrigger, "[hlmTabsTrigger]", ["hlmTabsTrigger"], {
    "triggerFor": {
      "alias": "hlmTabsTrigger";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnTabsTrigger;
    inputs: {
      "brnTabsTrigger": "hlmTabsTrigger";
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
declare const HlmTabsImports: readonly [typeof HlmTabs, typeof HlmTabsList, typeof HlmTabsTrigger, typeof HlmTabsContent, typeof HlmTabsContentLazy, typeof HlmTabsPaginatedList];
declare function hlm(...inputs: ClassValue[]): string;
/**
 * This function dynamically adds and removes classes for a given element without requiring
 * the a class binding (e.g. `[class]="..."`) which may interfere with other class bindings.
 *
 * 1. This will merge the existing classes on the element with the new classes.
 * 2. It will also remove any classes that were previously added by this function but are no longer present in the new classes.
 * 3. Multiple calls to this function on the same element will be merged efficiently.
 */
declare function classes(computed: () => ClassValue[] | string, options?: ClassesOptions): void;
interface ClassesOptions {
  elementRef?: ElementRef<HTMLElement>;
  injector?: Injector;
}
/**
 * Provides default configuration for Spartan Helm components.
 *
 * This utility configures the Angular CDK overlay to disable the `usePopover`
 * behavior introduced in Angular 21, which causes CDK overlay-based components
 * (sheets, dialogs, tooltips, etc.) to render above `position: fixed` elements
 * like `<hlm-toaster>`.
 *
 * @returns {EnvironmentProviders} Environment providers to be added to the application config.
 *
 * @example
 * ```ts
 * // app.config.ts
 * import { provideSpartanHlm } from '@spartan-ng/helm/utils';
 *
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideSpartanHlm(),
 *     // ... other providers
 *   ],
 * };
 * ```
 */
declare function provideSpartanHlm(): EnvironmentProviders;
export { type ColorScale, type ColorStep, type NeatAsideOpen, type NeatBreadcrumb, type NeatButtonSize, type NeatButtonVariant, type NeatColorScheme, type NeatEasing, type NeatEasingName, type NeatIconGlyph, type NeatIconName, type NeatNavChild, type NeatNavItem, type NeatPageNavGroup, type NeatPageNavLink, type NeatRgb, type NeatTone, type NeatTooltipPosition, type SurfaceScale, BROWSER_CLOCK as ɵBROWSER_CLOCK, COLLAPSIBLE_CLASSES as ɵCOLLAPSIBLE_CLASSES, FIELD_LABEL_CLASSES as ɵFIELD_LABEL_CLASSES, INPUT_CLASSES as ɵINPUT_CLASSES, INPUT_HELM_CLASSES as ɵINPUT_HELM_CLASSES, IN_PAGE_TOOLBAR as ɵIN_PAGE_TOOLBAR, OverlayFocus as ɵOverlayFocus, PANEL_SURFACE_CLASSES as ɵPANEL_SURFACE_CLASSES, POPOVER_HELM_CLASSES as ɵPOPOVER_HELM_CLASSES, STALE_CLASSES as ɵSTALE_CLASSES, hlm as ɵhlm, listVariants as ɵlistVariants, reducedMotion as ɵreducedMotion, seriesToken as ɵseriesToken, seriesTokenName as ɵseriesTokenName };