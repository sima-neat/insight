import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, input } from "@angular/core";
import { ɵhlm } from "@sima/neat-ui";
let nextCardId = 0;
const CARD_HELM_CLASSES = {
	card: "ring-foreground/10 bg-card text-card-foreground gap-(--card-spacing) overflow-hidden rounded-xl py-(--card-spacing) text-sm shadow-xs ring-1 [--card-spacing:--spacing(6)] has-[>img:first-child]:pt-0 data-[size=sm]:[--card-spacing:--spacing(4)] *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl group/card flex flex-col",
	header: "gap-1 rounded-t-xl px-(--card-spacing) [.border-b]:pb-(--card-spacing) group/card-header @container/card-header grid auto-rows-min items-start has-data-[slot=card-action]:grid-cols-[1fr_auto] has-data-[slot=card-description]:grid-rows-[auto_auto]",
	title: "text-base leading-normal font-medium group-data-[size=sm]/card:text-sm",
	description: "text-muted-foreground text-sm",
	action: "col-start-2 row-span-2 row-start-1 self-start justify-self-end",
	content: "px-(--card-spacing)",
	footer: "rounded-b-xl px-(--card-spacing) [.border-t]:pt-(--card-spacing) flex items-center"
};
const CARD_CLASSES = {
	card: ɵhlm(CARD_HELM_CLASSES.card, "min-w-0 border border-border rounded-(--radius) ring-0 shadow-none overflow-visible gap-(--neat-space-2) [--card-spacing:var(--neat-space-4)]"),
	header: ɵhlm(CARD_HELM_CLASSES.header, "@container-normal/card-header rounded-t-none gap-0 gap-x-1 has-data-[slot=card-description]:gap-y-1 min-h-[var(--neat-card-header-min-height,2rem)] [&:not(:has([data-slot=card-title]:not(:empty),[data-slot=card-description],[data-slot=card-action]:not(:empty)))]:hidden"),
	title: ɵhlm(CARD_HELM_CLASSES.title, "text-sm leading-normal"),
	description: ɵhlm(CARD_HELM_CLASSES.description, "text-xs col-start-1"),
	action: ɵhlm(CARD_HELM_CLASSES.action, "flex items-center gap-(--neat-space-2) empty:hidden"),
	content: ɵhlm(CARD_HELM_CLASSES.content, "flex-1 min-h-0 empty:hidden"),
	footer: ɵhlm(CARD_HELM_CLASSES.footer, "rounded-b-none gap-(--neat-space-2) empty:hidden")
};
var NeatCard = class NeatCard {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	headingLevel = input(3, ...ngDevMode ? [{ debugName: "headingLevel" }] : /* istanbul ignore next */ []);
	region = input(false, {
		...ngDevMode ? { debugName: "region" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	subtitle = input("", ...ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []);
	titleId = `neat-card-${++nextCardId}-title`;
	classes = CARD_CLASSES;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCard,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatCard,
		isStandalone: true,
		selector: "neat-card",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headingLevel: {
				classPropertyName: "headingLevel",
				publicName: "headingLevel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			region: {
				classPropertyName: "region",
				publicName: "region",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subtitle: {
				classPropertyName: "subtitle",
				publicName: "subtitle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "card" },
			properties: {
				"class": "classes.card",
				"attr.role": "region() && title() ? \"region\" : null",
				"attr.aria-labelledby": "region() && title() ? titleId : null",
				"attr.title": "null"
			}
		},
		ngImport: i0,
		template: `
    <div data-slot="card-header" [class]="classes.header">
      <!-- Always there: an element marked neatCardTitle fills it with no title text. -->
      <div
        data-slot="card-title"
        [class]="classes.title"
        [id]="titleId"
        [attr.role]="title() ? 'heading' : null"
        [attr.aria-level]="title() ? headingLevel() : null"
      >
        <ng-content select="[neatCardTitle]">{{ title() }}</ng-content>
      </div>
      @if (subtitle()) {
        <p data-slot="card-description" [class]="classes.description">{{ subtitle() }}</p>
      }
      <div data-slot="card-action" [class]="classes.action">
        <ng-content select="[neatCardActions]" />
      </div>
    </div>
    <div data-slot="card-content" [class]="classes.content"><ng-content /></div>
    <div data-slot="card-footer" [class]="classes.footer">
      <ng-content select="[neatCardFooter]" />
    </div>
  `,
		isInline: true,
		styles: [":host{--neat-surface: var(--card)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCard,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-card",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "card",
				"[class]": "classes.card",
				"[attr.role]": "region() && title() ? \"region\" : null",
				"[attr.aria-labelledby]": "region() && title() ? titleId : null",
				"[attr.title]": "null"
			},
			template: `
    <div data-slot="card-header" [class]="classes.header">
      <!-- Always there: an element marked neatCardTitle fills it with no title text. -->
      <div
        data-slot="card-title"
        [class]="classes.title"
        [id]="titleId"
        [attr.role]="title() ? 'heading' : null"
        [attr.aria-level]="title() ? headingLevel() : null"
      >
        <ng-content select="[neatCardTitle]">{{ title() }}</ng-content>
      </div>
      @if (subtitle()) {
        <p data-slot="card-description" [class]="classes.description">{{ subtitle() }}</p>
      }
      <div data-slot="card-action" [class]="classes.action">
        <ng-content select="[neatCardActions]" />
      </div>
    </div>
    <div data-slot="card-content" [class]="classes.content"><ng-content /></div>
    <div data-slot="card-footer" [class]="classes.footer">
      <ng-content select="[neatCardFooter]" />
    </div>
  `,
			styles: [":host{--neat-surface: var(--card)}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		headingLevel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headingLevel",
				required: false
			}]
		}],
		region: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "region",
				required: false
			}]
		}],
		subtitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subtitle",
				required: false
			}]
		}]
	}
});
export { NeatCard };

//# sourceMappingURL=sima-neat-ui-card.mjs.map