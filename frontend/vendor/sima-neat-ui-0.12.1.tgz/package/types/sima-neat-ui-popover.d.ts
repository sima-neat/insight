import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import * as i1 from "@spartan-ng/brain/popover";
import { BrnPopover } from "@spartan-ng/brain/popover";
type NeatPopoverAlign = 'start' | 'center' | 'end';
/**
 * Helm's popover classes (`lib/ui/popover`), copied because helm keeps them inline. popover.spec
 * checks that the string still appears in the vendored helm, so a helm update that changes it
 * fails until this table is reviewed.
 */
declare const POPOVER_HELM_CLASSES: {
  /** `hlm-popover-content.ts`: the panel. */
  readonly content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 gap-4 rounded-md p-4 text-sm shadow-md ring-1 duration-100 relative flex w-72 flex-col outline-none";
};
/** The panel's content: `<ng-template neatPopoverContent>…</ng-template>` inside `neat-popover`. */
export declare class NeatPopoverContent {
  readonly template: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopoverContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPopoverContent, "ng-template[neatPopoverContent]", never, {}, {}, never, never, true, never>;
}
/**
 * The button that opens and closes a `neat-popover`: `<button neatPopoverTrigger>` inside it. It
 * can be a `neatButton` with a tooltip as well. It announces the dialog it opens
 * (`aria-haspopup`, `aria-expanded`) and names the panel in `aria-controls` while it is open.
 *
 * The kit's own rather than brain's trigger: brain's points `aria-controls` at the panel while it
 * is closed too, when no element has that id.
 */
export declare class NeatPopoverTrigger {
  protected readonly popover: NeatPopover;
  readonly element: HTMLButtonElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopoverTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPopoverTrigger, "button[neatPopoverTrigger]", never, {}, {}, never, never, true, never>;
}
/**
 * A button that is a menu item of a `neat-popover`'s panel (the ⋯ menu): `<button neatPopoverItem>`
 * inside the content. The panel is a flex column, which would stretch every button across it; an
 * item hugs its text and lines up at the panel's start. The class is a literal so that Tailwind
 * finds it.
 */
export declare class NeatPopoverItem {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopoverItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPopoverItem, "button[neatPopoverItem]", never, {}, {}, never, never, true, never>;
}
/**
 * A panel of controls that opens below a button and stays open while they are used:
 *
 * ```html
 * <neat-popover label="View options" align="end" [(open)]="viewOptionsOpen">
 *   <button neatButton neatPopoverTrigger iconOnly aria-label="View options">…</button>
 *   <ng-template neatPopoverContent>…</ng-template>
 * </neat-popover>
 * ```
 *
 * The panel is a non-modal dialog named by `label`, on the popover surface. `align` lines it up
 * with the trigger's start, centre or end; it flips above the trigger when there is no room below.
 * The content template is created on opening and destroyed on closing, so keep its state (a typed
 * value, a checked switch) in the page. On opening, focus moves to the panel's first focusable
 * element. Escape, a click outside, the trigger, or `open` set to false close it; focus then goes
 * back to the trigger, unless the closing click put it somewhere else. Setting `open` to true
 * opens it as the trigger does, which is how a keyboard shortcut opens it.
 *
 * The panel is rendered at the end of the document, so the browser's Tab order does not pass
 * through it from the trigger. The kit carries it across by hand: Tab from the panel's last
 * control closes it and focuses the first tabbable element after the trigger, and Shift+Tab from
 * its first control closes it and focuses the trigger. Focus arriving anywhere else outside the
 * trigger and the panel (a click on another control, Tab from the trigger, a second popover
 * opening) closes it too, and focus stays where it went. Focus arriving in an overlay opened from
 * the panel, such as a `NeatConfirm`, does not close it.
 *
 * In the page toolbar, an open popover keeps the kiosk bar shown (`KioskService.holdToolbar`):
 * the panel lies outside the bar, so a pointer resting on it would otherwise fade the bar out.
 *
 * Brain's popover is the host directive: it places the panel, closes it on Escape and outside
 * clicks and moves focus in and out. The kit renders the dialog element itself, so that it can
 * name it, and gives the overlay pane around it no role.
 */
export declare class NeatPopover {
  /** Whether the panel is open; it follows the trigger, Escape and outside clicks. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  /** The panel's accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly panelId: string;
  protected readonly panelClasses: string;
  protected readonly brain: BrnPopover;
  protected readonly content: import("@angular/core").Signal<NeatPopoverContent>;
  private readonly trigger;
  private readonly overlayContainer;
  private readonly interactivity;
  private readonly document;
  constructor();
  /** Opens or closes the panel, as the trigger does. */
  toggle(): void;
  /**
   * Carries the Tab order across the panel, which the browser cannot: the panel is rendered in
   * CDK's overlay container at the end of the document, not next to the trigger. Tab from the
   * panel's last tabbable control would leave the document, and Shift+Tab from its first would
   * land on the last control of the page. So both close the panel and move focus where it would
   * go if the panel sat after the trigger: the first tabbable after the trigger, or the trigger
   * itself. With nothing tabbable after the trigger, the browser's own Tab is left to run.
   */
  protected carryTabOrder(event: KeyboardEvent): void;
  /**
   * Whether focus on `node` leaves the popover as it is: the trigger, and CDK's overlay container.
   * The container holds the panel and every other overlay, apart from the panel's own DOM, so an
   * element's ancestry cannot tell an overlay opened from the panel (a `NeatConfirm`) from any
   * other. None takes focus on its own while the panel is open, and another popover's trigger lies
   * outside the container, so the container is the narrowest test that keeps the dialogs a panel's
   * controls open.
   */
  private holdsFocus;
  /**
   * The tabbable elements under `root` in document order, as CDK's focus trap judges them
   * (`InteractivityChecker`): it knows tabindex, disabled and hidden elements, which a selector
   * list would get wrong. The overlay container's subtree is left out when `root` holds it.
   */
  private tabbablesIn;
  /** The first tabbable element after the trigger in the page, outside the overlay container. */
  private tabbableAfterTrigger;
  /** A walker over `root`'s tabbable elements that does not enter `excluded`. */
  private tabbableWalker;
  private show;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopover, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPopover, "neat-popover", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, ["content", "trigger"], ["*"], true, [{
    directive: typeof i1.BrnPopover;
    inputs: {
      "align": "align";
    };
    outputs: {};
  }]>;
}
export type { NeatPopoverAlign };