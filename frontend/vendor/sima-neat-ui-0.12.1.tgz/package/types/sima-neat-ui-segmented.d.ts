import { NeatIconName } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/** One choice of a `neat-segmented`: its value, its label and an optional icon before the label. */
interface NeatSegmentedOption<T> {
  readonly value: T;
  readonly label: string;
  readonly icon?: NeatIconName;
}
/**
 * Helm's toggle-group classes (`lib/ui/toggle-group`), copied because helm keeps them inline; the
 * segment's variant classes come from helm's exported `toggleVariants`. segmented.spec checks
 * that each copied string still appears in the vendored helm, so a helm update that changes one
 * fails until this table is reviewed.
 */
declare const SEGMENTED_HELM_CLASSES: {
  /** `hlm-toggle-group.ts` */
  readonly group: "rounded-md data-[spacing=0]:data-[variant=outline]:shadow-xs group/toggle-group flex w-fit flex-row items-center gap-[--spacing(var(--gap))] data-vertical:flex-col data-vertical:items-stretch";
  /** `hlm-toggle-group-item.ts` */
  readonly item: "data-[state=on]:bg-muted group-data-[spacing=0]/toggle-group:rounded-none group-data-[spacing=0]/toggle-group:px-2 group-data-[spacing=0]/toggle-group:shadow-none group-data-horizontal/toggle-group:data-[spacing=0]:first:rounded-s-md group-data-vertical/toggle-group:data-[spacing=0]:first:rounded-t-md group-data-horizontal/toggle-group:data-[spacing=0]:last:rounded-e-md group-data-vertical/toggle-group:data-[spacing=0]:last:rounded-b-md shrink-0 focus:z-10 focus-visible:z-10 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:border-s-0 group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:border-t-0 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-s group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-t";
};
/**
 * A row of mutually exclusive choices, such as a tile shape: `<neat-segmented label="Tile shape"
 * [options]="shapes" [(value)]="shape" />`. It is a radio group named by `label`: one tab stop
 * (the checked option, else the first), arrow keys move the choice and wrap, Home and End jump to
 * the ends, and a click on the checked option keeps it checked.
 *
 * Built on helm's toggle-group look but not on brain's toggle group: brain makes its items pressed
 * toggle buttons (`aria-pressed`, rewritten on every change) with no arrow keys, while a choice of
 * one is a radio group. The roles, the roving tab stop, the keys and `data-state` are the kit's.
 */
export declare class NeatSegmented<T> {
  readonly value: import("@angular/core").ModelSignal<T>;
  readonly options: import("@angular/core").InputSignal<readonly NeatSegmentedOption<T>[]>;
  /** The group's accessible name; each option is named by its own label. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly groupClasses: string;
  protected readonly itemClasses: string;
  /** The option keyboard focus enters on: the checked one, else the first. */
  protected readonly tabStop: import("@angular/core").Signal<number>;
  private readonly segments;
  /** Focuses the control's tab stop, the checked option (else the first): where Tab enters it. */
  focus(): void;
  /** Moves the choice from the segment at `current` (the one with focus) as the key says. */
  protected move(event: KeyboardEvent, current: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSegmented<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSegmented<any>, "neat-segmented", never, {
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
export type { NeatSegmentedOption };