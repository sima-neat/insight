import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, model, viewChildren } from "@angular/core";
import { NeatIcon, ɵhlm, ɵtoggleVariants } from "@sima/neat-ui";
const SEGMENTED_HELM_CLASSES = {
	group: "rounded-md data-[spacing=0]:data-[variant=outline]:shadow-xs group/toggle-group flex w-fit flex-row items-center gap-[--spacing(var(--gap))] data-vertical:flex-col data-vertical:items-stretch",
	item: "data-[state=on]:bg-muted group-data-[spacing=0]/toggle-group:rounded-none group-data-[spacing=0]/toggle-group:px-2 group-data-[spacing=0]/toggle-group:shadow-none group-data-horizontal/toggle-group:data-[spacing=0]:first:rounded-s-md group-data-vertical/toggle-group:data-[spacing=0]:first:rounded-t-md group-data-horizontal/toggle-group:data-[spacing=0]:last:rounded-e-md group-data-vertical/toggle-group:data-[spacing=0]:last:rounded-b-md shrink-0 focus:z-10 focus-visible:z-10 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:border-s-0 group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:border-t-0 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-s group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-t"
};
const ITEM_CLASSES = ɵhlm(SEGMENTED_HELM_CLASSES.item, ɵtoggleVariants({
	variant: "outline",
	size: "default"
}), "hover:bg-accent focus-visible:ring-ring", "data-[state=on]:bg-primary data-[state=on]:text-primary-foreground", "data-[state=on]:hover:bg-primary-hover data-[state=on]:hover:text-primary-foreground");
const MOVES = {
	ArrowRight: (index, count) => (index + 1) % count,
	ArrowDown: (index, count) => (index + 1) % count,
	ArrowLeft: (index, count) => (index - 1 + count) % count,
	ArrowUp: (index, count) => (index - 1 + count) % count,
	Home: () => 0,
	End: (_, count) => count - 1
};
var NeatSegmented = class NeatSegmented {
	value = model.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	groupClasses = SEGMENTED_HELM_CLASSES.group;
	itemClasses = ITEM_CLASSES;
	tabStop = computed(() => Math.max(0, this.options().findIndex((option) => option.value === this.value())), ...ngDevMode ? [{ debugName: "tabStop" }] : /* istanbul ignore next */ []);
	segments = viewChildren("segment", ...ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []);
	focus() {
		this.segments()[this.tabStop()]?.nativeElement.focus();
	}
	move(event, current) {
		const next = MOVES[event.key];
		if (!next || this.disabled()) return;
		event.preventDefault();
		const options = this.options();
		const index = next(current, options.length);
		this.value.set(options[index].value);
		this.segments()[index]?.nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSegmented,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSegmented,
		isStandalone: true,
		selector: "neat-segmented",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { classAttribute: "inline-flex" },
		viewQueries: [{
			propertyName: "segments",
			predicate: ["segment"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      role="radiogroup"
      [attr.aria-label]="label()"
      [attr.aria-disabled]="disabled() || null"
      data-variant="outline"
      data-spacing="0"
      data-orientation="horizontal"
      [class]="groupClasses"
    >
      @for (option of options(); track option.value; let index = $index) {
        <button
          #segment
          type="button"
          role="radio"
          [attr.aria-checked]="option.value === value()"
          [attr.data-state]="option.value === value() ? 'on' : 'off'"
          [tabIndex]="index === tabStop() ? 0 : -1"
          [disabled]="disabled()"
          data-variant="outline"
          data-size="default"
          data-spacing="0"
          [class]="itemClasses"
          (click)="value.set(option.value)"
          (keydown)="move($event, index)"
        >
          @if (option.icon) {
            <neat-icon [name]="option.icon" [size]="16" />
          }
          {{ option.label }}
        </button>
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSegmented,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-segmented",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "inline-flex" },
			template: `
    <div
      role="radiogroup"
      [attr.aria-label]="label()"
      [attr.aria-disabled]="disabled() || null"
      data-variant="outline"
      data-spacing="0"
      data-orientation="horizontal"
      [class]="groupClasses"
    >
      @for (option of options(); track option.value; let index = $index) {
        <button
          #segment
          type="button"
          role="radio"
          [attr.aria-checked]="option.value === value()"
          [attr.data-state]="option.value === value() ? 'on' : 'off'"
          [tabIndex]="index === tabStop() ? 0 : -1"
          [disabled]="disabled()"
          data-variant="outline"
          data-size="default"
          data-spacing="0"
          [class]="itemClasses"
          (click)="value.set(option.value)"
          (keydown)="move($event, index)"
        >
          @if (option.icon) {
            <neat-icon [name]="option.icon" [size]="16" />
          }
          {{ option.label }}
        </button>
      }
    </div>
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		segments: [{
			type: i0.ViewChildren,
			args: ["segment", { isSignal: true }]
		}]
	}
});
export { NeatSegmented };

//# sourceMappingURL=sima-neat-ui-segmented.mjs.map