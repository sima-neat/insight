import { NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, TemplateRef, afterRenderEffect, booleanAttribute, computed, contentChildren, inject, input, isDevMode, model, output, signal, viewChild } from "@angular/core";
import { NeatIcon } from "@sima/neat-ui";
const HOST_CLASSES = "relative flex h-full min-h-0 flex-col after:pointer-events-none after:absolute after:inset-0 has-[[role=listbox]:focus-visible]:after:outline-2 has-[[role=listbox]:focus-visible]:after:-outline-offset-2 has-[[role=listbox]:focus-visible]:after:outline-ring";
const SCROLLER_CLASSES = "relative isolate min-h-0 flex-1 overflow-x-hidden overflow-y-auto";
const GRID_CLASSES = "grid grid-cols-(--neat-select-list-columns) gap-x-(--neat-space-3) ps-[calc(var(--neat-space-3)+2px)] pe-(--neat-space-3)";
const LISTBOX_CLASSES = "col-span-full grid grid-cols-subgrid outline-none";
const LINE_CLASSES = "col-span-full grid grid-cols-subgrid items-center -ms-[calc(var(--neat-space-3)+2px)] -me-(--neat-space-3) border-s-2 px-(--neat-space-3)";
const ROW_CLASSES = `${LINE_CLASSES} min-h-9 cursor-default border-transparent py-1 text-sm data-active:border-primary`;
const HEADER_CLASSES = `${LINE_CLASSES} sticky top-0 z-1 h-7 border-b border-s-transparent border-b-border bg-(--neat-surface) text-xs font-medium text-muted-foreground`;
const GROUP_CLASSES = "col-span-full grid grid-cols-subgrid";
const GROUP_SEPARATOR_CLASSES = "col-span-full -ms-[calc(var(--neat-space-3)+2px)] -me-(--neat-space-3) h-(--neat-space-2) border-y border-border";
const GROUP_HEADING_BASE = "col-span-full -ms-[calc(var(--neat-space-3)+2px)] -me-(--neat-space-3) bg-muted py-1.5 ps-[calc(var(--neat-space-3)+2px)] pe-(--neat-space-3) text-xs font-medium uppercase";
const GROUP_HEADING_CLASSES = {
	plain: `${GROUP_HEADING_BASE} text-foreground`,
	muted: `${GROUP_HEADING_BASE} text-muted-foreground`
};
const HEADER_LABEL_CLASSES = {
	start: "min-w-0 truncate",
	end: "min-w-0 truncate text-end"
};
const CELL_CLASSES = {
	start: "min-w-0",
	end: "min-w-0 text-end"
};
const ROW_FILL_CLASSES = {
	neutral: "hover:bg-accent data-active:bg-accent",
	success: "bg-neat-tint-success hover:bg-neat-tint-success-accent data-active:bg-neat-tint-success-accent",
	warning: "bg-neat-tint-warning hover:bg-neat-tint-warning-accent data-active:bg-neat-tint-warning-accent",
	danger: "bg-neat-tint-danger hover:bg-neat-tint-danger-accent data-active:bg-neat-tint-danger-accent",
	info: "bg-neat-tint-info hover:bg-neat-tint-info-accent data-active:bg-neat-tint-info-accent",
	highlight: "bg-neat-tint-highlight hover:bg-neat-tint-highlight-accent data-active:bg-neat-tint-highlight-accent"
};
const CHECK_CLASSES = "flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-sm border border-input data-checked:border-primary data-checked:bg-primary";
const CHECK_TRACK = "1rem";
const MOVES = {
	ArrowDown: (index, count) => Math.min(index + 1, count - 1),
	ArrowUp: (index, count) => index < 0 ? count - 1 : Math.max(index - 1, 0),
	Home: () => 0,
	End: (_, count) => count - 1
};
const INTERACTIVE = "button, a[href], input, select, textarea, summary, [role=\"button\"], [contenteditable], [tabindex]";
const NONE = Symbol("none");
var NeatColumn = class NeatColumn {
	key = input.required({
		...ngDevMode ? { debugName: "key" } : /* istanbul ignore next */ {},
		alias: "neatColumn"
	});
	header = input("", ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	width = input("1fr", ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	align = input("start", ...ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []);
	hideBelow = input(...ngDevMode ? [void 0, { debugName: "hideBelow" }] : /* istanbul ignore next */ []);
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatColumn,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatColumn,
		isStandalone: true,
		selector: "ng-template[neatColumn]",
		inputs: {
			key: {
				classPropertyName: "key",
				publicName: "neatColumn",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			align: {
				classPropertyName: "align",
				publicName: "align",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideBelow: {
				classPropertyName: "hideBelow",
				publicName: "hideBelow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatColumn,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatColumn]" }]
	}],
	propDecorators: {
		key: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "neatColumn",
				required: true
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		align: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "align",
				required: false
			}]
		}],
		hideBelow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideBelow",
				required: false
			}]
		}]
	}
});
const sameColumns = (a, b) => a.length === b.length && a.every((column, index) => column === b[index]);
let nextListId = 0;
var NeatSelectList = class NeatSelectList {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	items = input.required(...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	trackBy = input.required(...ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []);
	selected = model(null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	checkable = input(false, {
		...ngDevMode ? { debugName: "checkable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	checked = model([], ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	canCheck = input(() => true, ...ngDevMode ? [{ debugName: "canCheck" }] : /* istanbul ignore next */ []);
	rowTone = input(() => "neutral", ...ngDevMode ? [{ debugName: "rowTone" }] : /* istanbul ignore next */ []);
	groups = input(null, ...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	groupOf = input(() => "", ...ngDevMode ? [{ debugName: "groupOf" }] : /* istanbul ignore next */ []);
	emptyLabel = input("", ...ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []);
	hint = input("", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	activated = output();
	scrollerClasses = SCROLLER_CLASSES;
	gridClasses = GRID_CLASSES;
	listboxClasses = LISTBOX_CLASSES;
	headerClasses = HEADER_CLASSES;
	headerLabelClasses = HEADER_LABEL_CLASSES;
	cellClasses = CELL_CLASSES;
	groupClasses = GROUP_CLASSES;
	separatorClasses = GROUP_SEPARATOR_CLASSES;
	checkClasses = CHECK_CLASSES;
	id = ++nextListId;
	emptyId = `neat-select-list-${this.id}-empty`;
	hintId = `neat-select-list-${this.id}-hint`;
	columns = contentChildren(NeatColumn, {
		...ngDevMode ? { debugName: "columns" } : /* istanbul ignore next */ {},
		descendants: true
	});
	listbox = viewChild.required("listbox", ...ngDevMode ? [{ debugName: "listbox" }] : /* istanbul ignore next */ []);
	scroller = viewChild.required("scroller", ...ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []);
	width = signal(null, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	hidesColumns = computed(() => this.columns().some((column) => column.hideBelow() !== void 0), ...ngDevMode ? [{ debugName: "hidesColumns" }] : /* istanbul ignore next */ []);
	visibleColumns = computed(() => {
		const width = this.width();
		return this.columns().filter((column) => {
			const hideBelow = column.hideBelow();
			return hideBelow === void 0 || width === null || width >= hideBelow;
		});
	}, {
		...ngDevMode ? { debugName: "visibleColumns" } : /* istanbul ignore next */ {},
		equal: sameColumns
	});
	hasHeader = computed(() => this.visibleColumns().some((column) => column.header()), ...ngDevMode ? [{ debugName: "hasHeader" }] : /* istanbul ignore next */ []);
	gridColumns = computed(() => [...this.checkable() ? [CHECK_TRACK] : [], ...this.visibleColumns().map((column) => column.width())].join(" "), ...ngDevMode ? [{ debugName: "gridColumns" }] : /* istanbul ignore next */ []);
	layout = computed(() => {
		const keyOf = this.trackBy();
		const canCheck = this.checkable() ? this.canCheck() : () => false;
		const toneOf = this.rowTone();
		const rows = [];
		const section = (key, group, items, position, separated = false) => {
			const headingId = `neat-select-list-${this.id}-group-${position}`;
			const start = rows.length;
			for (const item of items) {
				const index = rows.length;
				rows.push({
					item,
					key: keyOf(item),
					index,
					heading: group && index === start ? headingId : null,
					checkable: canCheck(item),
					classes: `${ROW_CLASSES} ${ROW_FILL_CLASSES[toneOf(item)]}`,
					id: `neat-select-list-${this.id}-${index}`,
					context: { $implicit: item }
				});
			}
			return {
				key,
				group,
				headingId,
				headingClasses: GROUP_HEADING_CLASSES[group?.muted ? "muted" : "plain"],
				separated,
				views: rows.slice(start).map((row) => ({ $implicit: row }))
			};
		};
		const groups = this.groups();
		if (groups === null) return {
			rows,
			sections: [section(null, null, this.items(), 0)],
			trailingHeading: null
		};
		const listed = [];
		const members = /* @__PURE__ */ new Map();
		for (const group of groups) {
			if (members.has(group.key)) {
				if (isDevMode()) throw new Error(`neat-select-list: the group "${group.key}" is listed twice`);
				continue;
			}
			members.set(group.key, []);
			listed.push(group);
		}
		const groupOf = this.groupOf();
		const unlisted = [];
		for (const item of this.items()) {
			const key = groupOf(item);
			const bucket = members.get(key);
			if (bucket) bucket.push(item);
			else if (isDevMode()) throw new Error(`neat-select-list: an item is in the unlisted group "${key}"`);
			else unlisted.push(item);
		}
		const sections = listed.map((group, position) => section(group.key, group, members.get(group.key), position));
		if (unlisted.length) sections.push(section(null, null, unlisted, listed.length, true));
		const last = sections.at(-1);
		return {
			rows,
			sections,
			trailingHeading: last?.group && last.views.length === 0 ? last.headingId : null
		};
	}, ...ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []);
	rows = computed(() => this.layout().rows, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	sections = computed(() => this.layout().sections, ...ngDevMode ? [{ debugName: "sections" }] : /* istanbul ignore next */ []);
	checkedKeys = computed(() => new Set(this.checked()), ...ngDevMode ? [{ debugName: "checkedKeys" }] : /* istanbul ignore next */ []);
	isEmpty = computed(() => this.rows().length === 0 && !!this.emptyLabel(), ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => [this.isEmpty() ? this.emptyId : "", this.hint() ? this.hintId : ""].filter(Boolean).join(" ") || null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	selectedKey = computed(() => {
		const selected = this.selected();
		return selected === null ? NONE : this.trackBy()(selected);
	}, ...ngDevMode ? [{ debugName: "selectedKey" }] : /* istanbul ignore next */ []);
	selectedIndex = computed(() => {
		const key = this.selectedKey();
		return this.rows().findIndex((row) => row.key === key);
	}, ...ngDevMode ? [{ debugName: "selectedIndex" }] : /* istanbul ignore next */ []);
	activeId = computed(() => this.rows()[this.selectedIndex()]?.id ?? null, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	revealed = NONE;
	constructor() {
		afterRenderEffect(() => this.revealSelected());
		this.watchWidthWhileNeeded();
	}
	watchWidthWhileNeeded() {
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		const setWidth = (width) => this.width.set(width > 0 ? width : null);
		let observer;
		afterRenderEffect(() => {
			if (observer || !this.hidesColumns()) return;
			setWidth(host.getBoundingClientRect().width);
			observer = new ResizeObserver((entries) => setWidth(entries[entries.length - 1].contentRect.width));
			observer.observe(host);
		});
		destroyRef.onDestroy(() => observer?.disconnect());
	}
	revealSelected() {
		const index = this.selectedIndex();
		if (index < 0) {
			this.revealed = NONE;
			return;
		}
		const { rows, trailingHeading } = this.layout();
		const row = rows[index];
		if (row.key === this.revealed) return;
		this.revealed = row.key;
		const listbox = this.listbox().nativeElement;
		const reveal = (element) => element?.scrollIntoView?.({ block: "nearest" });
		reveal(listbox.querySelector(`[role="option"][data-index="${index}"]`));
		if (row.heading) reveal(listbox.querySelector(`#${row.heading}`));
		if (trailingHeading && index === rows.length - 1) reveal(listbox.querySelector(`#${trailingHeading}`));
	}
	resetScroll() {
		this.scroller().nativeElement.scrollTop = 0;
		this.revealed = NONE;
		this.revealSelected();
	}
	focus() {
		this.listbox().nativeElement.focus();
	}
	onKeydown(event) {
		if (event.target !== event.currentTarget) return;
		if (event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
		if (event.key === " ") {
			event.preventDefault();
			const row = this.rows()[this.selectedIndex()];
			if (row) this.toggle(row);
			return;
		}
		const rows = this.rows();
		if (rows.length === 0) return;
		if (event.key === "Enter") {
			const row = rows[this.selectedIndex()];
			if (!row) return;
			event.preventDefault();
			this.activated.emit(row.item);
			return;
		}
		const move = MOVES[event.key];
		if (!move) return;
		event.preventDefault();
		this.selected.set(rows[move(this.selectedIndex(), rows.length)].item);
	}
	onClick(event) {
		const target = event.target;
		const option = target.closest("[role=\"option\"]");
		if (!option) return;
		const control = target.closest(INTERACTIVE);
		if (control && control !== option && option.contains(control)) return;
		const row = this.rows()[Number(option.getAttribute("data-index"))];
		if (target.closest("[data-slot=\"select-list-check\"]")) {
			this.toggle(row);
			return;
		}
		this.selected.set(row.item);
		this.activated.emit(row.item);
	}
	toggle(row) {
		if (!row.checkable) return;
		this.checked.update((keys) => keys.includes(row.key) ? keys.filter((key) => key !== row.key) : [...keys, row.key]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSelectList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSelectList,
		isStandalone: true,
		selector: "neat-select-list",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			trackBy: {
				classPropertyName: "trackBy",
				publicName: "trackBy",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checkable: {
				classPropertyName: "checkable",
				publicName: "checkable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checked: {
				classPropertyName: "checked",
				publicName: "checked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canCheck: {
				classPropertyName: "canCheck",
				publicName: "canCheck",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowTone: {
				classPropertyName: "rowTone",
				publicName: "rowTone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			groups: {
				classPropertyName: "groups",
				publicName: "groups",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			groupOf: {
				classPropertyName: "groupOf",
				publicName: "groupOf",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyLabel: {
				classPropertyName: "emptyLabel",
				publicName: "emptyLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selectedChange",
			checked: "checkedChange",
			activated: "activated"
		},
		host: {
			properties: { "style.--neat-select-list-columns": "gridColumns()" },
			classAttribute: "relative flex h-full min-h-0 flex-col after:pointer-events-none after:absolute after:inset-0 has-[[role=listbox]:focus-visible]:after:outline-2 has-[[role=listbox]:focus-visible]:after:-outline-offset-2 has-[[role=listbox]:focus-visible]:after:outline-ring"
		},
		queries: [{
			propertyName: "columns",
			predicate: NeatColumn,
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "listbox",
			first: true,
			predicate: ["listbox"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "scroller",
			first: true,
			predicate: ["scroller"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div #scroller [class]="scrollerClasses" [class.scroll-pt-7]="hasHeader()">
      @if (hint()) {
        <span class="sr-only" [id]="hintId">{{ hint() }}</span>
      }
      <div data-slot="select-list-grid" [class]="gridClasses">
        @if (hasHeader()) {
          <div data-slot="select-list-header" aria-hidden="true" [class]="headerClasses">
            @if (checkable()) {
              <span></span>
            }
            @for (column of visibleColumns(); track column) {
              <span [class]="headerLabelClasses[column.align()]">{{ column.header() }}</span>
            }
          </div>
        }
        <div
          #listbox
          role="listbox"
          tabindex="0"
          [class]="listboxClasses"
          [attr.aria-label]="label()"
          [attr.aria-multiselectable]="checkable() || null"
          [attr.aria-activedescendant]="activeId()"
          [attr.aria-describedby]="describedBy()"
          (keydown)="onKeydown($event)"
          (click)="onClick($event)"
        >
          @for (section of sections(); track section.key) {
            @if (section.group; as group) {
              <div role="group" [attr.aria-labelledby]="section.headingId" [class]="groupClasses">
                <div
                  role="presentation"
                  data-slot="select-list-group-heading"
                  [id]="section.headingId"
                  [class]="section.headingClasses"
                >
                  {{ group.label }}
                </div>
                @for (view of section.views; track view.$implicit.key) {
                  <ng-container [ngTemplateOutlet]="rowTemplate" [ngTemplateOutletContext]="view" />
                }
              </div>
            } @else {
              @if (section.separated) {
                <div
                  data-slot="select-list-group-separator"
                  aria-hidden="true"
                  [class]="separatorClasses"
                ></div>
              }
              @for (view of section.views; track view.$implicit.key) {
                <ng-container [ngTemplateOutlet]="rowTemplate" [ngTemplateOutletContext]="view" />
              }
            }
          }
        </div>
        @if (isEmpty()) {
          <p
            data-slot="select-list-empty"
            class="col-span-full py-(--neat-space-2) text-sm text-muted-foreground"
            [id]="emptyId"
          >
            {{ emptyLabel() }}
          </p>
        }
      </div>
    </div>
    <!--
      One row, as a listbox option; written once for rows inside a group and outside one. Its
      context is { $implicit: Row<T, K> }, which Angular cannot check in a local template.
    -->
    <ng-template #rowTemplate let-row>
      <div
        role="option"
        [id]="row.id"
        [attr.data-index]="row.index"
        [class]="row.classes"
        [attr.data-active]="row.key === selectedKey() ? '' : null"
        [attr.aria-selected]="
          checkable()
            ? row.checkable
              ? checkedKeys().has(row.key)
              : null
            : row.key === selectedKey()
        "
      >
        @if (checkable()) {
          <div class="flex">
            @if (row.checkable) {
              <span
                data-slot="select-list-check"
                aria-hidden="true"
                [class]="checkClasses"
                [attr.data-checked]="checkedKeys().has(row.key) ? '' : null"
              >
                @if (checkedKeys().has(row.key)) {
                  <neat-icon name="check" [size]="12" class="text-primary-foreground" />
                }
              </span>
            }
          </div>
        }
        @for (column of visibleColumns(); track column) {
          <div [class]="cellClasses[column.align()]">
            <ng-container
              [ngTemplateOutlet]="column.template"
              [ngTemplateOutletContext]="row.context"
            />
          </div>
        }
      </div>
    </ng-template>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}, {
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSelectList,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-select-list",
			imports: [NeatIcon, NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: HOST_CLASSES,
				"[style.--neat-select-list-columns]": "gridColumns()"
			},
			template: `
    <div #scroller [class]="scrollerClasses" [class.scroll-pt-7]="hasHeader()">
      @if (hint()) {
        <span class="sr-only" [id]="hintId">{{ hint() }}</span>
      }
      <div data-slot="select-list-grid" [class]="gridClasses">
        @if (hasHeader()) {
          <div data-slot="select-list-header" aria-hidden="true" [class]="headerClasses">
            @if (checkable()) {
              <span></span>
            }
            @for (column of visibleColumns(); track column) {
              <span [class]="headerLabelClasses[column.align()]">{{ column.header() }}</span>
            }
          </div>
        }
        <div
          #listbox
          role="listbox"
          tabindex="0"
          [class]="listboxClasses"
          [attr.aria-label]="label()"
          [attr.aria-multiselectable]="checkable() || null"
          [attr.aria-activedescendant]="activeId()"
          [attr.aria-describedby]="describedBy()"
          (keydown)="onKeydown($event)"
          (click)="onClick($event)"
        >
          @for (section of sections(); track section.key) {
            @if (section.group; as group) {
              <div role="group" [attr.aria-labelledby]="section.headingId" [class]="groupClasses">
                <div
                  role="presentation"
                  data-slot="select-list-group-heading"
                  [id]="section.headingId"
                  [class]="section.headingClasses"
                >
                  {{ group.label }}
                </div>
                @for (view of section.views; track view.$implicit.key) {
                  <ng-container [ngTemplateOutlet]="rowTemplate" [ngTemplateOutletContext]="view" />
                }
              </div>
            } @else {
              @if (section.separated) {
                <div
                  data-slot="select-list-group-separator"
                  aria-hidden="true"
                  [class]="separatorClasses"
                ></div>
              }
              @for (view of section.views; track view.$implicit.key) {
                <ng-container [ngTemplateOutlet]="rowTemplate" [ngTemplateOutletContext]="view" />
              }
            }
          }
        </div>
        @if (isEmpty()) {
          <p
            data-slot="select-list-empty"
            class="col-span-full py-(--neat-space-2) text-sm text-muted-foreground"
            [id]="emptyId"
          >
            {{ emptyLabel() }}
          </p>
        }
      </div>
    </div>
    <!--
      One row, as a listbox option; written once for rows inside a group and outside one. Its
      context is { $implicit: Row<T, K> }, which Angular cannot check in a local template.
    -->
    <ng-template #rowTemplate let-row>
      <div
        role="option"
        [id]="row.id"
        [attr.data-index]="row.index"
        [class]="row.classes"
        [attr.data-active]="row.key === selectedKey() ? '' : null"
        [attr.aria-selected]="
          checkable()
            ? row.checkable
              ? checkedKeys().has(row.key)
              : null
            : row.key === selectedKey()
        "
      >
        @if (checkable()) {
          <div class="flex">
            @if (row.checkable) {
              <span
                data-slot="select-list-check"
                aria-hidden="true"
                [class]="checkClasses"
                [attr.data-checked]="checkedKeys().has(row.key) ? '' : null"
              >
                @if (checkedKeys().has(row.key)) {
                  <neat-icon name="check" [size]="12" class="text-primary-foreground" />
                }
              </span>
            }
          </div>
        }
        @for (column of visibleColumns(); track column) {
          <div [class]="cellClasses[column.align()]">
            <ng-container
              [ngTemplateOutlet]="column.template"
              [ngTemplateOutletContext]="row.context"
            />
          </div>
        }
      </div>
    </ng-template>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: true
			}]
		}],
		trackBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trackBy",
				required: true
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		checkable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checkable",
				required: false
			}]
		}],
		checked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checked",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedChange"]
		}],
		canCheck: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canCheck",
				required: false
			}]
		}],
		rowTone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowTone",
				required: false
			}]
		}],
		groups: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groups",
				required: false
			}]
		}],
		groupOf: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groupOf",
				required: false
			}]
		}],
		emptyLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyLabel",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		activated: [{
			type: i0.Output,
			args: ["activated"]
		}],
		columns: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => NeatColumn), {
				descendants: true,
				isSignal: true
			}]
		}],
		listbox: [{
			type: i0.ViewChild,
			args: ["listbox", { isSignal: true }]
		}],
		scroller: [{
			type: i0.ViewChild,
			args: ["scroller", { isSignal: true }]
		}]
	}
});
export { NeatColumn, NeatSelectList };

//# sourceMappingURL=sima-neat-ui-select-list.mjs.map