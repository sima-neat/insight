import { NEAT_DANGER_BASE, NeatButton, SIMA_PALETTE } from "@sima/neat-ui";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, ElementRef, Injectable, Injector, NgZone, Renderer2, afterNextRender, afterRenderEffect, computed, effect, inject, input, linkedSignal, model, output, signal, untracked, viewChild } from "@angular/core";
const LATE_SHARE_ON = .5;
const LATE_SHARE_OFF = .1;
const BUFFER_MARGIN_MS = 50;
const BUFFER_STEP_MS = 50;
const BUFFER_MAX_MS = 4e3;
const SETTLE_MS_PER_RAISED_MS = 10;
const SETTLE_BASE_MS = 1e3;
function nextWarningActive(active, recentLateShare) {
	if (recentLateShare == null) return active;
	if (recentLateShare >= LATE_SHARE_ON) return true;
	if (recentLateShare < LATE_SHARE_OFF) return false;
	return active;
}
function suggestedBufferMs(currentBufferMs, p90LatenessMs) {
	if (p90LatenessMs === null) return null;
	if (!Number.isFinite(currentBufferMs) || !Number.isFinite(p90LatenessMs)) return null;
	const needed = currentBufferMs + p90LatenessMs + BUFFER_MARGIN_MS;
	const suggested = Math.ceil(needed / BUFFER_STEP_MS) * BUFFER_STEP_MS;
	return suggested > BUFFER_MAX_MS ? null : suggested;
}
function bufferSettleMs(previousBufferMs, nextBufferMs) {
	const raisedBy = Math.max(0, nextBufferMs - previousBufferMs);
	if (!Number.isFinite(raisedBy)) return SETTLE_BASE_MS;
	return raisedBy * SETTLE_MS_PER_RAISED_MS + SETTLE_BASE_MS;
}
function globalActionFor(suggested, followedBufferMs) {
	if (suggested === null) return null;
	if (typeof followedBufferMs === "number" && Number.isFinite(followedBufferMs) && followedBufferMs >= suggested) return {
		kind: "follow",
		valueMs: followedBufferMs
	};
	return {
		kind: "raise",
		valueMs: suggested
	};
}
function lateNoticeDetails(snapshot, currentBufferMs, bufferSupported, followedBufferMs) {
	const suggested = bufferSupported ? suggestedBufferMs(currentBufferMs, snapshot.recentLatenessP90Ms) : null;
	let blockedBy = null;
	if (!bufferSupported) blockedBy = "unsupported";
	else if (!Number.isFinite(snapshot.recentLatenessP90Ms)) blockedBy = "unmeasured";
	else if (suggested === null) blockedBy = "maximum";
	return {
		latenessMs: snapshot.recentLatenessMedianMs == null ? null : Math.round(snapshot.recentLatenessMedianMs),
		latePercent: snapshot.recentLateShare == null ? null : Math.round(snapshot.recentLateShare * 100),
		bufferMs: currentBufferMs,
		suggestedBufferMs: suggested,
		blockedBy,
		globalAction: globalActionFor(suggested, followedBufferMs)
	};
}
const OVERLAY_PALETTE = [
	"#2563eb",
	"#dc2626",
	"#16a34a",
	"#ca8a04",
	"#9333ea",
	"#0891b2",
	"#ea580c",
	"#4f46e5",
	"#be123c",
	"#0f766e",
	"#f472b6",
	"#84cc16",
	"#fbbf24",
	"#38bdf8",
	"#92400e",
	"#d946ef",
	"#14532d",
	"#fdba74",
	"#f43f5e",
	"#5eead4",
	"#989900",
	"#ff96d3",
	"#e1a0fe",
	"#b6b4ff",
	"#e2684a",
	"#267d30",
	"#4d7800",
	"#e06285",
	"#78c7fd",
	"#786900",
	"#bc6ece",
	"#10d8d8",
	"#927eec",
	"#2bdda4",
	"#66da85",
	"#ab413e",
	"#5590f3",
	"#8fd465",
	"#1899ec",
	"#b1cc46"
];
const OVERLAY_NEUTRAL_COLOR = "#f8fafc";
const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
function withAlphaHex(hex, alpha) {
	return `${hex}${Math.round(alpha * 255).toString(16).padStart(2, "0")}`;
}
const OVERLAY_ROI_COLORS = {
	inclusion: {
		fill: withAlphaHex(SIMA_PALETTE.green, .1),
		fillActive: withAlphaHex(SIMA_PALETTE.green, .3),
		stroke: SIMA_PALETTE.green
	},
	exclusion: {
		fill: withAlphaHex(NEAT_DANGER_BASE, .1),
		fillActive: withAlphaHex(NEAT_DANGER_BASE, .3),
		stroke: NEAT_DANGER_BASE
	}
};
const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
const NEAT_OVERLAY_DEFAULTS = {
	general: {
		lineWidth: 3,
		showRoi: true,
		applyRoiFiltering: true
	},
	types: {
		"object-detection": {
			visible: true,
			confidenceThreshold: 0,
			objects: []
		},
		segmentation: {
			visible: true,
			confidenceThreshold: 0,
			maskOpacity: .4,
			objects: []
		},
		tracking: {
			visible: true,
			confidenceThreshold: 0,
			history: {
				enabled: true,
				trailLength: 10,
				lostTrackTtlMs: 2e3
			}
		},
		"pose-estimation": {
			visible: true,
			showKeypoints: true,
			showKeypointLabels: false
		},
		classification: { visible: true }
	},
	roi: []
};
const NEAT_MIN_TILE_WIDTH = 64;
const HEIGHT_PER_WIDTH = 9 / 16;
function sanitizeArea(area) {
	const dimension = (value) => Number.isFinite(value) && value > 0 ? value : 0;
	return {
		width: dimension(area.width),
		height: dimension(area.height)
	};
}
function sanitizeGap(gap) {
	return Number.isFinite(gap) && gap > 0 ? gap : 0;
}
function packTiles(area, tileWidth, gap) {
	const { width: areaWidth, height: areaHeight } = sanitizeArea(area);
	const spacing = sanitizeGap(gap);
	const requested = Number.isNaN(tileWidth) ? 64 : Math.max(64, tileWidth);
	const fitting = Math.min(requested, areaWidth, areaHeight / HEIGHT_PER_WIDTH);
	const width = Math.max(1, fitting < requested ? Math.floor(fitting) : requested);
	const height = width * HEIGHT_PER_WIDTH;
	const columns = Math.max(1, Math.floor((areaWidth + spacing) / (width + spacing)));
	const rows = Math.max(1, Math.floor((areaHeight + spacing) / (height + spacing)));
	return {
		columns,
		rows,
		perPage: columns * rows,
		tileWidth: width,
		tileHeight: height
	};
}
function fitAllTileWidth(area, count, gap) {
	const { width: areaWidth, height: areaHeight } = sanitizeArea(area);
	const spacing = sanitizeGap(gap);
	const tiles = Number.isFinite(count) ? Math.max(1, Math.floor(count)) : 1;
	const widestRow = Math.floor((areaWidth + spacing) / (64 + spacing));
	const maxColumns = Math.min(tiles, Math.max(1, widestRow));
	let widest = 64;
	for (let columns = 1; columns <= maxColumns; columns++) {
		const rows = Math.ceil(tiles / columns);
		const byWidth = (areaWidth - (columns - 1) * spacing) / columns;
		const byHeight = (areaHeight - (rows - 1) * spacing) / rows / HEIGHT_PER_WIDTH;
		widest = Math.max(widest, Math.floor(Math.min(byWidth, byHeight)));
	}
	return widest;
}
const FALLBACK_GAP = 8;
function sameArea(a, b) {
	return a.width === b.width && a.height === b.height;
}
function sameLayout(a, b) {
	if (a === null || b === null) return a === b;
	return Object.keys(a).every((field) => a[field] === b[field]);
}
var NeatTileGrid = class NeatTileGrid {
	tileWidth = input.required(...ngDevMode ? [{ debugName: "tileWidth" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	count = input.required(...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	layout = output();
	gridElement = viewChild.required("grid", ...ngDevMode ? [{ debugName: "gridElement" }] : /* istanbul ignore next */ []);
	area = signal(null, {
		...ngDevMode ? { debugName: "area" } : /* istanbul ignore next */ {},
		equal: (a, b) => a === null || b === null ? a === b : sameArea(a, b)
	});
	tokenGap = signal(null, ...ngDevMode ? [{ debugName: "tokenGap" }] : /* istanbul ignore next */ []);
	gapPx = computed(() => {
		const token = this.tokenGap();
		return token === null ? null : this.gap() ?? token;
	}, ...ngDevMode ? [{ debugName: "gapPx" }] : /* istanbul ignore next */ []);
	packed = computed(() => {
		const area = this.area();
		const gap = this.gapPx();
		if (area === null || !(area.width > 0 && area.height > 0) || gap === null) return null;
		return {
			...packTiles(area, this.tileWidth(), gap),
			gap,
			areaWidth: area.width,
			areaHeight: area.height
		};
	}, {
		...ngDevMode ? { debugName: "packed" } : /* istanbul ignore next */ {},
		equal: sameLayout
	});
	view = computed(() => {
		const packed = this.packed();
		if (packed === null) return null;
		return {
			...packed,
			columns: Math.min(packed.columns, Math.max(1, this.count()))
		};
	}, ...ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []);
	constructor() {
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		effect(() => {
			const layout = this.packed();
			if (layout !== null) untracked(() => this.layout.emit(layout));
		});
		afterNextRender(() => {
			const resolved = parseFloat(getComputedStyle(this.gridElement().nativeElement).columnGap);
			this.tokenGap.set(Number.isFinite(resolved) ? resolved : FALLBACK_GAP);
			const observer = new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.area.set({
					width,
					height
				});
			});
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTileGrid,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatTileGrid,
		isStandalone: true,
		selector: "neat-tile-grid",
		inputs: {
			tileWidth: {
				classPropertyName: "tileWidth",
				publicName: "tileWidth",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { layout: "layout" },
		viewQueries: [{
			propertyName: "gridElement",
			first: true,
			predicate: ["grid"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      #grid
      class="grid"
      [attr.data-ready]="view() !== null"
      [style.--grid-columns]="view()?.columns"
      [style.--grid-tile-width.px]="view()?.tileWidth"
      [style.--grid-tile-height.px]="view()?.tileHeight"
      [style.--grid-gap.px]="gapPx()"
    >
      <ng-content />
    </div>
  `,
		isInline: true,
		styles: [":host{display:block;width:100%;height:100%;min-height:0;overflow:hidden}.grid{display:grid;box-sizing:border-box;width:100%;height:100%;justify-content:center;align-content:center;grid-template-columns:repeat(var(--grid-columns, 1),var(--grid-tile-width, auto));grid-auto-rows:var(--grid-tile-height, auto);gap:var(--grid-gap, var(--neat-space-2))}.grid[data-ready=false]{visibility:hidden}.grid[data-ready=true]{visibility:visible}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTileGrid,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tile-grid",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <div
      #grid
      class="grid"
      [attr.data-ready]="view() !== null"
      [style.--grid-columns]="view()?.columns"
      [style.--grid-tile-width.px]="view()?.tileWidth"
      [style.--grid-tile-height.px]="view()?.tileHeight"
      [style.--grid-gap.px]="gapPx()"
    >
      <ng-content />
    </div>
  `,
			styles: [":host{display:block;width:100%;height:100%;min-height:0;overflow:hidden}.grid{display:grid;box-sizing:border-box;width:100%;height:100%;justify-content:center;align-content:center;grid-template-columns:repeat(var(--grid-columns, 1),var(--grid-tile-width, auto));grid-auto-rows:var(--grid-tile-height, auto);gap:var(--grid-gap, var(--neat-space-2))}.grid[data-ready=false]{visibility:hidden}.grid[data-ready=true]{visibility:visible}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		tileWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tileWidth",
				required: true
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: true
			}]
		}],
		layout: [{
			type: i0.Output,
			args: ["layout"]
		}],
		gridElement: [{
			type: i0.ViewChild,
			args: ["grid", { isSignal: true }]
		}]
	}
});
const TYPE_NAMES = {
	inclusion: "Inclusion",
	exclusion: "Exclusion"
};
function neatRoiNames(regions) {
	const counts = {
		inclusion: 0,
		exclusion: 0
	};
	return regions.map((region) => `${TYPE_NAMES[region.type]} ${++counts[region.type]}`);
}
const RELEASE_AFTER_MS = 5e3;
function createColorMap() {
	return {
		holders: /* @__PURE__ */ new Map(),
		insertions: 0
	};
}
var NeatOverlayColors = class NeatOverlayColors {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatOverlayColors,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatOverlayColors,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatOverlayColors,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const classColorsOf = /* @__PURE__ */ new WeakMap();
function identityKey(identity) {
	if (identity === null || identity === void 0) return null;
	const text = String(identity);
	return text === "" ? null : text;
}
function isStale(holder, now) {
	return now - holder.lastSeen > RELEASE_AFTER_MS;
}
function olderThan(a, b) {
	return a.lastSeen < b.lastSeen || a.lastSeen === b.lastSeen && a.order < b.order;
}
function holdersBySlot(map) {
	const bySlot = /* @__PURE__ */ new Map();
	for (const [key, holder] of map.holders) {
		const group = bySlot.get(holder.slot);
		if (group) group.push({
			key,
			holder
		});
		else bySlot.set(holder.slot, [{
			key,
			holder
		}]);
	}
	return bySlot;
}
function pruneStaleSharers(map, now) {
	for (const group of holdersBySlot(map).values()) {
		if (group.length < 2) continue;
		const stale = group.filter(({ holder }) => isStale(holder, now));
		if (stale.length === group.length) {
			stale.sort((a, b) => olderThan(a.holder, b.holder) ? 1 : -1);
			stale.shift();
		}
		for (const { key } of stale) map.holders.delete(key);
	}
}
function separateFromSharers(map, key, holder, now) {
	let live = false;
	for (const [otherKey, other] of map.holders) {
		if (otherKey === key || other.slot !== holder.slot) continue;
		if (isStale(other, now)) map.holders.delete(otherKey);
		else live = true;
	}
	if (live) map.holders.delete(key);
	return live;
}
function freeSlot(map) {
	const used = /* @__PURE__ */ new Set();
	for (const holder of map.holders.values()) used.add(holder.slot);
	for (let slot = 0; slot < OVERLAY_PALETTE.length; slot += 1) if (!used.has(slot)) return slot;
	return -1;
}
function reclaimStaleSlot(map, now) {
	let oldest = null;
	for (const [key, holder] of map.holders) if (isStale(holder, now) && (oldest === null || olderThan(holder, oldest.holder))) oldest = {
		key,
		holder
	};
	if (oldest === null) return -1;
	map.holders.delete(oldest.key);
	return oldest.holder.slot;
}
function sharedSlot(map) {
	let chosen = null;
	for (const [slot, group] of holdersBySlot(map)) {
		const latest = group.reduce((a, b) => olderThan(a.holder, b.holder) ? b : a).holder;
		const candidate = {
			slot,
			lastSeen: latest.lastSeen,
			order: latest.order
		};
		if (chosen === null || olderThan(candidate, chosen)) chosen = candidate;
	}
	return chosen?.slot ?? 0;
}
function createColorAllocator(colors) {
	const classColors = classColorsOf.get(colors) ?? createColorMap();
	classColorsOf.set(colors, classColors);
	const maps = /* @__PURE__ */ new Map();
	function mapFor(channelIndex, namespace) {
		if (namespace === "class") return classColors;
		const key = `${channelIndex}:${namespace}`;
		let map = maps.get(key);
		if (!map) {
			map = createColorMap();
			maps.set(key, map);
		}
		return map;
	}
	return {
		colorFor(channelIndex, namespace, identity, now) {
			const key = identityKey(identity);
			if (key === null) return OVERLAY_NEUTRAL_COLOR;
			const map = mapFor(channelIndex, namespace);
			const existing = map.holders.get(key);
			if (existing && !(isStale(existing, now) && separateFromSharers(map, key, existing, now))) {
				existing.lastSeen = now;
				return OVERLAY_PALETTE[existing.slot];
			}
			let slot = freeSlot(map);
			if (slot < 0) {
				pruneStaleSharers(map, now);
				slot = reclaimStaleSlot(map, now);
			}
			if (slot < 0) slot = sharedSlot(map);
			map.insertions += 1;
			map.holders.set(key, {
				slot,
				lastSeen: now,
				order: map.insertions
			});
			return OVERLAY_PALETTE[slot];
		},
		clear() {
			maps.clear();
		},
		size(channelIndex, namespace) {
			return mapFor(channelIndex, namespace).holders.size;
		}
	};
}
function resolveColor({ allocator, channelIndex, namespace, identity, overrides, now }) {
	const key = identityKey(identity);
	if (overrides) {
		const own = key === null ? void 0 : overrides[key];
		if (typeof own === "string") return own;
		const fallback = overrides["default"];
		if (typeof fallback === "string") return fallback;
	}
	if (key === null) return OVERLAY_NEUTRAL_COLOR;
	return allocator.colorFor(channelIndex, namespace, key, now);
}
function letterbox(videoWidth, videoHeight, boxWidth, boxHeight) {
	if (!videoWidth || !videoHeight) return {
		scaleX: 1,
		scaleY: 1,
		offsetX: 0,
		offsetY: 0
	};
	const videoAspect = videoWidth / videoHeight;
	let drawWidth;
	let drawHeight;
	let offsetX = 0;
	let offsetY = 0;
	if (boxWidth / boxHeight > videoAspect) {
		drawHeight = boxHeight;
		drawWidth = videoAspect * drawHeight;
		offsetX = (boxWidth - drawWidth) / 2;
	} else {
		drawWidth = boxWidth;
		drawHeight = drawWidth / videoAspect;
		offsetY = (boxHeight - drawHeight) / 2;
	}
	return {
		scaleX: drawWidth / videoWidth,
		scaleY: drawHeight / videoHeight,
		offsetX,
		offsetY
	};
}
const MAX_RLE_MASK_PIXELS = 4194304;
const offscreenMaskSurface = {
	createContext() {
		const context = new OffscreenCanvas(1, 1).getContext("2d");
		if (!context) throw new Error("OffscreenCanvas has no 2d context");
		return context;
	},
	wrapPixels: (pixels, width, height) => new ImageData(pixels, width, height)
};
function decodeRleMaskAlpha(pixels, counts, maskWidth, maskHeight) {
	const total = maskWidth * maskHeight;
	let pos = 0;
	let foreground = false;
	for (let i = 0; i < counts.length && pos < total; i += 1) {
		const run = Number(counts[i]);
		const end = run > 0 ? Math.min(pos + run, total) : pos;
		if (foreground) for (; pos < end; pos += 1) pixels[(pos % maskHeight * maskWidth + Math.floor(pos / maskHeight)) * 4 + 3] = 255;
		else pos = end;
		foreground = !foreground;
	}
	return pixels;
}
var RleMaskCanvas = class {
	surface;
	context = null;
	pixels = /* @__PURE__ */ new Uint8ClampedArray(0);
	constructor(surface) {
		this.surface = surface;
	}
	paint(counts, width, height, color) {
		this.context ??= this.surface.createContext();
		const context = this.context;
		if (context.canvas.width !== width) context.canvas.width = width;
		if (context.canvas.height !== height) context.canvas.height = height;
		const length = width * height * 4;
		if (this.pixels.length < length) this.pixels = new Uint8ClampedArray(length);
		else this.pixels.fill(0, 0, length);
		const pixels = this.pixels.subarray(0, length);
		decodeRleMaskAlpha(pixels, counts, width, height);
		context.putImageData(this.surface.wrapPixels(pixels, width, height), 0, 0);
		context.save();
		context.globalCompositeOperation = "source-in";
		context.fillStyle = color;
		context.fillRect(0, 0, width, height);
		context.restore();
		return context.canvas;
	}
};
let pageMaskCanvas = null;
function sharedMaskCanvas() {
	pageMaskCanvas ??= new RleMaskCanvas(offscreenMaskSurface);
	return pageMaskCanvas;
}
function mapRoi(polygons, videoWidth, videoHeight, box) {
	return {
		polygons: polygons.map(({ type, points }) => ({
			type,
			points: points.map((p) => [p.x * videoWidth * box.scaleX + box.offsetX, p.y * videoHeight * box.scaleY + box.offsetY])
		})),
		drawn: false
	};
}
function drawRoiOnce(ctx, roi) {
	if (roi.drawn) return;
	roi.drawn = true;
	for (const { type, points } of roi.polygons) {
		if (points.length < 3) continue;
		ctx.beginPath();
		ctx.moveTo(points[0][0], points[0][1]);
		for (let i = 1; i < points.length; i += 1) ctx.lineTo(points[i][0], points[i][1]);
		ctx.closePath();
		const colors = type === "inclusion" ? OVERLAY_ROI_COLORS.inclusion : OVERLAY_ROI_COLORS.exclusion;
		ctx.fillStyle = colors.fill;
		ctx.strokeStyle = colors.stroke;
		ctx.lineWidth = 2;
		ctx.fill();
		ctx.stroke();
	}
}
function contains(polygon, x, y) {
	const pts = polygon.points;
	if (pts.length < 3) return false;
	let inside = false;
	for (let i = 0, j = pts.length - 1; i < pts.length; j = i, i += 1) {
		const [xi, yi] = pts[i];
		const [xj, yj] = pts[j];
		if (yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi || 1e-6) + xi) inside = !inside;
	}
	return inside;
}
function passesRoiFilter(roi, bbox, box, applyRoiFiltering) {
	if (!applyRoiFiltering) return true;
	const [x, y, w, h] = bbox;
	const cx = (x + w / 2) * box.scaleX + box.offsetX;
	const cy = (y + h / 2) * box.scaleY + box.offsetY;
	const inclusion = roi.polygons.filter((polygon) => polygon.type === "inclusion");
	const exclusion = roi.polygons.filter((polygon) => polygon.type === "exclusion");
	return (inclusion.length === 0 || inclusion.some((polygon) => contains(polygon, cx, cy))) && !exclusion.some((polygon) => contains(polygon, cx, cy));
}
function identityColor(dc, namespace, identity, overrides) {
	return resolveColor({
		allocator: dc.colors,
		channelIndex: dc.channel,
		namespace,
		identity,
		overrides,
		now: dc.now
	});
}
function classStyles(rows) {
	const styles = Object.create(null);
	const overrides = Object.create(null);
	for (const row of rows) {
		styles[row.label] = row;
		overrides[row.label] = row.color;
	}
	return {
		styles,
		overrides
	};
}
function styleFor(styles, label) {
	return styles[String(label)] ?? styles["default"];
}
function applyLineStyle(ctx, style, lineWidth) {
	ctx.lineWidth = style?.width ?? lineWidth;
	ctx.setLineDash(style?.style === "dashed" ? [6, 4] : style?.style === "dotted" ? [2, 2] : []);
}
function drawLabelPlate(dc, text, x, y, color) {
	const { ctx } = dc;
	const paddingX = 4;
	const paddingY = 3;
	const height = 18;
	ctx.font = dc.fonts.label;
	const width = ctx.measureText(text).width + 8;
	const labelY = Math.max(20, y);
	ctx.fillStyle = OVERLAY_LABEL_PLATE_COLOR;
	ctx.fillRect(x, labelY - height, width, height);
	ctx.fillStyle = color;
	ctx.fillText(text, x + paddingX, labelY - paddingY);
}
function percent(confidence) {
	return Math.round(Number(confidence) * 100);
}
const drawClassification = (dc, data) => {
	const classes = data?.top_classes;
	if (!classes || !dc.settings.types.classification.visible) return;
	const { ctx, box } = dc;
	ctx.font = dc.fonts.large;
	classes.slice(0, 3).forEach((entry, i) => {
		ctx.fillStyle = identityColor(dc, "class", entry.label);
		ctx.fillText(`${entry.label} (${percent(entry.confidence)}%)`, 10 * box.scaleX + box.offsetX, (20 + i * 20) * box.scaleY + box.offsetY);
	});
};
const drawObjectDetection = (dc, data) => {
	const objects = data?.objects;
	if (!objects) return;
	const { ctx, box, settings } = dc;
	const type = settings.types["object-detection"];
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) return;
	const { styles, overrides } = classStyles(type.objects);
	for (const object of objects) {
		if (Number(object.confidence) < type.confidenceThreshold) continue;
		const [x, y, w, h] = object.bbox;
		if (!passesRoiFilter(dc.roi, object.bbox, box, settings.general.applyRoiFiltering)) continue;
		const color = identityColor(dc, "class", object.label, overrides);
		ctx.strokeStyle = color;
		applyLineStyle(ctx, styleFor(styles, object.label), settings.general.lineWidth);
		ctx.font = dc.fonts.label;
		ctx.fillStyle = color;
		ctx.strokeRect(x * box.scaleX + box.offsetX, y * box.scaleY + box.offsetY, w * box.scaleX, h * box.scaleY);
		ctx.fillText(`${object.label} (${percent(object.confidence)}%)`, (x + 2) * box.scaleX + box.offsetX, (y - 6) * box.scaleY + box.offsetY);
	}
};
const COCO_SKELETON = [
	["nose", "left_eye"],
	["nose", "right_eye"],
	["left_eye", "left_ear"],
	["right_eye", "right_ear"],
	["nose", "left_shoulder"],
	["nose", "right_shoulder"],
	["left_shoulder", "left_elbow"],
	["left_elbow", "left_wrist"],
	["right_shoulder", "right_elbow"],
	["right_elbow", "right_wrist"],
	["left_shoulder", "left_hip"],
	["right_shoulder", "right_hip"],
	["left_hip", "right_hip"],
	["left_hip", "left_knee"],
	["left_knee", "left_ankle"],
	["right_hip", "right_knee"],
	["right_knee", "right_ankle"]
];
const KEYPOINT_MIN_CONFIDENCE = .3;
const BOX_PADDING = 8;
function confidenceAlpha(confidence) {
	const value = Number.isFinite(Number(confidence)) ? Number(confidence) : 1;
	return .18 + .82 * Math.min(1, Math.max(0, value));
}
function hasId$1(id) {
	return id !== null && id !== void 0 && id !== "";
}
const drawPoseEstimation = (dc, data) => {
	const poses = data?.poses;
	const type = dc.settings.types["pose-estimation"];
	if (!poses || !type.visible) return;
	const { ctx, box } = dc;
	const at = (kp) => [kp.x * box.scaleX + box.offsetX, kp.y * box.scaleY + box.offsetY];
	ctx.lineWidth = dc.settings.general.lineWidth;
	ctx.setLineDash([]);
	ctx.font = dc.fonts.label;
	for (const pose of poses) {
		if (!Array.isArray(pose?.keypoints)) continue;
		const color = identityColor(dc, "pose", pose.id);
		const keypoints = pose.keypoints.filter((kp) => Boolean(kp));
		const byName = new Map(keypoints.map((kp) => [kp.name, kp]));
		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		for (const [a, b] of COCO_SKELETON) {
			const from = byName.get(a);
			const to = byName.get(b);
			if (!from || !to) continue;
			ctx.beginPath();
			ctx.moveTo(...at(from));
			ctx.lineTo(...at(to));
			ctx.globalAlpha = confidenceAlpha(Math.min(Number(from.confidence ?? 1), Number(to.confidence ?? 1)));
			ctx.stroke();
		}
		for (const kp of keypoints) {
			ctx.globalAlpha = confidenceAlpha(kp.confidence);
			if (type.showKeypoints) {
				ctx.beginPath();
				ctx.arc(...at(kp), 3, 0, 2 * Math.PI);
				ctx.fill();
			}
			if (type.showKeypointLabels) ctx.fillText(String(kp.name), (kp.x + 4) * box.scaleX + box.offsetX, (kp.y - 4) * box.scaleY + box.offsetY);
		}
		ctx.globalAlpha = 1;
		const confident = keypoints.filter((kp) => Number(kp.confidence) > KEYPOINT_MIN_CONFIDENCE);
		if (confident.length < 2) continue;
		const xs = confident.map((kp) => kp.x);
		const ys = confident.map((kp) => kp.y);
		const left = Math.min(...xs) - BOX_PADDING;
		const top = Math.min(...ys) - BOX_PADDING;
		const width = Math.max(...xs) - Math.min(...xs) + 16;
		const height = Math.max(...ys) - Math.min(...ys) + 16;
		const boxLeft = left * box.scaleX + box.offsetX;
		const boxTop = top * box.scaleY + box.offsetY;
		ctx.strokeRect(boxLeft, boxTop, width * box.scaleX, height * box.scaleY);
		drawLabelPlate(dc, `${pose.label || "pose"}${hasId$1(pose.id) ? ` #${pose.id}` : ""}`, boxLeft, boxTop - 6, color);
	}
};
function polygonBounds(points) {
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const [px, py] of points) {
		if (px < minX) minX = px;
		if (py < minY) minY = py;
		if (px > maxX) maxX = px;
		if (py > maxY) maxY = py;
	}
	return [
		minX,
		minY,
		maxX - minX,
		maxY - minY
	];
}
function warnDropped(dc, id, reason) {
	const name = String(id ?? "<no id>");
	dc.warnOnce(`segment:${name}`, `segmentation: channel ${dc.channel} dropped RLE segment "${name}": ${reason}`);
}
function drawRleMask(dc, segment, bbox, color, opacity) {
	const mask = segment.mask;
	if (!mask || !Array.isArray(mask.size)) {
		warnDropped(dc, segment.id, "mask.size must be an array [mask_h, mask_w]");
		return false;
	}
	if (!Array.isArray(mask.counts)) {
		warnDropped(dc, segment.id, "mask.counts must be an array of run lengths, not a compressed byte string");
		return false;
	}
	const maskHeight = Math.floor(mask.size[0]);
	const maskWidth = Math.floor(mask.size[1]);
	if (!(maskWidth > 0) || !(maskHeight > 0)) {
		warnDropped(dc, segment.id, `mask.size must be positive, got ${maskHeight}x${maskWidth}`);
		return false;
	}
	if (maskWidth * maskHeight > 4194304) {
		warnDropped(dc, segment.id, `mask is ${maskHeight}x${maskWidth}, over the ${MAX_RLE_MASK_PIXELS} pixel decode buffer limit`);
		return false;
	}
	const image = dc.masks.paint(mask.counts, maskWidth, maskHeight, color);
	const { ctx, box } = dc;
	ctx.save();
	ctx.globalAlpha = opacity;
	ctx.imageSmoothingEnabled = true;
	ctx.drawImage(image, bbox[0] * box.scaleX + box.offsetX, bbox[1] * box.scaleY + box.offsetY, bbox[2] * box.scaleX, bbox[3] * box.scaleY);
	ctx.restore();
	return true;
}
const drawSegmentation = (dc, data) => {
	const segments = data?.segments;
	if (!Array.isArray(segments)) return;
	const { ctx, box, settings } = dc;
	const type = settings.types.segmentation;
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) return;
	const { styles, overrides } = classStyles(type.objects);
	for (const segment of segments) {
		const confidence = segment.confidence ?? 1;
		if (Number(confidence) < type.confidenceThreshold) continue;
		if (segment.mask_format !== "polygon" && segment.mask_format !== "rle") continue;
		let bbox = Array.isArray(segment.bbox) && segment.bbox.length === 4 ? segment.bbox : null;
		let polygon = null;
		if (segment.mask_format === "polygon") {
			if (!Array.isArray(segment.mask) || segment.mask.length < 3) continue;
			polygon = segment.mask;
			bbox ??= polygonBounds(polygon);
		}
		if (!bbox) {
			warnDropped(dc, segment.id, "an RLE mask needs a bbox as its destination rectangle");
			continue;
		}
		if (!passesRoiFilter(dc.roi, bbox, box, settings.general.applyRoiFiltering)) continue;
		const color = identityColor(dc, "class", segment.label, overrides);
		ctx.strokeStyle = color;
		applyLineStyle(ctx, styleFor(styles, segment.label), settings.general.lineWidth);
		ctx.font = dc.fonts.label;
		ctx.fillStyle = color;
		if (polygon) {
			ctx.beginPath();
			ctx.moveTo(polygon[0][0] * box.scaleX + box.offsetX, polygon[0][1] * box.scaleY + box.offsetY);
			for (let i = 1; i < polygon.length; i += 1) ctx.lineTo(polygon[i][0] * box.scaleX + box.offsetX, polygon[i][1] * box.scaleY + box.offsetY);
			ctx.closePath();
			ctx.save();
			ctx.globalAlpha = type.maskOpacity;
			ctx.fill();
			ctx.restore();
			ctx.stroke();
		} else if (!drawRleMask(dc, segment, bbox, color, type.maskOpacity)) continue;
		if (segment.show_rectangle === true) ctx.strokeRect(bbox[0] * box.scaleX + box.offsetX, bbox[1] * box.scaleY + box.offsetY, bbox[2] * box.scaleX, bbox[3] * box.scaleY);
		ctx.fillText(`${segment.label} (${percent(confidence)}%)`, (bbox[0] + 2) * box.scaleX + box.offsetX, (bbox[1] - 6) * box.scaleY + box.offsetY);
	}
};
function hasId(id) {
	return id !== null && id !== void 0 && id !== "";
}
function isIdentified(track) {
	return track.id !== null && track.id !== void 0;
}
function isDrawable(track) {
	const bbox = track?.bbox;
	return Array.isArray(bbox) && bbox.length >= 4 && bbox.slice(0, 4).every(Number.isFinite);
}
function updateTrackHistory(history, tracks, now, settings) {
	if (!settings.enabled) {
		history.clear();
		return;
	}
	const trailLength = Math.max(1, settings.trailLength);
	const current = /* @__PURE__ */ new Set();
	for (const track of tracks) {
		if (!isIdentified(track)) continue;
		const key = String(track.id);
		const [x, y, width, height] = track.bbox;
		current.add(key);
		const trail = history.get(key) ?? {
			points: [],
			lastSeen: now
		};
		trail.points = [...trail.points, {
			x: x + width / 2,
			y: y + height / 2
		}].slice(-trailLength);
		trail.lastSeen = now;
		history.set(key, trail);
	}
	for (const [key, trail] of history) if (!current.has(key) && now - trail.lastSeen > settings.lostTrackTtlMs) history.delete(key);
}
function drawTrail(dc, points, color, alpha) {
	if (points.length < 2) return;
	const { ctx, box } = dc;
	ctx.save();
	ctx.strokeStyle = color;
	ctx.lineWidth = dc.settings.general.lineWidth;
	ctx.globalAlpha = alpha;
	ctx.setLineDash([]);
	ctx.beginPath();
	points.forEach((point, i) => {
		const x = point.x * box.scaleX + box.offsetX;
		const y = point.y * box.scaleY + box.offsetY;
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	});
	ctx.stroke();
	ctx.restore();
}
const drawTracking = (dc, data) => {
	const tracks = data?.tracks;
	if (!Array.isArray(tracks)) return;
	const { ctx, box, settings } = dc;
	const type = settings.types.tracking;
	const visible = tracks.filter((track) => isDrawable(track) && !(Number(track.confidence ?? 1) < type.confidenceThreshold) && passesRoiFilter(dc.roi, track.bbox, box, settings.general.applyRoiFiltering));
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) {
		dc.trackHistory.clear();
		return;
	}
	if (!dc.held) updateTrackHistory(dc.trackHistory, visible, dc.now, type.history);
	const frameColors = /* @__PURE__ */ new Map();
	const trackColor = (id) => {
		if (id === null || id === void 0) return identityColor(dc, "track", id);
		const key = String(id);
		let color = frameColors.get(key);
		if (color === void 0) {
			color = identityColor(dc, "track", id);
			frameColors.set(key, color);
		}
		return color;
	};
	if (type.history.enabled) {
		const active = new Set(visible.filter(isIdentified).map((track) => String(track.id)));
		for (const [key, trail] of dc.trackHistory) drawTrail(dc, trail.points, trackColor(key), active.has(key) ? .72 : .35);
	}
	for (const track of visible) {
		const [x, y, w, h] = track.bbox;
		const color = trackColor(track.id);
		const left = x * box.scaleX + box.offsetX;
		const top = y * box.scaleY + box.offsetY;
		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		ctx.lineWidth = settings.general.lineWidth;
		ctx.setLineDash([]);
		ctx.strokeRect(left, top, w * box.scaleX, h * box.scaleY);
		const idText = hasId(track.id) ? ` #${track.id}` : "";
		const confidence = typeof track.confidence === "number" ? ` (${percent(track.confidence)}%)` : "";
		drawLabelPlate(dc, `${track.label || "track"}${idText}${confidence}`, left, top - 6, color);
	}
};
function stateOf$1(state) {
	return state;
}
const STRATEGIES = /* @__PURE__ */ new Map([
	["object-detection", drawObjectDetection],
	["segmentation", drawSegmentation],
	["tracking", drawTracking],
	["pose-estimation", drawPoseEstimation],
	["classification", drawClassification]
]);
const AUXILIARY_METADATA_TYPE$1 = "auxiliary-visualization";
const WARNING_MEMORY_LIMIT = 64;
const FALLBACK_FONTS = fontsOf("sans-serif");
function fontsOf(family) {
	return {
		label: `14px ${family}`,
		large: `16px ${family}`
	};
}
function createOverlayState(channel, colors) {
	return newOverlayState(channel, colors, sharedMaskCanvas());
}
function newOverlayState(channel, colors, masks) {
	return {
		channel,
		colors: createColorAllocator(colors),
		trackHistory: /* @__PURE__ */ new Map(),
		masks,
		warned: {
			unknown: /* @__PURE__ */ new Set(),
			failed: /* @__PURE__ */ new Set(),
			strategy: /* @__PURE__ */ new Set()
		},
		fonts: null
	};
}
function resetOverlayState(handle) {
	const state = stateOf$1(handle);
	state.trackHistory.clear();
	state.colors.clear();
}
function warnOnce(state, kind, key, message, ...details) {
	const warned = state.warned[kind];
	if (warned.has(key) || warned.size >= WARNING_MEMORY_LIMIT) return;
	warned.add(key);
	console.warn(message, ...details);
}
function fontsFor(state, canvas) {
	if (state.fonts) return state.fonts;
	const family = canvas instanceof HTMLCanvasElement ? getComputedStyle(canvas).getPropertyValue("--font-sans").trim() : "";
	if (!family) return FALLBACK_FONTS;
	state.fonts = fontsOf(family);
	return state.fonts;
}
function drawFrame(ctx, view, items, handle, settings, now) {
	const state = stateOf$1(handle);
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
	ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
	if (items.length === 0) return;
	const box = letterbox(view.videoWidth, view.videoHeight, view.cssWidth, view.cssHeight);
	const frame = {
		ctx,
		channel: state.channel,
		settings,
		box,
		roi: mapRoi(settings.roi, view.videoWidth, view.videoHeight, box),
		colors: state.colors,
		fonts: fontsFor(state, ctx.canvas),
		now,
		trackHistory: state.trackHistory,
		masks: state.masks,
		warnOnce: (key, message) => warnOnce(state, "strategy", key, message)
	};
	for (const { message, held } of items) {
		const { type } = message;
		if (type === AUXILIARY_METADATA_TYPE$1) continue;
		const draw = STRATEGIES.get(type);
		if (!draw) {
			warnOnce(state, "unknown", type, `metadata: channel ${state.channel} has no overlay for type "${type}"`);
			continue;
		}
		ctx.save();
		try {
			draw({
				...frame,
				held
			}, message.data);
		} catch (error) {
			warnOnce(state, "failed", type, `metadata: channel ${state.channel} failed to draw ${type}`, error);
		} finally {
			ctx.restore();
		}
	}
}
function parseMetadataMessage(text) {
	let parsed;
	try {
		parsed = JSON.parse(text);
	} catch {
		return null;
	}
	if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return null;
	if (typeof parsed.type !== "string") return null;
	return parsed;
}
const METADATA_QUEUE_LIMIT = 300;
const LATENESS_WINDOW_MS = 5e3;
const LATENESS_WINDOW_MIN_MESSAGES = 10;
const LATENESS_MEMORY_LIMIT = 1024;
const AUXILIARY_METADATA_TYPE = "auxiliary-visualization";
const AUXILIARY_MAX_ID_LENGTH = 128;
function stateOf(queue) {
	return queue;
}
function metadataTypeOf(message) {
	if (message.type !== AUXILIARY_METADATA_TYPE) return message.type;
	const data = message.data;
	const id = typeof data?.id === "string" ? data.id.trim() : "";
	return id && id.length <= AUXILIARY_MAX_ID_LENGTH ? `${AUXILIARY_METADATA_TYPE}\u0000${id}` : AUXILIARY_METADATA_TYPE;
}
function createMetadataQueue() {
	return {
		timestamped: /* @__PURE__ */ new Map(),
		timestampedEntries: 0,
		arrival: [],
		presented: /* @__PURE__ */ new Map(),
		lastPresented: null,
		lastPresentedAt: 0,
		outcomes: [],
		stats: {
			timestampMatches: 0,
			arrivalFallbacks: 0,
			frameMisses: 0,
			expired: 0,
			evicted: 0,
			untimestampedReceived: 0,
			late: 0
		}
	};
}
function enqueueMetadata(handle, message, receivedAt) {
	const queue = stateOf(handle);
	const key = message._insight?.rtp_timestamp;
	const item = {
		receivedAt,
		data: message
	};
	if (key !== void 0 && Number.isInteger(key) && key >= 0 && key <= 4294967295) {
		if (isLate(queue, key)) {
			const presentedAt = queue.presented.get(key);
			queue.stats.late += 1;
			recordOutcome(queue, {
				at: queue.lastPresentedAt,
				late: true,
				latenessMs: presentedAt === void 0 ? null : Math.max(0, receivedAt - presentedAt)
			});
			return;
		}
		const byType = queue.timestamped.get(key) ?? /* @__PURE__ */ new Map();
		const type = metadataTypeOf(message);
		if (!byType.has(type)) queue.timestampedEntries += 1;
		queue.timestamped.delete(key);
		byType.delete(type);
		byType.set(type, item);
		queue.timestamped.set(key, byType);
		while (queue.timestampedEntries > METADATA_QUEUE_LIMIT) {
			const [oldest, evictedTypes] = queue.timestamped.entries().next().value;
			queue.timestampedEntries -= evictedTypes.size;
			queue.stats.evicted += evictedTypes.size;
			queue.timestamped.delete(oldest);
		}
		return;
	}
	queue.stats.untimestampedReceived += 1;
	queue.arrival.push(item);
	if (queue.arrival.length > METADATA_QUEUE_LIMIT) {
		const evicted = queue.arrival.length - METADATA_QUEUE_LIMIT;
		queue.arrival.splice(0, evicted);
		queue.stats.evicted += evicted;
	}
}
function takeMetadataForFrame(handle, rtpTimestamp, metadataRetentionMs, now) {
	const queue = stateOf(handle);
	pruneMetadataQueue(queue, metadataRetentionMs, now);
	const hasFrameTimestamp = rtpTimestamp !== null && Number.isInteger(rtpTimestamp) && rtpTimestamp >= 0;
	if (hasFrameTimestamp) {
		const key = rtpTimestamp >>> 0;
		recordPresentedFrame(queue, key, now);
		const byType = queue.timestamped.get(key) ?? null;
		if (byType && byType.size > 0) {
			queue.timestamped.delete(key);
			queue.timestampedEntries -= byType.size;
			queue.stats.timestampMatches += 1;
			for (let matched = 0; matched < byType.size; matched += 1) recordOutcome(queue, {
				at: now,
				late: false,
				latenessMs: null
			});
			return [...byType.values()];
		}
	}
	if (!hasFrameTimestamp) {
		let latest = null;
		let latestFrame = null;
		for (const byType of queue.timestamped.values()) for (const item of byType.values()) if (!latest || item.receivedAt >= latest.receivedAt) {
			latest = item;
			latestFrame = byType;
		}
		for (const item of queue.arrival) if (!latest || item.receivedAt >= latest.receivedAt) {
			latest = item;
			latestFrame = null;
		}
		queue.timestamped.clear();
		queue.timestampedEntries = 0;
		queue.arrival.length = 0;
		if (latest) {
			queue.stats.arrivalFallbacks += 1;
			return latestFrame ? [...latestFrame.values()] : [latest];
		}
	}
	if (queue.arrival.length > 0) {
		const latest = queue.arrival[queue.arrival.length - 1];
		queue.arrival.length = 0;
		queue.stats.arrivalFallbacks += 1;
		return [latest];
	}
	queue.stats.frameMisses += 1;
	return [];
}
function holdOverlays(held, overlays, now) {
	const fresh = /* @__PURE__ */ new Set();
	for (const item of overlays) {
		const type = metadataTypeOf(item.data);
		fresh.add(type);
		held.set(type, {
			item,
			matchedAt: now
		});
	}
	const repeats = [];
	for (const [type, { item, matchedAt }] of held) {
		if (fresh.has(type)) continue;
		if (now - matchedAt > 200) held.delete(type);
		else repeats.push({
			...item,
			held: true
		});
	}
	return [...overlays, ...repeats];
}
function metadataQueueSnapshot(handle) {
	const queue = stateOf(handle);
	const lateOutcomes = queue.outcomes.filter((outcome) => outcome.late);
	const lateness = lateOutcomes.map((outcome) => outcome.latenessMs).filter((value) => value !== null).sort((a, b) => a - b);
	return {
		...queue.stats,
		timestampedPending: queue.timestampedEntries,
		arrivalPending: queue.arrival.length,
		recentLateShare: queue.outcomes.length >= LATENESS_WINDOW_MIN_MESSAGES ? lateOutcomes.length / queue.outcomes.length : null,
		recentLatenessMedianMs: nearestRank(lateness, .5),
		recentLatenessP90Ms: nearestRank(lateness, .9),
		recentLatenessMaxMs: lateness.length ? lateness[lateness.length - 1] : null
	};
}
function resetLatenessWindow(handle) {
	stateOf(handle).outcomes.length = 0;
}
function isLate(queue, key) {
	return queue.lastPresented !== null && (key - queue.lastPresented | 0) <= 0;
}
function recordPresentedFrame(queue, key, now) {
	queue.presented.delete(key);
	queue.presented.set(key, now);
	queue.lastPresented = key;
	queue.lastPresentedAt = now;
	for (const [timestamp, presentedAt] of queue.presented) {
		if (now - presentedAt <= LATENESS_WINDOW_MS && queue.presented.size <= LATENESS_MEMORY_LIMIT) break;
		queue.presented.delete(timestamp);
	}
	let expired = 0;
	while (expired < queue.outcomes.length && now - queue.outcomes[expired].at > LATENESS_WINDOW_MS) expired += 1;
	if (expired > 0) queue.outcomes.splice(0, expired);
}
function recordOutcome(queue, outcome) {
	queue.outcomes.push(outcome);
	if (queue.outcomes.length > LATENESS_MEMORY_LIMIT) queue.outcomes.splice(0, queue.outcomes.length - LATENESS_MEMORY_LIMIT);
}
function nearestRank(sorted, fraction) {
	if (sorted.length === 0) return null;
	return sorted[Math.min(sorted.length - 1, Math.ceil(fraction * sorted.length) - 1)];
}
function pruneMetadataQueue(queue, metadataRetentionMs, now) {
	if (metadataRetentionMs <= 0) return;
	for (const [timestamp, byType] of queue.timestamped) {
		for (const [type, item] of byType) {
			if (now - item.receivedAt <= metadataRetentionMs) continue;
			byType.delete(type);
			queue.timestampedEntries -= 1;
			queue.stats.expired += 1;
		}
		if (byType.size === 0) queue.timestamped.delete(timestamp);
	}
	while (queue.arrival.length && now - queue.arrival[0].receivedAt > metadataRetentionMs) {
		queue.arrival.shift();
		queue.stats.expired += 1;
	}
}
function startFrameLoop(video, onFrame, onNoCurrentFrame) {
	return typeof video.requestVideoFrameCallback === "function" ? videoFrameLoop(video, onFrame, onNoCurrentFrame) : animationFrameLoop(video, onFrame, onNoCurrentFrame);
}
function hasCurrentFrame(video) {
	return video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA;
}
function videoFrameLoop(video, onFrame, onNoCurrentFrame) {
	let stopped = false;
	let pending = 0;
	const request = () => {
		pending = video.requestVideoFrameCallback((now, metadata) => {
			if (stopped) return;
			request();
			if (hasCurrentFrame(video)) onFrame({
				now,
				rtpTimestamp: metadata.rtpTimestamp ?? null
			});
			else onNoCurrentFrame();
		});
	};
	request();
	return () => {
		stopped = true;
		video.cancelVideoFrameCallback(pending);
	};
}
function animationFrameLoop(video, onFrame, onNoCurrentFrame) {
	let stopped = false;
	let pending = 0;
	let decoded = 0;
	const request = () => {
		pending = requestAnimationFrame((now) => {
			if (stopped) return;
			request();
			if (!hasCurrentFrame(video)) {
				onNoCurrentFrame();
				return;
			}
			const total = video.getVideoPlaybackQuality().totalVideoFrames;
			if (total === decoded) return;
			decoded = total;
			onFrame({
				now,
				rtpTimestamp: null
			});
		});
	};
	request();
	return () => {
		stopped = true;
		cancelAnimationFrame(pending);
	};
}
const NEAT_STREAM_STALE_MS = 1800;
const FRAME_STATS_INTERVAL_MS = 1e3;
const MAX_CANVAS_DPR = 2;
function sameVideoBox(a, b) {
	if (a === null || b === null) return a === b;
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
var NeatVideoTile = class NeatVideoTile {
	source = input(null, ...ngDevMode ? [{ debugName: "source" }] : /* istanbul ignore next */ []);
	settings = input(NEAT_OVERLAY_DEFAULTS, ...ngDevMode ? [{ debugName: "settings" }] : /* istanbul ignore next */ []);
	retentionMs = input(0, ...ngDevMode ? [{ debugName: "retentionMs" }] : /* istanbul ignore next */ []);
	channel = input(0, ...ngDevMode ? [{ debugName: "channel" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	status = input(null, ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	bars = input(true, ...ngDevMode ? [{ debugName: "bars" }] : /* istanbul ignore next */ []);
	selected = input(false, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	stateChange = output();
	frameStats = output();
	state = signal("empty", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	box = signal(null, {
		...ngDevMode ? { debugName: "box" } : /* istanbul ignore next */ {},
		equal: sameVideoBox
	});
	videoBox = this.box.asReadonly();
	videoElement = viewChild.required("video", ...ngDevMode ? [{ debugName: "videoElement" }] : /* istanbul ignore next */ []);
	canvasElement = viewChild.required("canvas", ...ngDevMode ? [{ debugName: "canvasElement" }] : /* istanbul ignore next */ []);
	colors = inject(NeatOverlayColors);
	zone = inject(NgZone);
	document = inject(DOCUMENT);
	frameSettings = NEAT_OVERLAY_DEFAULTS;
	frameRetentionMs = 0;
	overlayState = null;
	currentState = "empty";
	canvas = null;
	context = null;
	view = {
		cssWidth: 0,
		cssHeight: 0,
		dpr: 1,
		videoWidth: 0,
		videoHeight: 0
	};
	playing = null;
	queue = createMetadataQueue();
	held = /* @__PURE__ */ new Map();
	lastFrameAt = null;
	staleTimer = null;
	staleCheckSawHidden = false;
	messagesThisSecond = 0;
	warnedUnreadable = false;
	warnedPlayback = false;
	destroyed = false;
	constructor() {
		effect(() => {
			this.frameSettings = this.settings();
			this.frameRetentionMs = this.retentionMs();
		});
		effect(() => {
			this.overlayState = createOverlayState(this.channel(), this.colors);
		});
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			this.canvas = this.canvasElement().nativeElement;
			const observer = this.zone.runOutsideAngular(() => new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.view.cssWidth = width;
				this.view.cssHeight = height;
				this.sizeCanvas(currentDpr());
				this.updateVideoBox();
			}));
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
			const video = this.videoElement().nativeElement;
			const onVideoSize = () => this.updateVideoBox();
			this.zone.runOutsideAngular(() => {
				video.addEventListener("loadedmetadata", onVideoSize);
				video.addEventListener("resize", onVideoSize);
			});
			destroyRef.onDestroy(() => {
				video.removeEventListener("loadedmetadata", onVideoSize);
				video.removeEventListener("resize", onVideoSize);
			});
		});
		afterRenderEffect(() => {
			const source = this.source();
			const stream = source?.stream() ?? null;
			untracked(() => this.play(source, stream));
		});
		destroyRef.onDestroy(() => {
			this.destroyed = true;
			this.stop();
		});
	}
	snapshot() {
		return metadataQueueSnapshot(this.queue);
	}
	resetLatenessWindow() {
		resetLatenessWindow(this.queue);
	}
	play(source, stream) {
		if (this.playing?.source === source && this.playing.stream === stream) return;
		this.stop();
		if (source === null || stream === null) return;
		const video = this.videoElement().nativeElement;
		this.context ??= this.canvasElement().nativeElement.getContext("2d");
		this.queue = createMetadataQueue();
		this.lastFrameAt = null;
		this.staleCheckSawHidden = false;
		this.messagesThisSecond = 0;
		video.srcObject = stream;
		this.startPlayback(video);
		const replay = () => this.startPlayback(video);
		const tracks = stream.getVideoTracks();
		for (const track of tracks) track.addEventListener("unmute", replay);
		const unsubscribe = source.onMetadata((text, receivedAt) => this.receive(text, receivedAt));
		const stopTimers = this.zone.runOutsideAngular(() => {
			const stopFrames = startFrameLoop(video, (frame) => this.present(frame, video), () => this.clearOverlays());
			const statsTimer = setInterval(() => this.reportFrameStats(video), FRAME_STATS_INTERVAL_MS);
			return () => {
				stopFrames();
				clearInterval(statsTimer);
			};
		});
		this.playing = {
			source,
			stream,
			stop: () => {
				stopTimers();
				unsubscribe();
				for (const track of tracks) track.removeEventListener("unmute", replay);
				video.srcObject = null;
			}
		};
	}
	startPlayback(video) {
		video.play().catch((error) => {
			if (error instanceof DOMException && error.name === "AbortError") return;
			if (this.warnedPlayback) return;
			this.warnedPlayback = true;
			const reason = error instanceof DOMException ? `${error.name}: ${error.message}` : error;
			console.warn(`video: channel ${this.channel()} cannot play its stream (${reason})`);
		});
	}
	stop() {
		if (this.playing === null) return;
		this.playing.stop();
		this.playing = null;
		if (this.staleTimer !== null) clearTimeout(this.staleTimer);
		this.staleTimer = null;
		this.clearOverlays();
		this.setState("empty");
	}
	receive(text, receivedAt) {
		const message = parseMetadataMessage(text);
		if (message === null) {
			if (!this.warnedUnreadable) {
				this.warnedUnreadable = true;
				console.warn(`metadata: channel ${this.channel()} dropped a message that is not a JSON object with a string "type"; later ones are dropped silently`);
			}
			return;
		}
		this.messagesThisSecond += 1;
		enqueueMetadata(this.queue, message, receivedAt);
	}
	present({ now, rtpTimestamp }, video) {
		this.lastFrameAt = now;
		this.setState("playing");
		this.staleTimer ??= setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS);
		const items = holdOverlays(this.held, takeMetadataForFrame(this.queue, rtpTimestamp, this.frameRetentionMs, now), now);
		const ctx = this.context;
		if (ctx === null || this.overlayState === null) return;
		const dpr = currentDpr();
		if (dpr !== this.view.dpr) this.sizeCanvas(dpr);
		this.view.videoWidth = video.videoWidth;
		this.view.videoHeight = video.videoHeight;
		drawFrame(ctx, this.view, items.map((item) => ({
			message: item.data,
			held: item.held === true
		})), this.overlayState, this.frameSettings, now);
	}
	checkStale() {
		this.staleTimer = null;
		if (this.lastFrameAt === null) return;
		const idle = performance.now() - this.lastFrameAt;
		if (this.document.hidden || this.staleCheckSawHidden) {
			this.staleCheckSawHidden = this.document.hidden;
			this.staleTimer = setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS);
			return;
		}
		if (idle < 1800) {
			this.staleTimer = setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS - idle);
			return;
		}
		this.clearOverlays();
		this.setState("stopped");
	}
	clearOverlays() {
		const ctx = this.context;
		if (ctx !== null) {
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
		}
		this.held.clear();
		if (this.overlayState !== null) resetOverlayState(this.overlayState);
	}
	setState(next) {
		if (this.currentState === next) return;
		this.currentState = next;
		this.state.set(next);
		this.updateVideoBox();
		if (!this.destroyed) this.stateChange.emit(next);
	}
	reportFrameStats(video) {
		const snapshot = metadataQueueSnapshot(this.queue);
		const lastFrameAt = this.lastFrameAt;
		this.frameStats.emit({
			timestampMatches: snapshot.timestampMatches,
			arrivalFallbacks: snapshot.arrivalFallbacks,
			frameMisses: snapshot.frameMisses,
			expired: snapshot.expired,
			evicted: snapshot.evicted,
			late: snapshot.late,
			untimestampedReceived: snapshot.untimestampedReceived,
			timestampedPending: snapshot.timestampedPending,
			arrivalPending: snapshot.arrivalPending,
			recentLatenessMedianMs: snapshot.recentLatenessMedianMs,
			recentLatenessMaxMs: snapshot.recentLatenessMaxMs,
			metadataMessagesPerSecond: this.messagesThisSecond,
			video: {
				readyState: video.readyState,
				paused: video.paused,
				currentTime: video.currentTime,
				videoWidth: video.videoWidth,
				videoHeight: video.videoHeight,
				lastFrameAgeMs: lastFrameAt === null ? null : Math.round(performance.now() - lastFrameAt),
				active: this.currentState === "playing"
			}
		});
		this.messagesThisSecond = 0;
	}
	updateVideoBox() {
		if (this.currentState !== "playing") {
			this.box.set(null);
			return;
		}
		const { videoWidth, videoHeight } = this.videoElement().nativeElement;
		const { cssWidth, cssHeight } = this.view;
		if (!videoWidth || !videoHeight || !cssWidth || !cssHeight) {
			this.box.set(null);
			return;
		}
		const { scaleX, scaleY, offsetX, offsetY } = letterbox(videoWidth, videoHeight, cssWidth, cssHeight);
		this.box.set({
			x: offsetX,
			y: offsetY,
			width: scaleX * videoWidth,
			height: scaleY * videoHeight
		});
	}
	sizeCanvas(dpr) {
		const canvas = this.canvas;
		if (canvas === null) return;
		this.view.dpr = dpr;
		canvas.width = Math.round(this.view.cssWidth * dpr);
		canvas.height = Math.round(this.view.cssHeight * dpr);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatVideoTile,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatVideoTile,
		isStandalone: true,
		selector: "neat-video-tile",
		inputs: {
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			settings: {
				classPropertyName: "settings",
				publicName: "settings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			retentionMs: {
				classPropertyName: "retentionMs",
				publicName: "retentionMs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			channel: {
				classPropertyName: "channel",
				publicName: "channel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bars: {
				classPropertyName: "bars",
				publicName: "bars",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			stateChange: "stateChange",
			frameStats: "frameStats"
		},
		host: { properties: {
			"attr.data-state": "state()",
			"attr.data-selected": "selected() ? \"\" : null"
		} },
		viewQueries: [{
			propertyName: "videoElement",
			first: true,
			predicate: ["video"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "canvasElement",
			first: true,
			predicate: ["canvas"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <video #video class="video" autoplay playsinline [muted]="true"></video>
    <canvas #canvas class="overlay" aria-hidden="true"></canvas>
    <div class="overlay-slot"><ng-content select="[neatTileOverlay]" /></div>
    @if (bars()) {
      @if (state() !== 'playing') {
        <p class="no-video"><span class="no-video-text">No active video received</span></p>
      }
      <div class="bar">
        <span class="label">{{ label() }}</span>
        <span class="status">{{ status() }}</span>
        <ng-content select="[neatTileChip]" />
      </div>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:block;width:100%;height:100%;overflow:hidden;isolation:isolate;background:var(--muted)}.video,.overlay{position:absolute;inset:0;width:100%;height:100%}.video{object-fit:contain}.overlay{pointer-events:none}.overlay-slot{position:absolute;inset:0;z-index:1;pointer-events:none}:host([data-state=\"empty\"]):after{content:\"\";position:absolute;inset:0;background:var(--muted)}:host([data-state=\"stopped\"]) .video{filter:blur(9px) saturate(.6) brightness(.75);transform:scale(1.07)}:host([data-state=\"stopped\"]) .overlay{visibility:hidden}.no-video{position:absolute;inset:0;z-index:1;pointer-events:none;display:flex;align-items:center;justify-content:center;margin:0;padding:var(--neat-space-2);text-align:center;font-size:var(--neat-text-sm)}.no-video-text{padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground)}.bar{position:absolute;inset-inline:0;bottom:0;z-index:1;display:flex;align-items:center;gap:var(--neat-space-2);padding:var(--neat-space-2) var(--neat-space-3);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground);font-size:var(--neat-text-xs)}.label{flex:none;font-weight:500}.status{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host([data-selected]):before{content:\"\";position:absolute;inset:0;z-index:2;box-shadow:inset 0 0 0 var(--neat-focus-ring-width) var(--ring);pointer-events:none}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatVideoTile,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-video-tile",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-state]": "state()",
				"[attr.data-selected]": "selected() ? \"\" : null"
			},
			template: `
    <video #video class="video" autoplay playsinline [muted]="true"></video>
    <canvas #canvas class="overlay" aria-hidden="true"></canvas>
    <div class="overlay-slot"><ng-content select="[neatTileOverlay]" /></div>
    @if (bars()) {
      @if (state() !== 'playing') {
        <p class="no-video"><span class="no-video-text">No active video received</span></p>
      }
      <div class="bar">
        <span class="label">{{ label() }}</span>
        <span class="status">{{ status() }}</span>
        <ng-content select="[neatTileChip]" />
      </div>
    }
  `,
			styles: [":host{position:relative;display:block;width:100%;height:100%;overflow:hidden;isolation:isolate;background:var(--muted)}.video,.overlay{position:absolute;inset:0;width:100%;height:100%}.video{object-fit:contain}.overlay{pointer-events:none}.overlay-slot{position:absolute;inset:0;z-index:1;pointer-events:none}:host([data-state=\"empty\"]):after{content:\"\";position:absolute;inset:0;background:var(--muted)}:host([data-state=\"stopped\"]) .video{filter:blur(9px) saturate(.6) brightness(.75);transform:scale(1.07)}:host([data-state=\"stopped\"]) .overlay{visibility:hidden}.no-video{position:absolute;inset:0;z-index:1;pointer-events:none;display:flex;align-items:center;justify-content:center;margin:0;padding:var(--neat-space-2);text-align:center;font-size:var(--neat-text-sm)}.no-video-text{padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground)}.bar{position:absolute;inset-inline:0;bottom:0;z-index:1;display:flex;align-items:center;gap:var(--neat-space-2);padding:var(--neat-space-2) var(--neat-space-3);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground);font-size:var(--neat-text-xs)}.label{flex:none;font-weight:500}.status{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host([data-selected]):before{content:\"\";position:absolute;inset:0;z-index:2;box-shadow:inset 0 0 0 var(--neat-focus-ring-width) var(--ring);pointer-events:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		settings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "settings",
				required: false
			}]
		}],
		retentionMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "retentionMs",
				required: false
			}]
		}],
		channel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "channel",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		bars: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bars",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}],
		stateChange: [{
			type: i0.Output,
			args: ["stateChange"]
		}],
		frameStats: [{
			type: i0.Output,
			args: ["frameStats"]
		}],
		videoElement: [{
			type: i0.ViewChild,
			args: ["video", { isSignal: true }]
		}],
		canvasElement: [{
			type: i0.ViewChild,
			args: ["canvas", { isSignal: true }]
		}]
	}
});
function currentDpr() {
	return Math.min(MAX_CANVAS_DPR, window.devicePixelRatio || 1);
}
const CLOSE_DISTANCE_PX = 10;
const MIN_POLYGON_POINTS = 3;
const STROKE_WIDTH = 2;
const HIGHLIGHT_STROKE_WIDTH = 3;
function clamp01(value) {
	return Math.min(1, Math.max(0, value));
}
function fitInto(start, length, limit) {
	return Math.max(0, Math.min(start, limit - length));
}
function sameSize(a, b) {
	if (a === null || b === null) return a === b;
	return a.width === b.width && a.height === b.height;
}
function distancePx(a, b, box) {
	return Math.hypot((a.x - b.x) * box.width, (a.y - b.y) * box.height);
}
function polylinePoints(points, box) {
	return points.map((point) => `${point.x * box.width},${point.y * box.height}`).join(" ");
}
var NeatRoiEditor = class NeatRoiEditor {
	regions = input.required(...ngDevMode ? [{ debugName: "regions" }] : /* istanbul ignore next */ []);
	mode = input("off", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	regionsChange = output();
	highlighted = model(null, ...ngDevMode ? [{ debugName: "highlighted" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef);
	injector = inject(Injector);
	renderer = inject(Renderer2);
	document = inject(DOCUMENT);
	videoBox = inject(NeatVideoTile).videoBox;
	menuElement = viewChild("menu", ...ngDevMode ? [{ debugName: "menuElement" }] : /* istanbul ignore next */ []);
	size = signal(null, {
		...ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {},
		equal: sameSize
	});
	boxSource = computed(() => {
		if (this.videoBox() !== null) return "video";
		return this.size() === null ? null : "tile";
	}, ...ngDevMode ? [{ debugName: "boxSource" }] : /* istanbul ignore next */ []);
	box = computed(() => {
		const video = this.videoBox();
		if (video !== null) return video;
		const size = this.size();
		return size === null ? null : {
			x: 0,
			y: 0,
			width: size.width,
			height: size.height
		};
	}, ...ngDevMode ? [{ debugName: "box" }] : /* istanbul ignore next */ []);
	open = linkedSignal({
		...ngDevMode ? { debugName: "open" } : /* istanbul ignore next */ {},
		source: () => ({
			mode: this.mode(),
			regions: this.regions(),
			boxSource: this.boxSource()
		}),
		computation: () => []
	});
	pointer = signal(null, ...ngDevMode ? [{ debugName: "pointer" }] : /* istanbul ignore next */ []);
	menu = linkedSignal({
		...ngDevMode ? { debugName: "menu" } : /* istanbul ignore next */ {},
		source: () => ({
			regions: this.regions(),
			boxSource: this.boxSource()
		}),
		computation: () => null
	});
	focusBeforeMenu = null;
	drawing = computed(() => this.open().length > 0, ...ngDevMode ? [{ debugName: "drawing" }] : /* istanbul ignore next */ []);
	placed = computed(() => {
		const box = this.box();
		if (box === null) return [];
		const highlighted = this.highlighted();
		return this.regions().map((region, index) => ({
			region,
			index
		})).filter(({ region }) => region.points.length >= MIN_POLYGON_POINTS).map(({ region, index }) => {
			const colors = OVERLAY_ROI_COLORS[region.type];
			const active = index === highlighted;
			return {
				index,
				points: polylinePoints(region.points, box),
				fill: active ? colors.fillActive : colors.fill,
				stroke: colors.stroke,
				strokeWidth: active ? HIGHLIGHT_STROKE_WIDTH : STROKE_WIDTH
			};
		});
	}, ...ngDevMode ? [{ debugName: "placed" }] : /* istanbul ignore next */ []);
	draft = computed(() => {
		const box = this.box();
		const mode = this.mode();
		const points = this.open();
		if (box === null || mode === "off" || points.length === 0) return null;
		const through = this.pointer() ?? points[points.length - 1];
		return {
			line: polylinePoints([...points, through], box),
			stroke: OVERLAY_ROI_COLORS[mode].stroke,
			startX: points[0].x * box.width,
			startY: points[0].y * box.height
		};
	}, ...ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []);
	menuLabel = computed(() => {
		const menu = this.menu();
		if (menu === null) return null;
		const name = neatRoiNames(this.regions())[menu.index];
		return name === void 0 ? null : `Delete ${name}`;
	}, ...ngDevMode ? [{ debugName: "menuLabel" }] : /* istanbul ignore next */ []);
	constructor() {
		const host = this.host.nativeElement;
		const destroyRef = inject(DestroyRef);
		const stopListening = this.renderer.listen(host, "pointermove", (event) => {
			if (this.open().length === 0) return;
			const located = this.locate(event);
			if (located !== null) this.pointer.set(located.point);
		});
		destroyRef.onDestroy(stopListening);
		const zone = inject(NgZone);
		afterNextRender(() => {
			const observer = zone.runOutsideAngular(() => new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.size.set(width > 0 && height > 0 ? {
					width,
					height
				} : null);
			}));
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
		});
		effect((onCleanup) => {
			if (this.menu() === null) return;
			onCleanup(this.renderer.listen(this.document, "pointerdown", (event) => {
				if (!this.inMenu(event.target)) this.closeMenu(false);
			}, { capture: true }));
		});
	}
	onClick(event) {
		const mode = this.mode();
		if (mode === "off" || event.button !== 0 || event.detail >= 2) return;
		if (this.inMenu(event.target)) return;
		const located = this.locate(event);
		if (located === null) return;
		const { point, box } = located;
		const points = this.open();
		if (points.length >= MIN_POLYGON_POINTS && distancePx(points[0], point, box) <= CLOSE_DISTANCE_PX) {
			this.close(mode, points);
			return;
		}
		this.pointer.set(point);
		this.open.set([...points, point]);
		if (points.length === 0) afterNextRender(() => this.host.nativeElement.focus({ preventScroll: true }), { injector: this.injector });
	}
	onDoubleClick(event) {
		const mode = this.mode();
		if (mode === "off" || event.button !== 0 || this.inMenu(event.target)) return;
		const points = this.open();
		if (points.length >= MIN_POLYGON_POINTS) this.close(mode, points);
	}
	cancelOnEscape(event) {
		if (this.open().length === 0) return;
		event.stopPropagation();
		this.open.set([]);
	}
	openMenu(event, index) {
		event.preventDefault();
		if (index >= this.regions().length) return;
		const origin = this.host.nativeElement.getBoundingClientRect();
		const active = this.document.activeElement;
		this.focusBeforeMenu = active instanceof HTMLElement ? active : null;
		const menu = {
			index,
			x: event.clientX - origin.left,
			y: event.clientY - origin.top
		};
		this.menu.set(menu);
		afterNextRender(() => this.placeMenu(menu), { injector: this.injector });
	}
	deleteFromMenu() {
		const menu = this.menu();
		if (menu === null) return;
		if (this.highlighted() === menu.index) this.highlighted.set(null);
		this.closeMenu(true);
		this.regionsChange.emit(this.regions().filter((_, index) => index !== menu.index));
	}
	closeMenuOnEscape(event) {
		event.stopPropagation();
		this.closeMenu(true);
	}
	closeMenuOnFocusOut(event) {
		if (event.relatedTarget === null || this.inMenu(event.relatedTarget)) return;
		this.closeMenu(false);
	}
	closeMenu(restoreFocus) {
		this.menu.set(null);
		const previous = this.focusBeforeMenu;
		this.focusBeforeMenu = null;
		if (restoreFocus && previous?.isConnected) previous.focus({ preventScroll: true });
	}
	placeMenu(menu) {
		const element = this.menuElement()?.nativeElement;
		if (element === void 0 || this.menu() !== menu) return;
		const size = this.size();
		const x = size === null ? menu.x : fitInto(menu.x, element.offsetWidth, size.width);
		const y = size === null ? menu.y : fitInto(menu.y, element.offsetHeight, size.height);
		this.renderer.setStyle(element, "left", `${x}px`);
		this.renderer.setStyle(element, "top", `${y}px`);
		element.querySelector("button")?.focus({ preventScroll: true });
	}
	inMenu(target) {
		const element = this.menuElement()?.nativeElement;
		return element !== void 0 && target instanceof Node && element.contains(target);
	}
	close(mode, points) {
		this.open.set([]);
		this.regionsChange.emit([...this.regions(), {
			type: mode,
			points
		}]);
	}
	locate(event) {
		const box = this.box();
		if (box === null || box.width <= 0 || box.height <= 0) return null;
		const origin = this.host.nativeElement.getBoundingClientRect();
		return {
			point: {
				x: clamp01((event.clientX - origin.left - box.x) / box.width),
				y: clamp01((event.clientY - origin.top - box.y) / box.height)
			},
			box
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRoiEditor,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatRoiEditor,
		isStandalone: true,
		selector: "neat-roi-editor",
		inputs: {
			regions: {
				classPropertyName: "regions",
				publicName: "regions",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			highlighted: {
				classPropertyName: "highlighted",
				publicName: "highlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			regionsChange: "regionsChange",
			highlighted: "highlightedChange"
		},
		host: {
			listeners: {
				"click": "onClick($event)",
				"dblclick": "onDoubleClick($event)",
				"keydown.escape": "cancelOnEscape($event)"
			},
			properties: {
				"attr.tabindex": "drawing() ? -1 : null",
				"attr.role": "drawing() ? \"group\" : null",
				"attr.aria-label": "drawing() ? \"Region drawing surface\" : null"
			}
		},
		viewQueries: [{
			propertyName: "menuElement",
			first: true,
			predicate: ["menu"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (box(); as box) {
      <svg
        class="surface"
        aria-hidden="true"
        [attr.data-mode]="mode()"
        [style.left.px]="box.x"
        [style.top.px]="box.y"
        [style.width.px]="box.width"
        [style.height.px]="box.height"
      >
        @for (region of placed(); track region.index) {
          <polygon
            class="region"
            [attr.points]="region.points"
            [attr.fill]="region.fill"
            [attr.stroke]="region.stroke"
            [attr.stroke-width]="region.strokeWidth"
            (pointerenter)="highlighted.set(region.index)"
            (pointerleave)="highlighted.set(null)"
            (contextmenu)="openMenu($event, region.index)"
          />
        }
        @if (draft(); as open) {
          <polyline
            [attr.points]="open.line"
            [attr.stroke]="open.stroke"
            fill="none"
            stroke-width="2"
            stroke-dasharray="4 4"
          />
          <circle [attr.cx]="open.startX" [attr.cy]="open.startY" r="4" [attr.fill]="open.stroke" />
        }
      </svg>
      @if (menuLabel(); as label) {
        <!-- A press on the card around the button must not take focus from it: focus would fall
             to the page, and Escape would no longer reach the bubble. Focus moves on mousedown,
             which browsers also send after a touch. -->
        <div #menu class="menu" (mousedown)="$event.preventDefault()">
          <button
            neatButton
            variant="text"
            size="small"
            type="button"
            [attr.aria-label]="label"
            (click)="deleteFromMenu()"
            (keydown.escape)="closeMenuOnEscape($event)"
            (focusout)="closeMenuOnFocusOut($event)"
          >
            Delete
          </button>
        </div>
      }
    }
  `,
		isInline: true,
		styles: [":host{position:absolute;inset:0;pointer-events:none;outline:none}.surface{position:absolute;overflow:visible}.surface[data-mode=off]{pointer-events:none}.surface[data-mode=inclusion],.surface[data-mode=exclusion]{pointer-events:auto;cursor:crosshair}.region{pointer-events:auto}.menu{position:absolute;padding:calc(var(--neat-space-2) / 2);border:1px solid color-mix(in oklch,var(--border),var(--foreground) 20%);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);pointer-events:auto}\n"],
		dependencies: [{
			kind: "directive",
			type: NeatButton,
			selector: "button[neatButton], a[neatButton]",
			inputs: [
				"variant",
				"size",
				"iconOnly",
				"rounded",
				"pressed"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRoiEditor,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-roi-editor",
			imports: [NeatButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.tabindex]": "drawing() ? -1 : null",
				"[attr.role]": "drawing() ? \"group\" : null",
				"[attr.aria-label]": "drawing() ? \"Region drawing surface\" : null",
				"(click)": "onClick($event)",
				"(dblclick)": "onDoubleClick($event)",
				"(keydown.escape)": "cancelOnEscape($event)"
			},
			template: `
    @if (box(); as box) {
      <svg
        class="surface"
        aria-hidden="true"
        [attr.data-mode]="mode()"
        [style.left.px]="box.x"
        [style.top.px]="box.y"
        [style.width.px]="box.width"
        [style.height.px]="box.height"
      >
        @for (region of placed(); track region.index) {
          <polygon
            class="region"
            [attr.points]="region.points"
            [attr.fill]="region.fill"
            [attr.stroke]="region.stroke"
            [attr.stroke-width]="region.strokeWidth"
            (pointerenter)="highlighted.set(region.index)"
            (pointerleave)="highlighted.set(null)"
            (contextmenu)="openMenu($event, region.index)"
          />
        }
        @if (draft(); as open) {
          <polyline
            [attr.points]="open.line"
            [attr.stroke]="open.stroke"
            fill="none"
            stroke-width="2"
            stroke-dasharray="4 4"
          />
          <circle [attr.cx]="open.startX" [attr.cy]="open.startY" r="4" [attr.fill]="open.stroke" />
        }
      </svg>
      @if (menuLabel(); as label) {
        <!-- A press on the card around the button must not take focus from it: focus would fall
             to the page, and Escape would no longer reach the bubble. Focus moves on mousedown,
             which browsers also send after a touch. -->
        <div #menu class="menu" (mousedown)="$event.preventDefault()">
          <button
            neatButton
            variant="text"
            size="small"
            type="button"
            [attr.aria-label]="label"
            (click)="deleteFromMenu()"
            (keydown.escape)="closeMenuOnEscape($event)"
            (focusout)="closeMenuOnFocusOut($event)"
          >
            Delete
          </button>
        </div>
      }
    }
  `,
			styles: [":host{position:absolute;inset:0;pointer-events:none;outline:none}.surface{position:absolute;overflow:visible}.surface[data-mode=off]{pointer-events:none}.surface[data-mode=inclusion],.surface[data-mode=exclusion]{pointer-events:auto;cursor:crosshair}.region{pointer-events:auto}.menu{position:absolute;padding:calc(var(--neat-space-2) / 2);border:1px solid color-mix(in oklch,var(--border),var(--foreground) 20%);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);pointer-events:auto}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		regions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "regions",
				required: true
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		regionsChange: [{
			type: i0.Output,
			args: ["regionsChange"]
		}],
		highlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "highlighted",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["highlightedChange"]
		}],
		menuElement: [{
			type: i0.ViewChild,
			args: ["menu", { isSignal: true }]
		}]
	}
});
var NeatRoiSwatch = class NeatRoiSwatch {
	type = input.required(...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	color = computed(() => OVERLAY_ROI_COLORS[this.type()].stroke, ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRoiSwatch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatRoiSwatch,
		isStandalone: true,
		selector: "neat-roi-swatch",
		inputs: { type: {
			classPropertyName: "type",
			publicName: "type",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "aria-hidden": "true" },
			properties: { "style.background-color": "color()" }
		},
		ngImport: i0,
		template: "",
		isInline: true,
		styles: [":host{display:inline-block;flex-shrink:0;width:.625em;height:.625em;border-radius:50%}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRoiSwatch,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-roi-swatch",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"aria-hidden": "true",
				"[style.background-color]": "color()"
			},
			template: "",
			styles: [":host{display:inline-block;flex-shrink:0;width:.625em;height:.625em;border-radius:50%}\n"]
		}]
	}],
	propDecorators: { type: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "type",
			required: true
		}]
	}] }
});
export { NEAT_MIN_TILE_WIDTH, NEAT_OVERLAY_DEFAULTS, NEAT_OVERLAY_STYLE_FALLBACK_COLOR, NeatRoiEditor, NeatRoiSwatch, NeatTileGrid, NeatVideoTile, bufferSettleMs, fitAllTileWidth, lateNoticeDetails, neatRoiNames, nextWarningActive };

//# sourceMappingURL=sima-neat-ui-video.mjs.map