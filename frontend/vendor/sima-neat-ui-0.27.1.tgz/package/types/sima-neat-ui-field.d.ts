import * as i0 from "@angular/core";
/**
 * A failure said in place, under the form or the work it belongs to:
 * `<neat-error-note>{{ message }}</neat-error-note>`. It is an `alert`, so a screen reader reads
 * it as it appears: render it when there is a failure (`@if`), not as an empty note waiting for
 * one. A message of several lines (a server's diagnostics) keeps its line breaks, and a long
 * unbroken string (a URL) wraps rather than widen the form. The words are the app's.
 *
 * `neat-field` shows one under its control for its `error`.
 */
export declare class NeatErrorNote {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatErrorNote, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatErrorNote, "neat-error-note", never, {}, {}, never, ["*"], true, never>;
}
/**
 * A form control under its visible name, with an optional hint and error under it:
 *
 * ```html
 * <neat-field label="Stream URL" hint="RTSP and RTSPS only." [error]="urlError()">
 *   <input neatInput size="small" type="url" />
 * </neat-field>
 * ```
 *
 * The control is the content, one `input neatInput` inside a `label` whose text is `label`: the
 * label names it, and a click on the name focuses it. The app may swap it (an `@if` in the
 * content); the field follows the control it has. `neat-select` shows its own name with
 * `showLabel` instead, drawn the same way.
 *
 * `hint` is a note under the control and `error` a `neat-error-note` under that, both outside the
 * label so that they are not part of the control's name. The field describes the control by them
 * (`aria-describedby`) and marks it `aria-invalid` while there is an error, so it owns those two
 * attributes of its control: do not bind them yourself.
 *
 * Lining up in a row: the name's text and the gap under it are `neat-select`'s, and the control's
 * height is its own `size` (`neatInput`, `neat-select` and `neatButton` share `small` and
 * `medium`; `neat-number-field` is `small`). A row of fields and a button of one size aligned at
 * their bottom edge (`align-items: end`) has its names on one baseline and its controls' edges
 * level. A hint or an error makes its field taller, so a row that must stay level shows them under
 * the row instead.
 */
export declare class NeatField {
  /** The control's visible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** A note under the control about what it takes; none while empty. */
  readonly hint: import("@angular/core").InputSignal<string>;
  /** What is wrong with the control's value; none while empty. */
  readonly error: import("@angular/core").InputSignal<string>;
  protected readonly classes: {
    readonly stack: "flex flex-col gap-2";
    readonly label: "text-sm font-medium";
  };
  private readonly id;
  protected readonly hintId: string;
  protected readonly errorId: string;
  /** The control, as a content query: a swapped control is a new value that the effect follows. */
  private readonly control;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatField, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatField, "neat-field", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["control"], ["*"], true, never>;
}