import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import { NeatTone } from "@sima/neat-ui";
/**
 * What a pointer does to a row: `click` selects it and tells `activated`; `double-click` only
 * selects it on a click and tells `activated` on a double click. Enter tells it in both.
 */
type NeatActivateOn = 'click' | 'double-click';
/** Stands for "no selection" in key comparisons; no item's key can be it. */
declare const NONE: unique symbol;
/**
 * One column of a `neat-select-list`, as a template for the cells in it:
 *
 * ```html
 * <ng-template neatColumn="state" header="State" width="6rem" let-slot>{{ slot.state }}</ng-template>
 * ```
 *
 * The key names the column, `header` is the label over it (no label on any column: no header row),
 * and `width` is its CSS track size in the list's grid, `1fr` by default. The header and the rows
 * share the grid's tracks, so a content-sized width (`auto`, `max-content`) fits the widest of the
 * label and the cells. `align="end"` puts the label and the cells' text at the end of the column,
 * as numbers read best. The template gets the item as its implicit context. A cell is a block
 * that may shrink to nothing (`min-width: 0`), so it does not push the next column out; it does not
 * cut its content, though. A long text wraps, and an unbroken one overflows into the next cell,
 * unless the template truncates it (an element with `overflow: hidden`, `text-overflow: ellipsis`
 * and `white-space: nowrap`).
 *
 * `hideBelow` is a width of the list in CSS pixels: while the list is narrower, the column and its
 * header leave the layout entirely, as if the template were not there. For columns that matter
 * less than the others on a narrow screen: `[hideBelow]="720"`.
 */
export declare class NeatColumn {
  /** The column's name, written as the directive's own attribute: `neatColumn="state"`. */
  readonly key: import("@angular/core").InputSignal<string>;
  /** The label over the column; empty by default, and no header row while no column has one. */
  readonly header: import("@angular/core").InputSignal<string>;
  /** The column's track size in the list's grid, any CSS grid track size (`6rem`, `auto`). */
  readonly width: import("@angular/core").InputSignal<string>;
  /** Where the label and the cells' text sit in the column. */
  readonly align: import("@angular/core").InputSignal<"start" | "end">;
  /** The list's width in CSS pixels below which the column is not shown; always shown if unset. */
  readonly hideBelow: import("@angular/core").InputSignal<number | undefined>;
  /**
   * @internal The template the list renders in each row; apps never read it.
   */
  readonly template: TemplateRef<unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatColumn, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatColumn, "ng-template[neatColumn]", never, {
    "key": {
      "alias": "neatColumn";
      "required": true;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "align": {
      "alias": "align";
      "required": false;
      "isSignal": true;
    };
    "hideBelow": {
      "alias": "hideBelow";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A group of a `neat-select-list`'s rows under a heading: `key` is what `groupOf` returns for its
 * items, `label` the heading's text (the app's own, a count included if it wants one), and `muted`
 * greys the heading, for a group with nothing in it.
 */
interface NeatSelectListGroup {
  readonly key: string;
  readonly label: string;
  readonly muted?: boolean;
}
/**
 * A row: the item, its key, its place among the rows as shown (`data-index`), whether it can be
 * checked, its classes (by its tone), the element id the listbox points at, and its cells' context.
 */
interface Row<T, K> {
  readonly item: T;
  readonly key: K;
  readonly index: number;
  /** The id of its group's heading if it is the group's first row, which reveals it too. */
  readonly heading: string | null;
  readonly checkable: boolean;
  readonly classes: string;
  readonly id: string;
  readonly context: {
    readonly $implicit: T;
  };
}
/**
 * Rows as shown together: a group's, under its heading (an element id and its classes), or rows
 * under no heading (`group` null): all rows of a list without groups, or, in production, the items
 * of groups the app did not list. `key` tracks it: the group's key, or null for the one without.
 * `separated` is that last case, set off from the groups before it. `views` are its rows as the
 * row template's contexts, made once with the rows rather than as a literal per row on every
 * check.
 */
interface Section<T, K> {
  readonly key: string | null;
  readonly group: NeatSelectListGroup | null;
  readonly headingId: string;
  readonly headingClasses: string;
  readonly separated: boolean;
  readonly views: readonly {
    readonly $implicit: Row<T, K>;
  }[];
}
/**
 * A list of items, one row each, in columns that the app lays out with templates; one row is
 * selected:
 *
 * ```html
 * <neat-select-list label="Streaming slots" [items]="slots()" [trackBy]="slotId" [(selected)]="slot">
 *   <ng-template neatColumn="name" header="Slot" let-slot>{{ slot.name }}</ng-template>
 *   <ng-template neatColumn="state" header="State" width="6rem" let-slot>…</ng-template>
 * </neat-select-list>
 * ```
 *
 * It fills its container (the container needs a height) and scrolls its rows inside, under a header
 * that stays put: the header sits in the scrolling area, sticky at its top, filled with
 * `--neat-surface` (the page's background, or a dialog's or popover's surface, which they set; a
 * card of the app's sets it to its own fill). `trackBy` gives an item's identity, unique in the
 * list: the selection follows the item with the same key when `items` is replaced by new objects (a
 * poll's answer), and rows, with the state in their cells, are kept rather than rebuilt. It is
 * called once per item whenever `items` changes, never while the list is only checked or the
 * selection moves.
 *
 * It is a single-select `listbox` named by `label`, whose `option` rows are `aria-selected`.
 * Selection follows focus: the listbox is the one tab stop, holds the focus, and names the
 * selected row in `aria-activedescendant`; ArrowDown and ArrowUp move the selection (the first
 * press picks the first or last row when nothing is selected), Home and End jump to the ends, and
 * the selected row scrolls into view (the list's own area only; the page around it stays where it
 * is). Enter, and a click on a row, tell `activated` with the row's item; with
 * `activateOn="double-click"` a click only selects, and a double click tells it (Enter still does).
 * A double click does not select a row's text. A click on a control in a cell, and every key
 * pressed while one has the focus, are that control's: they neither select nor activate. Controls
 * in cells are ordinary tab stops after the listbox.
 *
 * The header repeats the columns' labels for the eye and is hidden from assistive technology: the
 * rows read as the text of their cells in order, as a listbox's options do (a listbox cannot
 * name its columns).
 *
 * `hint` is read as the listbox's description, for keys the app adds on top of these.
 *
 * **Checked mode** (`checkable`) is for acting on several rows: each row that `canCheck` allows
 * has a box before its cells, and `checked` holds the keys (`trackBy`'s) of the checked rows. It
 * holds keys rather than items, and keeps the keys of rows it does not list (a file in another
 * folder, a type a filter hides): a newly checked key is appended, an unchecked one removed, the
 * rest left as they are. The listbox is then multi-selectable, and a checkable row is
 * `aria-selected` while it is checked (as the WAI-ARIA multi-select listbox has it); a row that
 * cannot be checked has no `aria-selected`. The selection that follows the arrow keys (`selected`)
 * stays: it is the row the keyboard is on, named in `aria-activedescendant` and drawn with the bar.
 * Space checks or unchecks that row; a click on a row's box checks or unchecks it and does nothing
 * else. A click elsewhere on the row selects and activates it as in the single mode, except on the
 * selected row, which it checks or unchecks as Space does (a row that cannot be checked is
 * activated again as before). The second click of a double click never checks; a double click on
 * the already selected checkable row checks it once, with its first click, and with
 * `activateOn="double-click"` the `dblclick` then only activates.
 * Ctrl-click or Cmd-click on a row checks or unchecks it and selects it
 * without activating it. Shift-click checks the rows from the anchor to the clicked one, inclusive,
 * and selects the clicked one; the anchor is the row last clicked plainly, with Ctrl or Cmd, or
 * checked by Space or its box, else the selected row, else the clicked row alone. A range only
 * checks, never unchecks, and Ctrl+A or Cmd+A checks every row. None of them checks a row without
 * a box or a blocked one, and a row they do not check stays as it is. The boxes are not tab stops.
 * The multi-selectable listbox says what checking is, so a checked list needs no `hint` of its
 * own.
 *
 * **Blocked checks** (`checkBlocked`) hold a row's box as it is while the app gives a reason (a
 * cap: "At most 8 runs can be compared."). The box is drawn disabled, and neither Space nor a click
 * on it checks or unchecks the row; everything else about the row stays, since only its box is
 * blocked: the keys still land on it, a click and Enter still select and activate it. Its option
 * keeps `aria-selected` (false while unchecked) and is `aria-disabled`: in this listbox selecting
 * is checking, so a disabled option says that Space will not check it, where an enabled one would
 * promise a check that silently fails. `aria-disabled` blocks no events and the row stays the
 * active descendant, so it is still reached and activated. The reason describes the option
 * (`aria-describedby`, so a screen reader says it as the keys land on the row), and a tooltip on
 * the box shows it on hover. A tooltip never opens on touch, so an app with a cap says it in its
 * own text too. Any reason but null blocks, so give a non-empty one: it is what is announced.
 * `canCheck` still means whether a row has a box at all.
 *
 * **Row tones** (`rowTone`) tint a row with a soft fill of a status colour, the tone its status
 * chip has (`NeatTone`), so that a state reads along the whole row: the app gives both the same
 * tone. A `neutral` row is untinted. A toned row still shows hover and selection, with more of its
 * tone, and the selected one keeps its bar. The tints are mixed over the content background
 * (`--background`), so a toned list belongs on it, not on a card. The words in the row still carry
 * the state; the tint repeats them.
 *
 * **Groups** (`groups`, with `groupOf` naming an item's group by its key) put the rows under
 * headings, in the groups' order, each item keeping its order within its group. A group is a
 * `group` named by its heading, which spans the columns; an empty group shows its heading alone,
 * and a `muted` one greys it. The arrow keys, Home and End move over the rows as shown, never onto
 * a heading, and a click on a heading does nothing. An item whose group is not listed is a mistake
 * in the app: it throws in dev mode, and in production shows after the groups, under no heading
 * and set off from the last group by a rule, rather than going missing.
 *
 * Typing a letter to jump to a row, Page Up and Page Down, and a disabled row are not offered; none
 * is needed yet.
 */
export declare class NeatSelectList<T, K = unknown> {
  /** The accessible name of the list. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The items, one row each, in the order given (within its group, with `groups`). */
  readonly items: import("@angular/core").InputSignal<readonly T[]>;
  /** An item's identity, unique in the list. */
  readonly trackBy: import("@angular/core").InputSignal<(item: T) => K>;
  /** The selected item: the row the keyboard is on; `null` while there is none. */
  readonly selected: import("@angular/core").ModelSignal<T | null>;
  /** Checked mode: a box on each row that `canCheck` allows, for acting on several rows. */
  readonly checkable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** In checked mode, the keys of the checked rows, including rows the list does not show. */
  readonly checked: import("@angular/core").ModelSignal<readonly K[]>;
  /** In checked mode, whether an item's row has a box; called once per item as `items` change. */
  readonly canCheck: import("@angular/core").InputSignal<(item: T) => boolean>;
  /**
   * In checked mode, why a row with a box cannot be ticked or unticked now (a cap that is
   * reached), or null while it can. Any string blocks, so make it a sentence: it is the row's
   * description and its box's tooltip. Called for each row with a box as `items` or `checked`
   * change.
   */
  readonly checkBlocked: import("@angular/core").InputSignal<(item: T) => string | null>;
  /** An item's row tone, `neutral` (untinted) by default; called once per item as `items` change. */
  readonly rowTone: import("@angular/core").InputSignal<(item: T) => NeatTone>;
  /** The groups to show the rows under, in order; `null` (the default) for no headings. */
  readonly groups: import("@angular/core").InputSignal<readonly NeatSelectListGroup[] | null>;
  /**
   * With `groups`, the key of an item's group; called once per item as the inputs that shape the
   * rows change (`items`, `groups` and the other per-item functions), never as the selection moves.
   */
  readonly groupOf: import("@angular/core").InputSignal<(item: T) => string>;
  /** What to say, in place of rows, while there are no items. */
  readonly emptyLabel: import("@angular/core").InputSignal<string>;
  /**
   * Text for assistive technology that says what keys an app adds beyond the listbox's own (such
   * as Delete on a row); it describes the listbox, and is not shown.
   */
  readonly hint: import("@angular/core").InputSignal<string>;
  /**
   * What the pointer does to a row: `click` (the default) selects it and tells `activated`;
   * `double-click` makes a click only select it, and a double click tells `activated`, as a file
   * manager opens a folder. Enter tells it in both.
   */
  readonly activateOn: import("@angular/core").InputSignal<NeatActivateOn>;
  /**
   * The item of the row that was activated: by a click or double click (`activateOn`), or Enter.
   */
  readonly activated: import("@angular/core").OutputEmitterRef<T>;
  protected readonly scrollerClasses = "relative isolate min-h-0 flex-1 overflow-x-hidden overflow-y-auto";
  protected readonly gridClasses = "grid grid-cols-(--neat-select-list-columns) gap-x-(--neat-space-3) ps-[calc(var(--neat-space-3)+2px)] pe-(--neat-space-3)";
  protected readonly listboxClasses = "col-span-full grid grid-cols-subgrid outline-none";
  protected readonly headerClasses = "col-span-full grid grid-cols-subgrid items-center -ms-[calc(var(--neat-space-3)+2px)] -me-(--neat-space-3) border-s-2 px-(--neat-space-3) sticky top-0 z-1 h-7 border-b border-s-transparent border-b-border bg-(--neat-surface) text-xs font-medium text-muted-foreground";
  protected readonly headerLabelClasses: Record<"start" | "end", string>;
  protected readonly cellClasses: Record<"start" | "end", string>;
  protected readonly groupClasses = "col-span-full grid grid-cols-subgrid";
  protected readonly separatorClasses = "col-span-full -ms-[calc(var(--neat-space-3)+2px)] -me-(--neat-space-3) h-(--neat-space-2) border-y border-border";
  protected readonly checkClasses: {
    readonly open: "flex size-4 shrink-0 items-center justify-center rounded-sm border border-input data-checked:border-primary data-checked:bg-primary cursor-pointer";
    readonly blocked: "flex size-4 shrink-0 items-center justify-center rounded-sm border border-input data-checked:border-primary data-checked:bg-primary cursor-not-allowed opacity-50";
  };
  private readonly id;
  protected readonly emptyId: string;
  protected readonly hintId: string;
  private readonly columns;
  private readonly listbox;
  private readonly scroller;
  /**
   * The list's own width in CSS pixels, watched only while a column has `hideBelow`; `null` until
   * then and while the list has no width (not laid out: hidden, or not in a document), when every
   * column shows.
   */
  private readonly width;
  private readonly hidesColumns;
  /** The columns shown at the list's width; a new list only when one comes or goes. */
  protected readonly visibleColumns: import("@angular/core").Signal<NeatColumn[]>;
  protected readonly hasHeader: import("@angular/core").Signal<boolean>;
  protected readonly gridColumns: import("@angular/core").Signal<string>;
  /**
   * The rows as shown and the sections they sit in, worked out as the inputs that shape them
   * change: each row's key, its tone's classes, in checked mode whether it has a box, and with
   * groups its group (calls of the app's functions), its index as shown, its id, its cells' context
   * and the heading it reveals. `trailingHeading` is the last empty group's heading, which End
   * reveals with the last row. Change detection then reads these and calls nothing.
   */
  private readonly layout;
  /** The rows in the order they are shown, which the keys move through. */
  protected readonly rows: import("@angular/core").Signal<readonly Row<T, K>[]>;
  protected readonly sections: import("@angular/core").Signal<readonly Section<T, K>[]>;
  protected readonly checkedKeys: import("@angular/core").Signal<Set<unknown>>;
  /**
   * The reasons the rows with a box cannot be checked now, by key. A block such as a cap depends on
   * the checks, so this reads `checked` and asks again whenever they change, even when the app's
   * function reads them from somewhere the list cannot see; never as the selection moves.
   */
  protected readonly blocked: import("@angular/core").Signal<Map<unknown, string>>;
  protected readonly isEmpty: import("@angular/core").Signal<boolean>;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  protected readonly selectedKey: import("@angular/core").Signal<K | typeof NONE>;
  private readonly selectedIndex;
  protected readonly activeId: import("@angular/core").Signal<string>;
  /**
   * The key of the row a Shift-click's range starts from: the one last clicked plainly, clicked
   * with Ctrl or Cmd, or checked by Space or its box. The arrow keys do not move it.
   */
  private anchor;
  /** The key of the row last scrolled to, so that a row that only moved is not scrolled to again. */
  private revealed;
  constructor();
  /**
   * Watches the list's width once a column has `hideBelow`, and never for a list without one. The
   * first width is read as soon as the list is rendered, so the first frame is laid out at it; a
   * resize then reports each change. The list is zoneless: setting the signal schedules the
   * render, and only a column coming or going changes what is drawn.
   */
  private watchWidthWhileNeeded;
  /** Scrolls the selected row into view unless that row was the last one scrolled to. */
  private revealSelected;
  /**
   * Scrolls the list's own area, and nothing else, by the least that brings the element in view,
   * below the sticky header. `scrollIntoView` would scroll every scrollable ancestor too, so a list
   * in a page, even one below the fold, would take the page along with it. The area is the
   * element's offset parent (it is positioned), so `offsetTop` is the element's place in it.
   */
  private reveal;
  /**
   * Scrolls back to the top, as a different set of rows (another folder) needs, or to the selected
   * row when there is one in the list. Call it once the new rows are rendered.
   */
  resetScroll(): void;
  /** Puts the keyboard focus on the list, where the arrow keys work. */
  focus(): void;
  protected onKeydown(event: KeyboardEvent): void;
  /** One listener on the listbox serves every row: the rows are found from the event's target. */
  protected onClick(event: MouseEvent): void;
  /**
   * A double click on a row tells `activated` in `double-click` mode. A click on a box or a control
   * is theirs, and a Ctrl, Cmd or Shift double click is the checking gestures' (see `onClick`),
   * which activate nothing.
   */
  protected onDoubleClick(event: MouseEvent): void;
  /** The second press of a double click would select the row's text; the row is not text. */
  protected onMousedown(event: MouseEvent): void;
  /** The row a pointer event on `target` is for, or null for a box, a control or no row. */
  private rowOf;
  private canToggle;
  /** Checks or unchecks a row that has a box; does nothing for one that has none or is blocked. */
  private toggle;
  /**
   * Checks the rows among these that have a box and are not blocked, and leaves the rest as they
   * are: no gesture over many rows unchecks one, or checks what a single click could not. The
   * blocks are those of now, asked once: a cap that the checks this makes would reach is not seen
   * until the app's `checkBlocked` changes, so a cap is also the app's to enforce on `checked`.
   */
  private checkAll;
  /**
   * The rows from the anchor to the row at `index`, both included, in the order shown. The anchor
   * is the row last clicked or checked, else the selected row, else the clicked row alone.
   */
  private rangeTo;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSelectList<any, any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSelectList<any, any>, "neat-select-list", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
    "trackBy": {
      "alias": "trackBy";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "checkable": {
      "alias": "checkable";
      "required": false;
      "isSignal": true;
    };
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "canCheck": {
      "alias": "canCheck";
      "required": false;
      "isSignal": true;
    };
    "checkBlocked": {
      "alias": "checkBlocked";
      "required": false;
      "isSignal": true;
    };
    "rowTone": {
      "alias": "rowTone";
      "required": false;
      "isSignal": true;
    };
    "groups": {
      "alias": "groups";
      "required": false;
      "isSignal": true;
    };
    "groupOf": {
      "alias": "groupOf";
      "required": false;
      "isSignal": true;
    };
    "emptyLabel": {
      "alias": "emptyLabel";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "activateOn": {
      "alias": "activateOn";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "checked": "checkedChange";
    "activated": "activated";
  }, ["columns"], never, true, never>;
}
export type { NeatActivateOn, NeatSelectListGroup };