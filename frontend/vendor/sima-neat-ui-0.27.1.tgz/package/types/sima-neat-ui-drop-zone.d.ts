import * as i0 from "@angular/core";
/**
 * A place to drop files, or to click for the system's file chooser:
 *
 * ```html
 * <neat-drop-zone label="Drop videos here or click to choose" accept="video/*" multiple
 *   (files)="upload($event)" />
 * ```
 *
 * `label` is the visible text and the accessible name. The zone is a native button: Tab focuses
 * it, Enter and Space (like a click) open the chooser. `files` emits the files that were dropped
 * or chosen, as one array per drop or choice. `multiple` allows several; without it, only the
 * first file is taken. `accept` is the native attribute's list (`video/*,.mkv`); the chooser
 * applies it itself, and the zone applies it to what is dropped, which the browser leaves
 * unfiltered. `rejected` emits the dropped files that were not taken (not allowed by `accept`,
 * or beyond the first without `multiple`), before `files` and even when `files` has nothing to
 * emit, so the app can say what it did not take. While `disabled` it does not react to clicks,
 * drags or drops.
 *
 * Files dragged over the zone light it up (`--primary` outline on an `--accent` tint). Only drags
 * that carry files do; text or a link dragged over it is ignored and the browser treats it as
 * anywhere else. The zone fills its container's width.
 *
 * The hidden file input is the chooser and stays out of the tab order and the accessibility tree:
 * the button is the control. Its value is cleared after each choice so that choosing the same file
 * again is a change.
 */
export declare class NeatDropZone {
  /** The visible text, and the accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Whether several files may be dropped or chosen at once. */
  readonly multiple: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The kinds of file to take, as the native `accept` attribute has it. */
  readonly accept: import("@angular/core").InputSignal<string | undefined>;
  /** Turns the zone off: it takes neither a drop nor a click to choose files. */
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The files that were dropped or chosen and taken, once per drop or choice. */
  readonly files: import("@angular/core").OutputEmitterRef<File[]>;
  /**
   * The dropped files that were left out, once per drop that left any out and before `files`:
   * those `accept` does not allow, and the ones after the first when `multiple` is off. An app
   * says why nothing (or not everything) was taken from this. Emitted even when `files` is not.
   */
  readonly rejected: import("@angular/core").OutputEmitterRef<File[]>;
  protected readonly zoneClasses: string;
  protected readonly dragActive: import("@angular/core").WritableSignal<boolean>;
  /**
   * How many elements of the zone the drag has entered and not left. Moving over the zone's own
   * children fires `dragenter` on the child before `dragleave` on the element it came from, so
   * the drag state ends when the count is back to zero, not at the first `dragleave`.
   */
  private entered;
  protected dragEnter(event: Event): void;
  protected dragOver(event: Event): void;
  protected dragLeave(event: Event): void;
  protected drop(event: Event): void;
  protected chosen(chooser: HTMLInputElement): void;
  private emit;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDropZone, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDropZone, "neat-drop-zone", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "files": "files";
    "rejected": "rejected";
  }, never, never, true, never>;
}