import * as i0 from "@angular/core";
/** What `NeatConfirm.ask` asks: the copy of the dialog and the weight of its confirm button. */
interface NeatConfirmOptions {
  /** The question, which names the dialog: "Reset all channels to global?". */
  title: string;
  /** What confirming does, which describes the dialog. */
  message: string;
  /** The confirm button's label, a verb for the action: "Reset". */
  confirmLabel: string;
  /** The cancel button's label; `'Cancel'` by default. */
  cancelLabel?: string;
  /** `'danger'` for an action that destroys or cannot be undone; `'default'` by default. */
  tone?: 'default' | 'danger';
}
/**
 * Helm's alert-dialog classes (`lib/ui/alert-dialog`), copied because helm keeps them inline.
 * confirm.spec checks that each string still appears in the vendored helm, so a helm update that
 * changes one fails until this table is reviewed.
 */
declare const CONFIRM_HELM_CLASSES: {
  /** `hlm-alert-dialog-content.ts`: the panel. */
  readonly content: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 bg-popover text-popover-foreground ring-foreground/10 gap-6 rounded-xl p-6 ring-1 duration-100 data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-lg group/alert-dialog-content grid w-full outline-none";
  /** `hlm-alert-dialog-header.ts`: title above message. */
  readonly header: "grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-6 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-start sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]";
  /** `hlm-alert-dialog-title.ts`. */
  readonly title: "text-lg font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2";
  /** `hlm-alert-dialog-description.ts`: the message. */
  readonly description: "text-muted-foreground *:[a]:hover:text-foreground text-sm text-balance md:text-pretty *:[a]:underline *:[a]:underline-offset-3";
  /** `hlm-alert-dialog-footer.ts`: the buttons, stacked on narrow screens. */
  readonly footer: "flex flex-col-reverse gap-2 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end";
  /** `hlm-alert-dialog-overlay.ts`: the backdrop over the page. */
  readonly overlay: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs";
};
/**
 * Asks the user to confirm an action before the app takes it:
 *
 * ```ts
 * if (await this.confirm.ask({ title: 'Reset all channels to global?', message: '…',
 *     confirmLabel: 'Reset', tone: 'danger' })) {
 *   this.store.resetAllChannels();
 * }
 * ```
 *
 * `ask` shows a modal alert dialog, named by the title and described by the message, with a cancel
 * and a confirm button. It resolves `true` when the confirm button is pressed and `false` on
 * cancel or Escape, once the dialog has closed and focus is back on the element that had it. A
 * click on the backdrop does nothing: the question needs an answer. Focus starts on cancel, the
 * choice that changes nothing, and stays inside the dialog. A `tone: 'danger'` confirm button is
 * the danger `neatButton`, otherwise the primary one.
 *
 * One question at a time: an `ask` while a dialog is open resolves that one `false` and closes it
 * at once, then shows the new one, which gives focus back where the first came from. A dialog
 * still closing after a button press keeps that answer.
 */
export declare class NeatConfirm {
  private readonly dialogs;
  private current;
  ask(options: NeatConfirmOptions): Promise<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatConfirm, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export type { NeatConfirmOptions };