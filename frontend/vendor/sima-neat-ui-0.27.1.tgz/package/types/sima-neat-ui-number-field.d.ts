import * as i0 from "@angular/core";
/**
 * A small field for one whole number, with its label before it: `<neat-number-field label="Page"
 * [value]="page" [accept]="inRange" (commit)="goTo($event)"><span neatNumberFieldSuffix>of
 * 9</span></neat-number-field>`. It is for jumping to a number, as a page or a channel.
 *
 * The field shows `value`. Typing changes nothing outside until the user commits with Enter or by
 * leaving the field; `commit` then carries the number if it is whole digits that `accept` takes,
 * even when it equals `value`, so an owner can treat a number the user typed as a choice. Anything
 * else puts `value` back in the field and emits nothing. Leaving a field that was not typed in
 * emits nothing, so tabbing past it chooses nothing; Enter always commits what is shown.
 *
 * The owner is expected to take what it accepted: after a commit the field shows that number
 * until `value` changes. Content marked `neatNumberFieldSuffix` follows the input, such as "of 9".
 */
export declare class NeatNumberField {
  /** Shown before the input, and its accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The number the field shows. */
  readonly value: import("@angular/core").InputSignal<number>;
  /** Whether the owner takes a whole number; the default takes any. */
  readonly accept: import("@angular/core").InputSignal<(n: number) => boolean>;
  /** A whole number the user committed and `accept` took. */
  readonly commit: import("@angular/core").OutputEmitterRef<number>;
  /** Whether the user typed since the field last showed `value` or committed. */
  protected edited: boolean;
  private readonly field;
  constructor();
  /**
   * Focuses the input with its number selected, so what the user types replaces it: for a
   * shortcut that jumps to the field, such as "g" for the page.
   */
  focus(): void;
  /**
   * Reads the field on Enter (`force`) or on leaving it: commits an accepted whole number, else
   * shows `value` again. Leaving an untouched field does nothing.
   */
  protected commitFrom(field: HTMLInputElement, force: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNumberField, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatNumberField, "neat-number-field", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
  }, {
    "commit": "commit";
  }, never, ["[neatNumberFieldSuffix]"], true, never>;
}