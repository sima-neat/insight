import * as i0 from "@angular/core";
/**
 * A data table's look (full width, a rule under every row, the column headings muted and small),
 * on a native `table` whose rows and cells the app writes:
 *
 * ```html
 * <table neatTable aria-label="Metrics of the run">
 *   <thead>
 *     <tr><th scope="col">Metric</th><th scope="col" neatNumeric>Mean</th></tr>
 *   </thead>
 *   <tbody>
 *     <tr><th scope="row">Power</th><td neatNumeric>12.5 W</td></tr>
 *   </tbody>
 * </table>
 * ```
 *
 * It sets the look only: the columns, what a cell holds and how a table gives up a column when
 * its container is narrow are the app's (the kit cannot know the container, or which columns
 * matter). The table's name for assistive technology is the app's too (`aria-label`).
 */
export declare class NeatTable {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTable, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTable, "table[neatTable]", never, {}, {}, never, never, true, never>;
}
/**
 * A figure's cell or heading, `th` or `td` of a `neatTable`, that keeps to one line with tabular
 * digits so that the figures of a column line up, and starts where any cell does. It only marks
 * the cell; the look is the table's, which is why the cell does nothing outside one. Use it where
 * the figures cannot end-align (a cell that holds something after the figure); otherwise use
 * `neatNumeric`.
 */
export declare class NeatFigure {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatFigure, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatFigure, "td[neatFigure], th[neatFigure]", never, {}, {}, never, never, true, never>;
}
/**
 * A figure's cell or heading as `neatFigure`, end-aligned as well. Put it on a column's heading
 * as well as on its cells so that the heading sits over the figures. It marks the cell as a
 * figure itself, so the cell needs no `neatFigure` beside it.
 */
export declare class NeatNumeric {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNumeric, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatNumeric, "td[neatNumeric], th[neatNumeric]", never, {}, {}, never, never, true, never>;
}