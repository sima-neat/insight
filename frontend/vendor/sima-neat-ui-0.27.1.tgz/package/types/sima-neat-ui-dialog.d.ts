import * as i0 from "@angular/core";
import { InputSignalWithTransform, Signal, TemplateRef, Type } from "@angular/core";
import { CdkPortalOutletAttachedRef, ComponentPortal, TemplatePortal } from "@angular/cdk/portal";
import { BrnDialogRef } from "@spartan-ng/brain/dialog";
/**
 * An open dialog, as the code that opened it and the dialog's own content see it. `NeatDialog.open`
 * returns it, and a component used as dialog content gets the same ref by injection:
 * `inject<NeatDialogRef<Result>>(NeatDialogRef)`. A template used as content gets it as the
 * template's implicit context: `<ng-template let-dialog>`.
 *
 * Only `NeatDialog` creates one.
 */
export declare abstract class NeatDialogRef<R = unknown> {
  /**
   * Settles once the dialog has closed and focus is back on the element that had it: with the
   * result given to `close`, or `undefined` when it was dismissed (Escape, the backdrop, the close
   * button) or closed by navigation. Navigating (the browser's Back button, a route change)
   * closes every dialog, dismissible or not; code that must not lose work to it has to guard the
   * navigation itself.
   */
  abstract readonly closed: Promise<R | undefined>;
  /** Whether Escape, the backdrop and the close button close the dialog right now. */
  abstract readonly dismissible: Signal<boolean>;
  /**
   * Closes the dialog; `closed` settles with the result. Closing a dialog that is already closing
   * changes nothing, so the first result stands.
   */
  abstract close(result?: R): void;
  /**
   * Allows or blocks closing from outside the dialog's own controls: while `false`, Escape and a
   * click on the backdrop do nothing and the close button is dimmed (`aria-disabled`) and does
   * nothing. For a dialog that is busy and would lose work if it closed; `close()` still works,
   * since the code that is busy calls it. Navigation still closes it (see `closed`).
   */
  abstract setDismissible(dismissible: boolean): void;
}
/** What `NeatDialog` gives a ref when it opens a dialog. */
interface DialogRefInit<R> {
  /** Whether Escape, the backdrop and the close button close the dialog to begin with. */
  readonly dismissible: boolean;
  /** Starts closing the dialog with the result. */
  readonly close: (result?: R) => void;
  /** Settles once the dialog has closed and focus is back on the element that had it. */
  readonly closed: Promise<R | undefined>;
}
/** The ref `NeatDialog` hands out; not exported by the entry. */
declare class DialogRefImpl<R> extends NeatDialogRef<R> {
  private readonly dismissibleState;
  private readonly closeDialog;
  readonly closed: Promise<R | undefined>;
  readonly dismissible: Signal<boolean>;
  constructor(init: DialogRefInit<R>);
  close(result?: R): void;
  setDismissible(dismissible: boolean): void;
}
/** How wide the dialog is on screens wider than a phone: 24, 32 and 48 rem. */
type NeatDialogSize = 'small' | 'medium' | 'large';
/**
 * Helm's dialog classes (`lib/ui/dialog`), copied because helm keeps them inline. dialog.spec
 * checks that each string still appears in the vendored helm, so a helm update that changes one
 * fails until this table is reviewed.
 */
declare const DIALOG_HELM_CLASSES: {
  /** `hlm-dialog-content.ts`: the panel. */
  readonly content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 ring-foreground/10 grid max-w-[calc(100%-2rem)] gap-6 rounded-xl p-6 text-sm ring-1 duration-100 sm:max-w-md relative mx-auto w-full outline-none sm:mx-0";
  /** `hlm-dialog-content.ts`: where the close button sits, in the panel's corner. */
  readonly closeButton: "absolute end-4 top-4";
  /** `hlm-dialog-header.ts`: the title's row. */
  readonly header: "gap-2 flex flex-col";
  /** `hlm-dialog-title.ts`. */
  readonly title: "leading-none font-medium";
  /** `hlm-dialog-footer.ts`: the buttons, stacked on narrow screens. */
  readonly footer: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end";
  /** `hlm-dialog-overlay.ts`: the backdrop over the page. */
  readonly overlay: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs";
};
/** What `NeatDialog` hands the panel through the brain dialog's context. */
interface DialogContext {
  readonly title: string;
  readonly size: NeatDialogSize;
  readonly content: TemplateRef<unknown> | Type<unknown>;
  /** A component's input values by name; empty for a template. */
  readonly inputs: Readonly<Record<string, unknown>>;
  readonly ref: NeatDialogRef;
}
/**
 * The dialog's frame, rendered by `NeatDialog` inside the CDK dialog container, which carries the
 * role, the modal state and the focus trap: the title, the content the app gave, and the close
 * button, which stays (marked `aria-disabled`) while the dialog is not dismissible, so that focus
 * on it is not lost when the dialog turns busy.
 *
 * Closing from outside is the kit's rather than brain's: brain reads "may this close" once, when
 * the dialog opens, and `setDismissible` changes it later. The dialog opens with brain's closing
 * switched off, and the panel closes it on Escape and a backdrop click while `ref.dismissible()`.
 */
declare class NeatDialogPanel {
  protected readonly brain: BrnDialogRef<unknown>;
  protected readonly context: DialogContext;
  protected readonly ref: NeatDialogRef<unknown>;
  protected readonly classes: {
    /** `hlm-dialog-content.ts`: the panel. */
    readonly content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 ring-foreground/10 grid max-w-[calc(100%-2rem)] gap-6 rounded-xl p-6 text-sm ring-1 duration-100 sm:max-w-md relative mx-auto w-full outline-none sm:mx-0";
    /** `hlm-dialog-content.ts`: where the close button sits, in the panel's corner. */
    readonly closeButton: "absolute end-4 top-4";
    /** `hlm-dialog-header.ts`: the title's row. */
    readonly header: "gap-2 flex flex-col";
    /** `hlm-dialog-title.ts`. */
    readonly title: "leading-none font-medium";
    /** `hlm-dialog-footer.ts`: the buttons, stacked on narrow screens. */
    readonly footer: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end";
    /** `hlm-dialog-overlay.ts`: the backdrop over the page. */
    readonly overlay: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs";
  };
  protected readonly panelClasses: string;
  /**
   * Helm's corner position. While the dialog is not dismissible the button is `aria-disabled`,
   * which `neatButton` dims, rather than removed or `disabled`: a button that has focus loses it
   * when it goes, and the trap only works from inside the dialog, so the next Tab would leave for
   * the page behind.
   */
  protected readonly closeButtonClasses: "absolute end-4 top-4";
  protected readonly content: ComponentPortal<unknown> | TemplatePortal<unknown>;
  constructor();
  /** Closes the dialog if it may be closed from outside; returns whether it did. */
  protected dismiss(): boolean;
  /**
   * A component's own element is the panel's flex item otherwise, and its body and actions would
   * sit inside it, out of the panel's flex column: no gap between them and no scrolling body.
   * `display: contents` takes the element out of the layout so that they are the panel's items.
   * It is set inline, where the content's own `:host { display: block }` (unlayered component CSS,
   * which beats any Tailwind utility) cannot undo it.
   */
  protected laidOutWithThePanel(attached: CdkPortalOutletAttachedRef): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDialogPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDialogPanel, "neat-dialog-panel", never, {}, {}, never, never, true, never>;
}
/** What `NeatDialog.open` takes besides the content. */
interface NeatDialogOptions {
  /** Names the dialog: "Assign source". Shown as its heading. */
  title: string;
  /** The dialog's width on screens wider than a phone; `'medium'` by default. */
  size?: NeatDialogSize;
  /**
   * Whether Escape, a click on the backdrop and the close button close the dialog; `true` by
   * default. `NeatDialogRef.setDismissible` changes it while the dialog is open.
   */
  dismissible?: boolean;
}
/**
 * The inputs of a component `C` that `NeatDialog.open` can set: each signal input (`input()`,
 * `input.required()`, and `model()`, which is one too) by its property name, with the type it
 * takes. All are optional here, since the type cannot tell a required input from one with a
 * default; a required one left out fails when the component reads it, as it would in a template.
 *
 * Do not alias an input of a dialog component (`input(…, { alias })`): the type names inputs by
 * property, Angular binds them by alias, and an aliased one passed here throws as the dialog
 * opens. The alias lives in the component's metadata, out of the type's reach.
 */
type NeatDialogInputs<C> = { readonly [K in keyof C as [InputValue<C[K]>] extends [never] ? never : K]?: InputValue<C[K]>; };
/**
 * What a signal input takes when it is set; `never` for a member that is no signal input. The read
 * type is inferred though unused: the input's node holds it both ways (a value out, a value in),
 * so a fixed `unknown` in its place would match no input at all.
 */
type InputValue<S> = S extends InputSignalWithTransform<infer Read, infer Write> ? Write : never;
/** What `NeatDialog.open` takes for a component whose inputs the opener sets. */
interface NeatDialogComponentOptions<C> extends NeatDialogOptions {
  /**
   * Values for the component's inputs, set as it is created, before its first change detection,
   * as a template's bindings would be: the component sees them in its template, in `computed`
   * and `linkedSignal`, and from `ngOnInit` on, but not in a field initializer or its constructor.
   * They are set once; the dialog does not follow later changes.
   */
  readonly inputs: NeatDialogInputs<C>;
}
/**
 * Opens modal dialogs whose content is the app's own:
 *
 * ```ts
 * const dialog = this.dialogs.open<string>(this.renameForm, { title: 'Rename source' });
 * const name = await dialog.closed; // undefined if it was dismissed
 * ```
 *
 * The content is a template or a component. It is rendered under the title the options name the
 * dialog by, and is built from `<neat-dialog-body>` (the part that scrolls) and
 * `<neat-dialog-actions>` (the buttons). It gets the `NeatDialogRef`, to close the dialog with a
 * result or to block dismissing it while it is busy: a template as its implicit context
 * (`<ng-template let-dialog>`), a component by injection.
 *
 * A component can take inputs from the opener, typed by the component (a template needs none: it
 * sees the opener's own fields):
 *
 * ```ts
 * const dialog = this.dialogs.open<ImportDialog, string | null>(ImportDialog, {
 *   title: 'Import media',
 *   inputs: { openingTab: 'youtube' },
 * });
 * ```
 *
 * With `inputs` the type arguments are the component's, then the result's; both are inferred when
 * none is given, the result as `unknown`.
 *
 * The dialog is modal: focus moves into it and stays inside, the page behind is hidden from
 * assistive technology, and Escape or a click on the backdrop close it while it is dismissible.
 * On closing, focus goes back to the element that had it on opening. Dialogs can stack; Escape
 * closes the topmost, and a handled Escape stops there: it never reaches `document` or `window`
 * listeners. Navigation (the browser's Back button, a route change) closes a dialog even when it
 * is not dismissible, and `closed` then settles with `undefined`. For a yes/no question use
 * `NeatConfirm`, which this does not replace.
 *
 * In kiosk mode a dialog does not hold the floating toolbar (as `neat-popover` does): the dialog
 * covers the page, and the toolbar behind it fading is as it should be. Closing returns focus to
 * the button in the toolbar, which shows the toolbar again.
 */
export declare class NeatDialog {
  private readonly dialogs;
  open<R = unknown>(content: TemplateRef<unknown> | Type<unknown>, options: NeatDialogOptions): NeatDialogRef<R>;
  open<C, R = unknown>(content: Type<C>, options: NeatDialogComponentOptions<C>): NeatDialogRef<R>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDialog, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The dialog's content between the title and the actions: `<neat-dialog-body>`. It is the part
 * that scrolls when the content is taller than the screen allows, so the title and the actions
 * stay in view. The negative margin and equal padding keep the focus ring of a control at its edge
 * from being clipped by that scrolling.
 */
export declare class NeatDialogBody {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDialogBody, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDialogBody, "neat-dialog-body", never, {}, {}, never, ["*"], true, never>;
}
/**
 * The dialog's buttons: `<neat-dialog-actions>` under the body, the cancelling button first and the
 * confirming one last. Helm's footer: a row at the end on wide screens; stacked on narrow ones,
 * with the confirming button on top.
 */
export declare class NeatDialogActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDialogActions, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDialogActions, "neat-dialog-actions", never, {}, {}, never, ["*"], true, never>;
}
export type { NeatDialogComponentOptions, NeatDialogInputs, NeatDialogOptions, NeatDialogSize };