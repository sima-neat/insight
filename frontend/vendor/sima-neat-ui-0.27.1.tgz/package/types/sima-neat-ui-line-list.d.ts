import * as i0 from "@angular/core";
/**
 * A short list of small lines under a thin rule, such as the channels that override a setting:
 * `<ul neatLineList><li neatLine>Channel 3 <button neatInlineButton neatLineEnd>Use global</button></li></ul>`.
 * It sets the look only (the rule, the inset, the text size); a line's content, and the roles of
 * the list, are the app's. The text colour is the parent's.
 */
export declare class NeatLineList {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatLineList, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatLineList, "ul[neatLineList], ol[neatLineList]", never, {}, {}, never, never, true, never>;
}
/**
 * One line of a `neatLineList`: a flex row, so its parts sit side by side, at least 1.5rem high so
 * that the buttons of neighbouring lines keep their distance.
 */
export declare class NeatLine {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatLine, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatLine, "li[neatLine]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks the element of a `neatLine` that sits at the line's end, such as its action (usually a
 * `neatInlineButton`): it is pushed there, whatever the text before it takes.
 */
export declare class NeatLineEnd {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatLineEnd, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatLineEnd, "[neatLineEnd]", never, {}, {}, never, never, true, never>;
}