import { NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, input } from "@angular/core";
import { BrnProgress, BrnProgressIndicator } from "@spartan-ng/brain/progress";
import { ɵhlm } from "@sima/neat-ui";
const PROGRESS_HELM_CLASSES = {
	track: "bg-muted h-1.5 rounded-full relative inline-flex w-full overflow-hidden",
	indicator: "bg-primary h-full w-full flex-1 transition-all"
};
const TRACK_CLASSES = ɵhlm(PROGRESS_HELM_CLASSES.track, "flex", "ring-1 ring-input");
const INDICATOR_CLASSES = PROGRESS_HELM_CLASSES.indicator.replace(" transition-all", "");
const INDETERMINATE_CLASSES = `animate-indeterminate motion-reduce:animate-none motion-reduce:bg-transparent motion-reduce:bg-[repeating-linear-gradient(135deg,var(--primary)_0_6px,transparent_6px_12px)]`;
const READOUT_CLASSES = "flex flex-col gap-(--neat-space-2) text-(length:--neat-text-sm)";
const TITLE_CLASSES = "m-0 flex justify-between gap-(--neat-space-3) font-medium tabular-nums";
const DETAIL_CLASSES = "m-0 truncate text-muted-foreground tabular-nums text-(length:--neat-text-xs)";
var NeatProgress = class NeatProgress {
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	heading = input("", ...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	detail = input("", ...ngDevMode ? [{ debugName: "detail" }] : /* istanbul ignore next */ []);
	trackClasses = TRACK_CLASSES;
	readoutClasses = READOUT_CLASSES;
	titleClasses = TITLE_CLASSES;
	detailClasses = DETAIL_CLASSES;
	shown = computed(() => {
		const value = this.value();
		return value === null || !Number.isFinite(value) ? null : Math.min(100, Math.max(0, value));
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	percent = computed(() => {
		const shown = this.shown();
		return shown === null ? null : Math.round(shown);
	}, ...ngDevMode ? [{ debugName: "percent" }] : /* istanbul ignore next */ []);
	indicatorClasses = computed(() => ɵhlm(INDICATOR_CLASSES, this.shown() === null ? INDETERMINATE_CLASSES : ""), ...ngDevMode ? [{ debugName: "indicatorClasses" }] : /* istanbul ignore next */ []);
	transform = computed(() => `translateX(-${100 - (this.shown() ?? 100)}%)`, ...ngDevMode ? [{ debugName: "transform" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatProgress,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatProgress,
		isStandalone: true,
		selector: "neat-progress",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			heading: {
				classPropertyName: "heading",
				publicName: "heading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			detail: {
				classPropertyName: "detail",
				publicName: "detail",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "block" },
		ngImport: i0,
		template: `
    <ng-template #bar>
      <brn-progress
        data-slot="progress"
        [class]="trackClasses"
        [value]="shown()"
        [attr.aria-label]="label() || heading()"
      >
        <brn-progress-indicator
          data-slot="progress-indicator"
          [class]="indicatorClasses()"
          [style.transform]="transform()"
        />
      </brn-progress>
    </ng-template>
    @if (heading()) {
      <div data-slot="progress-readout" [class]="readoutClasses">
        <p data-slot="progress-title" [class]="titleClasses">
          <span role="status" class="min-w-0 truncate" [attr.title]="heading()">{{
            heading()
          }}</span>
          @if (percent() !== null) {
            <span>{{ percent() }}%</span>
          }
        </p>
        @if (detail()) {
          <p data-slot="progress-detail" [class]="detailClasses" [attr.title]="detail()">
            {{ detail() }}
          </p>
        }
        <ng-container [ngTemplateOutlet]="bar" />
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="bar" />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnProgress,
				selector: "brn-progress",
				inputs: [
					"value",
					"max",
					"getValueLabel"
				],
				exportAs: ["brnProgress"]
			},
			{
				kind: "directive",
				type: BrnProgressIndicator,
				selector: "brn-progress-indicator",
				exportAs: ["brnProgressIndicator"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatProgress,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-progress",
			imports: [
				BrnProgress,
				BrnProgressIndicator,
				NgTemplateOutlet
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "block" },
			template: `
    <ng-template #bar>
      <brn-progress
        data-slot="progress"
        [class]="trackClasses"
        [value]="shown()"
        [attr.aria-label]="label() || heading()"
      >
        <brn-progress-indicator
          data-slot="progress-indicator"
          [class]="indicatorClasses()"
          [style.transform]="transform()"
        />
      </brn-progress>
    </ng-template>
    @if (heading()) {
      <div data-slot="progress-readout" [class]="readoutClasses">
        <p data-slot="progress-title" [class]="titleClasses">
          <span role="status" class="min-w-0 truncate" [attr.title]="heading()">{{
            heading()
          }}</span>
          @if (percent() !== null) {
            <span>{{ percent() }}%</span>
          }
        </p>
        @if (detail()) {
          <p data-slot="progress-detail" [class]="detailClasses" [attr.title]="detail()">
            {{ detail() }}
          </p>
        }
        <ng-container [ngTemplateOutlet]="bar" />
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="bar" />
    }
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		heading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "heading",
				required: false
			}]
		}],
		detail: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "detail",
				required: false
			}]
		}]
	}
});
export { NeatProgress };

//# sourceMappingURL=sima-neat-ui-progress.mjs.map