import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, model, viewChildren } from "@angular/core";
import { NeatIcon } from "@sima/neat-ui";
const GROUP_CLASSES = "relative isolate inline-grid grid-flow-col auto-cols-fr rounded-lg bg-neat-segmented-track p-0.5 aria-disabled:opacity-50";
const THUMB_CLASSES = "pointer-events-none absolute inset-y-0.5 left-0.5 z-0 w-[calc((100%-4px)/var(--neat-segmented-count))] translate-x-[calc(var(--neat-segmented-index)*100%)] rounded-md bg-neat-segmented-thumb shadow-sm ring-1 ring-neat-segmented-thumb-edge transition-transform duration-280 ease-[cubic-bezier(.3,.7,.2,1)] motion-reduce:transition-none";
const ITEM_CLASSES = "relative z-10 inline-flex h-7 cursor-pointer items-center justify-center gap-1.5 rounded-md bg-transparent px-3.5 text-sm font-medium whitespace-nowrap text-foreground outline-none transition-colors duration-200 motion-reduce:transition-none disabled:pointer-events-none focus-visible:z-20 focus-visible:ring-[3px] focus-visible:ring-ring data-[state=on]:font-semibold data-[state=on]:text-primary before:absolute before:inset-y-1.5 before:left-0 before:w-px before:bg-muted-foreground/40 before:transition-opacity before:duration-200 motion-reduce:before:transition-none first-of-type:before:hidden data-[state=on]:before:opacity-0 [[data-state=on]+&]:before:opacity-0";
const MOVES = {
	ArrowRight: (index, count) => (index + 1) % count,
	ArrowDown: (index, count) => (index + 1) % count,
	ArrowLeft: (index, count) => (index - 1 + count) % count,
	ArrowUp: (index, count) => (index - 1 + count) % count,
	Home: () => 0,
	End: (_, count) => count - 1
};
var NeatSegmented = class NeatSegmented {
	value = model.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	groupClasses = GROUP_CLASSES;
	thumbClasses = THUMB_CLASSES;
	itemClasses = ITEM_CLASSES;
	chosen = computed(() => this.options().findIndex((option) => option.value === this.value()), ...ngDevMode ? [{ debugName: "chosen" }] : /* istanbul ignore next */ []);
	tabStop = computed(() => Math.max(0, this.chosen()), ...ngDevMode ? [{ debugName: "tabStop" }] : /* istanbul ignore next */ []);
	segments = viewChildren("segment", ...ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []);
	focus() {
		this.segments()[this.tabStop()]?.nativeElement.focus();
	}
	move(event, current) {
		const next = MOVES[event.key];
		if (!next || this.disabled()) return;
		event.preventDefault();
		const options = this.options();
		const index = next(current, options.length);
		this.value.set(options[index].value);
		this.segments()[index]?.nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSegmented,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSegmented,
		isStandalone: true,
		selector: "neat-segmented",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { classAttribute: "inline-flex max-w-full shrink-0" },
		viewQueries: [{
			propertyName: "segments",
			predicate: ["segment"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      role="radiogroup"
      [attr.aria-label]="label()"
      [attr.aria-disabled]="disabled() || null"
      data-orientation="horizontal"
      [style.--neat-segmented-count]="options().length"
      [style.--neat-segmented-index]="tabStop()"
      [class]="groupClasses"
    >
      @if (chosen() >= 0) {
        <span aria-hidden="true" data-slot="segmented-thumb" [class]="thumbClasses"></span>
      }
      @for (option of options(); track option.value; let index = $index) {
        <button
          #segment
          type="button"
          role="radio"
          [attr.aria-checked]="option.value === value()"
          [attr.data-state]="option.value === value() ? 'on' : 'off'"
          [tabIndex]="index === tabStop() ? 0 : -1"
          [disabled]="disabled()"
          [class]="itemClasses"
          (click)="value.set(option.value)"
          (keydown)="move($event, index)"
        >
          @if (option.icon) {
            <neat-icon [name]="option.icon" [size]="16" />
          }
          <span data-slot="segmented-label" class="inline-grid min-w-0 grid-cols-1 text-center">
            <span class="col-start-1 row-start-1 truncate" [attr.title]="option.label">{{
              option.label
            }}</span>
            <span
              aria-hidden="true"
              data-slot="segmented-label-reserve"
              class="invisible col-start-1 row-start-1 truncate font-semibold"
              >{{ option.label }}</span
            >
          </span>
        </button>
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSegmented,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-segmented",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "inline-flex max-w-full shrink-0" },
			template: `
    <div
      role="radiogroup"
      [attr.aria-label]="label()"
      [attr.aria-disabled]="disabled() || null"
      data-orientation="horizontal"
      [style.--neat-segmented-count]="options().length"
      [style.--neat-segmented-index]="tabStop()"
      [class]="groupClasses"
    >
      @if (chosen() >= 0) {
        <span aria-hidden="true" data-slot="segmented-thumb" [class]="thumbClasses"></span>
      }
      @for (option of options(); track option.value; let index = $index) {
        <button
          #segment
          type="button"
          role="radio"
          [attr.aria-checked]="option.value === value()"
          [attr.data-state]="option.value === value() ? 'on' : 'off'"
          [tabIndex]="index === tabStop() ? 0 : -1"
          [disabled]="disabled()"
          [class]="itemClasses"
          (click)="value.set(option.value)"
          (keydown)="move($event, index)"
        >
          @if (option.icon) {
            <neat-icon [name]="option.icon" [size]="16" />
          }
          <span data-slot="segmented-label" class="inline-grid min-w-0 grid-cols-1 text-center">
            <span class="col-start-1 row-start-1 truncate" [attr.title]="option.label">{{
              option.label
            }}</span>
            <span
              aria-hidden="true"
              data-slot="segmented-label-reserve"
              class="invisible col-start-1 row-start-1 truncate font-semibold"
              >{{ option.label }}</span
            >
          </span>
        </button>
      }
    </div>
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		segments: [{
			type: i0.ViewChildren,
			args: ["segment", { isSignal: true }]
		}]
	}
});
export { NeatSegmented };

//# sourceMappingURL=sima-neat-ui-segmented.mjs.map