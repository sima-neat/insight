import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ElementRef, afterRenderEffect, contentChild, input } from "@angular/core";
import { NeatNote, ɵFIELD_LABEL_CLASSES } from "@sima/neat-ui";
import { NeatInput } from "@sima/neat-ui/input";
const ERROR_NOTE_CLASSES = "block text-destructive text-(length:--neat-text-sm) whitespace-pre-line wrap-anywhere";
var NeatErrorNote = class NeatErrorNote {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatErrorNote,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatErrorNote,
		isStandalone: true,
		selector: "neat-error-note",
		host: {
			attributes: {
				"role": "alert",
				"data-slot": "error-note"
			},
			classAttribute: "block text-destructive text-(length:--neat-text-sm) whitespace-pre-line wrap-anywhere"
		},
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatErrorNote,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-error-note",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				role: "alert",
				"data-slot": "error-note",
				class: ERROR_NOTE_CLASSES
			},
			template: "<ng-content />"
		}]
	}]
});
let nextFieldId = 0;
function setAttribute(element, name, value) {
	if (value === null) element.removeAttribute(name);
	else element.setAttribute(name, value);
}
var NeatField = class NeatField {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	hint = input("", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	error = input("", ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	classes = ɵFIELD_LABEL_CLASSES;
	id = ++nextFieldId;
	hintId = `neat-field-${this.id}-hint`;
	errorId = `neat-field-${this.id}-error`;
	control = contentChild(NeatInput, {
		...ngDevMode ? { debugName: "control" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	constructor() {
		afterRenderEffect(() => {
			const hint = this.hint();
			const error = this.error();
			const control = this.control()?.nativeElement;
			if (!control) return;
			setAttribute(control, "aria-describedby", [hint ? this.hintId : "", error ? this.errorId : ""].filter(Boolean).join(" ") || null);
			setAttribute(control, "aria-invalid", error ? "true" : null);
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatField,
		isStandalone: true,
		selector: "neat-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "field" },
			classAttribute: "flex flex-col gap-(--neat-space-2)"
		},
		queries: [{
			propertyName: "control",
			first: true,
			predicate: NeatInput,
			descendants: true,
			read: ElementRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <!-- eslint-disable-next-line @angular-eslint/template/label-has-associated-control -->
    <label [class]="classes.stack">
      <span [class]="classes.label">{{ label() }}</span>
      <ng-content />
    </label>
    @if (hint()) {
      <p neatNote [id]="hintId">{{ hint() }}</p>
    }
    @if (error()) {
      <neat-error-note [id]="errorId">{{ error() }}</neat-error-note>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatErrorNote,
			selector: "neat-error-note"
		}, {
			kind: "directive",
			type: NeatNote,
			selector: "[neatNote]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatField,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-field",
			imports: [NeatErrorNote, NeatNote],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "field",
				class: "flex flex-col gap-(--neat-space-2)"
			},
			template: `
    <!-- eslint-disable-next-line @angular-eslint/template/label-has-associated-control -->
    <label [class]="classes.stack">
      <span [class]="classes.label">{{ label() }}</span>
      <ng-content />
    </label>
    @if (hint()) {
      <p neatNote [id]="hintId">{{ hint() }}</p>
    }
    @if (error()) {
      <neat-error-note [id]="errorId">{{ error() }}</neat-error-note>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}],
		control: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatInput), {
				read: ElementRef,
				isSignal: true
			}]
		}]
	}
});
export { NeatErrorNote, NeatField };

//# sourceMappingURL=sima-neat-ui-field.mjs.map