import * as i0 from "@angular/core";
import { Directive } from "@angular/core";
const TABLE_CLASSES = "w-full border-collapse text-(length:--neat-text-sm) [&_:where(th,td)]:px-(--neat-space-3) [&_:where(th,td)]:py-(--neat-space-2) [&_:where(th,td)]:border-be [&_:where(th,td)]:border-border [&_:where(th,td)]:align-middle [&_:where(th,td):where(:not([data-numeric]))]:text-start [&_:where([data-numeric])]:text-end [&_:where([data-figure])]:whitespace-nowrap [&_:where([data-figure])]:tabular-nums [&_:where(th)]:font-medium [&_:where(thead_th)]:text-muted-foreground [&_:where(thead_th)]:text-(length:--neat-text-xs)";
var NeatTable = class NeatTable {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTable,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatTable,
		isStandalone: true,
		selector: "table[neatTable]",
		host: { classAttribute: "w-full border-collapse text-(length:--neat-text-sm) [&_:where(th,td)]:px-(--neat-space-3) [&_:where(th,td)]:py-(--neat-space-2) [&_:where(th,td)]:border-be [&_:where(th,td)]:border-border [&_:where(th,td)]:align-middle [&_:where(th,td):where(:not([data-numeric]))]:text-start [&_:where([data-numeric])]:text-end [&_:where([data-figure])]:whitespace-nowrap [&_:where([data-figure])]:tabular-nums [&_:where(th)]:font-medium [&_:where(thead_th)]:text-muted-foreground [&_:where(thead_th)]:text-(length:--neat-text-xs)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTable,
	decorators: [{
		type: Directive,
		args: [{
			selector: "table[neatTable]",
			host: { class: TABLE_CLASSES }
		}]
	}]
});
var NeatFigure = class NeatFigure {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatFigure,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatFigure,
		isStandalone: true,
		selector: "td[neatFigure], th[neatFigure]",
		host: { attributes: { "data-figure": "" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatFigure,
	decorators: [{
		type: Directive,
		args: [{
			selector: "td[neatFigure], th[neatFigure]",
			host: { "data-figure": "" }
		}]
	}]
});
var NeatNumeric = class NeatNumeric {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatNumeric,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatNumeric,
		isStandalone: true,
		selector: "td[neatNumeric], th[neatNumeric]",
		host: { attributes: {
			"data-figure": "",
			"data-numeric": ""
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatNumeric,
	decorators: [{
		type: Directive,
		args: [{
			selector: "td[neatNumeric], th[neatNumeric]",
			host: {
				"data-figure": "",
				"data-numeric": ""
			}
		}]
	}]
});
export { NeatFigure, NeatNumeric, NeatTable };

//# sourceMappingURL=sima-neat-ui-table.mjs.map