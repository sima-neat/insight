import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, ElementRef, Injector, TemplateRef, afterNextRender, contentChild, effect, inject, input, model, untracked } from "@angular/core";
import { DOCUMENT, NgTemplateOutlet } from "@angular/common";
import * as i1 from "@spartan-ng/brain/popover";
import { BrnPopover, BrnPopoverContent, provideBrnPopoverConfig, provideBrnPopoverDefaultOptions } from "@spartan-ng/brain/popover";
import { KioskService, ɵIN_PAGE_TOOLBAR, ɵOverlayFocus, ɵPANEL_SURFACE_CLASSES, ɵhlm } from "@sima/neat-ui";
const PANEL_CLASSES = ɵhlm(ɵPANEL_SURFACE_CLASSES, "[--neat-popover-inset:var(--neat-space-4)] p-(--neat-popover-inset) gap-(--neat-popover-inset)");
const ITEM_CLASSES = "-mx-(--neat-popover-inset) -my-[calc(var(--neat-popover-inset)/2)] block cursor-pointer px-(--neat-popover-inset) py-2 text-left text-sm text-foreground outline-hidden enabled:hover:bg-accent focus-visible:bg-accent focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring disabled:cursor-default disabled:text-muted-foreground";
const DIVIDER_CLASSES = "-mx-(--neat-popover-inset) -my-[calc(var(--neat-popover-inset)/4)] border-t border-border";
const SIDE_OFFSET = 4;
let nextPopoverId = 0;
var NeatPopoverContent = class NeatPopoverContent {
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopoverContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPopoverContent,
		isStandalone: true,
		selector: "ng-template[neatPopoverContent]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopoverContent,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatPopoverContent]" }]
	}]
});
var NeatPopoverTrigger = class NeatPopoverTrigger {
	popover = inject(NeatPopover);
	element = inject(ElementRef).nativeElement;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopoverTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPopoverTrigger,
		isStandalone: true,
		selector: "button[neatPopoverTrigger]",
		host: {
			attributes: {
				"type": "button",
				"aria-haspopup": "dialog"
			},
			listeners: { "click": "popover.toggle()" },
			properties: {
				"attr.aria-expanded": "popover.open()",
				"attr.aria-controls": "popover.open() ? popover.panelId : null"
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopoverTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatPopoverTrigger]",
			host: {
				type: "button",
				"aria-haspopup": "dialog",
				"[attr.aria-expanded]": "popover.open()",
				"[attr.aria-controls]": "popover.open() ? popover.panelId : null",
				"(click)": "popover.toggle()"
			}
		}]
	}]
});
var NeatPopoverItem = class NeatPopoverItem {
	itemClasses = ITEM_CLASSES;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopoverItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPopoverItem,
		isStandalone: true,
		selector: "button[neatPopoverItem]",
		host: { properties: { "class": "itemClasses" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopoverItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatPopoverItem]",
			host: { "[class]": "itemClasses" }
		}]
	}]
});
var NeatPopoverDivider = class NeatPopoverDivider {
	dividerClasses = DIVIDER_CLASSES;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopoverDivider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPopoverDivider,
		isStandalone: true,
		selector: "hr[neatPopoverDivider]",
		host: {
			attributes: { "role": "separator" },
			properties: { "class": "dividerClasses" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopoverDivider,
	decorators: [{
		type: Directive,
		args: [{
			selector: "hr[neatPopoverDivider]",
			host: {
				role: "separator",
				"[class]": "dividerClasses"
			}
		}]
	}]
});
var NeatPopover = class NeatPopover {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	panelId = `neat-popover-${++nextPopoverId}`;
	panelClasses = PANEL_CLASSES;
	brain = inject(BrnPopover);
	content = contentChild.required(NeatPopoverContent, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	trigger = contentChild.required(NeatPopoverTrigger, ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	focus = new ɵOverlayFocus(() => this.trigger().element, () => this.open.set(false));
	document = inject(DOCUMENT);
	injector = inject(Injector);
	constructor() {
		this.brain.stateChanged.subscribe((state) => this.open.set(state === "open"));
		effect(() => {
			const open = this.open();
			untracked(() => open ? this.show() : this.brain.close());
		});
		effect((onCleanup) => {
			if (this.open()) onCleanup(this.focus.watchOutsideFocus());
		});
		const kiosk = inject(KioskService);
		if (inject(ɵIN_PAGE_TOOLBAR)) effect((onCleanup) => {
			if (this.open() && kiosk.active()) onCleanup(kiosk.holdToolbar());
		});
	}
	toggle() {
		this.open.update((open) => !open);
	}
	carryTabOrder(event) {
		this.focus.carryTabOrder(event, event.currentTarget);
	}
	show() {
		const trigger = this.trigger().element;
		trigger.focus({ preventScroll: true });
		this.brain.setOrigin(trigger);
		this.brain.open();
		afterNextRender(() => {
			if (this.open()) this.focus.focusFirstControl(this.document.getElementById(this.panelId));
		}, { injector: this.injector });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopover,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatPopover,
		isStandalone: true,
		selector: "neat-popover",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: { classAttribute: "contents" },
		providers: [provideBrnPopoverConfig({ sideOffset: SIDE_OFFSET }), provideBrnPopoverDefaultOptions({
			role: null,
			autoFocus: false
		})],
		queries: [{
			propertyName: "content",
			first: true,
			predicate: NeatPopoverContent,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "trigger",
			first: true,
			predicate: NeatPopoverTrigger,
			descendants: true,
			isSignal: true
		}],
		hostDirectives: [{
			directive: i1.BrnPopover,
			inputs: ["align", "align"]
		}],
		ngImport: i0,
		template: `
    <ng-content />
    <ng-template brnPopoverContent>
      <div
        role="dialog"
        [id]="panelId"
        [attr.aria-label]="label()"
        [attr.data-state]="brain.stateComputed()"
        [class]="panelClasses"
        (keydown)="carryTabOrder($event)"
      >
        <ng-container [ngTemplateOutlet]="content().template" />
      </div>
    </ng-template>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: BrnPopoverContent,
			selector: "[brnPopoverContent]",
			exportAs: ["brnPopoverContent"]
		}, {
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopover,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-popover",
			imports: [BrnPopoverContent, NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideBrnPopoverConfig({ sideOffset: SIDE_OFFSET }), provideBrnPopoverDefaultOptions({
				role: null,
				autoFocus: false
			})],
			hostDirectives: [{
				directive: BrnPopover,
				inputs: ["align"]
			}],
			host: { class: "contents" },
			template: `
    <ng-content />
    <ng-template brnPopoverContent>
      <div
        role="dialog"
        [id]="panelId"
        [attr.aria-label]="label()"
        [attr.data-state]="brain.stateComputed()"
        [class]="panelClasses"
        (keydown)="carryTabOrder($event)"
      >
        <ng-container [ngTemplateOutlet]="content().template" />
      </div>
    </ng-template>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		content: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatPopoverContent), { isSignal: true }]
		}],
		trigger: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatPopoverTrigger), { isSignal: true }]
		}]
	}
});
export { NeatPopover, NeatPopoverContent, NeatPopoverDivider, NeatPopoverItem, NeatPopoverTrigger };

//# sourceMappingURL=sima-neat-ui-popover.mjs.map