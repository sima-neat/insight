import * as i0 from "@angular/core";
import { Directive, computed, input } from "@angular/core";
import * as i1 from "@spartan-ng/brain/input";
import { BrnInput } from "@spartan-ng/brain/input";
import { ɵINPUT_CLASSES } from "@sima/neat-ui";
var NeatInput = class NeatInput {
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	classes = computed(() => ɵINPUT_CLASSES[this.size()], ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatInput,
		isStandalone: true,
		selector: "input[neatInput]",
		inputs: { size: {
			classPropertyName: "size",
			publicName: "size",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "input" },
			properties: { "class": "classes()" }
		},
		hostDirectives: [{
			directive: i1.BrnInput,
			inputs: ["id", "id"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatInput,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[neatInput]",
			hostDirectives: [{
				directive: BrnInput,
				inputs: ["id"]
			}],
			host: {
				"data-slot": "input",
				"[class]": "classes()"
			}
		}]
	}],
	propDecorators: { size: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "size",
			required: false
		}]
	}] }
});
export { NeatInput };

//# sourceMappingURL=sima-neat-ui-input.mjs.map