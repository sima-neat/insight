import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, computed, input } from "@angular/core";
const CHIP_CLASSES = "inline-block max-w-full truncate rounded-(--radius) px-(--neat-space-2) align-middle text-(length:--neat-text-xs) leading-normal font-medium";
const TONE_CLASSES = {
	solid: {
		neutral: "bg-neat-chip-neutral text-muted-foreground",
		success: "bg-success text-success-foreground",
		warning: "bg-warning text-warning-foreground",
		danger: "bg-destructive text-destructive-foreground",
		info: "bg-info text-info-foreground",
		highlight: "bg-highlight text-highlight-foreground"
	},
	tinted: {
		neutral: "bg-neat-chip-neutral text-muted-foreground",
		success: "bg-neat-tint-success-accent text-success",
		warning: "bg-neat-tint-warning-accent text-neat-warning-text",
		danger: "bg-neat-tint-danger-accent text-destructive",
		info: "bg-neat-tint-info-accent text-info",
		highlight: "bg-neat-tint-highlight-accent text-highlight"
	}
};
const BUTTON_CLASSES = "shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-50";
var NeatStatusChip = class NeatStatusChip {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	variant = input("solid", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	classes = computed(() => `${CHIP_CLASSES} ${TONE_CLASSES[this.variant()][this.tone()]}`, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatStatusChip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatStatusChip,
		isStandalone: true,
		selector: "neat-status-chip",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "status-chip" },
			properties: { "class": "classes()" }
		},
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatStatusChip,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-status-chip",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "status-chip",
				"[class]": "classes()"
			},
			template: "<ng-content />"
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}]
	}
});
var NeatStatusChipButton = class NeatStatusChipButton {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	variant = input("solid", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	classes = computed(() => `${CHIP_CLASSES} ${TONE_CLASSES[this.variant()][this.tone()]} ${BUTTON_CLASSES}`, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatStatusChipButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatStatusChipButton,
		isStandalone: true,
		selector: "button[neatStatusChip]",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "status-chip" },
			properties: { "class": "classes()" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatStatusChipButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatStatusChip]",
			host: {
				"data-slot": "status-chip",
				"[class]": "classes()"
			}
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}]
	}
});
export { NeatStatusChip, NeatStatusChipButton };

//# sourceMappingURL=sima-neat-ui-status-chip.mjs.map