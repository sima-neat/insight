import { DialogRef } from "@angular/cdk/dialog";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Injectable, inject } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { BRN_ALERT_DIALOG_DEFAULT_OPTIONS, BrnAlertDialogDescription, BrnAlertDialogTitle } from "@spartan-ng/brain/alert-dialog";
import { BrnDialogRef, BrnDialogService, cssClassesToArray, injectBrnDialogContext } from "@spartan-ng/brain/dialog";
import { filter } from "rxjs";
import { NeatButton, ɵhlm } from "@sima/neat-ui";
const CONFIRM_HELM_CLASSES = {
	content: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 bg-popover text-popover-foreground ring-foreground/10 gap-6 rounded-xl p-6 ring-1 duration-100 data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-lg group/alert-dialog-content grid w-full outline-none",
	header: "grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-6 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-start sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]",
	title: "text-lg font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2",
	description: "text-muted-foreground *:[a]:hover:text-foreground text-sm text-balance md:text-pretty *:[a]:underline *:[a]:underline-offset-3",
	footer: "flex flex-col-reverse gap-2 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end",
	overlay: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs"
};
const CONTENT_CLASSES = ɵhlm(CONFIRM_HELM_CLASSES.content, "ring-border");
const CANCEL_ATTRIBUTE = "data-neat-confirm-cancel";
const DIALOG_OPTIONS = {
	...BRN_ALERT_DIALOG_DEFAULT_OPTIONS,
	autoFocus: `[${CANCEL_ATTRIBUTE}]`,
	backdropClass: cssClassesToArray(CONFIRM_HELM_CLASSES.overlay)
};
var NeatConfirmDialog = class NeatConfirmDialog {
	dialogRef = inject(BrnDialogRef);
	context = injectBrnDialogContext();
	options = this.context.options;
	classes = CONFIRM_HELM_CLASSES;
	contentClasses = CONTENT_CLASSES;
	constructor() {
		inject(DialogRef).keydownEvents.pipe(filter((event) => event.key === "Escape"), takeUntilDestroyed()).subscribe((event) => event.stopPropagation());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatConfirmDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatConfirmDialog,
		isStandalone: true,
		selector: "neat-confirm-dialog",
		host: {
			attributes: {
				"data-slot": "alert-dialog-content",
				"data-size": "default"
			},
			properties: {
				"attr.data-state": "dialogRef.state()",
				"class": "contentClasses"
			}
		},
		ngImport: i0,
		template: `
    <div [class]="classes.header">
      <h2 brnAlertDialogTitle [class]="classes.title">{{ options.title }}</h2>
      <p brnAlertDialogDescription [class]="classes.description">{{ options.message }}</p>
    </div>
    <div [class]="classes.footer">
      <button
        neatButton
        type="button"
        variant="outlined"
        data-neat-confirm-cancel
        (click)="context.answer(false)"
      >
        {{ options.cancelLabel }}
      </button>
      <button
        neatButton
        type="button"
        [variant]="options.tone === 'danger' ? 'danger' : 'primary'"
        (click)="context.answer(true)"
      >
        {{ options.confirmLabel }}
      </button>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnAlertDialogDescription,
				selector: "[brnAlertDialogDescription]",
				exportAs: ["brnAlertDialogDescription"]
			},
			{
				kind: "directive",
				type: BrnAlertDialogTitle,
				selector: "[brnAlertDialogTitle]",
				exportAs: ["brnAlertDialogTitle"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatConfirmDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-confirm-dialog",
			imports: [
				BrnAlertDialogDescription,
				BrnAlertDialogTitle,
				NeatButton
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "alert-dialog-content",
				"data-size": "default",
				"[attr.data-state]": "dialogRef.state()",
				"[class]": "contentClasses"
			},
			template: `
    <div [class]="classes.header">
      <h2 brnAlertDialogTitle [class]="classes.title">{{ options.title }}</h2>
      <p brnAlertDialogDescription [class]="classes.description">{{ options.message }}</p>
    </div>
    <div [class]="classes.footer">
      <button
        neatButton
        type="button"
        variant="outlined"
        data-neat-confirm-cancel
        (click)="context.answer(false)"
      >
        {{ options.cancelLabel }}
      </button>
      <button
        neatButton
        type="button"
        [variant]="options.tone === 'danger' ? 'danger' : 'primary'"
        (click)="context.answer(true)"
      >
        {{ options.confirmLabel }}
      </button>
    </div>
  `
		}]
	}],
	ctorParameters: () => []
});
var NeatConfirm = class NeatConfirm {
	dialogs = inject(BrnDialogService);
	current;
	ask(options) {
		this.current?.dialogRef.forceClose(this.current.answer ?? false);
		const context = {
			options: {
				...options,
				cancelLabel: options.cancelLabel ?? "Cancel",
				tone: options.tone ?? "default"
			},
			answer: (confirmed) => {
				question.answer = confirmed;
				dialogRef.close(confirmed);
			}
		};
		const dialogRef = this.dialogs.open(NeatConfirmDialog, void 0, context, DIALOG_OPTIONS);
		const question = { dialogRef };
		this.current = question;
		return new Promise((resolve) => {
			dialogRef.closed$.subscribe((result) => {
				if (this.current === question) this.current = void 0;
				resolve(result === true);
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatConfirm,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatConfirm,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatConfirm,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
export { NeatConfirm };

//# sourceMappingURL=sima-neat-ui-confirm.mjs.map