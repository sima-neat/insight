import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, input, output, signal } from "@angular/core";
import { NeatIcon } from "@sima/neat-ui";
const ZONE_CLASSES = "flex w-full cursor-pointer flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed border-input px-4 py-6 text-sm text-foreground outline-none transition-colors enabled:hover:bg-accent data-drag-active:border-primary data-drag-active:bg-accent focus-visible:ring-3 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50";
function carriesFiles(event) {
	return event.dataTransfer?.types.includes("Files") ?? false;
}
function isAccepted(file, accept) {
	const patterns = (accept ?? "").split(",").map((pattern) => pattern.trim().toLowerCase()).filter(Boolean);
	if (patterns.length === 0) return true;
	const name = file.name.toLowerCase();
	const type = file.type.toLowerCase();
	return patterns.some((pattern) => pattern.startsWith(".") ? name.endsWith(pattern) : pattern.endsWith("/*") ? type.startsWith(pattern.slice(0, -1)) : type === pattern);
}
var NeatDropZone = class NeatDropZone {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	multiple = input(false, {
		...ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	accept = input(...ngDevMode ? [void 0, { debugName: "accept" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	files = output();
	rejected = output();
	zoneClasses = ZONE_CLASSES;
	dragActive = signal(false, ...ngDevMode ? [{ debugName: "dragActive" }] : /* istanbul ignore next */ []);
	entered = 0;
	dragEnter(event) {
		if (this.disabled() || !carriesFiles(event)) return;
		this.entered++;
		this.dragActive.set(true);
	}
	dragOver(event) {
		if (this.disabled() || !carriesFiles(event)) return;
		event.preventDefault();
		event.dataTransfer.dropEffect = "copy";
	}
	dragLeave(event) {
		if (this.disabled() || !carriesFiles(event) || this.entered === 0) return;
		if (--this.entered === 0) this.dragActive.set(false);
	}
	drop(event) {
		this.entered = 0;
		this.dragActive.set(false);
		if (this.disabled() || !carriesFiles(event)) return;
		event.preventDefault();
		this.emit(Array.from(event.dataTransfer.files), true);
	}
	chosen(chooser) {
		const files = Array.from(chooser.files ?? []);
		chooser.value = "";
		if (!this.disabled()) this.emit(files, false);
	}
	emit(files, filter) {
		const allowed = filter ? files.filter((file) => isAccepted(file, this.accept())) : files;
		const kept = this.multiple() ? allowed : allowed.slice(0, 1);
		const rejected = files.filter((file) => !kept.includes(file));
		if (rejected.length > 0) this.rejected.emit(rejected);
		if (kept.length > 0) this.files.emit(kept);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDropZone,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatDropZone,
		isStandalone: true,
		selector: "neat-drop-zone",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			files: "files",
			rejected: "rejected"
		},
		host: {
			listeners: {
				"dragenter": "dragEnter($event)",
				"dragover": "dragOver($event)",
				"dragleave": "dragLeave($event)",
				"drop": "drop($event)"
			},
			classAttribute: "block"
		},
		ngImport: i0,
		template: `
    <button
      type="button"
      data-slot="drop-zone"
      [class]="zoneClasses"
      [disabled]="disabled()"
      [attr.data-drag-active]="dragActive() ? '' : null"
      (click)="chooser.click()"
    >
      <neat-icon name="upload" [size]="20" />
      <span>{{ label() }}</span>
    </button>
    <input
      #chooser
      type="file"
      hidden
      tabindex="-1"
      [multiple]="multiple()"
      [attr.accept]="accept() ?? null"
      [disabled]="disabled()"
      (change)="chosen(chooser)"
    />
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDropZone,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-drop-zone",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "block",
				"(dragenter)": "dragEnter($event)",
				"(dragover)": "dragOver($event)",
				"(dragleave)": "dragLeave($event)",
				"(drop)": "drop($event)"
			},
			template: `
    <button
      type="button"
      data-slot="drop-zone"
      [class]="zoneClasses"
      [disabled]="disabled()"
      [attr.data-drag-active]="dragActive() ? '' : null"
      (click)="chooser.click()"
    >
      <neat-icon name="upload" [size]="20" />
      <span>{{ label() }}</span>
    </button>
    <input
      #chooser
      type="file"
      hidden
      tabindex="-1"
      [multiple]="multiple()"
      [attr.accept]="accept() ?? null"
      [disabled]="disabled()"
      (change)="chosen(chooser)"
    />
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		files: [{
			type: i0.Output,
			args: ["files"]
		}],
		rejected: [{
			type: i0.Output,
			args: ["rejected"]
		}]
	}
});
export { NeatDropZone };

//# sourceMappingURL=sima-neat-ui-drop-zone.mjs.map