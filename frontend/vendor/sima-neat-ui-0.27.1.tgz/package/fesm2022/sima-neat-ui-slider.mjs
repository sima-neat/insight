import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, model } from "@angular/core";
import * as i1 from "@spartan-ng/brain/slider";
import { BrnSlider, BrnSliderRange, BrnSliderThumb, BrnSliderTrack } from "@spartan-ng/brain/slider";
import { ɵhlm } from "@sima/neat-ui";
const SLIDER_HELM_CLASSES = {
	root: "group flex w-full touch-none flex-col select-none data-vertical:h-full data-vertical:min-h-40 data-vertical:w-auto data-vertical:flex-row data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
	frame: "relative flex w-full items-center group-data-vertical:w-auto group-data-vertical:flex-col",
	track: "bg-muted rounded-full data-horizontal:h-1.5 data-horizontal:w-full data-vertical:h-full data-vertical:w-1.5 relative grow overflow-hidden",
	range: "bg-primary absolute select-none data-draggable-range:cursor-move data-horizontal:h-full data-vertical:w-full",
	thumb: "border-primary ring-ring/50 size-4 rounded-full border bg-white shadow-sm transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden absolute block shrink-0 select-none after:absolute after:-inset-2"
};
const TRACK_CLASSES = ɵhlm(SLIDER_HELM_CLASSES.track, "bg-input");
const THUMB_CLASSES = ɵhlm(SLIDER_HELM_CLASSES.thumb, "bg-background focus-visible:ring-ring");
var NeatSlider = class NeatSlider {
	value = model(0, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	min = input.required(...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input.required(...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	step = input.required(...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	describedBy = input(...ngDevMode ? [void 0, { debugName: "describedBy" }] : /* istanbul ignore next */ []);
	rootClasses = SLIDER_HELM_CLASSES.root;
	frameClasses = SLIDER_HELM_CLASSES.frame;
	trackClasses = TRACK_CLASSES;
	rangeClasses = SLIDER_HELM_CLASSES.range;
	thumbClasses = THUMB_CLASSES;
	disabledAttr;
	constructor() {
		const slider = inject(BrnSlider);
		this.disabledAttr = computed(() => slider.mutableDisabled() ? "true" : null, ...ngDevMode ? [{ debugName: "disabledAttr" }] : /* istanbul ignore next */ []);
		effect(() => slider.value.set([this.value()]));
		slider.valueChange.subscribe(([value]) => this.value.set(value));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSlider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatSlider,
		isStandalone: true,
		selector: "neat-slider",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { properties: { "class": "rootClasses" } },
		hostDirectives: [{
			directive: i1.BrnSlider,
			inputs: [
				"min",
				"min",
				"max",
				"max",
				"step",
				"step",
				"disabled",
				"disabled",
				"aria-label",
				"label"
			]
		}],
		ngImport: i0,
		template: `
    <div [class]="frameClasses">
      <div brnSliderTrack [class]="trackClasses">
        <div brnSliderRange [class]="rangeClasses"></div>
      </div>
      <span
        brnSliderThumb
        [class]="thumbClasses"
        [attr.aria-describedby]="describedBy() ?? null"
        [attr.aria-disabled]="disabledAttr()"
      ></span>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnSliderTrack,
				selector: "[brnSliderTrack]",
				exportAs: ["brnSliderTrack"]
			},
			{
				kind: "directive",
				type: BrnSliderRange,
				selector: "[brnSliderRange]",
				exportAs: ["brnSliderRange"]
			},
			{
				kind: "directive",
				type: BrnSliderThumb,
				selector: "[brnSliderThumb]",
				exportAs: ["brnSliderThumb"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSlider,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-slider",
			imports: [
				BrnSliderTrack,
				BrnSliderRange,
				BrnSliderThumb
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			hostDirectives: [{
				directive: BrnSlider,
				inputs: [
					"min",
					"max",
					"step",
					"disabled",
					"aria-label: label"
				]
			}],
			host: { "[class]": "rootClasses" },
			template: `
    <div [class]="frameClasses">
      <div brnSliderTrack [class]="trackClasses">
        <div brnSliderRange [class]="rangeClasses"></div>
      </div>
      <span
        brnSliderThumb
        [class]="thumbClasses"
        [attr.aria-describedby]="describedBy() ?? null"
        [attr.aria-disabled]="disabledAttr()"
      ></span>
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: true
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: true
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}]
	}
});
export { NeatSlider };

//# sourceMappingURL=sima-neat-ui-slider.mjs.map