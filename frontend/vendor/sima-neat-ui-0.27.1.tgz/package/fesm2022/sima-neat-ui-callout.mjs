import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input } from "@angular/core";
import { NeatIcon } from "@sima/neat-ui";
let nextCalloutId = 0;
const CALLOUT_CLASSES = "flex gap-(--neat-space-3) rounded-(--radius) border-s-4 p-(--neat-space-3) text-sm text-foreground";
const TONES = {
	neutral: {
		classes: "bg-muted border-muted-foreground",
		icon: "text-muted-foreground"
	},
	success: {
		classes: "bg-neat-tint-success border-success",
		icon: "text-success"
	},
	warning: {
		classes: "bg-neat-tint-warning border-warning",
		icon: "text-foreground"
	},
	danger: {
		classes: "bg-neat-tint-danger border-destructive",
		icon: "text-destructive"
	},
	info: {
		classes: "bg-neat-tint-info border-info",
		icon: "text-info"
	},
	highlight: {
		classes: "bg-neat-tint-highlight border-highlight",
		icon: "text-highlight"
	}
};
const ICONS = {
	neutral: "info",
	success: "check",
	warning: "warning",
	danger: "error",
	info: "info",
	highlight: "info"
};
var NeatCallout = class NeatCallout {
	tone = input("info", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	heading = input("", ...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	headingLevel = input(3, ...ngDevMode ? [{ debugName: "headingLevel" }] : /* istanbul ignore next */ []);
	region = input(false, {
		...ngDevMode ? { debugName: "region" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	announce = input(null, ...ngDevMode ? [{ debugName: "announce" }] : /* istanbul ignore next */ []);
	headingId = `neat-callout-${++nextCalloutId}-heading`;
	role = computed(() => this.announce() ?? (this.region() && this.heading() ? "region" : null), ...ngDevMode ? [{ debugName: "role" }] : /* istanbul ignore next */ []);
	classes = computed(() => `${CALLOUT_CLASSES} ${TONES[this.tone()].classes}`, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	icon = computed(() => ICONS[this.tone()], ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	iconClasses = computed(() => `mt-0.5 shrink-0 ${TONES[this.tone()].icon}`, ...ngDevMode ? [{ debugName: "iconClasses" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCallout,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatCallout,
		isStandalone: true,
		selector: "neat-callout",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			heading: {
				classPropertyName: "heading",
				publicName: "heading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headingLevel: {
				classPropertyName: "headingLevel",
				publicName: "headingLevel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			region: {
				classPropertyName: "region",
				publicName: "region",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			announce: {
				classPropertyName: "announce",
				publicName: "announce",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"class": "classes()",
			"attr.role": "role()",
			"attr.aria-labelledby": "role() && heading() ? headingId : null"
		} },
		ngImport: i0,
		template: `
    <neat-icon [name]="icon()" [size]="16" [class]="iconClasses()" />
    <div class="flex min-w-0 flex-1 flex-col gap-(--neat-space-2)">
      @if (heading()) {
        <div
          data-slot="callout-heading"
          role="heading"
          class="font-medium"
          [id]="headingId"
          [attr.aria-level]="headingLevel()"
        >
          {{ heading() }}
        </div>
      }
      <!-- empty:hidden: a callout with no body (a heading and actions) keeps no gap for it. -->
      <div data-slot="callout-body" class="empty:hidden"><ng-content /></div>
      <div
        data-slot="callout-actions"
        class="flex flex-wrap items-center gap-(--neat-space-2) empty:hidden"
      >
        <ng-content select="[neatCalloutActions]" />
      </div>
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCallout,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-callout",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[class]": "classes()",
				"[attr.role]": "role()",
				"[attr.aria-labelledby]": "role() && heading() ? headingId : null"
			},
			template: `
    <neat-icon [name]="icon()" [size]="16" [class]="iconClasses()" />
    <div class="flex min-w-0 flex-1 flex-col gap-(--neat-space-2)">
      @if (heading()) {
        <div
          data-slot="callout-heading"
          role="heading"
          class="font-medium"
          [id]="headingId"
          [attr.aria-level]="headingLevel()"
        >
          {{ heading() }}
        </div>
      }
      <!-- empty:hidden: a callout with no body (a heading and actions) keeps no gap for it. -->
      <div data-slot="callout-body" class="empty:hidden"><ng-content /></div>
      <div
        data-slot="callout-actions"
        class="flex flex-wrap items-center gap-(--neat-space-2) empty:hidden"
      >
        <ng-content select="[neatCalloutActions]" />
      </div>
    </div>
  `
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		heading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "heading",
				required: false
			}]
		}],
		headingLevel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headingLevel",
				required: false
			}]
		}],
		region: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "region",
				required: false
			}]
		}],
		announce: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "announce",
				required: false
			}]
		}]
	}
});
export { NeatCallout };

//# sourceMappingURL=sima-neat-ui-callout.mjs.map