import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, NgZone, afterRenderEffect, inject, input, viewChildren } from "@angular/core";
const METER_FLOOR_DBFS = -50;
const METER_SEGMENTS = 28;
function meterSegments(levelDbfs, count) {
	if (levelDbfs === null || levelDbfs === void 0 || !Number.isFinite(Number(levelDbfs))) return 0;
	const fraction = (Number(levelDbfs) - METER_FLOOR_DBFS) / 50;
	return Math.round(Math.max(0, Math.min(1, fraction)) * count);
}
function segmentTone(index, count) {
	if (index < Math.round(count * .7)) return "low";
	if (index < Math.round(count * .9)) return "mid";
	return "high";
}
const UNLIT_FILL = "bg-border";
const TONE_FILLS = {
	low: "bg-success",
	mid: "bg-warning",
	high: "bg-destructive"
};
const LIT_FILLS = Array.from({ length: METER_SEGMENTS }, (_, index) => TONE_FILLS[segmentTone(index, METER_SEGMENTS)]);
function everyAnimationFrame(onFrame) {
	let pending = requestAnimationFrame(function frame() {
		pending = requestAnimationFrame(frame);
		onFrame();
	});
	return () => cancelAnimationFrame(pending);
}
var NeatLevelMeter = class NeatLevelMeter {
	sample = input(null, ...ngDevMode ? [{ debugName: "sample" }] : /* istanbul ignore next */ []);
	segments = Array.from({ length: METER_SEGMENTS });
	segmentElements = viewChildren("segment", ...ngDevMode ? [{ debugName: "segmentElements" }] : /* istanbul ignore next */ []);
	lit = 0;
	constructor() {
		const zone = inject(NgZone);
		afterRenderEffect((onCleanup) => {
			const sample = this.sample();
			if (sample === null) return;
			const stop = zone.runOutsideAngular(() => everyAnimationFrame(() => this.show(meterSegments(sample(), METER_SEGMENTS))));
			onCleanup(() => {
				stop();
				this.show(0);
			});
		});
	}
	show(lit) {
		const elements = this.segmentElements();
		for (let index = Math.min(lit, this.lit); index < Math.max(lit, this.lit); index++) {
			const on = index < lit;
			const { classList } = elements[index].nativeElement;
			classList.remove(on ? UNLIT_FILL : LIT_FILLS[index]);
			classList.add(on ? LIT_FILLS[index] : UNLIT_FILL);
		}
		this.lit = lit;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLevelMeter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatLevelMeter,
		isStandalone: true,
		selector: "neat-level-meter",
		inputs: { sample: {
			classPropertyName: "sample",
			publicName: "sample",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "aria-hidden": "true" },
			classAttribute: "flex h-3.5 gap-0.5"
		},
		viewQueries: [{
			propertyName: "segmentElements",
			predicate: ["segment"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @for (segment of segments; track $index) {
      <span
        #segment
        data-slot="level-meter-segment"
        class="h-full min-w-0.5 flex-1 rounded-xs bg-border"
      ></span>
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLevelMeter,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-level-meter",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "flex h-3.5 gap-0.5",
				"aria-hidden": "true"
			},
			template: `
    @for (segment of segments; track $index) {
      <span
        #segment
        data-slot="level-meter-segment"
        class="h-full min-w-0.5 flex-1 rounded-xs bg-border"
      ></span>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		sample: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sample",
				required: false
			}]
		}],
		segmentElements: [{
			type: i0.ViewChildren,
			args: ["segment", { isSignal: true }]
		}]
	}
});
export { NeatLevelMeter };

//# sourceMappingURL=sima-neat-ui-level-meter.mjs.map