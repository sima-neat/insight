import * as i0 from "@angular/core";
import { Directive } from "@angular/core";
const LIST_CLASSES = "m-0 p-0 list-none ps-(--neat-space-3) border-s-2 border-border text-(length:--neat-text-xs)";
const LINE_CLASSES = "flex items-center gap-(--neat-space-2) min-h-6";
const END_CLASSES = "ms-auto";
var NeatLineList = class NeatLineList {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLineList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatLineList,
		isStandalone: true,
		selector: "ul[neatLineList], ol[neatLineList]",
		host: { classAttribute: "m-0 p-0 list-none ps-(--neat-space-3) border-s-2 border-border text-(length:--neat-text-xs)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLineList,
	decorators: [{
		type: Directive,
		args: [{
			selector: "ul[neatLineList], ol[neatLineList]",
			host: { class: LIST_CLASSES }
		}]
	}]
});
var NeatLine = class NeatLine {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLine,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatLine,
		isStandalone: true,
		selector: "li[neatLine]",
		host: { classAttribute: "flex items-center gap-(--neat-space-2) min-h-6" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLine,
	decorators: [{
		type: Directive,
		args: [{
			selector: "li[neatLine]",
			host: { class: LINE_CLASSES }
		}]
	}]
});
var NeatLineEnd = class NeatLineEnd {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLineEnd,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatLineEnd,
		isStandalone: true,
		selector: "[neatLineEnd]",
		host: { classAttribute: "ms-auto" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLineEnd,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatLineEnd]",
			host: { class: END_CLASSES }
		}]
	}]
});
export { NeatLine, NeatLineEnd, NeatLineList };

//# sourceMappingURL=sima-neat-ui-line-list.mjs.map