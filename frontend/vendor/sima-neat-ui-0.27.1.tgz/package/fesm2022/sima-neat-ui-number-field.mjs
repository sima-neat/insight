import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, effect, input, output, viewChild } from "@angular/core";
import { NeatInput } from "@sima/neat-ui/input";
var NeatNumberField = class NeatNumberField {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	accept = input(() => true, ...ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []);
	commit = output();
	edited = false;
	field = viewChild.required("field", ...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			this.value();
			this.edited = false;
		});
	}
	focus() {
		const field = this.field().nativeElement;
		field.focus();
		field.select();
	}
	commitFrom(field, force) {
		if (!force && !this.edited) return;
		this.edited = false;
		const typed = field.value.trim();
		const number = /^\d+$/.test(typed) ? Number(typed) : NaN;
		if (Number.isSafeInteger(number) && this.accept()(number)) {
			field.value = String(number);
			this.commit.emit(number);
		} else field.value = String(this.value());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatNumberField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatNumberField,
		isStandalone: true,
		selector: "neat-number-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { commit: "commit" },
		viewQueries: [{
			propertyName: "field",
			first: true,
			predicate: ["field"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <label>
      {{ label() }}
      <span class="box">
        <input
          #field
          neatInput
          size="small"
          inputmode="numeric"
          [attr.aria-label]="label()"
          [value]="value()"
          (input)="edited = true"
          (keydown.enter)="commitFrom(field, true)"
          (blur)="commitFrom(field, false)"
        />
      </span>
      <ng-content select="[neatNumberFieldSuffix]" />
    </label>
  `,
		isInline: true,
		styles: [":host{display:flex;flex:none;font-size:var(--neat-text-sm)}label{display:flex;align-items:center;gap:var(--neat-space-2);white-space:nowrap}.box{display:flex;width:3rem}\n"],
		dependencies: [{
			kind: "directive",
			type: NeatInput,
			selector: "input[neatInput]",
			inputs: ["size"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatNumberField,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-number-field",
			imports: [NeatInput],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <label>
      {{ label() }}
      <span class="box">
        <input
          #field
          neatInput
          size="small"
          inputmode="numeric"
          [attr.aria-label]="label()"
          [value]="value()"
          (input)="edited = true"
          (keydown.enter)="commitFrom(field, true)"
          (blur)="commitFrom(field, false)"
        />
      </span>
      <ng-content select="[neatNumberFieldSuffix]" />
    </label>
  `,
			styles: [":host{display:flex;flex:none;font-size:var(--neat-text-sm)}label{display:flex;align-items:center;gap:var(--neat-space-2);white-space:nowrap}.box{display:flex;width:3rem}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		commit: [{
			type: i0.Output,
			args: ["commit"]
		}],
		field: [{
			type: i0.ViewChild,
			args: ["field", { isSignal: true }]
		}]
	}
});
export { NeatNumberField };

//# sourceMappingURL=sima-neat-ui-number-field.mjs.map