import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ComponentRef, Injectable, Injector, TemplateRef, ViewContainerRef, inject, inputBinding, signal } from "@angular/core";
import { BrnDialogRef, BrnDialogService, BrnDialogTitle, cssClassesToArray, injectBrnDialogContext } from "@spartan-ng/brain/dialog";
import { CdkPortalOutlet, ComponentPortal, TemplatePortal } from "@angular/cdk/portal";
import { DialogRef } from "@angular/cdk/dialog";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { filter } from "rxjs";
import { NeatButton, NeatIcon, ɵhlm } from "@sima/neat-ui";
var NeatDialogRef = class {};
var DialogRefImpl = class extends NeatDialogRef {
	dismissibleState;
	closeDialog;
	closed;
	dismissible;
	constructor(init) {
		super();
		this.dismissibleState = signal(init.dismissible, ...ngDevMode ? [{ debugName: "dismissibleState" }] : /* istanbul ignore next */ []);
		this.dismissible = this.dismissibleState.asReadonly();
		this.closeDialog = init.close;
		this.closed = init.closed;
	}
	close(result) {
		this.closeDialog(result);
	}
	setDismissible(dismissible) {
		this.dismissibleState.set(dismissible);
	}
};
const DIALOG_HELM_CLASSES = {
	content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 ring-foreground/10 grid max-w-[calc(100%-2rem)] gap-6 rounded-xl p-6 text-sm ring-1 duration-100 sm:max-w-md relative mx-auto w-full outline-none sm:mx-0",
	closeButton: "absolute end-4 top-4",
	header: "gap-2 flex flex-col",
	title: "leading-none font-medium",
	footer: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
	overlay: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs"
};
const PANEL_CLASSES = ɵhlm(DIALOG_HELM_CLASSES.content, "ring-border flex flex-col max-h-[calc(100dvh-2rem)] sm:max-w-[calc(100%-2rem)] [--neat-surface:var(--popover)]");
const SIZE_CLASSES = {
	small: "sm:w-sm",
	medium: "sm:w-lg",
	large: "sm:w-3xl"
};
var NeatDialogPanel = class NeatDialogPanel {
	brain = inject(BrnDialogRef);
	context = injectBrnDialogContext();
	ref = this.context.ref;
	classes = DIALOG_HELM_CLASSES;
	panelClasses = ɵhlm(PANEL_CLASSES, SIZE_CLASSES[this.context.size]);
	closeButtonClasses = DIALOG_HELM_CLASSES.closeButton;
	content;
	constructor() {
		const injector = inject(Injector);
		const content = this.context.content;
		this.content = content instanceof TemplateRef ? new TemplatePortal(content, inject(ViewContainerRef), { $implicit: this.ref }) : new ComponentPortal(content, null, Injector.create({
			providers: [{
				provide: NeatDialogRef,
				useValue: this.ref
			}],
			parent: injector
		}), null, Object.entries(this.context.inputs).map(([name, value]) => inputBinding(name, () => value)));
		const cdkRef = inject(DialogRef);
		cdkRef.backdropClick.pipe(takeUntilDestroyed()).subscribe(() => this.dismiss());
		cdkRef.keydownEvents.pipe(filter((event) => event.key === "Escape"), takeUntilDestroyed()).subscribe((event) => {
			event.stopPropagation();
			if (this.dismiss()) event.preventDefault();
		});
	}
	dismiss() {
		if (!this.ref.dismissible()) return false;
		this.ref.close();
		return true;
	}
	laidOutWithThePanel(attached) {
		if (attached instanceof ComponentRef) attached.location.nativeElement.style.display = "contents";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDialogPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatDialogPanel,
		isStandalone: true,
		selector: "neat-dialog-panel",
		host: {
			attributes: { "data-slot": "dialog-content" },
			properties: {
				"attr.data-state": "brain.state()",
				"class": "panelClasses"
			}
		},
		ngImport: i0,
		template: `
    <div [class]="classes.header">
      <h2 brnDialogTitle [class]="classes.title">{{ context.title }}</h2>
    </div>
    <ng-container [cdkPortalOutlet]="content" (attached)="laidOutWithThePanel($event)" />
    <button
      neatButton
      type="button"
      variant="text"
      size="small"
      iconOnly
      aria-label="Close"
      [attr.aria-disabled]="ref.dismissible() ? null : 'true'"
      [class]="closeButtonClasses"
      (click)="dismiss()"
    >
      <neat-icon name="close" [size]="16" />
    </button>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnDialogTitle,
				selector: "[brnDialogTitle]",
				exportAs: ["brnDialogTitle"]
			},
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDialogPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-dialog-panel",
			imports: [
				BrnDialogTitle,
				CdkPortalOutlet,
				NeatButton,
				NeatIcon
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "dialog-content",
				"[attr.data-state]": "brain.state()",
				"[class]": "panelClasses"
			},
			template: `
    <div [class]="classes.header">
      <h2 brnDialogTitle [class]="classes.title">{{ context.title }}</h2>
    </div>
    <ng-container [cdkPortalOutlet]="content" (attached)="laidOutWithThePanel($event)" />
    <button
      neatButton
      type="button"
      variant="text"
      size="small"
      iconOnly
      aria-label="Close"
      [attr.aria-disabled]="ref.dismissible() ? null : 'true'"
      [class]="closeButtonClasses"
      (click)="dismiss()"
    >
      <neat-icon name="close" [size]="16" />
    </button>
  `
		}]
	}],
	ctorParameters: () => []
});
const DIALOG_OPTIONS = {
	disableClose: true,
	backdropClass: cssClassesToArray(DIALOG_HELM_CLASSES.overlay)
};
var NeatDialog = class NeatDialog {
	dialogs = inject(BrnDialogService);
	open(content, options) {
		let resolveClosed;
		const closed = new Promise((resolve) => resolveClosed = resolve);
		const ref = new DialogRefImpl({
			dismissible: options.dismissible ?? true,
			close: (result) => dialog.close(result),
			closed
		});
		const context = {
			title: options.title,
			size: options.size ?? "medium",
			content,
			inputs: options.inputs ?? {},
			ref
		};
		const dialog = this.dialogs.open(NeatDialogPanel, void 0, context, DIALOG_OPTIONS);
		dialog.closed$.subscribe((result) => resolveClosed(result));
		return ref;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDialog,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDialog,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var NeatDialogBody = class NeatDialogBody {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDialogBody,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatDialogBody,
		isStandalone: true,
		selector: "neat-dialog-body",
		host: { classAttribute: "block min-h-0 overflow-y-auto -m-1 p-1" },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDialogBody,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-dialog-body",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: { class: "block min-h-0 overflow-y-auto -m-1 p-1" }
		}]
	}]
});
var NeatDialogActions = class NeatDialogActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDialogActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatDialogActions,
		isStandalone: true,
		selector: "neat-dialog-actions",
		host: { classAttribute: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end" },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDialogActions,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-dialog-actions",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: { class: DIALOG_HELM_CLASSES.footer }
		}]
	}]
});
export { NeatDialog, NeatDialogActions, NeatDialogBody, NeatDialogRef };

//# sourceMappingURL=sima-neat-ui-dialog.mjs.map