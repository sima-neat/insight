import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, model } from "@angular/core";
const SWITCH_HELM_CLASSES = {
	track: "data-checked:bg-primary data-unchecked:bg-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 dark:data-unchecked:bg-input/80 rounded-full border border-transparent shadow-xs focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 data-[size=default]:h-[18.4px] data-[size=default]:w-[32px] data-[size=sm]:h-[14px] data-[size=sm]:w-[24px] group/switch inline-flex shrink-0 items-center transition-all outline-none data-disabled:cursor-not-allowed data-disabled:opacity-50",
	thumb: "bg-background dark:data-unchecked:bg-foreground dark:data-checked:bg-primary-foreground rounded-full group-data-[size=default]/switch:size-4 group-data-[size=sm]/switch:size-3 data-unchecked:translate-x-0 data-checked:ltr:translate-x-[calc(100%-2px)] data-checked:rtl:-translate-x-[calc(100%-2px)] pointer-events-none block ring-0 transition-transform"
};
const HOST_CLASSES = "inline-flex items-center gap-2 rounded-md text-sm font-medium outline-none focus-visible:ring-3 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50";
var NeatSwitch = class NeatSwitch {
	checked = model(false, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	hostClasses = HOST_CLASSES;
	trackClasses = SWITCH_HELM_CLASSES.track;
	thumbClasses = SWITCH_HELM_CLASSES.thumb;
	state = computed(() => this.checked() ? "checked" : "unchecked", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	toggle() {
		this.checked.update((checked) => !checked);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSwitch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatSwitch,
		isStandalone: true,
		selector: "button[neatSwitch]",
		inputs: {
			checked: {
				classPropertyName: "checked",
				publicName: "checked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { checked: "checkedChange" },
		host: {
			attributes: {
				"data-slot": "switch",
				"type": "button",
				"role": "switch"
			},
			listeners: { "click": "toggle()" },
			properties: {
				"attr.aria-checked": "checked()",
				"disabled": "disabled()",
				"class": "hostClasses"
			}
		},
		ngImport: i0,
		template: `
    <span
      data-slot="switch-track"
      data-size="default"
      aria-hidden="true"
      [attr.data-state]="state()"
      [class]="trackClasses"
    >
      <span data-slot="switch-thumb" [attr.data-state]="state()" [class]="thumbClasses"></span>
    </span>
    <ng-content />
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSwitch,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[neatSwitch]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "switch",
				type: "button",
				role: "switch",
				"[attr.aria-checked]": "checked()",
				"[disabled]": "disabled()",
				"[class]": "hostClasses",
				"(click)": "toggle()"
			},
			template: `
    <span
      data-slot="switch-track"
      data-size="default"
      aria-hidden="true"
      [attr.data-state]="state()"
      [class]="trackClasses"
    >
      <span data-slot="switch-thumb" [attr.data-state]="state()" [class]="thumbClasses"></span>
    </span>
    <ng-content />
  `
		}]
	}],
	propDecorators: {
		checked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checked",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
export { NeatSwitch };

//# sourceMappingURL=sima-neat-ui-switch.mjs.map