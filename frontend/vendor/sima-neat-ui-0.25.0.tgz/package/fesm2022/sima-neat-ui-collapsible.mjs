import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, effect, inject, input, untracked, viewChild } from "@angular/core";
import { DOCUMENT } from "@angular/common";
import * as i1 from "@spartan-ng/brain/collapsible";
import { BrnCollapsible, BrnCollapsibleContent, BrnCollapsibleTrigger } from "@spartan-ng/brain/collapsible";
import { NeatIcon } from "@sima/neat-ui";
const TRIGGER_CLASSES = "group flex w-full min-w-0 cursor-pointer items-center gap-(--neat-space-2) rounded-(--radius) py-1 text-start text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring";
const ROW_CLASSES = "flex flex-wrap items-center gap-(--neat-space-2)";
const HEADING_CLASSES = "min-w-0 grow";
const CHEVRON_CLASSES = "shrink-0 text-muted-foreground transition-transform duration-(--neat-transition-duration) group-hover:text-foreground motion-reduce:transition-none";
const CONTENT_CLASSES = "pt-(--neat-space-2) data-closed:hidden";
var NeatCollapsible = class NeatCollapsible {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	summary = input("", ...ngDevMode ? [{ debugName: "summary" }] : /* istanbul ignore next */ []);
	headingLevel = input(null, ...ngDevMode ? [{ debugName: "headingLevel" }] : /* istanbul ignore next */ []);
	brain = inject(BrnCollapsible);
	triggerClasses = TRIGGER_CLASSES;
	chevronClasses = CHEVRON_CLASSES;
	contentClasses = CONTENT_CLASSES;
	rowClasses = ROW_CLASSES;
	headingClasses = HEADING_CLASSES;
	endFocus = null;
	trigger = viewChild("trigger", ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	content = viewChild("content", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	constructor() {
		const document = inject(DOCUMENT);
		effect(() => {
			if (this.brain.expanded()) return;
			untracked(() => {
				const endRemoved = this.endFocus !== null && !this.endFocus.isConnected;
				const lost = document.activeElement === null || document.activeElement === document.body;
				if (endRemoved && lost || this.content()?.nativeElement.contains(document.activeElement)) this.trigger()?.nativeElement.focus();
				this.endFocus = null;
			});
		});
	}
	noteFocus(event) {
		const target = event.target;
		this.endFocus = target === this.trigger()?.nativeElement ? null : target;
	}
	forgetFocus(event) {
		if (event.relatedTarget) this.endFocus = null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCollapsible,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatCollapsible,
		isStandalone: true,
		selector: "neat-collapsible",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			summary: {
				classPropertyName: "summary",
				publicName: "summary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headingLevel: {
				classPropertyName: "headingLevel",
				publicName: "headingLevel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "block" },
		viewQueries: [{
			propertyName: "trigger",
			first: true,
			predicate: ["trigger"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "content",
			first: true,
			predicate: ["content"],
			descendants: true,
			isSignal: true
		}],
		hostDirectives: [{
			directive: i1.BrnCollapsible,
			inputs: ["expanded", "open"],
			outputs: ["expandedChange", "openChange"]
		}],
		ngImport: i0,
		template: `
    <div
      data-slot="collapsible-row"
      [class]="rowClasses"
      (focusin)="noteFocus($event)"
      (focusout)="forgetFocus($event)"
    >
      <!-- A heading only at a level the app sets; otherwise a plain wrapper. -->
      <div
        data-slot="collapsible-heading"
        [class]="headingClasses"
        [attr.role]="headingLevel() ? 'heading' : null"
        [attr.aria-level]="headingLevel()"
      >
        <button
          #trigger
          brnCollapsibleTrigger
          data-slot="collapsible-trigger"
          [class]="triggerClasses"
        >
          <neat-icon
            name="next"
            [size]="16"
            [class]="chevronClasses"
            [class.rotate-90]="brain.expanded()"
          />
          <span class="shrink-0 font-medium">{{ label() }}</span>
          @if (!brain.expanded() && summary()) {
            <span data-slot="collapsible-summary" class="min-w-0 truncate text-muted-foreground">{{
              summary()
            }}</span>
          }
        </button>
      </div>
      <!-- Outside the heading and the button: controls of their own, never part of the name. -->
      <ng-content select="[neatCollapsibleEnd]" />
    </div>
    <div #content brnCollapsibleContent data-slot="collapsible-content" [class]="contentClasses">
      <ng-content />
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnCollapsibleTrigger,
				selector: "button[brnCollapsibleTrigger]",
				inputs: ["type"],
				exportAs: ["brnCollapsibleTrigger"]
			},
			{
				kind: "directive",
				type: BrnCollapsibleContent,
				selector: "[brnCollapsibleContent],brn-collapsible-content",
				inputs: ["id"],
				exportAs: ["brnCollapsibleContent"]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCollapsible,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-collapsible",
			imports: [
				BrnCollapsibleTrigger,
				BrnCollapsibleContent,
				NeatIcon
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			hostDirectives: [{
				directive: BrnCollapsible,
				inputs: ["expanded: open"],
				outputs: ["expandedChange: openChange"]
			}],
			host: { class: "block" },
			template: `
    <div
      data-slot="collapsible-row"
      [class]="rowClasses"
      (focusin)="noteFocus($event)"
      (focusout)="forgetFocus($event)"
    >
      <!-- A heading only at a level the app sets; otherwise a plain wrapper. -->
      <div
        data-slot="collapsible-heading"
        [class]="headingClasses"
        [attr.role]="headingLevel() ? 'heading' : null"
        [attr.aria-level]="headingLevel()"
      >
        <button
          #trigger
          brnCollapsibleTrigger
          data-slot="collapsible-trigger"
          [class]="triggerClasses"
        >
          <neat-icon
            name="next"
            [size]="16"
            [class]="chevronClasses"
            [class.rotate-90]="brain.expanded()"
          />
          <span class="shrink-0 font-medium">{{ label() }}</span>
          @if (!brain.expanded() && summary()) {
            <span data-slot="collapsible-summary" class="min-w-0 truncate text-muted-foreground">{{
              summary()
            }}</span>
          }
        </button>
      </div>
      <!-- Outside the heading and the button: controls of their own, never part of the name. -->
      <ng-content select="[neatCollapsibleEnd]" />
    </div>
    <div #content brnCollapsibleContent data-slot="collapsible-content" [class]="contentClasses">
      <ng-content />
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		summary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "summary",
				required: false
			}]
		}],
		headingLevel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headingLevel",
				required: false
			}]
		}],
		trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}],
		content: [{
			type: i0.ViewChild,
			args: ["content", { isSignal: true }]
		}]
	}
});
export { NeatCollapsible };

//# sourceMappingURL=sima-neat-ui-collapsible.mjs.map