import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DOCUMENT, DestroyRef, Directive, ElementRef, HostAttributeToken, Injectable, InjectionToken, Injector, PLATFORM_ID, TemplateRef, ViewContainerRef, afterNextRender, afterRenderEffect, booleanAttribute, computed, contentChildren, effect, inject, input, isDevMode, isSignal, linkedSignal, makeEnvironmentProviders, model, output, provideEnvironmentInitializer, runInInjectionContext, signal, untracked, viewChild } from "@angular/core";
import { LucideDynamicIcon } from "@lucide/angular";
import { Activity, Blocks, Cable, Camera, Check, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, CircleAlert, CircuitBoard, Copy, Cpu, Ellipsis, Expand, File, FileText, Folder, FolderOpen, House, Info, LayoutGrid, LoaderCircle, Maximize, Maximize2, Mic, Minimize, Moon, Palette, PanelLeftClose, PanelLeftOpen, PanelRight, Pause, Play, Radar, RadioTower, RectangleHorizontal, RefreshCw, Search, Shapes, Square, SquareTerminal, Sun, TriangleAlert, Upload, X } from "lucide";
import { CdkPortalOutlet, ComponentPortal, TemplatePortal } from "@angular/cdk/portal";
import { NavigationEnd, NavigationSkipped, NavigationSkippedCode, PRIMARY_OUTLET, Router, RouterLink, RouterLinkActive, TitleStrategy, UrlTree, containsTree } from "@angular/router";
import * as i1$2 from "@spartan-ng/brain/button";
import { BrnButton } from "@spartan-ng/brain/button";
import { DOCUMENT as DOCUMENT$1, HashLocationStrategy, LocationStrategy, NgTemplateOutlet, isPlatformBrowser } from "@angular/common";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Overlay, OverlayContainer } from "@angular/cdk/overlay";
import { cva } from "class-variance-authority";
import * as i1$1 from "@spartan-ng/brain/tooltip";
import { BrnTooltip, provideBrnTooltipDefaultOptions } from "@spartan-ng/brain/tooltip";
import { InteractivityChecker } from "@angular/cdk/a11y";
import { Title } from "@angular/platform-browser";
import { takeUntilDestroyed, toObservable } from "@angular/core/rxjs-interop";
import { BrnCollapsible, BrnCollapsibleContent, BrnCollapsibleTrigger } from "@spartan-ng/brain/collapsible";
import * as i1 from "@spartan-ng/brain/tabs";
import { BrnTabs, BrnTabsContent, BrnTabsContentLazy, BrnTabsList, BrnTabsPaginatedList, BrnTabsTrigger } from "@spartan-ng/brain/tabs";
import { CdkObserveContent } from "@angular/cdk/observers";
const HEX_PATTERN = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i;
function parseHex(hex) {
	const match = HEX_PATTERN.exec(hex);
	if (!match) throw new Error(`Expected a #RRGGBB color, got "${hex}"`);
	return [
		parseInt(match[1], 16) / 255,
		parseInt(match[2], 16) / 255,
		parseInt(match[3], 16) / 255
	];
}
function formatHex(rgb) {
	const channel = (value) => Math.round(Math.min(1, Math.max(0, value)) * 255).toString(16).padStart(2, "0");
	return `#${rgb.map(channel).join("")}`.toUpperCase();
}
function toLinear(channel) {
	return channel <= .04045 ? channel / 12.92 : ((channel + .055) / 1.055) ** 2.4;
}
function fromLinear(channel) {
	return channel <= .0031308 ? channel * 12.92 : 1.055 * channel ** (1 / 2.4) - .055;
}
function linearToOklab([r, g, b]) {
	const l = Math.cbrt(.4122214708 * r + .5363325363 * g + .0514459929 * b);
	const m = Math.cbrt(.2119034982 * r + .6806995451 * g + .1073969566 * b);
	const s = Math.cbrt(.0883024619 * r + .2817188376 * g + .6299787005 * b);
	return [
		.2104542553 * l + .793617785 * m - .0040720468 * s,
		1.9779984951 * l - 2.428592205 * m + .4505937099 * s,
		.0259040371 * l + .7827717662 * m - .808675766 * s
	];
}
function oklabToLinear([lightness, a, b]) {
	const l = (lightness + .3963377774 * a + .2158037573 * b) ** 3;
	const m = (lightness - .1055613458 * a - .0638541728 * b) ** 3;
	const s = (lightness - .0894841775 * a - 1.291485548 * b) ** 3;
	return [
		4.0767416621 * l - 3.3077115913 * m + .2309699292 * s,
		-1.2684380046 * l + 2.6097574011 * m - .3413193965 * s,
		-.0041960863 * l - .7034186147 * m + 1.707614701 * s
	];
}
function normalizeHex(hex) {
	return formatHex(parseHex(hex));
}
function hexToLinear(hex) {
	const [r, g, b] = parseHex(hex);
	return [
		toLinear(r),
		toLinear(g),
		toLinear(b)
	];
}
function linearToHex([r, g, b]) {
	return formatHex([
		fromLinear(r),
		fromLinear(g),
		fromLinear(b)
	]);
}
function hexToOklab(hex) {
	return linearToOklab(hexToLinear(hex));
}
function oklabToHex(lab) {
	return linearToHex(oklabToLinear(lab));
}
function oklchToOklab({ l, c, h }) {
	const radians = h * Math.PI / 180;
	return [
		l,
		c * Math.cos(radians),
		c * Math.sin(radians)
	];
}
function hexToOklch(hex) {
	const [l, a, b] = hexToOklab(hex);
	const h = Math.atan2(b, a) * 180 / Math.PI;
	return {
		l,
		c: Math.hypot(a, b),
		h: h < 0 ? h + 360 : h
	};
}
function oklchToHex(color) {
	return oklabToHex(oklchToOklab(color));
}
function isInSrgbGamut(color) {
	return oklabToLinear(oklchToOklab(color)).every((channel) => channel >= -1e-6 && channel <= 1.000001);
}
function relativeLuminance(hex) {
	const [r, g, b] = hexToLinear(hex);
	return .2126 * r + .7152 * g + .0722 * b;
}
function contrastRatio(a, b) {
	const [lighter, darker] = [relativeLuminance(a), relativeLuminance(b)].sort((x, y) => y - x);
	return (lighter + .05) / (darker + .05);
}
const SIMA_PALETTE = {
	text: "#010F0E",
	background: "#F3F4F5",
	backgroundAlt: "#E8E9EB",
	white: "#FFFFFF",
	orange: "#D26728",
	purple: "#D1CEE6",
	blue: "#5998DD",
	mint: "#C0E8DB",
	green: "#2A9C4F",
	lime: "#A4CC2D"
};
const NEAT_PRIMARY_BASE = SIMA_PALETTE.orange;
const NEAT_DANGER_BASE = "#C8372D";
const NEAT_WARN_BASE = "#E9A23B";
const NEAT_HIGHLIGHT_BASE = "#9D93D6";
const NEAT_SERIES_TEAL_BASE = "#2A8C9A";
const NEAT_NEAR_BLACK = "#101010";
const LIGHTEST_L = .985;
const DARKEST_L = .13;
const LIGHTER_FRACTIONS = {
	50: .92,
	100: .8,
	200: .62,
	300: .42,
	400: .2
};
const DARKER_FRACTIONS = {
	600: .15,
	700: .32,
	800: .5,
	900: .66,
	950: .8
};
const CHROMA_FALLOFF = .6;
const GAMUT_SEARCH_ROUNDS = 24;
const SURFACE_FRACTIONS = {
	200: .1,
	300: .22,
	400: .36,
	500: .5,
	600: .62,
	700: .73,
	800: .83,
	900: .92
};
function fitToSrgb(color) {
	if (isInSrgbGamut(color)) return color;
	let inside = 0;
	let outside = color.c;
	for (let round = 0; round < GAMUT_SEARCH_ROUNDS; round++) {
		const c = (inside + outside) / 2;
		if (isInSrgbGamut({
			...color,
			c
		})) inside = c;
		else outside = c;
	}
	return {
		...color,
		c: inside
	};
}
function shade(base, targetL, fraction) {
	return oklchToHex(fitToSrgb({
		l: base.l + (targetL - base.l) * fraction,
		c: base.c * (1 - CHROMA_FALLOFF * fraction),
		h: base.h
	}));
}
function buildColorScale(base) {
	const oklch = hexToOklch(base);
	const lighter = (step) => shade(oklch, LIGHTEST_L, LIGHTER_FRACTIONS[step]);
	const darker = (step) => shade(oklch, DARKEST_L, DARKER_FRACTIONS[step]);
	return {
		50: lighter(50),
		100: lighter(100),
		200: lighter(200),
		300: lighter(300),
		400: lighter(400),
		500: normalizeHex(base),
		600: darker(600),
		700: darker(700),
		800: darker(800),
		900: darker(900),
		950: darker(950)
	};
}
function surfaceRamp({ background, backgroundAlt, darkest }) {
	const from = hexToOklab(backgroundAlt);
	const to = hexToOklab(darkest);
	const between = (step) => {
		const t = SURFACE_FRACTIONS[step];
		const mix = (channel) => from[channel] + (to[channel] - from[channel]) * t;
		return oklabToHex([
			mix(0),
			mix(1),
			mix(2)
		]);
	};
	return {
		0: SIMA_PALETTE.white,
		50: background,
		100: backgroundAlt,
		200: between(200),
		300: between(300),
		400: between(400),
		500: between(500),
		600: between(600),
		700: between(700),
		800: between(800),
		900: between(900),
		950: darkest
	};
}
function gray(hex) {
	return oklabToHex([
		hexToOklab(hex)[0],
		0,
		0
	]);
}
function buildSurfaceScale() {
	return surfaceRamp({
		background: SIMA_PALETTE.background,
		backgroundAlt: SIMA_PALETTE.backgroundAlt,
		darkest: SIMA_PALETTE.text
	});
}
function buildNeutralSurfaceScale() {
	return surfaceRamp({
		background: gray(SIMA_PALETTE.background),
		backgroundAlt: gray(SIMA_PALETTE.backgroundAlt),
		darkest: NEAT_NEAR_BLACK
	});
}
const safeStorage = {
	get(key) {
		try {
			return localStorage.getItem(key);
		} catch {
			return null;
		}
	},
	set(key, value) {
		try {
			localStorage.setItem(key, value);
		} catch {}
	}
};
const STORAGE_KEY = "neat-ui:color-scheme";
const NEAT_DARK_CLASS = "neat-dark";
var ThemeService = class ThemeService {
	root = inject(DOCUMENT).documentElement;
	current = signal(safeStorage.get(STORAGE_KEY) === "dark" ? "dark" : "light", ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	scheme = this.current.asReadonly();
	constructor() {
		this.apply(this.current());
	}
	setScheme(scheme, { persist = true } = {}) {
		this.current.set(scheme);
		this.apply(scheme);
		if (persist) safeStorage.set(STORAGE_KEY, scheme);
	}
	toggle() {
		this.setScheme(this.current() === "dark" ? "light" : "dark");
	}
	apply(scheme) {
		this.root.classList.toggle(NEAT_DARK_CLASS, scheme === "dark");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ThemeService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function provideNeatUi() {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => inject(ThemeService))]);
}
const SENTINELS = ["#000000", "#ffffff"];
const colorProbe = {};
function probe() {
	if (colorProbe.context === void 0) {
		const canvas = typeof document === "undefined" ? null : document.createElement("canvas");
		if (canvas) canvas.width = canvas.height = 1;
		const context = canvas?.getContext("2d", { willReadFrequently: true }) ?? null;
		if (!context) return null;
		colorProbe.context = context;
	}
	return colorProbe.context;
}
function neatResolveColor(css) {
	const context = probe();
	if (!context) return null;
	const parsed = SENTINELS.map((sentinel) => {
		context.fillStyle = sentinel;
		context.fillStyle = css;
		return context.fillStyle;
	});
	if (parsed[0] !== parsed[1]) return null;
	context.clearRect(0, 0, 1, 1);
	context.fillRect(0, 0, 1, 1);
	const [red, green, blue] = context.getImageData(0, 0, 1, 1).data;
	return [
		red / 255,
		green / 255,
		blue / 255
	];
}
function neatThemeColors(tokens, element) {
	const document = inject(DOCUMENT);
	const theme = inject(ThemeService);
	return computed(() => {
		theme.scheme();
		const style = getComputedStyle(element?.() ?? document.documentElement);
		const entries = Object.entries(tokens).map(([name, token]) => [name, neatResolveColor(style.getPropertyValue(token).trim())]);
		return Object.fromEntries(entries);
	});
}
function drawing(name, node) {
	return {
		name,
		node
	};
}
function filled(name, node) {
	return drawing(name, node.map(([tag, attrs]) => [tag, {
		...attrs,
		fill: "currentColor"
	}]));
}
const NEAT_ICONS = {
	home: drawing("home", House),
	media: drawing("media", FolderOpen),
	streaming: drawing("streaming", RadioTower),
	viewer: drawing("viewer", LayoutGrid),
	peripherals: drawing("peripherals", Cable),
	camera: drawing("camera", Camera),
	microphone: drawing("microphone", Mic),
	lidar: drawing("lidar", Radar),
	device: drawing("device", CircuitBoard),
	stats: drawing("stats", Activity),
	board: drawing("board", Cpu),
	info: drawing("info", Info),
	sun: drawing("sun", Sun),
	moon: drawing("moon", Moon),
	"kiosk-enter": drawing("kiosk-enter", Maximize),
	"kiosk-exit": drawing("kiosk-exit", Minimize),
	"expand-window": drawing("expand-window", Expand),
	"rail-expand": drawing("rail-expand", PanelLeftOpen),
	"rail-collapse": drawing("rail-collapse", PanelLeftClose),
	"side-panel": drawing("side-panel", PanelRight),
	palette: drawing("palette", Palette),
	shapes: drawing("shapes", Shapes),
	blocks: drawing("blocks", Blocks),
	document: drawing("document", FileText),
	previous: drawing("previous", ChevronLeft),
	next: drawing("next", ChevronRight),
	close: drawing("close", X),
	check: drawing("check", Check),
	copy: drawing("copy", Copy),
	expand: drawing("expand", ChevronDown),
	collapse: drawing("collapse", ChevronUp),
	"aspect-wide": drawing("aspect-wide", RectangleHorizontal),
	"aspect-square": drawing("aspect-square", Square),
	search: drawing("search", Search),
	more: drawing("more", Ellipsis),
	"fit-all": drawing("fit-all", Maximize2),
	upload: drawing("upload", Upload),
	folder: drawing("folder", Folder),
	file: drawing("file", File),
	error: drawing("error", CircleAlert),
	warning: drawing("warning", TriangleAlert),
	refresh: drawing("refresh", RefreshCw),
	spinner: drawing("spinner", LoaderCircle),
	terminal: drawing("terminal", SquareTerminal),
	pause: filled("pause", Pause),
	play: filled("play", Play),
	stop: filled("stop", Square)
};
const NEAT_ICON_NAMES = Object.keys(NEAT_ICONS);
var NeatIcon = class NeatIcon {
	name = input.required(...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	size = input(20, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	kitName = computed(() => {
		const name = this.name();
		return typeof name === "string" ? name : null;
	}, ...ngDevMode ? [{ debugName: "kitName" }] : /* istanbul ignore next */ []);
	glyph = computed(() => {
		const name = this.name();
		return typeof name === "string" ? NEAT_ICONS[name] : {
			name: "glyph",
			node: name
		};
	}, ...ngDevMode ? [{ debugName: "glyph" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatIcon,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatIcon,
		isStandalone: true,
		selector: "neat-icon",
		inputs: {
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "attr.data-icon": "kitName()" } },
		ngImport: i0,
		template: `
    <svg
      [lucideIcon]="glyph()"
      [size]="size()"
      [title]="label()"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() ?? null"
    ></svg>
  `,
		isInline: true,
		styles: [":host{display:inline-flex}@media(prefers-reduced-motion:no-preference){:host([data-icon=\"spinner\"]) svg{animation:neat-icon-spin 1s linear infinite}}@keyframes neat-icon-spin{to{transform:rotate(360deg)}}\n"],
		dependencies: [{
			kind: "component",
			type: LucideDynamicIcon,
			selector: "svg[lucideIcon]",
			inputs: ["lucideIcon"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatIcon,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-icon",
			imports: [LucideDynamicIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[attr.data-icon]": "kitName()" },
			template: `
    <svg
      [lucideIcon]="glyph()"
      [size]="size()"
      [title]="label()"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() ?? null"
    ></svg>
  `,
			styles: [":host{display:inline-flex}@media(prefers-reduced-motion:no-preference){:host([data-icon=\"spinner\"]) svg{animation:neat-icon-spin 1s linear infinite}}@keyframes neat-icon-spin{to{transform:rotate(360deg)}}\n"]
		}]
	}],
	propDecorators: {
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
function hlm(...inputs) {
	return twMerge(clsx(inputs));
}
const elementClassManagers = /* @__PURE__ */ new WeakMap();
let globalObserver = null;
const observedElements = /* @__PURE__ */ new Set();
let sourceCounter = 0;
function classes(computed, options = {}) {
	runInInjectionContext(options.injector ?? inject(Injector), () => {
		const elementRef = options.elementRef ?? inject(ElementRef);
		const platformId = inject(PLATFORM_ID);
		const destroyRef = inject(DestroyRef);
		const baseClasses = inject(new HostAttributeToken("class"), { optional: true });
		const element = elementRef.nativeElement;
		const sourceId = sourceCounter++;
		let manager = elementClassManagers.get(element);
		if (!manager) {
			const initialBaseClasses = /* @__PURE__ */ new Set();
			if (baseClasses) toClassList(baseClasses).forEach((cls) => initialBaseClasses.add(cls));
			manager = {
				element,
				sources: /* @__PURE__ */ new Map(),
				baseClasses: initialBaseClasses,
				isUpdating: false,
				nextOrder: 0,
				hasInitialized: false,
				restoreRafId: null,
				transitionsSuppressed: false,
				previousTransition: "",
				previousTransitionPriority: ""
			};
			elementClassManagers.set(element, manager);
			setupGlobalObserver(platformId);
			observedElements.add(element);
			if (isPlatformBrowser(platformId)) {
				manager.previousTransition = element.style.getPropertyValue("transition");
				manager.previousTransitionPriority = element.style.getPropertyPriority("transition");
				element.style.setProperty("transition", "none", "important");
				manager.transitionsSuppressed = true;
			}
		}
		const sourceOrder = manager.nextOrder++;
		function updateClasses() {
			const newClasses = toClassList(computed());
			manager.sources.set(sourceId, {
				classes: new Set(newClasses),
				order: sourceOrder
			});
			updateElement(manager);
			if (manager.transitionsSuppressed) {
				manager.transitionsSuppressed = false;
				manager.restoreRafId = requestAnimationFrame(() => {
					manager.restoreRafId = null;
					restoreTransitionSuppression(manager);
				});
			}
		}
		destroyRef.onDestroy(() => {
			if (manager.restoreRafId !== null) {
				cancelAnimationFrame(manager.restoreRafId);
				manager.restoreRafId = null;
			}
			if (manager.transitionsSuppressed) {
				manager.transitionsSuppressed = false;
				restoreTransitionSuppression(manager);
			}
			manager.sources.delete(sourceId);
			if (manager.sources.size === 0) cleanupManager(element);
			else updateElement(manager);
		});
		effect(updateClasses);
	});
}
function restoreTransitionSuppression(manager) {
	const prev = manager.previousTransition;
	if (prev) manager.element.style.setProperty("transition", prev, manager.previousTransitionPriority || void 0);
	else manager.element.style.removeProperty("transition");
}
function setupGlobalObserver(platformId) {
	if (isPlatformBrowser(platformId) && !globalObserver) {
		globalObserver = new MutationObserver((mutations) => {
			for (const mutation of mutations) if (mutation.type === "attributes" && mutation.attributeName === "class") {
				const element = mutation.target;
				const manager = elementClassManagers.get(element);
				if (manager && observedElements.has(element)) {
					if (manager.isUpdating) continue;
					const currentClasses = toClassList(element.className);
					const allSourceClasses = /* @__PURE__ */ new Set();
					for (const source of manager.sources.values()) for (const className of source.classes) allSourceClasses.add(className);
					manager.baseClasses.clear();
					for (const className of currentClasses) if (!allSourceClasses.has(className)) manager.baseClasses.add(className);
					updateElement(manager);
				}
			}
		});
		globalObserver.observe(document, {
			attributes: true,
			attributeFilter: ["class"],
			subtree: true
		});
	}
}
function updateElement(manager) {
	if (manager.isUpdating) return;
	manager.isUpdating = true;
	if (!manager.hasInitialized && manager.sources.size > 0) {
		const currentClasses = toClassList(manager.element.className);
		const allSourceClasses = /* @__PURE__ */ new Set();
		for (const source of manager.sources.values()) source.classes.forEach((className) => allSourceClasses.add(className));
		currentClasses.forEach((className) => {
			if (!allSourceClasses.has(className)) manager.baseClasses.add(className);
		});
		manager.hasInitialized = true;
	}
	const sortedSources = Array.from(manager.sources.entries()).sort(([, a], [, b]) => a.order - b.order);
	const allSourceClasses = [];
	for (const [, source] of sortedSources) allSourceClasses.push(...source.classes);
	const classesToApply = allSourceClasses.length > 0 || manager.baseClasses.size > 0 ? hlm([...allSourceClasses, ...manager.baseClasses]) : "";
	if (manager.element.className !== classesToApply) manager.element.className = classesToApply;
	manager.isUpdating = false;
}
function cleanupManager(element) {
	observedElements.delete(element);
	elementClassManagers.delete(element);
	if (observedElements.size === 0 && globalObserver) {
		globalObserver.disconnect();
		globalObserver = null;
	}
}
const classListCache = /* @__PURE__ */ new Map();
function toClassList(className) {
	if (typeof className === "string" && classListCache.has(className)) return classListCache.get(className);
	const result = clsx(className).split(" ").filter((c) => c.length > 0);
	if (typeof className === "string" && classListCache.size < 1e3) classListCache.set(className, result);
	return result;
}
const defaultConfig = {
	variant: "default",
	size: "default"
};
const BrnButtonConfigToken = new InjectionToken("BrnButtonConfig");
function injectBrnButtonConfig() {
	return inject(BrnButtonConfigToken, { optional: true }) ?? defaultConfig;
}
const buttonVariants = cva("focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 rounded-md border border-transparent bg-clip-padding text-sm font-medium focus-visible:ring-3 active:not-aria-[haspopup]:translate-y-px data-[matches-spartan-invalid=true]:ring-3 [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] group/button inline-flex shrink-0 items-center justify-center whitespace-nowrap transition-all outline-none select-none data-disabled:pointer-events-none data-disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/80",
			outline: "border-border bg-background hover:bg-muted hover:text-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50 aria-expanded:bg-muted aria-expanded:text-foreground shadow-xs",
			secondary: "bg-secondary text-secondary-foreground aria-expanded:bg-secondary aria-expanded:text-secondary-foreground hover:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)]",
			ghost: "hover:bg-muted hover:text-foreground dark:hover:bg-muted/50 aria-expanded:bg-muted aria-expanded:text-foreground",
			destructive: "bg-destructive/10 hover:bg-destructive/20 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/20 text-destructive focus-visible:border-destructive/40 dark:hover:bg-destructive/30",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 gap-1.5 px-2.5 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			xs: "h-6 gap-1 rounded-[min(var(--radius-md),8px)] px-2 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(3)]",
			sm: "h-8 gap-1 rounded-[min(var(--radius-md),10px)] px-2.5 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5",
			lg: "h-10 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			icon: "size-9",
			"icon-xs": "size-6 rounded-[min(var(--radius-md),8px)] in-data-[slot=button-group]:rounded-md [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(3)]",
			"icon-sm": "size-8 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-md",
			"icon-lg": "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var HlmButton = class HlmButton {
	_config = injectBrnButtonConfig();
	_additionalClasses = signal("", ...ngDevMode ? [{ debugName: "_additionalClasses" }] : /* istanbul ignore next */ []);
	variant = input(this._config.variant, ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(this._config.size, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => [buttonVariants({
			variant: this.variant(),
			size: this.size()
		}), this._additionalClasses()]);
	}
	setClass(classes) {
		this._additionalClasses.set(classes);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmButton,
		isStandalone: true,
		selector: "button[hlmBtn], a[hlmBtn]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "button" } },
		exportAs: ["hlmBtn"],
		hostDirectives: [{
			directive: i1$2.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[hlmBtn], a[hlmBtn]",
			exportAs: "hlmBtn",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: { "data-slot": "button" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
const TEXT_HOVER = "hover:bg-accent dark:hover:bg-accent";
const DANGER_FOCUS = "focus-visible:ring-destructive dark:focus-visible:ring-destructive";
const VARIANTS = {
	primary: {
		spartan: "default",
		hover: "hover:bg-primary-hover",
		focus: "focus-visible:ring-ring"
	},
	secondary: {
		spartan: "secondary",
		hover: "",
		focus: "focus-visible:ring-ring"
	},
	outlined: {
		spartan: "outline",
		hover: "hover:bg-accent",
		focus: "focus-visible:ring-ring"
	},
	text: {
		spartan: "ghost",
		hover: TEXT_HOVER,
		focus: "focus-visible:ring-ring"
	},
	danger: {
		spartan: "destructive",
		rest: "bg-destructive text-destructive-foreground dark:bg-destructive",
		hover: "hover:bg-destructive/90 dark:hover:bg-destructive/90",
		focus: DANGER_FOCUS
	},
	"danger-text": {
		spartan: "ghost",
		rest: "text-destructive",
		hover: `${TEXT_HOVER} hover:text-destructive`,
		focus: DANGER_FOCUS
	},
	success: {
		spartan: "default",
		rest: "bg-success text-success-foreground",
		hover: "hover:bg-success/90",
		focus: "focus-visible:ring-ring"
	}
};
const SIZES = {
	small: {
		spartan: "sm",
		spartanIconOnly: "icon-sm"
	},
	medium: {
		spartan: "default",
		spartanIconOnly: "icon"
	},
	large: {
		spartan: "lg",
		spartanIconOnly: "icon-lg"
	},
	touch: {
		spartan: "lg",
		spartanIconOnly: "icon-lg",
		extra: "h-auto min-h-12 min-w-12",
		extraIconOnly: "size-12"
	}
};
const PRESSED = "bg-foreground text-background hover:bg-foreground hover:text-background dark:bg-foreground dark:text-background dark:hover:bg-foreground dark:hover:text-background";
const HELD = "aria-disabled:cursor-not-allowed aria-disabled:opacity-50";
var NeatButton = class NeatButton {
	variant = input("primary", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	iconOnly = input(false, {
		...ngDevMode ? { debugName: "iconOnly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rounded = input(false, {
		...ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	pressed = input(void 0, ...ngDevMode ? [{ debugName: "pressed" }] : /* istanbul ignore next */ []);
	classes = computed(() => {
		const variant = VARIANTS[this.variant()];
		const size = SIZES[this.size()];
		const iconOnly = this.iconOnly();
		return hlm(buttonVariants({
			variant: variant.spartan,
			size: iconOnly ? size.spartanIconOnly : size.spartan
		}), variant.rest, variant.hover, variant.focus, HELD, iconOnly ? size.extraIconOnly : size.extra, this.rounded() && "rounded-full", this.pressed() && PRESSED);
	}, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatButton,
		isStandalone: true,
		selector: "button[neatButton], a[neatButton]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconOnly: {
				classPropertyName: "iconOnly",
				publicName: "iconOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rounded: {
				classPropertyName: "rounded",
				publicName: "rounded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pressed: {
				classPropertyName: "pressed",
				publicName: "pressed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "button" },
			properties: {
				"class": "classes()",
				"attr.aria-pressed": "pressed()"
			}
		},
		hostDirectives: [{
			directive: i1$2.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatButton], a[neatButton]",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: {
				"data-slot": "button",
				"[class]": "classes()",
				"[attr.aria-pressed]": "pressed()"
			}
		}]
	}],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		iconOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconOnly",
				required: false
			}]
		}],
		rounded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		pressed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pressed",
				required: false
			}]
		}]
	}
});
const KIOSK_POINTER_IDLE_MS = 2500;
const ACTIVITY_EVENTS = [
	"pointermove",
	"pointerdown",
	"touchstart"
];
function kioskRequested(search) {
	const value = new URLSearchParams(search).get("kiosk");
	return value !== null && value !== "0" && value !== "false";
}
var KioskService = class KioskService {
	document = inject(DOCUMENT);
	isActive = signal(kioskRequested(this.document.location?.search ?? ""), ...ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ []);
	isPointerIdle = signal(false, ...ngDevMode ? [{ debugName: "isPointerIdle" }] : /* istanbul ignore next */ []);
	ownsFullscreen = false;
	holds = 0;
	idleTimer;
	active = this.isActive.asReadonly();
	pointerIdle = this.isPointerIdle.asReadonly();
	constructor() {
		const onActivity = () => this.onActivity();
		const onFullscreenChange = () => this.onFullscreenChange();
		const passive = { passive: true };
		this.document.addEventListener("fullscreenchange", onFullscreenChange);
		for (const type of ACTIVITY_EVENTS) this.document.addEventListener(type, onActivity, passive);
		this.restartIdleTimer();
		inject(DestroyRef).onDestroy(() => {
			this.document.removeEventListener("fullscreenchange", onFullscreenChange);
			for (const type of ACTIVITY_EVENTS) this.document.removeEventListener(type, onActivity, passive);
			clearTimeout(this.idleTimer);
		});
	}
	async enter() {
		this.isActive.set(true);
		const root = this.document.documentElement;
		if (typeof root.requestFullscreen !== "function" || this.document.fullscreenElement) return;
		try {
			await root.requestFullscreen();
			this.ownsFullscreen = this.document.fullscreenElement === root;
		} catch {}
	}
	async exit() {
		this.isActive.set(false);
		if (!this.ownsFullscreen) return;
		this.ownsFullscreen = false;
		if (!this.document.fullscreenElement || typeof this.document.exitFullscreen !== "function") return;
		try {
			await this.document.exitFullscreen();
		} catch {}
	}
	toggle() {
		return this.isActive() ? this.exit() : this.enter();
	}
	holdToolbar() {
		this.holds++;
		this.isPointerIdle.set(false);
		this.restartIdleTimer();
		let released = false;
		return () => {
			if (released) return;
			released = true;
			this.holds--;
			this.restartIdleTimer();
		};
	}
	onFullscreenChange() {
		if (this.ownsFullscreen && !this.document.fullscreenElement) {
			this.ownsFullscreen = false;
			this.isActive.set(false);
		}
	}
	onActivity() {
		if (this.isPointerIdle()) this.isPointerIdle.set(false);
		this.restartIdleTimer();
	}
	restartIdleTimer() {
		clearTimeout(this.idleTimer);
		if (this.holds === 0) this.idleTimer = setTimeout(() => this.isPointerIdle.set(true), KIOSK_POINTER_IDLE_MS);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KioskService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KioskService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: KioskService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatKioskExit = class NeatKioskExit {
	kiosk = inject(KioskService);
	control = viewChild.required(NeatButton, {
		...ngDevMode ? { debugName: "control" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	exited = output();
	focus() {
		this.control().nativeElement.focus();
	}
	exit() {
		this.kiosk.exit();
		this.exited.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatKioskExit,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatKioskExit,
		isStandalone: true,
		selector: "neat-kiosk-exit",
		outputs: { exited: "exited" },
		viewQueries: [{
			propertyName: "control",
			first: true,
			predicate: NeatButton,
			descendants: true,
			read: ElementRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <button
      neatButton
      type="button"
      class="shadow-md"
      variant="secondary"
      size="touch"
      rounded
      iconOnly
      aria-label="Exit kiosk mode"
      (click)="exit()"
    >
      <neat-icon name="kiosk-exit" />
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NeatButton,
			selector: "button[neatButton], a[neatButton]",
			inputs: [
				"variant",
				"size",
				"iconOnly",
				"rounded",
				"pressed"
			]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatKioskExit,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-kiosk-exit",
			imports: [NeatButton, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      neatButton
      type="button"
      class="shadow-md"
      variant="secondary"
      size="touch"
      rounded
      iconOnly
      aria-label="Exit kiosk mode"
      (click)="exit()"
    >
      <neat-icon name="kiosk-exit" />
    </button>
  `
		}]
	}],
	propDecorators: {
		control: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatButton), {
				read: ElementRef,
				isSignal: true
			}]
		}],
		exited: [{
			type: i0.Output,
			args: ["exited"]
		}]
	}
});
var ShellSlot = class {
	secondError;
	current = signal(null, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	portal = this.current.asReadonly();
	constructor(secondError) {
		this.secondError = secondError;
	}
	register(portal) {
		if (isDevMode() && this.current() !== null) throw new Error(this.secondError);
		this.current.set(portal);
	}
	unregister(portal) {
		if (portal.isAttached) portal.detach();
		if (this.current() === portal) this.current.set(null);
	}
};
const IN_PAGE_TOOLBAR = new InjectionToken("neat-ui: in the page toolbar", {
	providedIn: "root",
	factory: () => false
});
var PageToolbarSlot = class PageToolbarSlot extends ShellSlot {
	constructor() {
		super("neat-ui: only one page toolbar at a time; remove the other *neatPageToolbar first.");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageToolbarSlot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageToolbarSlot,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PageToolbarSlot,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatPageToolbar = class NeatPageToolbar {
	constructor() {
		const slot = inject(PageToolbarSlot);
		const injector = Injector.create({
			providers: [{
				provide: IN_PAGE_TOOLBAR,
				useValue: true
			}],
			parent: inject(Injector)
		});
		const portal = new TemplatePortal(inject(TemplateRef), inject(ViewContainerRef), void 0, injector);
		slot.register(portal);
		inject(DestroyRef).onDestroy(() => slot.unregister(portal));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPageToolbar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPageToolbar,
		isStandalone: true,
		selector: "[neatPageToolbar]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPageToolbar,
	decorators: [{
		type: Directive,
		args: [{ selector: "[neatPageToolbar]" }]
	}],
	ctorParameters: () => []
});
const DEFAULT_TOOLTIP_SVG_CLASS = "bg-foreground fill-foreground z-50 block size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px]";
const DEFAULT_TOOLTIP_CONTENT_CLASSES = hlm("data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 rounded-md px-3 py-1.5 text-xs bg-foreground text-background data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) text-balance");
const tooltipPositionVariants = cva("absolute", { variants: { position: {
	top: "bottom-0 left-[calc(50%-5px)] translate-y-full",
	bottom: "-top-2.5 left-[calc(50%-5px)] translate-y-0 rotate-180",
	left: "-end-2.5 top-[calc(50%-5px)] translate-y-0 rotate-270 rtl:-rotate-270",
	right: "-start-2.5 top-[calc(50%-5px)] translate-y-0 rotate-90 rtl:-rotate-90"
} } });
var HlmTooltip = class HlmTooltip {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HlmTooltip,
		isStandalone: true,
		selector: "[hlmTooltip]",
		providers: [provideBrnTooltipDefaultOptions({
			svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
			tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
			arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
		})],
		exportAs: ["hlmTooltip"],
		hostDirectives: [{
			directive: i1$1.BrnTooltip,
			inputs: [
				"brnTooltip",
				"hlmTooltip",
				"position",
				"position",
				"hideDelay",
				"hideDelay",
				"showDelay",
				"showDelay",
				"tooltipDisabled",
				"tooltipDisabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTooltip]",
			exportAs: "hlmTooltip",
			providers: [provideBrnTooltipDefaultOptions({
				svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
				tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
				arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
			})],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: [
					"brnTooltip: hlmTooltip",
					"position",
					"hideDelay",
					"showDelay",
					"tooltipDisabled"
				]
			}]
		}]
	}]
});
function provideNeatTooltipOptions(position) {
	return provideBrnTooltipDefaultOptions({
		svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
		tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
		arrowClasses: (side) => hlm(tooltipPositionVariants({ position: side })),
		...position ? { position } : {}
	});
}
var NeatTooltip = class NeatTooltip {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatTooltip,
		isStandalone: true,
		selector: "[neatTooltip]",
		providers: [provideNeatTooltipOptions()],
		hostDirectives: [{
			directive: i1$1.BrnTooltip,
			inputs: [
				"brnTooltip",
				"neatTooltip",
				"position",
				"neatTooltipPosition",
				"tooltipDisabled",
				"neatTooltipDisabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatTooltip]",
			providers: [provideNeatTooltipOptions()],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: [
					"brnTooltip: neatTooltip",
					"position: neatTooltipPosition",
					"tooltipDisabled: neatTooltipDisabled"
				]
			}]
		}]
	}]
});
var AsideToggleSlot = class AsideToggleSlot extends ShellSlot {
	constructor() {
		super("neat-ui: only one aside toggle at a time; remove the other neat-aside-toggle first.");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AsideToggleSlot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AsideToggleSlot,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AsideToggleSlot,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatAsideToggle = class NeatAsideToggle {
	label = input("Side panel", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	slot = inject(AsideToggleSlot);
	viewContainer = inject(ViewContainerRef);
	destroyRef = inject(DestroyRef);
	template = viewChild.required("toggle", {
		...ngDevMode ? { debugName: "template" } : /* istanbul ignore next */ {},
		read: TemplateRef
	});
	button = viewChild("button", ...ngDevMode ? [{ debugName: "button" }] : /* istanbul ignore next */ []);
	constructor() {
		if (isDevMode() && inject(IN_PAGE_TOOLBAR)) throw new Error("neat-ui: declare neat-aside-toggle outside *neatPageToolbar; the shell draws it at the top bar's right edge.");
	}
	ngOnInit() {
		const portal = new TemplatePortal(this.template(), this.viewContainer);
		this.slot.register(portal);
		this.destroyRef.onDestroy(() => this.slot.unregister(portal));
	}
	focus() {
		this.button()?.nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideToggle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatAsideToggle,
		isStandalone: true,
		selector: "neat-aside-toggle",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: { attributes: { "hidden": "" } },
		viewQueries: [{
			propertyName: "template",
			first: true,
			predicate: ["toggle"],
			descendants: true,
			read: TemplateRef,
			isSignal: true
		}, {
			propertyName: "button",
			first: true,
			predicate: ["button"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #toggle>
      <button
        #button
        neatButton
        type="button"
        variant="text"
        size="large"
        rounded
        iconOnly
        neatTooltipPosition="bottom"
        [attr.aria-label]="label()"
        [neatTooltip]="label()"
        [pressed]="open()"
        (click)="open.set(!open())"
      >
        <neat-icon name="side-panel" />
      </button>
    </ng-template>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideToggle,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-aside-toggle",
			imports: [
				NeatButton,
				NeatIcon,
				NeatTooltip
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { hidden: "" },
			template: `
    <ng-template #toggle>
      <button
        #button
        neatButton
        type="button"
        variant="text"
        size="large"
        rounded
        iconOnly
        neatTooltipPosition="bottom"
        [attr.aria-label]="label()"
        [neatTooltip]="label()"
        [pressed]="open()"
        (click)="open.set(!open())"
      >
        <neat-icon name="side-panel" />
      </button>
    </ng-template>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		template: [{
			type: i0.ViewChild,
			args: ["toggle", {
				read: TemplateRef,
				isSignal: true
			}]
		}],
		button: [{
			type: i0.ViewChild,
			args: ["button", { isSignal: true }]
		}]
	}
});
var NeatAsidePanel = class NeatAsidePanel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsidePanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsidePanel,
		isStandalone: true,
		selector: "[neatAsidePanel]",
		host: { classAttribute: "flex flex-col gap-(--neat-space-3)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsidePanel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsidePanel]",
			host: { class: "flex flex-col gap-(--neat-space-3)" }
		}]
	}]
});
var NeatAsideTitle = class NeatAsideTitle {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideTitle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsideTitle,
		isStandalone: true,
		selector: "[neatAsideTitle]",
		host: { classAttribute: "m-0 text-base font-medium" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideTitle,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsideTitle]",
			host: { class: "m-0 text-base font-medium" }
		}]
	}]
});
var NeatAsideHeading = class NeatAsideHeading {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideHeading,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsideHeading,
		isStandalone: true,
		selector: "[neatAsideHeading]",
		host: { classAttribute: "mb-0 mt-(--neat-space-3) first:mt-0 text-(length:--neat-text-sm) font-semibold" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideHeading,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsideHeading]",
			host: { class: "mb-0 mt-(--neat-space-3) first:mt-0 text-(length:--neat-text-sm) font-semibold" }
		}]
	}]
});
var NeatAsideActions = class NeatAsideActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsideActions,
		isStandalone: true,
		selector: "[neatAsideActions]",
		host: { classAttribute: "flex flex-wrap items-center gap-(--neat-space-2)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideActions,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsideActions]",
			host: { class: "flex flex-wrap items-center gap-(--neat-space-2)" }
		}]
	}]
});
var NeatCode = class NeatCode {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCode,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatCode,
		isStandalone: true,
		selector: "code[neatCode]",
		host: { classAttribute: "neat-code" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCode,
	decorators: [{
		type: Directive,
		args: [{
			selector: "code[neatCode]",
			host: { class: "neat-code" }
		}]
	}]
});
function openLink(links, url, router, exactPath) {
	let open;
	for (const link of links) if ((!open || link.path.length > open.path.length) && containsTree(url, router.parseUrl(link.path), {
		paths: link.path === exactPath ? "exact" : "subset",
		queryParams: "ignored",
		matrixParams: "ignored",
		fragment: "ignored"
	})) open = link;
	return open;
}
const NARROW_QUERY = "(width < 48rem)";
var NeatViewport = class NeatViewport {
	state = signal(false, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	narrow = this.state.asReadonly();
	constructor() {
		if (typeof matchMedia !== "function") return;
		const query = matchMedia(NARROW_QUERY);
		this.state.set(query.matches);
		const follow = (event) => this.state.set(event.matches);
		query.addEventListener("change", follow);
		inject(DestroyRef).onDestroy(() => query.removeEventListener("change", follow));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatViewport,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatViewport,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatViewport,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatLogo = class NeatLogo {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLogo,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatLogo,
		isStandalone: true,
		selector: "neat-logo",
		ngImport: i0,
		template: `
    <svg
      role="img"
      aria-label="SiMa.ai"
      viewBox="0 0 111.34 100"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path fill="#a4cc2d" d="M86.08,83.06,100,69.23V100S94.4,92.45,86.08,83.06Z" />
      <path
        fill="#d1cee6"
        d="M53.94,53.87,100,69.23,86.08,83.06C77.28,73.12,65.44,61.14,53.94,53.87Z"
      />
      <path
        fill="#5998dd"
        d="M53.94,53.87c11.5,7.27,23.34,19.25,32.14,29.19L69.18,99.85A77,77,0,0,0,53.94,53.87Z"
      />
      <path fill="#010f0e" d="M69.18,99.85l16.9-16.79C94.4,92.45,100,100,100,100H69.23Z" />
      <polygon fill="#2a9c4f" points="100 0 100 30.77 84.62 15.39 100 0" />
      <polygon fill="#010f0e" points="100 30.77 69.24 30.77 84.62 15.39 100 30.77" />
      <polygon fill="#a4cc2d" points="84.62 15.39 69.24 30.77 69.24 0 84.62 15.39" />
      <polygon fill="#c0e8db" points="30.77 69.23 15.39 84.62 0 69.23 30.77 69.23" />
      <polygon fill="#d26728" points="30.77 69.23 30.77 100 15.39 84.62 30.77 69.23" />
      <polygon fill="#010f0e" points="30.77 100 0 100 15.39 84.62 30.77 100" />
      <polygon fill="#2a9c4f" points="15.39 84.62 0 100 0 69.23 15.39 84.62" />
      <path fill="#d26728" d="M13.92,16.94,0,30.77V0S5.6,7.55,13.92,16.94Z" />
      <path
        fill="#010f0e"
        d="M46.06,46.13,0,30.77,13.92,16.94C22.72,26.88,34.56,38.86,46.06,46.13Z"
      />
      <path
        fill="#5998dd"
        d="M46.06,46.13c-11.5-7.27-23.34-19.25-32.14-29.19L30.82.15A77,77,0,0,0,46.06,46.13Z"
      />
      <polygon fill="#c0e8db" points="100 0 84.62 15.39 69.24 0 100 0" />
      <path fill="#d1cee6" d="M30.82.15,13.92,16.94C5.6,7.55,0,0,0,0H30.77Z" />
      <path
        fill="#010f0e"
        d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
      />
    </svg>
  `,
		isInline: true,
		styles: [":host{display:inline-flex}svg{height:1.75rem;width:auto}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLogo,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-logo",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <svg
      role="img"
      aria-label="SiMa.ai"
      viewBox="0 0 111.34 100"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path fill="#a4cc2d" d="M86.08,83.06,100,69.23V100S94.4,92.45,86.08,83.06Z" />
      <path
        fill="#d1cee6"
        d="M53.94,53.87,100,69.23,86.08,83.06C77.28,73.12,65.44,61.14,53.94,53.87Z"
      />
      <path
        fill="#5998dd"
        d="M53.94,53.87c11.5,7.27,23.34,19.25,32.14,29.19L69.18,99.85A77,77,0,0,0,53.94,53.87Z"
      />
      <path fill="#010f0e" d="M69.18,99.85l16.9-16.79C94.4,92.45,100,100,100,100H69.23Z" />
      <polygon fill="#2a9c4f" points="100 0 100 30.77 84.62 15.39 100 0" />
      <polygon fill="#010f0e" points="100 30.77 69.24 30.77 84.62 15.39 100 30.77" />
      <polygon fill="#a4cc2d" points="84.62 15.39 69.24 30.77 69.24 0 84.62 15.39" />
      <polygon fill="#c0e8db" points="30.77 69.23 15.39 84.62 0 69.23 30.77 69.23" />
      <polygon fill="#d26728" points="30.77 69.23 30.77 100 15.39 84.62 30.77 69.23" />
      <polygon fill="#010f0e" points="30.77 100 0 100 15.39 84.62 30.77 100" />
      <polygon fill="#2a9c4f" points="15.39 84.62 0 100 0 69.23 15.39 84.62" />
      <path fill="#d26728" d="M13.92,16.94,0,30.77V0S5.6,7.55,13.92,16.94Z" />
      <path
        fill="#010f0e"
        d="M46.06,46.13,0,30.77,13.92,16.94C22.72,26.88,34.56,38.86,46.06,46.13Z"
      />
      <path
        fill="#5998dd"
        d="M46.06,46.13c-11.5-7.27-23.34-19.25-32.14-29.19L30.82.15A77,77,0,0,0,46.06,46.13Z"
      />
      <polygon fill="#c0e8db" points="100 0 84.62 15.39 69.24 0 100 0" />
      <path fill="#d1cee6" d="M30.82.15,13.92,16.94C5.6,7.55,0,0,0,0H30.77Z" />
      <path
        fill="#010f0e"
        d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
      />
    </svg>
  `,
			styles: [":host{display:inline-flex}svg{height:1.75rem;width:auto}\n"]
		}]
	}]
});
function neatAsideOpen(remembered, remember) {
	const narrow = inject(NeatViewport).narrow;
	const transient = linkedSignal({
		...ngDevMode ? { debugName: "transient" } : /* istanbul ignore next */ {},
		source: narrow,
		computation: () => false
	});
	return {
		open: computed(() => narrow() ? transient() : remembered()),
		set: (open) => narrow() ? transient.set(open) : remember(open)
	};
}
const RAIL_EXPANDED_KEY = "neat-ui:rail-expanded";
var RailState = class RailState {
	viewport = inject(NeatViewport);
	remembered = signal(safeStorage.get(RAIL_EXPANDED_KEY) === "true", ...ngDevMode ? [{ debugName: "remembered" }] : /* istanbul ignore next */ []);
	state = neatAsideOpen(this.remembered, (expanded) => {
		this.remembered.set(expanded);
		safeStorage.set(RAIL_EXPANDED_KEY, String(expanded));
	});
	expanded = this.state.open;
	set(expanded) {
		this.state.set(expanded);
	}
	collapseWhenNarrow() {
		if (this.viewport.narrow()) this.state.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RailState,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RailState
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RailState,
	decorators: [{ type: Injectable }]
});
const RAIL_ITEM_HAS_MENU = new InjectionToken("neat-rail-item-has-menu");
var NeatRailItem = class NeatRailItem {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	detail = input(...ngDevMode ? [void 0, { debugName: "detail" }] : /* istanbul ignore next */ []);
	tone = input(...ngDevMode ? [void 0, { debugName: "tone" }] : /* istanbul ignore next */ []);
	showsLines = computed(() => !!this.detail() || (this.text() ?? this.label()) !== this.label(), ...ngDevMode ? [{ debugName: "showsLines" }] : /* istanbul ignore next */ []);
	rail = inject(RailState, { optional: true });
	isLink = inject(ElementRef).nativeElement instanceof HTMLAnchorElement;
	constructor() {
		if (this.rail === null) throw new Error("neat-ui: a neatRailItem belongs in neat-shell (its [neatRailEnd] slot).");
		const tooltip = inject(BrnTooltip);
		const menu = inject(RAIL_ITEM_HAS_MENU, { optional: true });
		effect(() => tooltip.mutableTooltipDisabled.set(this.expanded() || menu !== null));
	}
	expanded() {
		return this.rail?.expanded() ?? true;
	}
	followed() {
		if (this.isLink) this.rail?.collapseWhenNarrow();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRailItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatRailItem,
		isStandalone: true,
		selector: "button[neatRailItem], a[neatRailItem]",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			detail: {
				classPropertyName: "detail",
				publicName: "detail",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			listeners: { "click": "followed()" },
			properties: { "attr.data-tone": "tone() ?? null" }
		},
		providers: [provideNeatTooltipOptions("right")],
		hostDirectives: [{
			directive: i1$1.BrnTooltip,
			inputs: ["brnTooltip", "label"]
		}],
		ngImport: i0,
		template: `
    <span class="icon">
      <ng-content />
      @if (tone()) {
        <span class="dot" aria-hidden="true"></span>
      }
    </span>
    <span class="label" [class.sr-only]="!expanded()">
      <ng-content select="[neatRailItemLabel]">
        @if (showsLines()) {
          <span class="lines" aria-hidden="true">
            <span class="line">{{ text() ?? label() }}</span>
            @if (detail(); as detail) {
              <span class="line detail">{{ detail }}</span>
            }
          </span>
          <span class="sr-only">{{ label() }}</span>
        } @else {
          {{ label() }}
        }
      </ng-content>
    </span>
  `,
		isInline: true,
		styles: [":host{position:relative;display:flex;flex:none;align-items:center;gap:.75rem;box-sizing:border-box;width:100%;min-height:2.5rem;padding:0 .625rem;border:0;border-radius:var(--radius);background:transparent;color:var(--muted-foreground);font:inherit;text-align:start;text-decoration:none;cursor:pointer;--rail-item-surface: var(--sidebar)}:host([data-branch]){color:var(--sidebar-foreground)}:host(:hover),:host([aria-current=\"page\"]){--rail-item-surface: var(--sidebar-accent);background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}:host([aria-current=\"page\"]),:host([data-branch]){font-weight:500}:host([data-child]){min-height:2rem;font-size:var(--neat-text-sm)}:host([data-child]) .icon{display:none}:host(:focus-visible){outline:var(--neat-focus-ring-width) solid var(--sidebar-ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}.icon{position:relative;display:inline-flex;flex:none}:host([data-tone=\"success\"]){--rail-item-dot: var(--success);--rail-item-detail: var(--muted-foreground)}:host([data-tone=\"neutral\"]){--rail-item-dot: var(--muted-foreground);--rail-item-detail: var(--muted-foreground)}:host([data-tone=\"warning\"]){--rail-item-dot: var(--neat-line-warning);--rail-item-detail: color-mix(in oklab, var(--neat-line-warning) 80%, var(--foreground))}:host([data-tone=\"danger\"]){--rail-item-dot: var(--destructive);--rail-item-detail: var(--destructive)}:host([data-tone=\"info\"]){--rail-item-dot: var(--info);--rail-item-detail: var(--info)}:host([data-tone=\"highlight\"]){--rail-item-dot: var(--highlight);--rail-item-detail: var(--highlight)}.dot{position:absolute;inset-block-end:-.125rem;inset-inline-end:-.125rem;inline-size:.5rem;block-size:.5rem;border-radius:50%;background:var(--rail-item-dot);box-shadow:0 0 0 .125rem var(--rail-item-surface)}.label,.line{min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.lines{display:flex;flex-direction:column;line-height:1.25}.detail{color:var(--rail-item-detail, var(--muted-foreground));font-size:var(--neat-text-xs)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRailItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[neatRailItem], a[neatRailItem]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideNeatTooltipOptions("right")],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: ["brnTooltip: label"]
			}],
			host: {
				"[attr.data-tone]": "tone() ?? null",
				"(click)": "followed()"
			},
			template: `
    <span class="icon">
      <ng-content />
      @if (tone()) {
        <span class="dot" aria-hidden="true"></span>
      }
    </span>
    <span class="label" [class.sr-only]="!expanded()">
      <ng-content select="[neatRailItemLabel]">
        @if (showsLines()) {
          <span class="lines" aria-hidden="true">
            <span class="line">{{ text() ?? label() }}</span>
            @if (detail(); as detail) {
              <span class="line detail">{{ detail }}</span>
            }
          </span>
          <span class="sr-only">{{ label() }}</span>
        } @else {
          {{ label() }}
        }
      </ng-content>
    </span>
  `,
			styles: [":host{position:relative;display:flex;flex:none;align-items:center;gap:.75rem;box-sizing:border-box;width:100%;min-height:2.5rem;padding:0 .625rem;border:0;border-radius:var(--radius);background:transparent;color:var(--muted-foreground);font:inherit;text-align:start;text-decoration:none;cursor:pointer;--rail-item-surface: var(--sidebar)}:host([data-branch]){color:var(--sidebar-foreground)}:host(:hover),:host([aria-current=\"page\"]){--rail-item-surface: var(--sidebar-accent);background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}:host([aria-current=\"page\"]),:host([data-branch]){font-weight:500}:host([data-child]){min-height:2rem;font-size:var(--neat-text-sm)}:host([data-child]) .icon{display:none}:host(:focus-visible){outline:var(--neat-focus-ring-width) solid var(--sidebar-ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}.icon{position:relative;display:inline-flex;flex:none}:host([data-tone=\"success\"]){--rail-item-dot: var(--success);--rail-item-detail: var(--muted-foreground)}:host([data-tone=\"neutral\"]){--rail-item-dot: var(--muted-foreground);--rail-item-detail: var(--muted-foreground)}:host([data-tone=\"warning\"]){--rail-item-dot: var(--neat-line-warning);--rail-item-detail: color-mix(in oklab, var(--neat-line-warning) 80%, var(--foreground))}:host([data-tone=\"danger\"]){--rail-item-dot: var(--destructive);--rail-item-detail: var(--destructive)}:host([data-tone=\"info\"]){--rail-item-dot: var(--info);--rail-item-detail: var(--info)}:host([data-tone=\"highlight\"]){--rail-item-dot: var(--highlight);--rail-item-detail: var(--highlight)}.dot{position:absolute;inset-block-end:-.125rem;inset-inline-end:-.125rem;inline-size:.5rem;block-size:.5rem;border-radius:50%;background:var(--rail-item-dot);box-shadow:0 0 0 .125rem var(--rail-item-surface)}.label,.line{min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.lines{display:flex;flex-direction:column;line-height:1.25}.detail{color:var(--rail-item-detail, var(--muted-foreground));font-size:var(--neat-text-xs)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		detail: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "detail",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}]
	}
});
var NeatRailDivider = class NeatRailDivider {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRailDivider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatRailDivider,
		isStandalone: true,
		selector: "hr[neatRailDivider]",
		host: {
			attributes: { "aria-hidden": "true" },
			classAttribute: "mx-0 my-1 h-0 shrink-0 border-t border-sidebar-border"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRailDivider,
	decorators: [{
		type: Directive,
		args: [{
			selector: "hr[neatRailDivider]",
			host: {
				"aria-hidden": "true",
				class: "mx-0 my-1 h-0 shrink-0 border-t border-sidebar-border"
			}
		}]
	}]
});
var OverlayFocus = class {
	trigger;
	close;
	overlayContainer = inject(OverlayContainer);
	interactivity = inject(InteractivityChecker);
	document = inject(DOCUMENT$1);
	constructor(trigger, close) {
		this.trigger = trigger;
		this.close = close;
	}
	carryTabOrder(event, panel) {
		if (event.key !== "Tab" || event.altKey || event.ctrlKey || event.metaKey) return;
		const tabbables = this.tabbablesIn(panel);
		if (event.shiftKey && event.target === tabbables[0]) {
			event.preventDefault();
			this.close();
			this.trigger().focus();
		} else if (!event.shiftKey && event.target === tabbables.at(-1)) {
			const next = this.tabbableAfterTrigger();
			if (next) {
				event.preventDefault();
				next.focus();
			}
			this.close();
		}
	}
	watchOutsideFocus() {
		const closeOnOutsideFocus = (event) => {
			if (event.target instanceof Node && !this.holdsFocus(event.target)) this.close();
		};
		this.document.addEventListener("focusin", closeOnOutsideFocus);
		return () => this.document.removeEventListener("focusin", closeOnOutsideFocus);
	}
	holdsFocus(node) {
		return this.trigger().contains(node) || this.overlayContainer.getContainerElement().contains(node);
	}
	focusFirstControl(panel) {
		if (panel) this.tabbablesIn(panel)[0]?.focus();
	}
	tabbablesIn(root) {
		return tabbablesIn(this.document, this.interactivity, root, this.overlayContainer.getContainerElement());
	}
	tabbableAfterTrigger() {
		const walker = tabbableWalker(this.document, this.interactivity, this.document.body, this.overlayContainer.getContainerElement());
		walker.currentNode = this.trigger();
		return walker.nextNode();
	}
};
function tabbablesIn(document, interactivity, root, excluded = null) {
	const walker = tabbableWalker(document, interactivity, root, excluded);
	const found = [];
	for (let node = walker.nextNode(); node; node = walker.nextNode()) found.push(node);
	return found;
}
function tabbableWalker(document, interactivity, root, excluded) {
	return document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, (node) => {
		if (node === excluded) return NodeFilter.FILTER_REJECT;
		const element = node;
		return interactivity.isTabbable(element) && !interactivity.isDisabled(element) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	});
}
const POPOVER_HELM_CLASSES = { content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 gap-4 rounded-md p-4 text-sm shadow-md ring-1 duration-100 relative flex w-72 flex-col outline-none" };
const PANEL_SURFACE_CLASSES = hlm(POPOVER_HELM_CLASSES.content, "ring-border [--neat-surface:var(--popover)]");
const RAIL_GAP = 4;
const HOVER_CLOSE_DELAY = 150;
var OpenRailMenu = class OpenRailMenu {
	open;
	claim(menu) {
		const previous = this.open;
		this.open = menu;
		if (previous && previous !== menu) previous.close();
	}
	release(menu) {
		if (this.open === menu) this.open = void 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OpenRailMenu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OpenRailMenu,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: OpenRailMenu,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const LABELED_RAIL = {
	expanded: signal(true),
	collapseWhenNarrow: () => void 0
};
let nextMenuId = 0;
var RailMenuPanel = class RailMenuPanel {
	page = input.required(...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	current = input(...ngDevMode ? [void 0, { debugName: "current" }] : /* istanbul ignore next */ []);
	chosen = output();
	menuId = ++nextMenuId;
	panelId = `neat-rail-menu-panel-${this.menuId}`;
	headingId = `neat-rail-menu-${this.menuId}`;
	panelClasses = hlm(PANEL_SURFACE_CLASSES, "w-auto min-w-48 gap-0 p-2");
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RailMenuPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: RailMenuPanel,
		isStandalone: true,
		selector: "neat-rail-menu-panel",
		inputs: {
			page: {
				classPropertyName: "page",
				publicName: "page",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			current: {
				classPropertyName: "current",
				publicName: "current",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { chosen: "chosen" },
		host: {
			attributes: { "role": "group" },
			properties: {
				"id": "panelId",
				"class": "panelClasses",
				"attr.aria-labelledby": "headingId"
			}
		},
		ngImport: i0,
		template: `
    <h2 class="m-0 px-2.5 pt-1 pb-2 text-sm font-medium text-muted-foreground" [id]="headingId">
      {{ page().label }}
    </h2>
    <ul class="m-0 flex list-none flex-col gap-1 p-0">
      @for (child of page().children; track child.path) {
        <li>
          <!-- The row's text is the item's own label, which the rule cannot see. -->
          <!-- eslint-disable-next-line @angular-eslint/template/elements-content -->
          <a
            neatRailItem
            data-child
            [label]="child.label"
            [routerLink]="child.path"
            [attr.aria-current]="child === current() ? 'page' : null"
            (click)="chosen.emit()"
          ></a>
        </li>
      }
    </ul>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatRailItem,
			selector: "button[neatRailItem], a[neatRailItem]",
			inputs: [
				"label",
				"text",
				"detail",
				"tone"
			]
		}, {
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RailMenuPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-rail-menu-panel",
			imports: [NeatRailItem, RouterLink],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				role: "group",
				"[id]": "panelId",
				"[class]": "panelClasses",
				"[attr.aria-labelledby]": "headingId"
			},
			template: `
    <h2 class="m-0 px-2.5 pt-1 pb-2 text-sm font-medium text-muted-foreground" [id]="headingId">
      {{ page().label }}
    </h2>
    <ul class="m-0 flex list-none flex-col gap-1 p-0">
      @for (child of page().children; track child.path) {
        <li>
          <!-- The row's text is the item's own label, which the rule cannot see. -->
          <!-- eslint-disable-next-line @angular-eslint/template/elements-content -->
          <a
            neatRailItem
            data-child
            [label]="child.label"
            [routerLink]="child.path"
            [attr.aria-current]="child === current() ? 'page' : null"
            (click)="chosen.emit()"
          ></a>
        </li>
      }
    </ul>
  `
		}]
	}],
	propDecorators: {
		page: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "page",
				required: true
			}]
		}],
		current: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "current",
				required: false
			}]
		}],
		chosen: [{
			type: i0.Output,
			args: ["chosen"]
		}]
	}
});
var RailMenu = class RailMenu {
	neatRailMenu = input.required(...ngDevMode ? [{ debugName: "neatRailMenu" }] : /* istanbul ignore next */ []);
	neatRailMenuCurrent = input(...ngDevMode ? [void 0, { debugName: "neatRailMenuCurrent" }] : /* istanbul ignore next */ []);
	controls = signal(null, ...ngDevMode ? [{ debugName: "controls" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	overlay = inject(Overlay);
	injector = inject(Injector);
	openMenu = inject(OpenRailMenu);
	focus = new OverlayFocus(() => this.element, () => this.close());
	ref;
	panel;
	justClosed = false;
	closeTimer;
	stopWatchingFocus;
	constructor() {
		inject(DestroyRef).onDestroy(() => this.close());
		effect(() => {
			const current = this.neatRailMenuCurrent();
			if (this.panel) {
				this.panel.setInput("current", current);
				this.panel.changeDetectorRef.detectChanges();
			}
		});
	}
	pressed() {
		this.close();
	}
	focused() {
		if (!this.justClosed && this.showsFocusRing()) {
			this.cancelClose();
			this.show();
		}
	}
	hovered(event) {
		if (event.pointerType !== "mouse" && event.pointerType !== "pen") return;
		this.cancelClose();
		this.show();
	}
	left(event) {
		if (event.pointerType === "mouse" || event.pointerType === "pen") this.closeAfterHover();
	}
	show() {
		if (this.ref) return;
		this.openMenu.claim(this);
		const ref = this.overlay.create({
			positionStrategy: this.overlay.position().flexibleConnectedTo(this.element).withPositions(this.positions()),
			scrollStrategy: this.overlay.scrollStrategies.reposition()
		});
		const rows = Injector.create({
			parent: this.injector,
			providers: [{
				provide: RailState,
				useValue: LABELED_RAIL
			}]
		});
		const panel = ref.attach(new ComponentPortal(RailMenuPanel, null, rows));
		panel.setInput("page", this.neatRailMenu());
		panel.setInput("current", this.neatRailMenuCurrent());
		panel.instance.chosen.subscribe(() => this.closeToItem());
		panel.changeDetectorRef.detectChanges();
		this.panel = panel;
		ref.overlayElement.addEventListener("pointerenter", () => this.cancelClose());
		ref.overlayElement.addEventListener("pointerleave", () => this.closeAfterHover());
		ref.keydownEvents().subscribe((event) => this.keydown(event, ref.overlayElement));
		ref.outsidePointerEvents().subscribe((event) => {
			if (!this.element.contains(event.target)) this.close();
		});
		this.stopWatchingFocus = this.focus.watchOutsideFocus();
		this.ref = ref;
		this.controls.set(panel.instance.panelId);
	}
	positions() {
		const offsetX = (this.element.closest(".rail") ?? this.element).getBoundingClientRect().right - this.element.getBoundingClientRect().right + RAIL_GAP;
		return [{
			originX: "end",
			originY: "top",
			overlayX: "start",
			overlayY: "top",
			offsetX
		}, {
			originX: "end",
			originY: "bottom",
			overlayX: "start",
			overlayY: "bottom",
			offsetX
		}];
	}
	keydown(event, panel) {
		if (event.key === "Escape") {
			event.preventDefault();
			this.closeToItem();
		} else if (event.key === "Tab" && !event.shiftKey && !event.altKey && !event.ctrlKey && !event.metaKey && event.target === this.element) {
			event.preventDefault();
			this.focus.focusFirstControl(panel);
		} else this.focus.carryTabOrder(event, panel);
	}
	closeAfterHover() {
		this.cancelClose();
		this.closeTimer = setTimeout(() => {
			if (!this.keyboardHolds()) this.close();
		}, HOVER_CLOSE_DELAY);
	}
	keyboardHolds() {
		const active = this.element.ownerDocument.activeElement;
		if (!active || !this.ref) return false;
		return this.ref.overlayElement.contains(active) || active === this.element && this.showsFocusRing();
	}
	showsFocusRing() {
		return this.element.matches(":focus-visible");
	}
	cancelClose() {
		clearTimeout(this.closeTimer);
	}
	closeToItem() {
		const active = this.element.ownerDocument.activeElement;
		const ownsFocus = !active || active === this.element.ownerDocument.body || this.focus.holdsFocus(active);
		this.close();
		if (ownsFocus) this.element.focus();
	}
	close() {
		this.openMenu.release(this);
		this.justClosed = true;
		queueMicrotask(() => this.justClosed = false);
		this.cancelClose();
		this.stopWatchingFocus?.();
		this.stopWatchingFocus = void 0;
		this.ref?.dispose();
		this.ref = void 0;
		this.panel = void 0;
		this.controls.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RailMenu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: RailMenu,
		isStandalone: true,
		selector: "a[neatRailItem][neatRailMenu]",
		inputs: {
			neatRailMenu: {
				classPropertyName: "neatRailMenu",
				publicName: "neatRailMenu",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			neatRailMenuCurrent: {
				classPropertyName: "neatRailMenuCurrent",
				publicName: "neatRailMenuCurrent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			listeners: {
				"click": "pressed()",
				"focus": "focused()",
				"pointerenter": "hovered($event)",
				"pointerleave": "left($event)"
			},
			properties: { "attr.aria-controls": "controls()" }
		},
		providers: [{
			provide: RAIL_ITEM_HAS_MENU,
			useValue: true
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RailMenu,
	decorators: [{
		type: Directive,
		args: [{
			selector: "a[neatRailItem][neatRailMenu]",
			providers: [{
				provide: RAIL_ITEM_HAS_MENU,
				useValue: true
			}],
			host: {
				"[attr.aria-controls]": "controls()",
				"(click)": "pressed()",
				"(focus)": "focused()",
				"(pointerenter)": "hovered($event)",
				"(pointerleave)": "left($event)"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		neatRailMenu: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "neatRailMenu",
				required: true
			}]
		}],
		neatRailMenuCurrent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "neatRailMenuCurrent",
				required: false
			}]
		}]
	}
});
const PAGE_TOOLBAR_LABEL = "Page tools";
const ACTIVE_MATCH = {
	paths: "subset",
	queryParams: "ignored",
	matrixParams: "ignored",
	fragment: "ignored"
};
const EXACT_MATCH = {
	...ACTIVE_MATCH,
	paths: "exact"
};
function routeTitle(root, skip) {
	let title = "";
	let reached = 0;
	let parentTitle;
	let route = root;
	while (route) {
		reached += route.url.length;
		if (route.title !== parentTitle && (skip === void 0 || reached > skip)) title = route.title ?? title;
		parentTitle = route.title;
		route = route.children.find((child) => child.outlet === PRIMARY_OUTLET);
	}
	return title;
}
var NeatShell = class NeatShell {
	appName = input.required(...ngDevMode ? [{ debugName: "appName" }] : /* istanbul ignore next */ []);
	navItems = input.required(...ngDevMode ? [{ debugName: "navItems" }] : /* istanbul ignore next */ []);
	theme = inject(ThemeService);
	kiosk = inject(KioskService);
	viewport = inject(NeatViewport);
	pageToolbar = inject(PageToolbarSlot).portal;
	asideToggle = inject(AsideToggleSlot).portal;
	toolbarLabel = PAGE_TOOLBAR_LABEL;
	router = inject(Router);
	injector = inject(Injector);
	activeMatch = ACTIVE_MATCH;
	rail = inject(RailState);
	railExpanded = this.rail.expanded;
	kioskExit = viewChild(NeatKioskExit, ...ngDevMode ? [{ debugName: "kioskExit" }] : /* istanbul ignore next */ []);
	kioskButton = viewChild("kioskButton", ...ngDevMode ? [{ debugName: "kioskButton" }] : /* istanbul ignore next */ []);
	active = computed(() => {
		const url = this.router.lastSuccessfulNavigation()?.finalUrl;
		if (!url) return;
		const item = this.navItems().find((candidate) => containsTree(url, this.router.parseUrl(candidate.path), ACTIVE_MATCH));
		const child = item?.children && openLink(item.children, url, this.router, item.path);
		return item && {
			item,
			child,
			url
		};
	}, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	unfolded = computed(() => {
		const active = this.active();
		return this.railExpanded() && active?.item.children?.length ? active : void 0;
	}, ...ngDevMode ? [{ debugName: "unfolded" }] : /* istanbul ignore next */ []);
	pageTitle = computed(() => {
		const active = this.active();
		if (!active) return { text: this.router.lastSuccessfulNavigation() ? this.routeTitle() : "" };
		const { item, child, url } = active;
		if (!child) return { text: item.label };
		const own = !containsTree(url, this.router.parseUrl(child.path), EXACT_MATCH) ? this.routeTitle(this.segmentCount(child.path)) : "";
		return own ? {
			text: own,
			context: `${item.label} › ${child.label}`
		} : {
			text: child.label,
			context: item.label
		};
	}, ...ngDevMode ? [{ debugName: "pageTitle" }] : /* istanbul ignore next */ []);
	holdsOpenChild(item) {
		const unfolded = this.unfolded();
		return unfolded?.item === item && !!unfolded.child;
	}
	isActivePage(item) {
		return this.active()?.item === item;
	}
	currentChild(item) {
		const active = this.active();
		return active?.item === item ? active.child : void 0;
	}
	isOpen(child) {
		return this.unfolded()?.child === child;
	}
	routeTitle(skip) {
		return routeTitle(this.router.routerState.snapshot.root, skip);
	}
	segmentCount(path) {
		return this.router.parseUrl(path).root.children[PRIMARY_OUTLET]?.segments.length ?? 0;
	}
	constructor() {
		let wasActive = this.kiosk.active();
		effect(() => {
			const active = this.kiosk.active();
			if (active && !wasActive) afterNextRender(() => this.kioskExit()?.focus(), { injector: this.injector });
			wasActive = active;
		});
	}
	focusKioskButtonAfterExit() {
		afterNextRender(() => this.kioskButton()?.nativeElement.focus(), { injector: this.injector });
	}
	toggleRail() {
		this.rail.set(!this.railExpanded());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatShell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatShell,
		isStandalone: true,
		selector: "neat-shell",
		inputs: {
			appName: {
				classPropertyName: "appName",
				publicName: "appName",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			navItems: {
				classPropertyName: "navItems",
				publicName: "navItems",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { properties: {
			"attr.data-kiosk": "kiosk.active()",
			"attr.data-narrow": "viewport.narrow()"
		} },
		providers: [RailState],
		viewQueries: [{
			propertyName: "kioskExit",
			first: true,
			predicate: NeatKioskExit,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "kioskButton",
			first: true,
			predicate: ["kioskButton"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (kiosk.active()) {\n  <div class=\"kiosk-chrome\" [attr.data-shown]=\"!kiosk.pointerIdle()\">\n    <!-- First in the tab order, so it is reachable from the keyboard; drawn last (right). -->\n    <neat-kiosk-exit (exited)=\"focusKioskButtonAfterExit()\" />\n    @if (pageToolbar() || asideToggle()) {\n      <div class=\"kiosk-toolbar shadow-md\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"pageToolbar()\" />\n        <ng-template [cdkPortalOutlet]=\"asideToggle()\" />\n      </div>\n    }\n  </div>\n} @else {\n  <header class=\"topbar\" [attr.data-toolbar]=\"pageToolbar() ? 'true' : 'false'\">\n    <div class=\"brand\">\n      <neat-logo />\n      <span class=\"app-name\" [class.sr-only]=\"viewport.narrow()\">{{ appName() }}</span>\n    </div>\n    @if (pageTitle(); as title) {\n      @if (title.text) {\n        <!-- The muted part is inside the heading: it is where the person is, and the page's name\n             to a screen reader too. -->\n        <h1 class=\"page-title\" [class.sr-only]=\"viewport.narrow()\">\n          {{ title.text }}\n          @if (title.context) {\n            <span class=\"page-context\">{{ title.context }}</span>\n          }\n        </h1>\n      }\n    }\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"page-toolbar\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n    <div class=\"topbar-end\">\n      <ng-content select=\"[neatTopbarEnd]\" />\n    </div>\n    <div class=\"topbar-actions\">\n      <button\n        #kioskButton\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Kiosk mode\"\n        neatTooltip=\"Kiosk mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"kiosk.toggle()\"\n      >\n        <neat-icon name=\"kiosk-enter\" />\n      </button>\n    </div>\n    @if (asideToggle(); as toggle) {\n      <!-- The page's aside toggle, at the right edge above the panel. -->\n      <div class=\"aside-edge\">\n        <ng-template [cdkPortalOutlet]=\"toggle\" />\n      </div>\n    }\n  </header>\n\n  <div\n    class=\"rail data-[floating=true]:shadow-md\"\n    [attr.data-expanded]=\"railExpanded()\"\n    [attr.data-floating]=\"viewport.narrow() && railExpanded()\"\n  >\n    <nav aria-label=\"Main\">\n      <ul class=\"rail-list\">\n        @for (item of navItems(); track item.path) {\n          <li>\n            @if (item.children?.length && !railExpanded()) {\n              <!-- Collapsed, a page with sub-pages is a link to the page like any other; hover and\n                   keyboard focus show the menu of its sub-pages beside the rail. -->\n              <a\n                neatRailItem\n                [label]=\"item.label\"\n                [routerLink]=\"item.path\"\n                [neatRailMenu]=\"item\"\n                [neatRailMenuCurrent]=\"currentChild(item)\"\n                [attr.aria-current]=\"isActivePage(item) ? 'page' : null\"\n              >\n                <neat-icon [name]=\"item.icon\" />\n              </a>\n            } @else {\n              <a\n                neatRailItem\n                [label]=\"item.label\"\n                [routerLink]=\"item.path\"\n                routerLinkActive=\"active\"\n                [routerLinkActiveOptions]=\"activeMatch\"\n                [ariaCurrentWhenActive]=\"holdsOpenChild(item) ? undefined : 'page'\"\n                [attr.data-branch]=\"holdsOpenChild(item) ? '' : null\"\n              >\n                <neat-icon [name]=\"item.icon\" />\n              </a>\n            }\n            @if (unfolded(); as open) {\n              @if (open.item === item) {\n                <ul class=\"rail-children\">\n                  @for (child of item.children; track child.path) {\n                    <li>\n                      <!-- The row's text is the item's own label, which the rule cannot see. -->\n                      <!-- eslint-disable-next-line @angular-eslint/template/elements-content -->\n                      <a\n                        neatRailItem\n                        data-child\n                        [label]=\"child.label\"\n                        [routerLink]=\"child.path\"\n                        [attr.aria-current]=\"isOpen(child) ? 'page' : null\"\n                      ></a>\n                    </li>\n                  }\n                </ul>\n              }\n            }\n          </li>\n        }\n      </ul>\n    </nav>\n\n    <!-- The app's items, then the kit's theme item: after the pages in the tab order. -->\n    <div class=\"rail-end\">\n      <hr neatRailDivider />\n      <ng-content select=\"[neatRailEnd]\" />\n      <button\n        neatRailItem\n        type=\"button\"\n        [label]=\"theme.scheme() === 'dark' ? 'Light theme' : 'Dark theme'\"\n        (click)=\"theme.toggle()\"\n      >\n        <neat-icon [name]=\"theme.scheme() === 'dark' ? 'sun' : 'moon'\" />\n      </button>\n    </div>\n\n    <button\n      neatRailItem\n      type=\"button\"\n      [label]=\"railExpanded() ? 'Collapse' : 'Show labels'\"\n      (click)=\"toggleRail()\"\n    >\n      <neat-icon [name]=\"railExpanded() ? 'rail-collapse' : 'rail-expand'\" />\n    </button>\n  </div>\n}\n\n<main class=\"content\">\n  <ng-content />\n</main>\n",
		styles: [":host{--neat-rail-width: 3.5rem;--neat-rail-width-expanded: 13rem;--neat-topbar-height: 3rem;display:grid;height:100dvh;max-height:100%;overflow:hidden;background:var(--background);color:var(--foreground)}:host([data-kiosk=\"false\"]){grid-template-areas:\"topbar topbar\" \"rail content\"}:host([data-kiosk=\"false\"][data-narrow=\"false\"]){grid-template-columns:auto minmax(0,1fr);grid-template-rows:var(--neat-topbar-height) minmax(0,1fr)}:host([data-kiosk=\"false\"][data-narrow=\"true\"]){position:relative;grid-template-columns:var(--neat-rail-width) minmax(0,1fr);grid-template-rows:auto minmax(0,1fr)}:host([data-kiosk=\"true\"]){grid-template-areas:\"content\";grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr)}.rail{grid-area:rail;display:flex;flex-direction:column;gap:.5rem;box-sizing:border-box;padding:.5rem;overflow:hidden;background:var(--sidebar);color:var(--sidebar-foreground)}.rail[data-floating=false]{box-shadow:inset -1px 0 0 var(--sidebar-border)}.rail[data-expanded=false]{width:var(--neat-rail-width)}.rail[data-expanded=true]{width:var(--neat-rail-width-expanded)}.rail[data-floating=true]{position:absolute;inset-block:0;inset-inline-start:0;z-index:1}@media(prefers-reduced-motion:no-preference){:host([data-narrow=\"false\"]) .rail{transition:width var(--neat-transition-duration)}}nav{flex:1;min-height:0;overflow:hidden auto}.rail-list,.rail-children{display:flex;flex-direction:column;gap:.25rem;margin:0;padding:0;list-style:none}.rail-children{margin:.25rem 0 0 1.25rem;padding-inline-start:.5rem;border-inline-start:1px solid var(--sidebar-border)}.rail-end{display:flex;flex:none;flex-direction:column;gap:.25rem}.topbar{grid-area:topbar;display:flex;align-items:center;min-width:0;border-block-end:1px solid var(--border);padding-inline-start:calc(var(--neat-rail-width) / 2 - .875rem)}:host([data-narrow=\"false\"]) .topbar{gap:1rem;padding-inline-end:var(--neat-space-2)}:host([data-narrow=\"true\"]) .topbar{flex-wrap:wrap;min-height:var(--neat-topbar-height);gap:0 var(--neat-space-2);padding-inline-end:var(--neat-space-2)}.brand{display:flex;flex:none;align-items:center;gap:.5rem}.app-name{font-weight:700;white-space:nowrap}.page-title{min-width:0;margin:0;padding-inline-start:1rem;border-inline-start:1px solid var(--border);overflow:hidden;font-size:1rem;font-weight:500;line-height:1.5;white-space:nowrap;text-overflow:ellipsis}.page-context{margin-inline-start:.5rem;color:var(--muted-foreground);font-weight:400}.page-toolbar{display:flex;align-items:center;gap:.5rem;min-width:0;padding-inline:.25rem;overflow:auto hidden;scrollbar-width:thin}:host([data-narrow=\"false\"]) .page-toolbar{flex:0 100 auto;align-self:stretch;margin-inline-start:auto}:host([data-narrow=\"true\"]) .page-toolbar{order:1;flex:0 0 100%;box-sizing:border-box;min-height:2.5rem}.topbar-end{display:flex;min-width:0;align-items:center;gap:.5rem}:host([data-narrow=\"true\"]) .topbar-end{flex:1 1 0;justify-content:flex-end}.topbar[data-toolbar=false] .topbar-end{margin-inline-start:auto}.topbar-actions{display:flex;flex:none;align-items:center;gap:.25rem}.aside-edge{display:flex;flex:none;align-self:stretch;align-items:center;justify-content:center;box-sizing:border-box;width:var(--neat-topbar-height);margin-inline-end:calc(-1 * var(--neat-space-2));border-inline-start:1px solid var(--border)}.content{grid-area:content;min-width:0;min-height:0;overflow:hidden;isolation:isolate}.kiosk-chrome{grid-area:content;place-self:start end;z-index:1;display:flex;flex-direction:row-reverse;align-items:center;gap:.5rem;min-width:0;max-width:calc(100% - 2rem);margin:1rem}.kiosk-chrome[data-shown=false]:not(:has(:focus-visible)){opacity:0;pointer-events:none}@media(prefers-reduced-motion:no-preference){.kiosk-chrome{transition:opacity var(--neat-transition-duration)}}neat-kiosk-exit{flex:none}.kiosk-toolbar{display:flex;align-items:center;gap:.5rem;box-sizing:border-box;min-width:0;min-height:3rem;padding-inline:.75rem;overflow:auto hidden;scrollbar-width:thin;border:1px solid var(--border);border-radius:1.5rem;background:var(--background)}\n"],
		dependencies: [
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatKioskExit,
				selector: "neat-kiosk-exit",
				outputs: ["exited"]
			},
			{
				kind: "component",
				type: NeatLogo,
				selector: "neat-logo"
			},
			{
				kind: "directive",
				type: NeatRailDivider,
				selector: "hr[neatRailDivider]"
			},
			{
				kind: "component",
				type: NeatRailItem,
				selector: "button[neatRailItem], a[neatRailItem]",
				inputs: [
					"label",
					"text",
					"detail",
					"tone"
				]
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			},
			{
				kind: "directive",
				type: RailMenu,
				selector: "a[neatRailItem][neatRailMenu]",
				inputs: ["neatRailMenu", "neatRailMenuCurrent"]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatShell,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-shell",
			imports: [
				CdkPortalOutlet,
				NeatButton,
				NeatIcon,
				NeatKioskExit,
				NeatLogo,
				NeatRailDivider,
				NeatRailItem,
				NeatTooltip,
				RailMenu,
				RouterLink,
				RouterLinkActive
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [RailState],
			host: {
				"[attr.data-kiosk]": "kiosk.active()",
				"[attr.data-narrow]": "viewport.narrow()"
			},
			template: "@if (kiosk.active()) {\n  <div class=\"kiosk-chrome\" [attr.data-shown]=\"!kiosk.pointerIdle()\">\n    <!-- First in the tab order, so it is reachable from the keyboard; drawn last (right). -->\n    <neat-kiosk-exit (exited)=\"focusKioskButtonAfterExit()\" />\n    @if (pageToolbar() || asideToggle()) {\n      <div class=\"kiosk-toolbar shadow-md\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"pageToolbar()\" />\n        <ng-template [cdkPortalOutlet]=\"asideToggle()\" />\n      </div>\n    }\n  </div>\n} @else {\n  <header class=\"topbar\" [attr.data-toolbar]=\"pageToolbar() ? 'true' : 'false'\">\n    <div class=\"brand\">\n      <neat-logo />\n      <span class=\"app-name\" [class.sr-only]=\"viewport.narrow()\">{{ appName() }}</span>\n    </div>\n    @if (pageTitle(); as title) {\n      @if (title.text) {\n        <!-- The muted part is inside the heading: it is where the person is, and the page's name\n             to a screen reader too. -->\n        <h1 class=\"page-title\" [class.sr-only]=\"viewport.narrow()\">\n          {{ title.text }}\n          @if (title.context) {\n            <span class=\"page-context\">{{ title.context }}</span>\n          }\n        </h1>\n      }\n    }\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"page-toolbar\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n    <div class=\"topbar-end\">\n      <ng-content select=\"[neatTopbarEnd]\" />\n    </div>\n    <div class=\"topbar-actions\">\n      <button\n        #kioskButton\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Kiosk mode\"\n        neatTooltip=\"Kiosk mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"kiosk.toggle()\"\n      >\n        <neat-icon name=\"kiosk-enter\" />\n      </button>\n    </div>\n    @if (asideToggle(); as toggle) {\n      <!-- The page's aside toggle, at the right edge above the panel. -->\n      <div class=\"aside-edge\">\n        <ng-template [cdkPortalOutlet]=\"toggle\" />\n      </div>\n    }\n  </header>\n\n  <div\n    class=\"rail data-[floating=true]:shadow-md\"\n    [attr.data-expanded]=\"railExpanded()\"\n    [attr.data-floating]=\"viewport.narrow() && railExpanded()\"\n  >\n    <nav aria-label=\"Main\">\n      <ul class=\"rail-list\">\n        @for (item of navItems(); track item.path) {\n          <li>\n            @if (item.children?.length && !railExpanded()) {\n              <!-- Collapsed, a page with sub-pages is a link to the page like any other; hover and\n                   keyboard focus show the menu of its sub-pages beside the rail. -->\n              <a\n                neatRailItem\n                [label]=\"item.label\"\n                [routerLink]=\"item.path\"\n                [neatRailMenu]=\"item\"\n                [neatRailMenuCurrent]=\"currentChild(item)\"\n                [attr.aria-current]=\"isActivePage(item) ? 'page' : null\"\n              >\n                <neat-icon [name]=\"item.icon\" />\n              </a>\n            } @else {\n              <a\n                neatRailItem\n                [label]=\"item.label\"\n                [routerLink]=\"item.path\"\n                routerLinkActive=\"active\"\n                [routerLinkActiveOptions]=\"activeMatch\"\n                [ariaCurrentWhenActive]=\"holdsOpenChild(item) ? undefined : 'page'\"\n                [attr.data-branch]=\"holdsOpenChild(item) ? '' : null\"\n              >\n                <neat-icon [name]=\"item.icon\" />\n              </a>\n            }\n            @if (unfolded(); as open) {\n              @if (open.item === item) {\n                <ul class=\"rail-children\">\n                  @for (child of item.children; track child.path) {\n                    <li>\n                      <!-- The row's text is the item's own label, which the rule cannot see. -->\n                      <!-- eslint-disable-next-line @angular-eslint/template/elements-content -->\n                      <a\n                        neatRailItem\n                        data-child\n                        [label]=\"child.label\"\n                        [routerLink]=\"child.path\"\n                        [attr.aria-current]=\"isOpen(child) ? 'page' : null\"\n                      ></a>\n                    </li>\n                  }\n                </ul>\n              }\n            }\n          </li>\n        }\n      </ul>\n    </nav>\n\n    <!-- The app's items, then the kit's theme item: after the pages in the tab order. -->\n    <div class=\"rail-end\">\n      <hr neatRailDivider />\n      <ng-content select=\"[neatRailEnd]\" />\n      <button\n        neatRailItem\n        type=\"button\"\n        [label]=\"theme.scheme() === 'dark' ? 'Light theme' : 'Dark theme'\"\n        (click)=\"theme.toggle()\"\n      >\n        <neat-icon [name]=\"theme.scheme() === 'dark' ? 'sun' : 'moon'\" />\n      </button>\n    </div>\n\n    <button\n      neatRailItem\n      type=\"button\"\n      [label]=\"railExpanded() ? 'Collapse' : 'Show labels'\"\n      (click)=\"toggleRail()\"\n    >\n      <neat-icon [name]=\"railExpanded() ? 'rail-collapse' : 'rail-expand'\" />\n    </button>\n  </div>\n}\n\n<main class=\"content\">\n  <ng-content />\n</main>\n",
			styles: [":host{--neat-rail-width: 3.5rem;--neat-rail-width-expanded: 13rem;--neat-topbar-height: 3rem;display:grid;height:100dvh;max-height:100%;overflow:hidden;background:var(--background);color:var(--foreground)}:host([data-kiosk=\"false\"]){grid-template-areas:\"topbar topbar\" \"rail content\"}:host([data-kiosk=\"false\"][data-narrow=\"false\"]){grid-template-columns:auto minmax(0,1fr);grid-template-rows:var(--neat-topbar-height) minmax(0,1fr)}:host([data-kiosk=\"false\"][data-narrow=\"true\"]){position:relative;grid-template-columns:var(--neat-rail-width) minmax(0,1fr);grid-template-rows:auto minmax(0,1fr)}:host([data-kiosk=\"true\"]){grid-template-areas:\"content\";grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr)}.rail{grid-area:rail;display:flex;flex-direction:column;gap:.5rem;box-sizing:border-box;padding:.5rem;overflow:hidden;background:var(--sidebar);color:var(--sidebar-foreground)}.rail[data-floating=false]{box-shadow:inset -1px 0 0 var(--sidebar-border)}.rail[data-expanded=false]{width:var(--neat-rail-width)}.rail[data-expanded=true]{width:var(--neat-rail-width-expanded)}.rail[data-floating=true]{position:absolute;inset-block:0;inset-inline-start:0;z-index:1}@media(prefers-reduced-motion:no-preference){:host([data-narrow=\"false\"]) .rail{transition:width var(--neat-transition-duration)}}nav{flex:1;min-height:0;overflow:hidden auto}.rail-list,.rail-children{display:flex;flex-direction:column;gap:.25rem;margin:0;padding:0;list-style:none}.rail-children{margin:.25rem 0 0 1.25rem;padding-inline-start:.5rem;border-inline-start:1px solid var(--sidebar-border)}.rail-end{display:flex;flex:none;flex-direction:column;gap:.25rem}.topbar{grid-area:topbar;display:flex;align-items:center;min-width:0;border-block-end:1px solid var(--border);padding-inline-start:calc(var(--neat-rail-width) / 2 - .875rem)}:host([data-narrow=\"false\"]) .topbar{gap:1rem;padding-inline-end:var(--neat-space-2)}:host([data-narrow=\"true\"]) .topbar{flex-wrap:wrap;min-height:var(--neat-topbar-height);gap:0 var(--neat-space-2);padding-inline-end:var(--neat-space-2)}.brand{display:flex;flex:none;align-items:center;gap:.5rem}.app-name{font-weight:700;white-space:nowrap}.page-title{min-width:0;margin:0;padding-inline-start:1rem;border-inline-start:1px solid var(--border);overflow:hidden;font-size:1rem;font-weight:500;line-height:1.5;white-space:nowrap;text-overflow:ellipsis}.page-context{margin-inline-start:.5rem;color:var(--muted-foreground);font-weight:400}.page-toolbar{display:flex;align-items:center;gap:.5rem;min-width:0;padding-inline:.25rem;overflow:auto hidden;scrollbar-width:thin}:host([data-narrow=\"false\"]) .page-toolbar{flex:0 100 auto;align-self:stretch;margin-inline-start:auto}:host([data-narrow=\"true\"]) .page-toolbar{order:1;flex:0 0 100%;box-sizing:border-box;min-height:2.5rem}.topbar-end{display:flex;min-width:0;align-items:center;gap:.5rem}:host([data-narrow=\"true\"]) .topbar-end{flex:1 1 0;justify-content:flex-end}.topbar[data-toolbar=false] .topbar-end{margin-inline-start:auto}.topbar-actions{display:flex;flex:none;align-items:center;gap:.25rem}.aside-edge{display:flex;flex:none;align-self:stretch;align-items:center;justify-content:center;box-sizing:border-box;width:var(--neat-topbar-height);margin-inline-end:calc(-1 * var(--neat-space-2));border-inline-start:1px solid var(--border)}.content{grid-area:content;min-width:0;min-height:0;overflow:hidden;isolation:isolate}.kiosk-chrome{grid-area:content;place-self:start end;z-index:1;display:flex;flex-direction:row-reverse;align-items:center;gap:.5rem;min-width:0;max-width:calc(100% - 2rem);margin:1rem}.kiosk-chrome[data-shown=false]:not(:has(:focus-visible)){opacity:0;pointer-events:none}@media(prefers-reduced-motion:no-preference){.kiosk-chrome{transition:opacity var(--neat-transition-duration)}}neat-kiosk-exit{flex:none}.kiosk-toolbar{display:flex;align-items:center;gap:.5rem;box-sizing:border-box;min-width:0;min-height:3rem;padding-inline:.75rem;overflow:auto hidden;scrollbar-width:thin;border:1px solid var(--border);border-radius:1.5rem;background:var(--background)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		appName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appName",
				required: true
			}]
		}],
		navItems: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navItems",
				required: true
			}]
		}],
		kioskExit: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatKioskExit), { isSignal: true }]
		}],
		kioskButton: [{
			type: i0.ViewChild,
			args: ["kioskButton", { isSignal: true }]
		}]
	}
});
var NeatTitleStrategy = class extends TitleStrategy {
	appName;
	title = inject(Title);
	constructor(appName) {
		super();
		this.appName = appName;
	}
	updateTitle(snapshot) {
		const page = this.buildTitle(snapshot);
		this.title.setTitle(page ? `${this.appName} · ${page}` : this.appName);
	}
};
function provideNeatTitles(appName) {
	return makeEnvironmentProviders([{
		provide: TitleStrategy,
		useFactory: () => new NeatTitleStrategy(appName)
	}]);
}
const NEAT_EASINGS = {
	"ease-in-out": (t) => t < .5 ? 4 * t ** 3 : 1 - (-2 * t + 2) ** 3 / 2,
	"ease-out": (t) => 1 - (1 - t) ** 3,
	"ease-in": (t) => t ** 3,
	linear: (t) => t
};
const EASE_MS = 400;
const REDUCED_MOTION = "(prefers-reduced-motion: reduce)";
const BROWSER_CLOCK = {
	now: () => performance.now(),
	request: (callback) => requestAnimationFrame(callback),
	cancel: (handle) => cancelAnimationFrame(handle)
};
const isNone = (value) => value === null || value === void 0;
function reducedMotion() {
	return typeof matchMedia === "function" && matchMedia(REDUCED_MOTION).matches;
}
function neatEased(source, options = {}) {
	return easedBy(BROWSER_CLOCK, source, options);
}
function easedBy(clock, source, { durationMs = EASE_MS, easing = "ease-in-out" } = {}) {
	const shown = signal(void 0, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	let from = 0;
	let to;
	let start = 0;
	let handle;
	const stop = () => {
		if (handle !== void 0) clock.cancel(handle);
		handle = void 0;
	};
	const curve = () => {
		const current = isSignal(easing) ? untracked(easing) : easing;
		return typeof current === "function" ? current : NEAT_EASINGS[current];
	};
	const tick = () => {
		handle = void 0;
		if (isNone(to)) return;
		const t = Math.min(1, (clock.now() - start) / durationMs);
		shown.set(t >= 1 ? to : from + (to - from) * curve()(t));
		if (t < 1) handle = clock.request(tick);
	};
	const retarget = (value) => {
		if (value === to) return;
		const current = shown();
		to = value;
		if (isNone(value) || isNone(current) || reducedMotion()) {
			stop();
			shown.set(value);
			return;
		}
		from = current;
		start = clock.now();
		handle ??= clock.request(tick);
	};
	effect(() => {
		const value = source();
		untracked(() => retarget(value));
	});
	inject(DestroyRef).onDestroy(stop);
	return shown.asReadonly();
}
function inPageLinkTarget(event, page) {
	if (event.defaultPrevented || event.button !== 0) return null;
	if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return null;
	const link = event.target?.closest?.("a[href]");
	if (!link || link.closest("neat-page") !== page) return null;
	const target = link.getAttribute("target");
	if (target && target !== "_self" || link.hasAttribute("download")) return null;
	const href = link.getAttribute("href") ?? "";
	if (!href.startsWith("#") || href.length === 1) return null;
	try {
		return decodeURIComponent(href.slice(1));
	} catch {
		return href.slice(1);
	}
}
function scrollToTarget(target, box, smooth) {
	const padding = length(getComputedStyle(box).scrollPaddingTop, box.clientHeight);
	const margin = length(getComputedStyle(target).scrollMarginTop, 0);
	const offset = target.getBoundingClientRect().top - box.getBoundingClientRect().top;
	box.scrollTo({
		top: Math.max(0, box.scrollTop + offset - padding - margin),
		behavior: smooth ? "smooth" : "instant"
	});
}
function length(value, basis) {
	const number = parseFloat(value);
	if (!Number.isFinite(number)) return 0;
	return value.trim().endsWith("%") ? number / 100 * basis : number;
}
const MIN_REM = 18;
const BODY_MIN_REM = 20;
const KEY_STEP = 16;
var NeatPage = class NeatPage {
	viewport = inject(NeatViewport);
	scroll = input("body", ...ngDevMode ? [{ debugName: "scroll" }] : /* istanbul ignore next */ []);
	padding = input("page", ...ngDevMode ? [{ debugName: "padding" }] : /* istanbul ignore next */ []);
	aside = input("closed", ...ngDevMode ? [{ debugName: "aside" }] : /* istanbul ignore next */ []);
	asideWidth = model(null, ...ngDevMode ? [{ debugName: "asideWidth" }] : /* istanbul ignore next */ []);
	page = inject(ElementRef).nativeElement;
	body = viewChild.required("body", ...ngDevMode ? [{ debugName: "body" }] : /* istanbul ignore next */ []);
	panel = viewChild("aside", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	pageWidth = signal(0, ...ngDevMode ? [{ debugName: "pageWidth" }] : /* istanbul ignore next */ []);
	panelWidth = signal(0, ...ngDevMode ? [{ debugName: "panelWidth" }] : /* istanbul ignore next */ []);
	rem = signal(16, ...ngDevMode ? [{ debugName: "rem" }] : /* istanbul ignore next */ []);
	dragWidth = signal(null, ...ngDevMode ? [{ debugName: "dragWidth" }] : /* istanbul ignore next */ []);
	dragStart = null;
	bounds = computed(() => {
		const rem = this.rem();
		const min = Math.round(MIN_REM * rem);
		const page = this.pageWidth();
		return {
			min,
			max: page > 0 ? Math.max(min, Math.floor(page - BODY_MIN_REM * rem)) : null
		};
	}, ...ngDevMode ? [{ debugName: "bounds" }] : /* istanbul ignore next */ []);
	requested = computed(() => this.viewport.narrow() ? null : this.dragWidth() ?? this.asideWidth(), ...ngDevMode ? [{ debugName: "requested" }] : /* istanbul ignore next */ []);
	width = computed(() => {
		const wanted = this.requested() ?? (this.panelWidth() > 0 ? this.panelWidth() : null);
		return wanted === null ? null : this.clamp(wanted);
	}, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	constructor() {
		effect((onCleanup) => {
			const panel = this.panel()?.nativeElement;
			const narrow = this.viewport.narrow();
			onCleanup(() => this.cancelDrag());
			if (!panel || narrow || typeof ResizeObserver !== "function") return;
			const observer = new ResizeObserver(() => this.measure(panel));
			observer.observe(this.page);
			observer.observe(panel);
			onCleanup(() => observer.disconnect());
		});
		this.followFragments();
	}
	followFragments() {
		const router = inject(Router, { optional: true });
		if (!router) return;
		const injector = inject(Injector);
		const changes = inject(ChangeDetectorRef);
		let shown = false;
		afterNextRender(() => shown = true);
		router.events.pipe(takeUntilDestroyed()).subscribe((event) => {
			const url = event instanceof NavigationEnd ? event.urlAfterRedirects : event instanceof NavigationSkipped && event.code === NavigationSkippedCode.IgnoredSameUrlNavigation ? event.url : null;
			const id = url === null ? null : router.parseUrl(url).fragment;
			if (!id) return;
			const smooth = shown && !reducedMotion();
			afterNextRender(() => this.scrollToFragment(id, smooth), { injector });
			changes.markForCheck();
		});
		if (inject(LocationStrategy, { optional: true }) instanceof HashLocationStrategy) return;
		const onClick = (event) => {
			const id = inPageLinkTarget(event, this.page);
			if (id === null) return;
			event.preventDefault();
			const current = router.parseUrl(router.url);
			router.navigateByUrl(new UrlTree(current.root, current.queryParams, id));
		};
		this.page.addEventListener("click", onClick);
		inject(DestroyRef).onDestroy(() => this.page.removeEventListener("click", onClick));
	}
	scrollToFragment(id, smooth) {
		const target = Array.from(this.page.querySelectorAll(`#${CSS.escape(id)}`)).find((element) => element.closest("neat-page") === this.page);
		if (!target) return;
		const box = [this.scroll() === "body" ? this.body().nativeElement : null, this.panel()?.nativeElement].find((candidate) => candidate?.contains(target));
		if (box) scrollToTarget(target, box, smooth);
	}
	step(event) {
		const { min, max } = this.bounds();
		const current = this.current();
		const next = {
			ArrowLeft: current + KEY_STEP,
			ArrowRight: current - KEY_STEP,
			Home: min,
			End: max ?? current
		}[event.key];
		if (next === void 0) return;
		event.preventDefault();
		const width = this.clamp(next);
		if (width !== current) this.asideWidth.set(width);
	}
	startDrag(event) {
		if (event.button !== 0) return;
		event.currentTarget.setPointerCapture(event.pointerId);
		const width = this.current();
		this.dragStart = {
			x: event.clientX,
			width,
			moved: false
		};
		this.dragWidth.set(width);
	}
	drag(event) {
		if (!this.dragStart) return;
		this.dragStart.moved = true;
		this.dragWidth.set(this.clamp(this.dragStart.width + this.dragStart.x - event.clientX));
	}
	endDrag() {
		const width = this.dragWidth();
		const moved = this.dragStart?.moved;
		this.cancelDrag();
		if (moved && width !== null) this.asideWidth.set(width);
	}
	cancelDrag() {
		this.dragStart = null;
		this.dragWidth.set(null);
	}
	current() {
		return this.width() ?? this.clamp(this.panel()?.nativeElement.offsetWidth || this.bounds().min);
	}
	clamp(width) {
		const { min, max } = this.bounds();
		return Math.round(Math.min(max ?? Infinity, Math.max(min, width)));
	}
	measure(panel) {
		this.pageWidth.set(this.page.clientWidth);
		this.panelWidth.set(panel.offsetWidth);
		const fontSize = getComputedStyle(this.page.ownerDocument.documentElement).fontSize;
		this.rem.set(parseFloat(fontSize) || 16);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatPage,
		isStandalone: true,
		selector: "neat-page",
		inputs: {
			scroll: {
				classPropertyName: "scroll",
				publicName: "scroll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			padding: {
				classPropertyName: "padding",
				publicName: "padding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			aside: {
				classPropertyName: "aside",
				publicName: "aside",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			asideWidth: {
				classPropertyName: "asideWidth",
				publicName: "asideWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { asideWidth: "asideWidthChange" },
		host: { properties: {
			"attr.data-aside": "viewport.narrow() ? 'overlay' : 'beside'",
			"attr.data-nav": "viewport.narrow() ? 'above' : 'beside'",
			"attr.data-resizing": "dragWidth() === null ? null : ''"
		} },
		viewQueries: [{
			propertyName: "body",
			first: true,
			predicate: ["body"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "panel",
			first: true,
			predicate: ["aside"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-content select="[neatPageNav]" />
    <div class="content">
      <div #body class="body" [attr.data-scroll]="scroll()" [attr.data-padding]="padding()">
        <ng-content />
      </div>
      @if (aside() === 'open') {
        @if (!viewport.narrow()) {
          <div
            class="separator"
            role="separator"
            tabindex="0"
            aria-orientation="vertical"
            aria-label="Resize side panel"
            [attr.aria-valuemin]="bounds().min"
            [attr.aria-valuemax]="bounds().max"
            [attr.aria-valuenow]="width()"
            [attr.aria-valuetext]="width() === null ? null : width() + ' px'"
            (keydown)="step($event)"
            (pointerdown)="startDrag($event)"
            (pointermove)="drag($event)"
            (pointerup)="endDrag()"
            (pointercancel)="cancelDrag()"
            (lostpointercapture)="cancelDrag()"
            (dblclick)="asideWidth.set(null)"
          ></div>
        }
        <aside
          #aside
          class="in-data-[aside=overlay]:shadow-md"
          [style.--neat-aside-width]="requested() === null ? null : requested() + 'px'"
          [style.--neat-page-aside-min]="viewport.narrow() ? null : bounds().min + 'px'"
          [style.--neat-page-aside-max]="
            viewport.narrow() || bounds().max === null ? null : bounds().max + 'px'
          "
        >
          <ng-content select="[neatPageAside]" />
        </aside>
      }
    </div>
  `,
		isInline: true,
		styles: [":host{display:flex;height:100%;overflow:hidden}:host([data-nav=\"beside\"]){flex-direction:row}:host([data-nav=\"above\"]){flex-direction:column}.content{position:relative;display:flex;flex:1 1 0;min-width:0;min-height:0}.body{flex:1 1 0;min-width:0;box-sizing:border-box;height:100%}.body[data-scroll=body]{overflow:auto}.body[data-scroll=none]{overflow:hidden}.body[data-padding=page]{padding:var(--neat-space-6);scroll-padding-top:var(--neat-space-6)}.body[data-padding=none]{padding:0}.separator{position:relative;z-index:1;flex:none;width:var(--neat-space-2);margin-inline:calc(var(--neat-space-2) / -2);cursor:col-resize;touch-action:none;-webkit-user-select:none;user-select:none}.separator:focus-visible{outline:var(--neat-focus-ring-width) solid transparent}.separator:after{content:\"\";position:absolute;inset-block:0;inset-inline-start:calc(50% - var(--neat-focus-ring-width) / 2);width:var(--neat-focus-ring-width);background:var(--ring);opacity:0}.separator:hover:after,.separator:focus-visible:after,:host([data-resizing]) .separator:after{opacity:1}@media(prefers-reduced-motion:no-preference){.separator:after{transition:opacity var(--neat-transition-duration)}}aside{box-sizing:border-box;height:100%;padding:var(--neat-space-4);scroll-padding-top:var(--neat-space-4);overflow:auto;border-inline-start:1px solid var(--border)}:host([data-aside=\"beside\"]) aside{flex:none;width:clamp(var(--neat-page-aside-min),var(--neat-aside-width),var(--neat-page-aside-max, 100%))}:host([data-aside=\"overlay\"]) aside{position:absolute;inset-block:0;inset-inline-end:0;z-index:1;width:min(var(--neat-aside-width),100%);background:var(--background)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPage,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-aside]": "viewport.narrow() ? 'overlay' : 'beside'",
				"[attr.data-nav]": "viewport.narrow() ? 'above' : 'beside'",
				"[attr.data-resizing]": "dragWidth() === null ? null : ''"
			},
			template: `
    <ng-content select="[neatPageNav]" />
    <div class="content">
      <div #body class="body" [attr.data-scroll]="scroll()" [attr.data-padding]="padding()">
        <ng-content />
      </div>
      @if (aside() === 'open') {
        @if (!viewport.narrow()) {
          <div
            class="separator"
            role="separator"
            tabindex="0"
            aria-orientation="vertical"
            aria-label="Resize side panel"
            [attr.aria-valuemin]="bounds().min"
            [attr.aria-valuemax]="bounds().max"
            [attr.aria-valuenow]="width()"
            [attr.aria-valuetext]="width() === null ? null : width() + ' px'"
            (keydown)="step($event)"
            (pointerdown)="startDrag($event)"
            (pointermove)="drag($event)"
            (pointerup)="endDrag()"
            (pointercancel)="cancelDrag()"
            (lostpointercapture)="cancelDrag()"
            (dblclick)="asideWidth.set(null)"
          ></div>
        }
        <aside
          #aside
          class="in-data-[aside=overlay]:shadow-md"
          [style.--neat-aside-width]="requested() === null ? null : requested() + 'px'"
          [style.--neat-page-aside-min]="viewport.narrow() ? null : bounds().min + 'px'"
          [style.--neat-page-aside-max]="
            viewport.narrow() || bounds().max === null ? null : bounds().max + 'px'
          "
        >
          <ng-content select="[neatPageAside]" />
        </aside>
      }
    </div>
  `,
			styles: [":host{display:flex;height:100%;overflow:hidden}:host([data-nav=\"beside\"]){flex-direction:row}:host([data-nav=\"above\"]){flex-direction:column}.content{position:relative;display:flex;flex:1 1 0;min-width:0;min-height:0}.body{flex:1 1 0;min-width:0;box-sizing:border-box;height:100%}.body[data-scroll=body]{overflow:auto}.body[data-scroll=none]{overflow:hidden}.body[data-padding=page]{padding:var(--neat-space-6);scroll-padding-top:var(--neat-space-6)}.body[data-padding=none]{padding:0}.separator{position:relative;z-index:1;flex:none;width:var(--neat-space-2);margin-inline:calc(var(--neat-space-2) / -2);cursor:col-resize;touch-action:none;-webkit-user-select:none;user-select:none}.separator:focus-visible{outline:var(--neat-focus-ring-width) solid transparent}.separator:after{content:\"\";position:absolute;inset-block:0;inset-inline-start:calc(50% - var(--neat-focus-ring-width) / 2);width:var(--neat-focus-ring-width);background:var(--ring);opacity:0}.separator:hover:after,.separator:focus-visible:after,:host([data-resizing]) .separator:after{opacity:1}@media(prefers-reduced-motion:no-preference){.separator:after{transition:opacity var(--neat-transition-duration)}}aside{box-sizing:border-box;height:100%;padding:var(--neat-space-4);scroll-padding-top:var(--neat-space-4);overflow:auto;border-inline-start:1px solid var(--border)}:host([data-aside=\"beside\"]) aside{flex:none;width:clamp(var(--neat-page-aside-min),var(--neat-aside-width),var(--neat-page-aside-max, 100%))}:host([data-aside=\"overlay\"]) aside{position:absolute;inset-block:0;inset-inline-end:0;z-index:1;width:min(var(--neat-aside-width),100%);background:var(--background)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		scroll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scroll",
				required: false
			}]
		}],
		padding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "padding",
				required: false
			}]
		}],
		aside: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "aside",
				required: false
			}]
		}],
		asideWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "asideWidth",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["asideWidthChange"]
		}],
		body: [{
			type: i0.ViewChild,
			args: ["body", { isSignal: true }]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["aside", { isSignal: true }]
		}]
	}
});
const COLLAPSIBLE_CLASSES = {
	trigger: "group flex w-full min-w-0 cursor-pointer items-center gap-(--neat-space-2) rounded-(--radius) py-1 text-start text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring",
	chevron: "shrink-0 text-muted-foreground transition-transform duration-(--neat-transition-duration) group-hover:text-foreground motion-reduce:transition-none",
	label: "shrink-0 font-medium",
	summary: "min-w-0 truncate text-muted-foreground",
	content: "pt-(--neat-space-2) data-closed:hidden"
};
const INPUT_HELM_CLASSES = "dark:bg-input/30 border-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 h-9 rounded-md border bg-transparent px-2.5 py-1 text-base shadow-xs transition-[color,box-shadow] file:h-7 file:text-sm file:font-medium focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 md:text-sm file:text-foreground placeholder:text-muted-foreground w-full min-w-0 outline-none file:inline-flex file:border-0 file:bg-transparent disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50";
const OVERRIDES = "focus-visible:ring-ring dark:bg-transparent";
const INPUT_CLASSES = {
	medium: hlm(INPUT_HELM_CLASSES, OVERRIDES),
	small: hlm(INPUT_HELM_CLASSES, OVERRIDES, "h-8")
};
const SIZE_CLASSES = {
	small: INPUT_CLASSES.small,
	medium: INPUT_CLASSES.medium,
	large: hlm(INPUT_CLASSES.medium, "h-12 text-base md:text-base")
};
const VARIANT_CLASSES = {
	filled: "rounded-full border-transparent bg-foreground/8 shadow-none hover:bg-foreground/12 focus-visible:bg-(--neat-surface) dark:bg-foreground/8 dark:hover:bg-foreground/12 dark:focus-visible:bg-(--neat-surface)",
	outlined: "",
	underlined: "rounded-none border-x-0 border-t-0 shadow-none focus-visible:border-b-2 focus-visible:ring-0",
	raised: "rounded-xl border-border bg-card shadow-sm dark:bg-card"
};
let nextSearchId = 0;
var NeatSearch = class NeatSearch {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = model("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	variant = input("filled", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	clearLabel = input("Clear search", ...ngDevMode ? [{ debugName: "clearLabel" }] : /* istanbul ignore next */ []);
	status = input(...ngDevMode ? [void 0, { debugName: "status" }] : /* istanbul ignore next */ []);
	listbox = input(...ngDevMode ? [void 0, { debugName: "listbox" }] : /* istanbul ignore next */ []);
	activeOption = input(null, ...ngDevMode ? [{ debugName: "activeOption" }] : /* istanbul ignore next */ []);
	id = `neat-search-${++nextSearchId}`;
	fieldClasses = computed(() => hlm(SIZE_CLASSES[this.size()], VARIANT_CLASSES[this.variant()]), ...ngDevMode ? [{ debugName: "fieldClasses" }] : /* istanbul ignore next */ []);
	field = viewChild.required("field", ...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	clear() {
		this.value.set("");
		this.field().nativeElement.focus();
	}
	escape(event) {
		if (!this.value()) return;
		event.preventDefault();
		event.stopPropagation();
		this.value.set("");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSearch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSearch,
		isStandalone: true,
		selector: "neat-search",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearLabel: {
				classPropertyName: "clearLabel",
				publicName: "clearLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			listbox: {
				classPropertyName: "listbox",
				publicName: "listbox",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activeOption: {
				classPropertyName: "activeOption",
				publicName: "activeOption",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { properties: {
			"attr.data-size": "size()",
			"attr.data-variant": "variant()"
		} },
		viewQueries: [{
			propertyName: "field",
			first: true,
			predicate: ["field"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div class="field">
      <neat-icon class="glyph" name="search" [size]="size() === 'large' ? 20 : 16" />
      <input
        #field
        type="search"
        autocomplete="off"
        spellcheck="false"
        [id]="id"
        [class]="fieldClasses()"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="status() === undefined ? null : id + '-status'"
        [attr.role]="listbox() ? 'combobox' : null"
        [attr.aria-controls]="listbox() ?? null"
        [attr.aria-expanded]="listbox() ? 'true' : null"
        [attr.aria-autocomplete]="listbox() ? 'list' : null"
        [attr.aria-activedescendant]="listbox() ? activeOption() : null"
        [placeholder]="placeholder()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (keydown.escape)="escape($event)"
      />
      @if (value()) {
        <button type="button" class="clear" [attr.aria-label]="clearLabel()" (click)="clear()">
          <neat-icon name="close" [size]="size() === 'large' ? 18 : 16" />
        </button>
      }
    </div>
    @if (status() !== undefined) {
      <p class="status" [id]="id + '-status'" aria-live="polite">{{ status() }}</p>
    }
  `,
		isInline: true,
		styles: [":host{display:block;min-width:0;--search-glyph-start: .625rem;--search-text-start: 2rem;--search-text-end: 2.25rem;--search-clear-end: .375rem;--search-clear-size: 1.5rem}:host([data-size=\"small\"]){--search-text-end: 2rem;--search-clear-end: .25rem}:host([data-variant=\"filled\"]){--search-glyph-start: .875rem;--search-text-start: 2.25rem;--search-clear-end: .5rem}:host([data-variant=\"underlined\"]){--search-glyph-start: .125rem;--search-text-start: 1.5rem;--search-clear-end: 0}:host([data-size=\"large\"]){--search-glyph-start: 1rem;--search-text-start: 2.75rem;--search-text-end: 3rem;--search-clear-end: .625rem;--search-clear-size: 2rem}:host([data-size=\"large\"][data-variant=\"underlined\"]){--search-glyph-start: .125rem;--search-text-start: 2rem;--search-clear-end: 0}.field{position:relative}input{padding-inline:var(--search-text-start) var(--search-text-end)}.glyph{position:absolute;inset-inline-start:var(--search-glyph-start);top:50%;translate:0 -50%;color:var(--muted-foreground);pointer-events:none}input::-webkit-search-cancel-button,input::-webkit-search-decoration{appearance:none}.clear{position:absolute;inset-inline-end:var(--search-clear-end);top:50%;translate:0 -50%;display:inline-flex;align-items:center;justify-content:center;width:var(--search-clear-size);height:var(--search-clear-size);padding:0;border:0;border-radius:calc(var(--radius) - 2px);background:transparent;color:var(--muted-foreground);cursor:pointer}:host([data-variant=\"filled\"]) .clear{border-radius:50%}.clear:hover{background:var(--accent);color:var(--accent-foreground)}.clear:focus-visible{outline:2px solid var(--ring);outline-offset:0}.status{margin:var(--neat-space-2) 0 0;font-size:var(--neat-text-xs);color:var(--muted-foreground)}\n"],
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSearch,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-search",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-size]": "size()",
				"[attr.data-variant]": "variant()"
			},
			template: `
    <div class="field">
      <neat-icon class="glyph" name="search" [size]="size() === 'large' ? 20 : 16" />
      <input
        #field
        type="search"
        autocomplete="off"
        spellcheck="false"
        [id]="id"
        [class]="fieldClasses()"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="status() === undefined ? null : id + '-status'"
        [attr.role]="listbox() ? 'combobox' : null"
        [attr.aria-controls]="listbox() ?? null"
        [attr.aria-expanded]="listbox() ? 'true' : null"
        [attr.aria-autocomplete]="listbox() ? 'list' : null"
        [attr.aria-activedescendant]="listbox() ? activeOption() : null"
        [placeholder]="placeholder()"
        [value]="value()"
        (input)="value.set($any($event.target).value)"
        (keydown.escape)="escape($event)"
      />
      @if (value()) {
        <button type="button" class="clear" [attr.aria-label]="clearLabel()" (click)="clear()">
          <neat-icon name="close" [size]="size() === 'large' ? 18 : 16" />
        </button>
      }
    </div>
    @if (status() !== undefined) {
      <p class="status" [id]="id + '-status'" aria-live="polite">{{ status() }}</p>
    }
  `,
			styles: [":host{display:block;min-width:0;--search-glyph-start: .625rem;--search-text-start: 2rem;--search-text-end: 2.25rem;--search-clear-end: .375rem;--search-clear-size: 1.5rem}:host([data-size=\"small\"]){--search-text-end: 2rem;--search-clear-end: .25rem}:host([data-variant=\"filled\"]){--search-glyph-start: .875rem;--search-text-start: 2.25rem;--search-clear-end: .5rem}:host([data-variant=\"underlined\"]){--search-glyph-start: .125rem;--search-text-start: 1.5rem;--search-clear-end: 0}:host([data-size=\"large\"]){--search-glyph-start: 1rem;--search-text-start: 2.75rem;--search-text-end: 3rem;--search-clear-end: .625rem;--search-clear-size: 2rem}:host([data-size=\"large\"][data-variant=\"underlined\"]){--search-glyph-start: .125rem;--search-text-start: 2rem;--search-clear-end: 0}.field{position:relative}input{padding-inline:var(--search-text-start) var(--search-text-end)}.glyph{position:absolute;inset-inline-start:var(--search-glyph-start);top:50%;translate:0 -50%;color:var(--muted-foreground);pointer-events:none}input::-webkit-search-cancel-button,input::-webkit-search-decoration{appearance:none}.clear{position:absolute;inset-inline-end:var(--search-clear-end);top:50%;translate:0 -50%;display:inline-flex;align-items:center;justify-content:center;width:var(--search-clear-size);height:var(--search-clear-size);padding:0;border:0;border-radius:calc(var(--radius) - 2px);background:transparent;color:var(--muted-foreground);cursor:pointer}:host([data-variant=\"filled\"]) .clear{border-radius:50%}.clear:hover{background:var(--accent);color:var(--accent-foreground)}.clear:focus-visible{outline:2px solid var(--ring);outline-offset:0}.status{margin:var(--neat-space-2) 0 0;font-size:var(--neat-text-xs);color:var(--muted-foreground)}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		clearLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearLabel",
				required: false
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		listbox: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "listbox",
				required: false
			}]
		}],
		activeOption: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeOption",
				required: false
			}]
		}],
		field: [{
			type: i0.ViewChild,
			args: ["field", { isSignal: true }]
		}]
	}
});
let nextNavId = 0;
var NeatPageNav = class NeatPageNav {
	groups = input.required(...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	filterLabel = input(...ngDevMode ? [void 0, { debugName: "filterLabel" }] : /* istanbul ignore next */ []);
	viewport = inject(NeatViewport);
	router = inject(Router);
	document = inject(DOCUMENT);
	host = inject(ElementRef).nativeElement;
	trigger = viewChild("trigger", ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	list = viewChild("list", ...ngDevMode ? [{ debugName: "list" }] : /* istanbul ignore next */ []);
	id = `neat-page-nav-${++nextNavId}`;
	collapsible = COLLAPSIBLE_CLASSES;
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	name = signal("", ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	filter = signal("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	query = computed(() => this.filter().trim().toLowerCase(), ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	shown = computed(() => {
		const query = this.query();
		if (!query) return this.groups();
		return this.groups().flatMap((group) => {
			const items = group.items.filter((link) => link.label.toLowerCase().includes(query));
			return items.length ? [{
				label: group.label,
				items
			}] : [];
		});
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	current = computed(() => {
		const url = this.router.lastSuccessfulNavigation()?.finalUrl;
		if (!url) return void 0;
		return openLink(this.groups().flatMap((group) => group.items), url, this.router);
	}, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	constructor() {
		afterRenderEffect(() => {
			const link = this.current();
			const box = this.viewport.narrow() ? this.open() ? this.list()?.nativeElement : void 0 : this.host;
			if (link && box) this.reveal(box);
		});
	}
	ngAfterViewInit() {
		const label = this.host.getAttribute("aria-label");
		const labelledBy = this.host.getAttribute("aria-labelledby");
		if (isDevMode() && !label && !labelledBy) throw new Error("nav[neatPageNav] needs an aria-label (or aria-labelledby) naming the list.");
		this.name.set(label ?? (labelledBy ?? "").split(/\s+/).map((id) => this.document.getElementById(id)?.textContent?.trim() ?? "").join(" ").trim());
	}
	chosen() {
		if (!this.viewport.narrow() || !this.open()) return;
		this.open.set(false);
		this.trigger()?.nativeElement.focus();
	}
	reveal(box) {
		const link = box.querySelector("a[aria-current=\"page\"]");
		if (!link) return;
		const covered = box.querySelector(".filter")?.offsetHeight ?? 0;
		const top = link.offsetTop;
		const bottom = top + link.offsetHeight;
		const shown = box.clientHeight - covered;
		if (top >= box.scrollTop + covered && bottom <= box.scrollTop + box.clientHeight) return;
		box.scrollTop = top - covered - (shown - link.offsetHeight) / 2;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPageNav,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatPageNav,
		isStandalone: true,
		selector: "nav[neatPageNav]",
		inputs: {
			groups: {
				classPropertyName: "groups",
				publicName: "groups",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filterLabel: {
				classPropertyName: "filterLabel",
				publicName: "filterLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "attr.data-layout": "viewport.narrow() ? 'collapsible' : 'column'" } },
		viewQueries: [{
			propertyName: "trigger",
			first: true,
			predicate: ["trigger"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "list",
			first: true,
			predicate: ["list"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (viewport.narrow()) {
      <div class="section" brnCollapsible [(expanded)]="open">
        <button #trigger brnCollapsibleTrigger [class]="collapsible.trigger">
          <neat-icon
            name="next"
            [size]="16"
            [class]="collapsible.chevron"
            [class.rotate-90]="open()"
          />
          <span [class]="collapsible.label">{{ name() }}</span>
          @if (!open() && current(); as link) {
            <span [class]="collapsible.summary">{{ link.label }}</span>
          }
        </button>
        <div #list brnCollapsibleContent class="list" [class]="collapsible.content">
          <ng-container *ngTemplateOutlet="links" />
        </div>
      </div>
    } @else {
      <ng-container *ngTemplateOutlet="links" />
    }
    <ng-template #links>
      @if (filterLabel(); as label) {
        <div class="filter">
          <neat-search size="small" [label]="label" [placeholder]="label" [(value)]="filter" />
        </div>
      }
      @for (group of shown(); track $index; let i = $index) {
        @if (group.label) {
          <h2 [id]="id + '-' + i">{{ group.label }}</h2>
        }
        <ul [attr.aria-labelledby]="group.label ? id + '-' + i : null">
          @for (link of group.items; track link.path) {
            <li>
              <a
                [routerLink]="link.path"
                [attr.aria-current]="link === current() ? 'page' : null"
                (click)="chosen()"
                >{{ link.label }}</a
              >
            </li>
          }
        </ul>
      } @empty {
        @if (query()) {
          <p>Nothing matches</p>
        }
      }
    </ng-template>
  `,
		isInline: true,
		styles: [":host{display:flex;flex-direction:column;position:relative;box-sizing:border-box}:host([data-layout=\"column\"]){flex:none;width:15rem;padding:0 var(--neat-space-3) var(--neat-space-4);overflow-y:auto;border-inline-end:1px solid var(--border)}:host([data-layout=\"collapsible\"]){flex:0 1 auto;min-height:0;padding:var(--neat-space-2) var(--neat-space-6);border-block-end:1px solid var(--border)}.section{display:flex;flex-direction:column;min-height:0}.list{position:relative;min-height:0;overflow-y:auto}.filter{position:sticky;top:0;background:var(--neat-surface)}:host([data-layout=\"column\"]) .filter{padding-block:var(--neat-space-4) var(--neat-space-2)}:host([data-layout=\"collapsible\"]) .filter{padding-block:0 var(--neat-space-2)}h2{margin:var(--neat-space-4) 0 var(--neat-space-2);padding-inline:var(--neat-space-3);color:var(--muted-foreground);font-size:var(--neat-text-xs);font-weight:600;letter-spacing:.06em;text-transform:uppercase}ul{margin:0;padding:0;list-style:none}a{display:block;padding:calc(var(--neat-space-2) / 2) var(--neat-space-3);border-radius:var(--radius);color:var(--muted-foreground);font-size:var(--neat-text-sm);text-decoration:none}a:hover,a[aria-current=page]{background:var(--accent);color:var(--accent-foreground)}a[aria-current=page]{font-weight:500}a:focus-visible{outline:var(--neat-focus-ring-width) solid var(--ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}p{margin:var(--neat-space-4) 0 0;padding-inline:var(--neat-space-3);color:var(--muted-foreground);font-size:var(--neat-text-sm)}\n"],
		dependencies: [
			{
				kind: "directive",
				type: BrnCollapsible,
				selector: "[brnCollapsible],brn-collapsible",
				inputs: ["expanded", "disabled"],
				outputs: ["expandedChange"],
				exportAs: ["brnCollapsible"]
			},
			{
				kind: "directive",
				type: BrnCollapsibleContent,
				selector: "[brnCollapsibleContent],brn-collapsible-content",
				inputs: ["id"],
				exportAs: ["brnCollapsibleContent"]
			},
			{
				kind: "directive",
				type: BrnCollapsibleTrigger,
				selector: "button[brnCollapsibleTrigger]",
				inputs: ["type"],
				exportAs: ["brnCollapsibleTrigger"]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatSearch,
				selector: "neat-search",
				inputs: [
					"label",
					"value",
					"placeholder",
					"variant",
					"size",
					"clearLabel",
					"status",
					"listbox",
					"activeOption"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPageNav,
	decorators: [{
		type: Component,
		args: [{
			selector: "nav[neatPageNav]",
			imports: [
				BrnCollapsible,
				BrnCollapsibleContent,
				BrnCollapsibleTrigger,
				NeatIcon,
				NeatSearch,
				NgTemplateOutlet,
				RouterLink
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[attr.data-layout]": "viewport.narrow() ? 'collapsible' : 'column'" },
			template: `
    @if (viewport.narrow()) {
      <div class="section" brnCollapsible [(expanded)]="open">
        <button #trigger brnCollapsibleTrigger [class]="collapsible.trigger">
          <neat-icon
            name="next"
            [size]="16"
            [class]="collapsible.chevron"
            [class.rotate-90]="open()"
          />
          <span [class]="collapsible.label">{{ name() }}</span>
          @if (!open() && current(); as link) {
            <span [class]="collapsible.summary">{{ link.label }}</span>
          }
        </button>
        <div #list brnCollapsibleContent class="list" [class]="collapsible.content">
          <ng-container *ngTemplateOutlet="links" />
        </div>
      </div>
    } @else {
      <ng-container *ngTemplateOutlet="links" />
    }
    <ng-template #links>
      @if (filterLabel(); as label) {
        <div class="filter">
          <neat-search size="small" [label]="label" [placeholder]="label" [(value)]="filter" />
        </div>
      }
      @for (group of shown(); track $index; let i = $index) {
        @if (group.label) {
          <h2 [id]="id + '-' + i">{{ group.label }}</h2>
        }
        <ul [attr.aria-labelledby]="group.label ? id + '-' + i : null">
          @for (link of group.items; track link.path) {
            <li>
              <a
                [routerLink]="link.path"
                [attr.aria-current]="link === current() ? 'page' : null"
                (click)="chosen()"
                >{{ link.label }}</a
              >
            </li>
          }
        </ul>
      } @empty {
        @if (query()) {
          <p>Nothing matches</p>
        }
      }
    </ng-template>
  `,
			styles: [":host{display:flex;flex-direction:column;position:relative;box-sizing:border-box}:host([data-layout=\"column\"]){flex:none;width:15rem;padding:0 var(--neat-space-3) var(--neat-space-4);overflow-y:auto;border-inline-end:1px solid var(--border)}:host([data-layout=\"collapsible\"]){flex:0 1 auto;min-height:0;padding:var(--neat-space-2) var(--neat-space-6);border-block-end:1px solid var(--border)}.section{display:flex;flex-direction:column;min-height:0}.list{position:relative;min-height:0;overflow-y:auto}.filter{position:sticky;top:0;background:var(--neat-surface)}:host([data-layout=\"column\"]) .filter{padding-block:var(--neat-space-4) var(--neat-space-2)}:host([data-layout=\"collapsible\"]) .filter{padding-block:0 var(--neat-space-2)}h2{margin:var(--neat-space-4) 0 var(--neat-space-2);padding-inline:var(--neat-space-3);color:var(--muted-foreground);font-size:var(--neat-text-xs);font-weight:600;letter-spacing:.06em;text-transform:uppercase}ul{margin:0;padding:0;list-style:none}a{display:block;padding:calc(var(--neat-space-2) / 2) var(--neat-space-3);border-radius:var(--radius);color:var(--muted-foreground);font-size:var(--neat-text-sm);text-decoration:none}a:hover,a[aria-current=page]{background:var(--accent);color:var(--accent-foreground)}a[aria-current=page]{font-weight:500}a:focus-visible{outline:var(--neat-focus-ring-width) solid var(--ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}p{margin:var(--neat-space-4) 0 0;padding-inline:var(--neat-space-3);color:var(--muted-foreground);font-size:var(--neat-text-sm)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		groups: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groups",
				required: true
			}]
		}],
		filterLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterLabel",
				required: false
			}]
		}],
		trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}],
		list: [{
			type: i0.ViewChild,
			args: ["list", { isSignal: true }]
		}]
	}
});
const CLASSES = hlm(buttonVariants({ variant: "link" }), "h-auto border-0 p-0 has-data-[icon=inline-end]:pr-0 has-data-[icon=inline-start]:pl-0 text-[length:inherit] text-inherit focus-visible:ring-ring");
var NeatInlineButton = class NeatInlineButton {
	classes = CLASSES;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatInlineButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatInlineButton,
		isStandalone: true,
		selector: "button[neatInlineButton], a[neatInlineButton]",
		host: {
			attributes: { "data-slot": "button" },
			properties: { "class": "classes" }
		},
		hostDirectives: [{
			directive: i1$2.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatInlineButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatInlineButton], a[neatInlineButton]",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: {
				"data-slot": "button",
				"[class]": "classes"
			}
		}]
	}]
});
var NeatBreadcrumbs = class NeatBreadcrumbs {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	crumbs = input.required(...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	go = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatBreadcrumbs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatBreadcrumbs,
		isStandalone: true,
		selector: "neat-breadcrumbs",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			crumbs: {
				classPropertyName: "crumbs",
				publicName: "crumbs",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { go: "go" },
		ngImport: i0,
		template: `
    <nav [attr.aria-label]="label()">
      <ol class="m-0 flex list-none flex-wrap items-center gap-x-(--neat-space-2) p-0 text-sm">
        @for (crumb of crumbs(); track $index; let first = $first; let last = $last) {
          <li class="flex items-center gap-(--neat-space-2)">
            @if (!first) {
              <span aria-hidden="true" class="text-muted-foreground">›</span>
            }
            @if (last) {
              <!--
                Elements only, so no stray space joins the name; the detail's own space keeps it a
                word apart where it is read rather than seen.
              -->
              <span aria-current="location" class="font-medium">
                <span>{{ crumb.label }}</span>
                @if (crumb.detail) {
                  <span class="font-normal text-muted-foreground">{{ ' ' + crumb.detail }}</span>
                }
              </span>
            } @else {
              <button neatInlineButton type="button" (click)="go.emit($index)">
                {{ crumb.label }}
              </button>
            }
          </li>
        }
      </ol>
    </nav>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NeatInlineButton,
			selector: "button[neatInlineButton], a[neatInlineButton]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatBreadcrumbs,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-breadcrumbs",
			imports: [NeatInlineButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <nav [attr.aria-label]="label()">
      <ol class="m-0 flex list-none flex-wrap items-center gap-x-(--neat-space-2) p-0 text-sm">
        @for (crumb of crumbs(); track $index; let first = $first; let last = $last) {
          <li class="flex items-center gap-(--neat-space-2)">
            @if (!first) {
              <span aria-hidden="true" class="text-muted-foreground">›</span>
            }
            @if (last) {
              <!--
                Elements only, so no stray space joins the name; the detail's own space keeps it a
                word apart where it is read rather than seen.
              -->
              <span aria-current="location" class="font-medium">
                <span>{{ crumb.label }}</span>
                @if (crumb.detail) {
                  <span class="font-normal text-muted-foreground">{{ ' ' + crumb.detail }}</span>
                }
              </span>
            } @else {
              <button neatInlineButton type="button" (click)="go.emit($index)">
                {{ crumb.label }}
              </button>
            }
          </li>
        }
      </ol>
    </nav>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		crumbs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "crumbs",
				required: true
			}]
		}],
		go: [{
			type: i0.Output,
			args: ["go"]
		}]
	}
});
var NeatLiveDot = class NeatLiveDot {
	pulse = input(false, {
		...ngDevMode ? { debugName: "pulse" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLiveDot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatLiveDot,
		isStandalone: true,
		selector: "neat-live-dot",
		inputs: { pulse: {
			classPropertyName: "pulse",
			publicName: "pulse",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { attributes: { "aria-hidden": "true" } },
		ngImport: i0,
		template: `
    <span class="dot" [class.beat]="pulse()"></span>
    @if (pulse()) {
      <span class="ring"></span>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:inline-block;flex:none;width:.625rem;height:.625rem}.dot,.ring{position:absolute;inset:0;border-radius:50%;background:var(--neat-live)}.ring{display:none;pointer-events:none}@media(prefers-reduced-motion:no-preference){.beat{animation:live-dot-beat 1.6s ease-in-out infinite}.ring{display:block;animation:live-dot-ring 1.6s cubic-bezier(.2,.6,.3,1) infinite}}@keyframes live-dot-beat{0%,to{opacity:1}50%{opacity:.7}}@keyframes live-dot-ring{0%{transform:scale(1);opacity:.45}to{transform:scale(2.6);opacity:0}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLiveDot,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-live-dot",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "aria-hidden": "true" },
			template: `
    <span class="dot" [class.beat]="pulse()"></span>
    @if (pulse()) {
      <span class="ring"></span>
    }
  `,
			styles: [":host{position:relative;display:inline-block;flex:none;width:.625rem;height:.625rem}.dot,.ring{position:absolute;inset:0;border-radius:50%;background:var(--neat-live)}.ring{display:none;pointer-events:none}@media(prefers-reduced-motion:no-preference){.beat{animation:live-dot-beat 1.6s ease-in-out infinite}.ring{display:block;animation:live-dot-ring 1.6s cubic-bezier(.2,.6,.3,1) infinite}}@keyframes live-dot-beat{0%,to{opacity:1}50%{opacity:.7}}@keyframes live-dot-ring{0%{transform:scale(1);opacity:.45}to{transform:scale(2.6);opacity:0}}\n"]
		}]
	}],
	propDecorators: { pulse: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "pulse",
			required: false
		}]
	}] }
});
function seriesTokenName(index) {
	return `--neat-series-${index + 1}`;
}
function seriesToken(index) {
	return `var(${seriesTokenName(index)})`;
}
var NeatSeriesSwatch = class NeatSeriesSwatch {
	index = input.required(...ngDevMode ? [{ debugName: "index" }] : /* istanbul ignore next */ []);
	color = computed(() => seriesToken(this.index()), ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSeriesSwatch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatSeriesSwatch,
		isStandalone: true,
		selector: "neat-series-swatch",
		inputs: { index: {
			classPropertyName: "index",
			publicName: "index",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "aria-hidden": "true" },
			properties: { "style.--swatch": "color()" }
		},
		ngImport: i0,
		template: "",
		isInline: true,
		styles: [":host{display:inline-block;flex:none;width:.625rem;height:.625rem;border-radius:2px;background:var(--swatch)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSeriesSwatch,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-series-swatch",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"aria-hidden": "true",
				"[style.--swatch]": "color()"
			},
			template: "",
			styles: [":host{display:inline-block;flex:none;width:.625rem;height:.625rem;border-radius:2px;background:var(--swatch)}\n"]
		}]
	}],
	propDecorators: { index: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "index",
			required: true
		}]
	}] }
});
var NeatSwatch = class NeatSwatch {
	color = input.required(...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSwatch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatSwatch,
		isStandalone: true,
		selector: "neat-swatch",
		inputs: { color: {
			classPropertyName: "color",
			publicName: "color",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "aria-hidden": "true" },
			properties: { "style.--swatch": "color()" }
		},
		ngImport: i0,
		template: "",
		isInline: true,
		styles: [":host{display:inline-block;flex:none;width:.625rem;height:.625rem;border-radius:2px;background:var(--swatch)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSwatch,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-swatch",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"aria-hidden": "true",
				"[style.--swatch]": "color()"
			},
			template: "",
			styles: [":host{display:inline-block;flex:none;width:.625rem;height:.625rem;border-radius:2px;background:var(--swatch)}\n"]
		}]
	}],
	propDecorators: { color: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "color",
			required: true
		}]
	}] }
});
const NOTE_CLASSES = "m-0 text-muted-foreground text-(length:--neat-text-xs)";
var NeatNote = class NeatNote {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatNote,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatNote,
		isStandalone: true,
		selector: "[neatNote]",
		host: { classAttribute: "m-0 text-muted-foreground text-(length:--neat-text-xs)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatNote,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatNote]",
			host: { class: NOTE_CLASSES }
		}]
	}]
});
var NeatProse = class NeatProse {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatProse,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatProse,
		isStandalone: true,
		selector: "[neatProse]",
		host: { classAttribute: "neat-prose" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatProse,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatProse]",
			host: { class: "neat-prose" }
		}]
	}]
});
var NeatExpand = class NeatExpand {
	expanded = model(false, ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef).nativeElement;
	document = inject(DOCUMENT);
	interactivity = inject(InteractivityChecker);
	shown = false;
	returnFocus = null;
	addedTabIndex = false;
	constructor() {
		afterRenderEffect(() => this.show(this.expanded()));
	}
	open() {
		this.expanded.set(true);
	}
	close() {
		this.expanded.set(false);
	}
	toggle() {
		this.expanded.update((expanded) => !expanded);
	}
	onKeydown(event) {
		if (!this.expanded() || event.defaultPrevented) return;
		if (event.key === "Escape") {
			event.preventDefault();
			event.stopPropagation();
			this.close();
		} else if (event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey) this.keepTabInside(event);
	}
	onToggle(event) {
		if (event.target === this.host && event.newState === "closed") this.close();
	}
	show(expanded) {
		if (expanded === this.shown) return;
		this.shown = expanded;
		const host = this.host;
		const popover = typeof host.showPopover === "function";
		if (expanded) {
			const active = this.document.activeElement;
			this.returnFocus = active instanceof HTMLElement ? active : null;
			this.addedTabIndex = !host.hasAttribute("tabindex");
			if (this.addedTabIndex) host.setAttribute("tabindex", "-1");
			if (popover) {
				host.setAttribute("popover", "manual");
				host.showPopover();
			}
			if (!host.contains(this.document.activeElement)) host.focus({ preventScroll: true });
		} else {
			const active = this.document.activeElement;
			const focusInside = active === null || active === this.document.body || host.contains(active);
			if (popover && host.hasAttribute("popover")) {
				host.hidePopover();
				host.removeAttribute("popover");
			}
			if (this.addedTabIndex) host.removeAttribute("tabindex");
			if (focusInside && this.returnFocus?.isConnected) this.returnFocus.focus();
			this.returnFocus = null;
		}
	}
	keepTabInside(event) {
		const tabbables = tabbablesIn(this.document, this.interactivity, this.host);
		const first = tabbables[0];
		const last = tabbables.at(-1);
		if (first === void 0 || last === void 0) event.preventDefault();
		else if (event.shiftKey && (event.target === first || event.target === this.host)) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && event.target === last) {
			event.preventDefault();
			first.focus();
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatExpand,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatExpand,
		isStandalone: true,
		selector: "[neatExpand]",
		inputs: { expanded: {
			classPropertyName: "expanded",
			publicName: "expanded",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		outputs: { expanded: "expandedChange" },
		host: {
			listeners: {
				"keydown": "onKeydown($event)",
				"toggle": "onToggle($event)"
			},
			properties: { "attr.data-neat-expanded": "expanded() ? \"\" : null" }
		},
		exportAs: ["neatExpand"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatExpand,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatExpand]",
			exportAs: "neatExpand",
			host: {
				"[attr.data-neat-expanded]": "expanded() ? \"\" : null",
				"(keydown)": "onKeydown($event)",
				"(toggle)": "onToggle($event)"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { expanded: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "expanded",
			required: false
		}]
	}, {
		type: i0.Output,
		args: ["expandedChange"]
	}] }
});
const KEYS = /* @__PURE__ */ new Map([
	["Mod", {
		mac: text("⌘", "Command"),
		other: text("Ctrl", "Control")
	}],
	["Control", {
		mac: text("⌃", "Control"),
		other: text("Ctrl", "Control")
	}],
	["Meta", {
		mac: text("⌘", "Command"),
		other: text("Meta", "Meta")
	}],
	["Alt", {
		mac: text("⌥", "Option"),
		other: text("Alt", "Alt")
	}],
	["Shift", {
		mac: text("⇧", "Shift"),
		other: text("Shift", "Shift")
	}],
	["Escape", both(text("Esc", "Escape"))],
	["ArrowUp", both(text("↑", "Up arrow"))],
	["ArrowDown", both(text("↓", "Down arrow"))],
	["ArrowLeft", both(text("←", "Left arrow"))],
	["ArrowRight", both(text("→", "Right arrow"))]
]);
function text(shown, spoken) {
	return {
		shown,
		spoken
	};
}
function both(keyText) {
	return {
		mac: keyText,
		other: keyText
	};
}
var NeatShortcut = class NeatShortcut {
	keys = input.required(...ngDevMode ? [{ debugName: "keys" }] : /* istanbul ignore next */ []);
	platform = isMac() ? "mac" : "other";
	texts = computed(() => this.keys().map((key) => this.textOf(key)), ...ngDevMode ? [{ debugName: "texts" }] : /* istanbul ignore next */ []);
	shown = computed(() => this.texts().map((key) => key.shown), ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	spoken = computed(() => this.texts().map((key) => key.spoken).join(" "), ...ngDevMode ? [{ debugName: "spoken" }] : /* istanbul ignore next */ []);
	textOf(key) {
		const known = KEYS.get(key);
		if (known) return known[this.platform];
		const shown = key.length === 1 ? key.toUpperCase() : key;
		return {
			shown,
			spoken: shown
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatShortcut,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatShortcut,
		isStandalone: true,
		selector: "neat-shortcut",
		inputs: { keys: {
			classPropertyName: "keys",
			publicName: "keys",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0,
		template: `
    <span class="sr-only">{{ spoken() }}</span>
    @for (key of shown(); track $index) {
      <kbd class="neat-key" aria-hidden="true">{{ key }}</kbd>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:inline-flex;gap:.1875rem;vertical-align:middle}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatShortcut,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-shortcut",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <span class="sr-only">{{ spoken() }}</span>
    @for (key of shown(); track $index) {
      <kbd class="neat-key" aria-hidden="true">{{ key }}</kbd>
    }
  `,
			styles: [":host{position:relative;display:inline-flex;gap:.1875rem;vertical-align:middle}\n"]
		}]
	}],
	propDecorators: { keys: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "keys",
			required: true
		}]
	}] }
});
function isMac() {
	return typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform);
}
const STALE_CLASSES = "opacity-55 grayscale";
var NeatStale = class NeatStale {
	neatStale = input.required(...ngDevMode ? [{ debugName: "neatStale" }] : /* istanbul ignore next */ []);
	classes = computed(() => this.neatStale() ? STALE_CLASSES : "", ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatStale,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatStale,
		isStandalone: true,
		selector: "[neatStale]",
		inputs: { neatStale: {
			classPropertyName: "neatStale",
			publicName: "neatStale",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { properties: { "class": "classes()" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatStale,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatStale]",
			host: { "[class]": "classes()" }
		}]
	}],
	propDecorators: { neatStale: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "neatStale",
			required: true
		}]
	}] }
});
function neatDuration(seconds) {
	if (typeof seconds !== "number" || !Number.isFinite(seconds) || seconds < 0) return "–";
	const whole = Math.floor(seconds);
	if (whole < 60) return `${whole} s`;
	const minutes = Math.floor(whole / 60);
	if (minutes < 60) return `${minutes} min ${pad(whole % 60)} s`;
	const hours = Math.floor(minutes / 60);
	if (hours < 24) return `${hours} h ${pad(minutes % 60)} min`;
	return `${Math.floor(hours / 24)} d ${pad(hours % 24)} h`;
}
function pad(value) {
	return String(value).padStart(2, "0");
}
function neatSecondsAgo(seconds) {
	const whole = Math.round(seconds);
	if (whole < 10) return "just now";
	if (whole < 60) return `${whole} s ago`;
	if (whole < 3600) return `${Math.floor(whole / 60)} min ago`;
	if (whole < 86400) return `${Math.floor(whole / 3600)} h ago`;
	return `${Math.floor(whole / 86400)} d ago`;
}
var NeatEasedNumber = class NeatEasedNumber {
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	digits = input(0, ...ngDevMode ? [{ debugName: "digits" }] : /* istanbul ignore next */ []);
	easing = input("ease-in-out", ...ngDevMode ? [{ debugName: "easing" }] : /* istanbul ignore next */ []);
	shown = neatEased(this.value, { easing: this.easing });
	text = computed(() => {
		const value = this.shown();
		return value === null || value === void 0 ? "–" : value.toFixed(this.digits());
	}, ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatEasedNumber,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatEasedNumber,
		isStandalone: true,
		selector: "neat-eased-number",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			digits: {
				classPropertyName: "digits",
				publicName: "digits",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			easing: {
				classPropertyName: "easing",
				publicName: "easing",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "tabular-nums" },
		ngImport: i0,
		template: `{{ text() }}`,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatEasedNumber,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-eased-number",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "tabular-nums" },
			template: `{{ text() }}`
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		digits: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "digits",
				required: false
			}]
		}],
		easing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "easing",
				required: false
			}]
		}]
	}
});
function neatStoredSignal(key, initial, parse) {
	const value = signal(read(key, parse) ?? initial, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	const set = value.set;
	value.set = (next) => {
		set(next);
		write(key, next);
	};
	value.update = (change) => value.set(change(untracked(value)));
	return value;
}
function read(key, parse) {
	const text = safeStorage.get(key);
	if (text === null) return void 0;
	let stored;
	try {
		stored = JSON.parse(text);
	} catch {
		return;
	}
	return parse(stored);
}
function write(key, value) {
	let text;
	try {
		text = JSON.stringify(value);
	} catch {
		return;
	}
	safeStorage.set(key, text);
}
const FIELD_LABEL_CLASSES = {
	stack: "flex flex-col gap-2",
	label: "text-sm font-medium"
};
const READOUT_CLASSES = {
	box: "z-1 flex flex-col gap-0.5 p-(--neat-space-2) border border-border rounded-(--radius) bg-popover text-popover-foreground text-(length:--neat-text-xs) tabular-nums whitespace-nowrap pointer-events-none",
	muted: "text-muted-foreground",
	row: "inline-flex items-center gap-(--neat-space-2)"
};
function classStyles(rows) {
	const styles = Object.create(null);
	const overrides = Object.create(null);
	for (const row of rows) {
		styles[row.label] = row;
		overrides[row.label] = row.color;
	}
	return {
		styles,
		overrides
	};
}
function styleFor(styles, label) {
	return styles[String(label)] ?? styles["default"];
}
const OVERLAY_PALETTE = [
	"#2563eb",
	"#dc2626",
	"#16a34a",
	"#ca8a04",
	"#9333ea",
	"#0891b2",
	"#ea580c",
	"#4f46e5",
	"#be123c",
	"#0f766e",
	"#f472b6",
	"#84cc16",
	"#fbbf24",
	"#38bdf8",
	"#92400e",
	"#d946ef",
	"#14532d",
	"#fdba74",
	"#f43f5e",
	"#5eead4",
	"#989900",
	"#ff96d3",
	"#e1a0fe",
	"#b6b4ff",
	"#e2684a",
	"#267d30",
	"#4d7800",
	"#e06285",
	"#78c7fd",
	"#786900",
	"#bc6ece",
	"#10d8d8",
	"#927eec",
	"#2bdda4",
	"#66da85",
	"#ab413e",
	"#5590f3",
	"#8fd465",
	"#1899ec",
	"#b1cc46"
];
const OVERLAY_NEUTRAL_COLOR = "#f8fafc";
const RELEASE_AFTER_MS = 5e3;
function createColorMap() {
	return {
		holders: /* @__PURE__ */ new Map(),
		insertions: 0
	};
}
var NeatOverlayColors = class NeatOverlayColors {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatOverlayColors,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatOverlayColors,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatOverlayColors,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const classColorsOf = /* @__PURE__ */ new WeakMap();
function bump(changes) {
	changes.update((count) => count + 1);
}
function identityKey(identity) {
	if (identity === null || identity === void 0) return null;
	const text = String(identity);
	return text === "" ? null : text;
}
function isStale(holder, now) {
	return now - holder.lastSeen > RELEASE_AFTER_MS;
}
function olderThan(a, b) {
	return a.lastSeen < b.lastSeen || a.lastSeen === b.lastSeen && a.order < b.order;
}
function holdersBySlot(map) {
	const bySlot = /* @__PURE__ */ new Map();
	for (const [key, holder] of map.holders) {
		const group = bySlot.get(holder.slot);
		if (group) group.push({
			key,
			holder
		});
		else bySlot.set(holder.slot, [{
			key,
			holder
		}]);
	}
	return bySlot;
}
function pruneStaleSharers(map, now) {
	for (const group of holdersBySlot(map).values()) {
		if (group.length < 2) continue;
		const stale = group.filter(({ holder }) => isStale(holder, now));
		if (stale.length === group.length) {
			stale.sort((a, b) => olderThan(a.holder, b.holder) ? 1 : -1);
			stale.shift();
		}
		for (const { key } of stale) map.holders.delete(key);
	}
}
function separateFromSharers(map, key, holder, now) {
	let live = false;
	for (const [otherKey, other] of map.holders) {
		if (otherKey === key || other.slot !== holder.slot) continue;
		if (isStale(other, now)) map.holders.delete(otherKey);
		else live = true;
	}
	if (live) map.holders.delete(key);
	return live;
}
function freeSlot(map) {
	const used = /* @__PURE__ */ new Set();
	for (const holder of map.holders.values()) used.add(holder.slot);
	for (let slot = 0; slot < OVERLAY_PALETTE.length; slot += 1) if (!used.has(slot)) return slot;
	return -1;
}
function reclaimStaleSlot(map, now) {
	let oldest = null;
	for (const [key, holder] of map.holders) if (isStale(holder, now) && (oldest === null || olderThan(holder, oldest.holder))) oldest = {
		key,
		holder
	};
	if (oldest === null) return -1;
	map.holders.delete(oldest.key);
	return oldest.holder.slot;
}
function sharedSlot(map) {
	let chosen = null;
	for (const [slot, group] of holdersBySlot(map)) {
		const latest = group.reduce((a, b) => olderThan(a.holder, b.holder) ? b : a).holder;
		const candidate = {
			slot,
			lastSeen: latest.lastSeen,
			order: latest.order
		};
		if (chosen === null || olderThan(candidate, chosen)) chosen = candidate;
	}
	return chosen?.slot ?? 0;
}
function createColorAllocator(colors) {
	const classColors = classColorsOf.get(colors) ?? {
		map: createColorMap(),
		changes: signal(0)
	};
	classColorsOf.set(colors, classColors);
	const maps = /* @__PURE__ */ new Map();
	const ownChanges = signal(0, ...ngDevMode ? [{ debugName: "ownChanges" }] : /* istanbul ignore next */ []);
	function mapFor(channelIndex, namespace) {
		if (namespace === "class") return classColors.map;
		const key = `${channelIndex}:${namespace}`;
		let map = maps.get(key);
		if (!map) {
			map = createColorMap();
			maps.set(key, map);
		}
		return map;
	}
	function changesOf(namespace) {
		return namespace === "class" ? classColors.changes : ownChanges;
	}
	return {
		colorFor(channelIndex, namespace, identity, now) {
			const key = identityKey(identity);
			if (key === null) return OVERLAY_NEUTRAL_COLOR;
			const map = mapFor(channelIndex, namespace);
			const existing = map.holders.get(key);
			if (existing && !isStale(existing, now)) {
				existing.lastSeen = now;
				return OVERLAY_PALETTE[existing.slot];
			}
			bump(changesOf(namespace));
			if (existing && !separateFromSharers(map, key, existing, now)) {
				existing.lastSeen = now;
				return OVERLAY_PALETTE[existing.slot];
			}
			let slot = freeSlot(map);
			if (slot < 0) {
				pruneStaleSharers(map, now);
				slot = reclaimStaleSlot(map, now);
			}
			if (slot < 0) slot = sharedSlot(map);
			map.insertions += 1;
			map.holders.set(key, {
				slot,
				lastSeen: now,
				order: map.insertions
			});
			return OVERLAY_PALETTE[slot];
		},
		held(channelIndex, namespace, identity) {
			changesOf(namespace)();
			const key = identityKey(identity);
			if (key === null) return OVERLAY_NEUTRAL_COLOR;
			const holder = (namespace === "class" ? classColors.map : maps.get(`${channelIndex}:${namespace}`))?.holders.get(key);
			return holder === void 0 ? null : OVERLAY_PALETTE[holder.slot];
		},
		clear() {
			if (maps.size === 0) return;
			maps.clear();
			bump(ownChanges);
		},
		size(channelIndex, namespace) {
			return mapFor(channelIndex, namespace).holders.size;
		}
	};
}
function resolveColor(query) {
	const { allocator, channelIndex, namespace, identity, now } = query;
	return overrideFor(query) ?? allocator.colorFor(channelIndex, namespace, identity, now);
}
function heldColor(query) {
	const { allocator, channelIndex, namespace, identity } = query;
	return overrideFor(query) ?? allocator.held(channelIndex, namespace, identity);
}
function overrideFor({ identity, overrides, ...query }) {
	if (!overrides) return null;
	const key = identityKey("label" in query ? query.label : identity);
	const own = key === null ? void 0 : overrides[key];
	if (typeof own === "string") return own;
	const fallback = overrides["default"];
	return typeof fallback === "string" ? fallback : null;
}
var HlmTabs = class HlmTabs {
	tab = input.required(...ngDevMode ? [{ debugName: "tab" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabs,
		isStandalone: true,
		selector: "[hlmTabs],hlm-tabs",
		inputs: { tab: {
			classPropertyName: "tab",
			publicName: "tab",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs" } },
		exportAs: ["hlmTabs"],
		hostDirectives: [{
			directive: i1.BrnTabs,
			inputs: [
				"orientation",
				"orientation",
				"activationMode",
				"activationMode",
				"brnTabs",
				"tab"
			],
			outputs: ["tabActivated", "tabActivated"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabs,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabs],hlm-tabs",
			exportAs: "hlmTabs",
			hostDirectives: [{
				directive: BrnTabs,
				inputs: [
					"orientation",
					"activationMode",
					"brnTabs: tab"
				],
				outputs: ["tabActivated"]
			}],
			host: { "data-slot": "tabs" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { tab: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "tab",
			required: true
		}]
	}] }
});
var HlmTabsContent = class HlmTabsContent {
	contentFor = input.required({
		...ngDevMode ? { debugName: "contentFor" } : /* istanbul ignore next */ {},
		alias: "hlmTabsContent"
	});
	constructor() {
		classes(() => "flex-1 text-sm outline-none");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsContent,
		isStandalone: true,
		selector: "[hlmTabsContent]",
		inputs: { contentFor: {
			classPropertyName: "contentFor",
			publicName: "hlmTabsContent",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs-content" } },
		exportAs: ["hlmTabsContent"],
		hostDirectives: [{
			directive: i1.BrnTabsContent,
			inputs: ["brnTabsContent", "hlmTabsContent"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsContent]",
			exportAs: "hlmTabsContent",
			hostDirectives: [{
				directive: BrnTabsContent,
				inputs: ["brnTabsContent: hlmTabsContent"]
			}],
			host: { "data-slot": "tabs-content" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { contentFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hlmTabsContent",
			required: true
		}]
	}] }
});
var HlmTabsContentLazy = class HlmTabsContentLazy {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsContentLazy,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HlmTabsContentLazy,
		isStandalone: true,
		selector: "ng-template[hlmTabsContentLazy]",
		exportAs: ["hlmTabsContentLazy"],
		hostDirectives: [{ directive: i1.BrnTabsContentLazy }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsContentLazy,
	decorators: [{
		type: Directive,
		args: [{
			selector: "ng-template[hlmTabsContentLazy]",
			exportAs: "hlmTabsContentLazy",
			hostDirectives: [BrnTabsContentLazy]
		}]
	}]
});
const listVariants = cva("rounded-lg p-[3px] group-data-horizontal/tabs:h-9 data-[variant=line]:rounded-none group/tabs-list text-muted-foreground inline-flex w-fit items-center justify-center group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col", {
	variants: { variant: {
		default: "bg-muted",
		line: "gap-1 bg-transparent"
	} },
	defaultVariants: { variant: "default" }
});
var HlmTabsList = class HlmTabsList {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => listVariants({ variant: this.variant() }));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsList,
		isStandalone: true,
		selector: "[hlmTabsList],hlm-tabs-list",
		inputs: { variant: {
			classPropertyName: "variant",
			publicName: "variant",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "tabs-list" },
			properties: { "attr.data-variant": "variant()" }
		},
		exportAs: ["hlmTabsList"],
		hostDirectives: [{ directive: i1.BrnTabsList }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsList,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsList],hlm-tabs-list",
			exportAs: "hlmTabsList",
			hostDirectives: [BrnTabsList],
			host: {
				"data-slot": "tabs-list",
				"[attr.data-variant]": "variant()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { variant: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "variant",
			required: false
		}]
	}] }
});
var HlmTabsPaginatedList = class HlmTabsPaginatedList extends BrnTabsPaginatedList {
	constructor() {
		super();
		classes(() => "relative flex flex-shrink-0 items-center gap-1 overflow-hidden");
	}
	items = contentChildren(BrnTabsTrigger, {
		...ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemsChanges = toObservable(this.items);
	tabListContainer = viewChild.required("tabListContainer", ...ngDevMode ? [{ debugName: "tabListContainer" }] : /* istanbul ignore next */ []);
	tabList = viewChild.required("tabList", ...ngDevMode ? [{ debugName: "tabList" }] : /* istanbul ignore next */ []);
	tabListInner = viewChild.required("tabListInner", ...ngDevMode ? [{ debugName: "tabListInner" }] : /* istanbul ignore next */ []);
	nextPaginator = viewChild.required("nextPaginator", ...ngDevMode ? [{ debugName: "nextPaginator" }] : /* istanbul ignore next */ []);
	previousPaginator = viewChild.required("previousPaginator", ...ngDevMode ? [{ debugName: "previousPaginator" }] : /* istanbul ignore next */ []);
	tabListClass = input("", {
		...ngDevMode ? { debugName: "tabListClass" } : /* istanbul ignore next */ {},
		alias: "tabListClass"
	});
	_tabListClass = computed(() => hlm(listVariants(), this.tabListClass()), ...ngDevMode ? [{ debugName: "_tabListClass" }] : /* istanbul ignore next */ []);
	paginationButtonClass = input("", ...ngDevMode ? [{ debugName: "paginationButtonClass" }] : /* istanbul ignore next */ []);
	_paginationButtonClass = computed(() => hlm("relative z-[2] select-none disabled:cursor-default", buttonVariants({
		variant: "ghost",
		size: "icon-sm"
	}), this.paginationButtonClass(), this.showPaginationControls() ? "inline-flex" : "hidden"), ...ngDevMode ? [{ debugName: "_paginationButtonClass" }] : /* istanbul ignore next */ []);
	_itemSelected(event) {
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsPaginatedList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: HlmTabsPaginatedList,
		isStandalone: true,
		selector: "hlm-paginated-tabs-list",
		inputs: {
			tabListClass: {
				classPropertyName: "tabListClass",
				publicName: "tabListClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			paginationButtonClass: {
				classPropertyName: "paginationButtonClass",
				publicName: "paginationButtonClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "tabs-paginated-list" } },
		queries: [{
			propertyName: "items",
			predicate: BrnTabsTrigger,
			isSignal: true
		}],
		viewQueries: [
			{
				propertyName: "tabListContainer",
				first: true,
				predicate: ["tabListContainer"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tabList",
				first: true,
				predicate: ["tabList"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tabListInner",
				first: true,
				predicate: ["tabListInner"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "nextPaginator",
				first: true,
				predicate: ["nextPaginator"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "previousPaginator",
				first: true,
				predicate: ["previousPaginator"],
				descendants: true,
				isSignal: true
			}
		],
		exportAs: ["hlmTabsPaginatedList"],
		usesInheritance: true,
		ngImport: i0,
		template: `
    <button
      #previousPaginator
      data-pagination="previous"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollBefore || null"
      (click)="_handlePaginatorClick('before')"
      (mousedown)="_handlePaginatorPress('before', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="previous" [size]="16" />
    </button>

    <div
      #tabListContainer
      class="z-[1] flex grow overflow-hidden"
      (keydown)="_handleKeydown($event)"
    >
      <div
        class="relative grow transition-transform"
        #tabList
        role="tablist"
        (cdkObserveContent)="_onContentChanges()"
      >
        <div #tabListInner [class]="_tabListClass()">
          <ng-content />
        </div>
      </div>
    </div>

    <button
      #nextPaginator
      data-pagination="next"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollAfter || null"
      (click)="_handlePaginatorClick('after')"
      (mousedown)="_handlePaginatorPress('after', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="next" [size]="16" />
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: CdkObserveContent,
			selector: "[cdkObserveContent]",
			inputs: ["cdkObserveContentDisabled", "debounce"],
			outputs: ["cdkObserveContent"],
			exportAs: ["cdkObserveContent"]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsPaginatedList,
	decorators: [{
		type: Component,
		args: [{
			selector: "hlm-paginated-tabs-list",
			exportAs: "hlmTabsPaginatedList",
			imports: [CdkObserveContent, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "data-slot": "tabs-paginated-list" },
			template: `
    <button
      #previousPaginator
      data-pagination="previous"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollBefore || null"
      (click)="_handlePaginatorClick('before')"
      (mousedown)="_handlePaginatorPress('before', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="previous" [size]="16" />
    </button>

    <div
      #tabListContainer
      class="z-[1] flex grow overflow-hidden"
      (keydown)="_handleKeydown($event)"
    >
      <div
        class="relative grow transition-transform"
        #tabList
        role="tablist"
        (cdkObserveContent)="_onContentChanges()"
      >
        <div #tabListInner [class]="_tabListClass()">
          <ng-content />
        </div>
      </div>
    </div>

    <button
      #nextPaginator
      data-pagination="next"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollAfter || null"
      (click)="_handlePaginatorClick('after')"
      (mousedown)="_handlePaginatorPress('after', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="next" [size]="16" />
    </button>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		items: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => BrnTabsTrigger), {
				descendants: false,
				isSignal: true
			}]
		}],
		tabListContainer: [{
			type: i0.ViewChild,
			args: ["tabListContainer", { isSignal: true }]
		}],
		tabList: [{
			type: i0.ViewChild,
			args: ["tabList", { isSignal: true }]
		}],
		tabListInner: [{
			type: i0.ViewChild,
			args: ["tabListInner", { isSignal: true }]
		}],
		nextPaginator: [{
			type: i0.ViewChild,
			args: ["nextPaginator", { isSignal: true }]
		}],
		previousPaginator: [{
			type: i0.ViewChild,
			args: ["previousPaginator", { isSignal: true }]
		}],
		tabListClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tabListClass",
				required: false
			}]
		}],
		paginationButtonClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "paginationButtonClass",
				required: false
			}]
		}]
	}
});
var HlmTabsTrigger = class HlmTabsTrigger {
	triggerFor = input.required({
		...ngDevMode ? { debugName: "triggerFor" } : /* istanbul ignore next */ {},
		alias: "hlmTabsTrigger"
	});
	constructor() {
		classes(() => [
			`gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0`,
			"group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
			"data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground",
			"after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100"
		]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsTrigger,
		isStandalone: true,
		selector: "[hlmTabsTrigger]",
		inputs: { triggerFor: {
			classPropertyName: "triggerFor",
			publicName: "hlmTabsTrigger",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs-trigger" } },
		exportAs: ["hlmTabsTrigger"],
		hostDirectives: [{
			directive: i1.BrnTabsTrigger,
			inputs: [
				"brnTabsTrigger",
				"hlmTabsTrigger",
				"disabled",
				"disabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsTrigger]",
			exportAs: "hlmTabsTrigger",
			hostDirectives: [{
				directive: BrnTabsTrigger,
				inputs: ["brnTabsTrigger: hlmTabsTrigger", "disabled"]
			}],
			host: { "data-slot": "tabs-trigger" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { triggerFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hlmTabsTrigger",
			required: true
		}]
	}] }
});
export { KIOSK_POINTER_IDLE_MS, KioskService, NEAT_DANGER_BASE, NEAT_EASINGS, NEAT_HIGHLIGHT_BASE, NEAT_ICON_NAMES, NEAT_NEAR_BLACK, NEAT_PRIMARY_BASE, NEAT_SERIES_TEAL_BASE, NEAT_WARN_BASE, NeatAsideActions, NeatAsideHeading, NeatAsidePanel, NeatAsideTitle, NeatAsideToggle, NeatBreadcrumbs, NeatButton, NeatCode, NeatEasedNumber, NeatExpand, NeatIcon, NeatInlineButton, NeatLiveDot, NeatNote, NeatPage, NeatPageNav, NeatPageToolbar, NeatProse, NeatRailDivider, NeatRailItem, NeatSearch, NeatSeriesSwatch, NeatShell, NeatShortcut, NeatStale, NeatSwatch, NeatTooltip, NeatViewport, SIMA_PALETTE, ThemeService, buildColorScale, buildNeutralSurfaceScale, buildSurfaceScale, contrastRatio, neatAsideOpen, neatDuration, neatEased, neatResolveColor, neatSecondsAgo, neatStoredSignal, neatThemeColors, provideNeatTitles, provideNeatUi, BROWSER_CLOCK as ɵBROWSER_CLOCK, COLLAPSIBLE_CLASSES as ɵCOLLAPSIBLE_CLASSES, FIELD_LABEL_CLASSES as ɵFIELD_LABEL_CLASSES, INPUT_CLASSES as ɵINPUT_CLASSES, INPUT_HELM_CLASSES as ɵINPUT_HELM_CLASSES, IN_PAGE_TOOLBAR as ɵIN_PAGE_TOOLBAR, NeatOverlayColors as ɵNeatOverlayColors, OVERLAY_NEUTRAL_COLOR as ɵOVERLAY_NEUTRAL_COLOR, OVERLAY_PALETTE as ɵOVERLAY_PALETTE, OverlayFocus as ɵOverlayFocus, PANEL_SURFACE_CLASSES as ɵPANEL_SURFACE_CLASSES, POPOVER_HELM_CLASSES as ɵPOPOVER_HELM_CLASSES, READOUT_CLASSES as ɵREADOUT_CLASSES, STALE_CLASSES as ɵSTALE_CLASSES, classStyles as ɵclassStyles, createColorAllocator as ɵcreateColorAllocator, heldColor as ɵheldColor, hlm as ɵhlm, listVariants as ɵlistVariants, reducedMotion as ɵreducedMotion, resolveColor as ɵresolveColor, seriesToken as ɵseriesToken, seriesTokenName as ɵseriesTokenName, styleFor as ɵstyleFor };

//# sourceMappingURL=sima-neat-ui.mjs.map