import { DestroyRef, NgZone, computed, inject, signal } from "@angular/core";
const BACKOFF_MS = [
	1e3,
	2e3,
	5e3,
	1e4
];
const STALL_MS = 5e3;
const HEALTH_INTERVAL_MS = 1e3;
const UNREACHABLE_TEXT = "Insight not reachable";
const WAITING_TEXT = {
	no_video: "Waiting for video",
	codec_changed: "Video format changed",
	insight_unreachable: UNREACHABLE_TEXT,
	negotiation_failed: "Could not connect"
};
const GATEWAY_STATUSES = /* @__PURE__ */ new Set([
	502,
	503,
	504
]);
function openInsightConnection(options, events) {
	let closed = false;
	let peer = null;
	let health = null;
	let failures = 0;
	let checking = false;
	let retryTimer = null;
	let healthTimer = null;
	const clearRetry = () => {
		if (retryTimer !== null) clearTimeout(retryTimer);
		retryTimer = null;
	};
	const dropPeer = () => {
		const pc = peer;
		peer = null;
		health = null;
		events.videoDelayMs(null);
		pc?.close();
	};
	const close = () => {
		if (closed) return;
		closed = true;
		clearRetry();
		if (healthTimer !== null) clearInterval(healthTimer);
		healthTimer = null;
		dropPeer();
		events.stream(null);
		events.waiting(null);
	};
	const fail = (text) => {
		close();
		events.failure(text);
	};
	const retry = () => {
		if (closed) return;
		dropPeer();
		events.stream(null);
		const delay = BACKOFF_MS[Math.min(failures, BACKOFF_MS.length - 1)];
		failures += 1;
		clearRetry();
		retryTimer = setTimeout(() => void attempt(), delay);
	};
	const attempt = async () => {
		if (closed) return;
		clearRetry();
		dropPeer();
		const pc = new RTCPeerConnection();
		peer = pc;
		const transceiver = pc.addTransceiver("video", { direction: "recvonly" });
		if (options.videoBufferMs !== void 0) applyJitterBufferTarget(transceiver.receiver, options.videoBufferMs);
		const metadata = pc.createDataChannel("metadata", {
			ordered: true,
			maxRetransmits: 0
		});
		metadata.onmessage = (event) => {
			if (pc !== peer || typeof event.data !== "string") return;
			events.metadata(event.data, performance.now());
		};
		pc.ontrack = (event) => {
			if (pc !== peer || event.track.kind !== "video") return;
			events.waiting(null);
			events.stream(event.streams[0] ?? new MediaStream([event.track]));
		};
		pc.onconnectionstatechange = () => {
			if (pc !== peer) return;
			if (pc.connectionState === "connected") failures = 0;
			else if (pc.connectionState === "failed" || pc.connectionState === "closed") retry();
		};
		try {
			const offer = await pc.createOffer();
			await pc.setLocalDescription(offer);
			const response = await fetch(options.offerUrl, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					type: offer.type,
					sdp: offer.sdp
				})
			}).catch(() => {
				throw new OfferError(null, {
					code: null,
					message: null
				});
			});
			if (!response.ok) throw new OfferError(response.status, await errorOf(response));
			const answer = await response.json();
			if (closed || pc !== peer) return;
			await pc.setRemoteDescription(answer);
			health = {
				framesDecoded: -1,
				progressAt: Date.now(),
				disconnectedSince: null,
				delaySeconds: null,
				emittedCount: 0
			};
		} catch (error) {
			if (pc !== peer) return;
			if (error instanceof OfferError && error.final) fail(error.failureText());
			else {
				events.waiting(error instanceof OfferError ? error.waitingText() : null);
				retry();
			}
		}
	};
	const checkHealth = async () => {
		const pc = peer;
		if (closed || checking || !pc || !health) return;
		checking = true;
		try {
			let framesDecoded = 0;
			let delaySeconds = 0;
			let emittedCount = 0;
			(await pc.getStats()).forEach((report) => {
				if (report.type === "inbound-rtp" && report.kind === "video") {
					framesDecoded = report.framesDecoded ?? 0;
					delaySeconds = report.jitterBufferDelay ?? 0;
					emittedCount = report.jitterBufferEmittedCount ?? 0;
				}
			});
			const current = health;
			if (pc !== peer || !current) return;
			const now = Date.now();
			if (framesDecoded > current.framesDecoded) {
				current.framesDecoded = framesDecoded;
				current.progressAt = now;
			}
			sampleDelay(current, pc.connectionState === "connected", delaySeconds, emittedCount);
			if (pc.connectionState === "disconnected") current.disconnectedSince ??= now;
			else current.disconnectedSince = null;
			const disconnected = current.disconnectedSince !== null && now - current.disconnectedSince >= STALL_MS;
			if (now - current.progressAt >= STALL_MS || disconnected) retry();
		} catch {} finally {
			checking = false;
		}
	};
	const sampleDelay = (current, connected, delaySeconds, emittedCount) => {
		const frames = emittedCount - current.emittedCount;
		const seconds = delaySeconds - (current.delaySeconds ?? 0);
		const hadBaseline = current.delaySeconds !== null;
		current.delaySeconds = delaySeconds;
		current.emittedCount = emittedCount;
		events.videoDelayMs(connected && hadBaseline && frames > 0 ? seconds / frames * 1e3 : null);
	};
	if (typeof RTCPeerConnection !== "function") {
		closed = true;
		events.failure("This browser has no WebRTC");
		return () => void 0;
	}
	healthTimer = setInterval(() => void checkHealth(), HEALTH_INTERVAL_MS);
	attempt();
	return close;
}
function applyJitterBufferTarget(receiver, ms) {
	if (!("jitterBufferTarget" in receiver)) return;
	try {
		receiver.jitterBufferTarget = ms;
	} catch {}
}
async function errorOf(response) {
	try {
		const { error } = await response.json();
		return {
			code: typeof error?.code === "string" ? error.code : null,
			message: typeof error?.message === "string" ? error.message : null
		};
	} catch {
		return {
			code: null,
			message: null
		};
	}
}
var OfferError = class extends Error {
	status;
	code;
	detail;
	constructor(status, body) {
		super(status === null ? "no answer" : `HTTP ${status}`);
		this.status = status;
		this.code = body.code;
		this.detail = body.message;
	}
	get final() {
		return this.status !== null && this.status >= 400 && this.status < 500;
	}
	failureText() {
		if (this.status === 415) return "Codec not supported by this browser";
		return this.detail ?? `Connection failed: HTTP ${this.status}`;
	}
	waitingText() {
		if (this.code !== null) return Object.hasOwn(WAITING_TEXT, this.code) ? WAITING_TEXT[this.code] : null;
		return this.status === null || GATEWAY_STATUSES.has(this.status) ? UNREACHABLE_TEXT : null;
	}
};
function neatInsightChannel(channel, options = {}) {
	const destroyRef = inject(DestroyRef);
	const zone = inject(NgZone);
	const { offer, videoBufferMs } = options;
	const offerUrl = typeof offer === "function" ? offer(channel) : offer ?? `/api/channels/${channel}/offer`;
	const stream = signal(null, ...ngDevMode ? [{ debugName: "stream" }] : /* istanbul ignore next */ []);
	const waiting = signal(null, ...ngDevMode ? [{ debugName: "waiting" }] : /* istanbul ignore next */ []);
	const failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	const videoDelayMs = signal(null, ...ngDevMode ? [{ debugName: "videoDelayMs" }] : /* istanbul ignore next */ []);
	const listeners = /* @__PURE__ */ new Set();
	const closeConnection = zone.runOutsideAngular(() => openInsightConnection({
		offerUrl,
		videoBufferMs
	}, {
		stream: (value) => stream.set(value),
		waiting: (text) => waiting.set(text),
		failure: (text) => failure.set(text),
		videoDelayMs: (ms) => videoDelayMs.set(ms),
		metadata: (text, receivedAt) => {
			for (const listener of listeners) listener(text, receivedAt);
		}
	}));
	const stopOnDestroy = destroyRef.onDestroy(closeConnection);
	return {
		stream: stream.asReadonly(),
		notice: computed(() => failure() ?? waiting()),
		failure: failure.asReadonly(),
		videoDelayMs: videoDelayMs.asReadonly(),
		onMetadata(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		close() {
			stopOnDestroy();
			closeConnection();
		}
	};
}
export { neatInsightChannel };

//# sourceMappingURL=sima-neat-ui-insight.mjs.map