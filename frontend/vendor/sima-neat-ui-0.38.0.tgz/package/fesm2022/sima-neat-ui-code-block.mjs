import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, input, signal } from "@angular/core";
import { NeatButton, NeatIcon } from "@sima/neat-ui";
const SETTLE_MS = 2500;
const CAPTION = {
	idle: "Copy",
	copied: "Copied",
	failed: "Could not copy"
};
const ANNOUNCEMENT = {
	idle: "",
	copied: "Copied to the clipboard.",
	failed: "Could not copy: the browser refused the clipboard."
};
var NeatCopyButton = class NeatCopyButton {
	text = input.required(...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	what = input.required(...ngDevMode ? [{ debugName: "what" }] : /* istanbul ignore next */ []);
	state = signal("idle", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	caption = computed(() => CAPTION[this.state()], ...ngDevMode ? [{ debugName: "caption" }] : /* istanbul ignore next */ []);
	icon = computed(() => this.state() === "copied" ? "check" : "copy", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	name = computed(() => this.state() === "idle" ? `Copy ${this.what()}` : this.caption(), ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	announcement = computed(() => ANNOUNCEMENT[this.state()], ...ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []);
	timer;
	constructor() {
		inject(DestroyRef).onDestroy(() => clearTimeout(this.timer));
	}
	async copy() {
		let copied = true;
		try {
			await navigator.clipboard.writeText(this.text());
		} catch {
			copied = false;
		}
		this.state.set(copied ? "copied" : "failed");
		clearTimeout(this.timer);
		this.timer = setTimeout(() => this.state.set("idle"), SETTLE_MS);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCopyButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatCopyButton,
		isStandalone: true,
		selector: "neat-copy-button",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			what: {
				classPropertyName: "what",
				publicName: "what",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <button
      neatButton
      type="button"
      variant="text"
      size="small"
      [attr.aria-label]="name()"
      (click)="copy()"
    >
      <neat-icon [name]="icon()" [size]="16" />
      {{ caption() }}
    </button>
    <span class="sr-only" role="status">{{ announcement() }}</span>
  `,
		isInline: true,
		styles: [":host{position:relative;display:inline-flex}\n"],
		dependencies: [{
			kind: "directive",
			type: NeatButton,
			selector: "button[neatButton], a[neatButton]",
			inputs: [
				"variant",
				"size",
				"iconOnly",
				"rounded",
				"pressed"
			]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCopyButton,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-copy-button",
			imports: [NeatButton, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      neatButton
      type="button"
      variant="text"
      size="small"
      [attr.aria-label]="name()"
      (click)="copy()"
    >
      <neat-icon [name]="icon()" [size]="16" />
      {{ caption() }}
    </button>
    <span class="sr-only" role="status">{{ announcement() }}</span>
  `,
			styles: [":host{position:relative;display:inline-flex}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: true
			}]
		}],
		what: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "what",
				required: true
			}]
		}]
	}
});
var NeatCodeBlock = class NeatCodeBlock {
	code = input.required(...ngDevMode ? [{ debugName: "code" }] : /* istanbul ignore next */ []);
	copy = input(...ngDevMode ? [void 0, { debugName: "copy" }] : /* istanbul ignore next */ []);
	overflow = input("wrap", ...ngDevMode ? [{ debugName: "overflow" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCodeBlock,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatCodeBlock,
		isStandalone: true,
		selector: "neat-code-block",
		inputs: {
			code: {
				classPropertyName: "code",
				publicName: "code",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			copy: {
				classPropertyName: "copy",
				publicName: "copy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overflow: {
				classPropertyName: "overflow",
				publicName: "overflow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <pre [attr.data-overflow]="overflow()"><code><ng-content>{{ code() }}</ng-content></code></pre>
    @if (copy(); as what) {
      <neat-copy-button [text]="code()" [what]="what" />
    }
  `,
		isInline: true,
		styles: [":host{display:flex;align-items:center;gap:var(--neat-space-2);min-width:0;padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--muted);font-size:var(--neat-text-xs);line-height:1.6}pre{flex:1;min-width:0;margin:0}pre[data-overflow=wrap]{white-space:pre-wrap;overflow-wrap:anywhere}pre[data-overflow=scroll]{overflow-x:auto}\n"],
		dependencies: [{
			kind: "component",
			type: NeatCopyButton,
			selector: "neat-copy-button",
			inputs: ["text", "what"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCodeBlock,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-code-block",
			imports: [NeatCopyButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <pre [attr.data-overflow]="overflow()"><code><ng-content>{{ code() }}</ng-content></code></pre>
    @if (copy(); as what) {
      <neat-copy-button [text]="code()" [what]="what" />
    }
  `,
			styles: [":host{display:flex;align-items:center;gap:var(--neat-space-2);min-width:0;padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--muted);font-size:var(--neat-text-xs);line-height:1.6}pre{flex:1;min-width:0;margin:0}pre[data-overflow=wrap]{white-space:pre-wrap;overflow-wrap:anywhere}pre[data-overflow=scroll]{overflow-x:auto}\n"]
		}]
	}],
	propDecorators: {
		code: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "code",
				required: true
			}]
		}],
		copy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "copy",
				required: false
			}]
		}],
		overflow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overflow",
				required: false
			}]
		}]
	}
});
export { NeatCodeBlock, NeatCopyButton };

//# sourceMappingURL=sima-neat-ui-code-block.mjs.map