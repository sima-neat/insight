import { BrnSelect } from "@spartan-ng/brain/select";
import * as i0 from "@angular/core";
/** `medium` matches the kit's medium input and button (2.25rem), `small` the small ones (2rem). */
type NeatSelectSize = 'small' | 'medium';
/** Where a shown label sits: over the select, as a field's does, or before it on its row. */
type NeatSelectLabelPosition = 'above' | 'inline';
/** One choice of a `neat-select`. */
interface NeatSelectOption<T> {
  value: T;
  /** What the option shows, and what a screen reader reads. */
  label: string;
  /** A disabled option is shown but cannot be picked, and the arrow keys skip it. */
  disabled?: boolean;
}
/**
 * Helm's select classes (`lib/ui/select/src/lib/hlm-select-trigger.ts`, `hlm-select-content.ts`
 * and `hlm-select-item.ts`), copied because helm keeps them inline. select.spec checks that each
 * string still appears in the vendored helm, so a helm update that changes one fails until this
 * table is reviewed.
 */
declare const SELECT_HELM_CLASSES: {
  readonly trigger: "border-input data-placeholder:text-muted-foreground dark:bg-input/30 dark:hover:bg-input/50 focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 gap-1.5 rounded-md border bg-transparent py-2 ps-2.5 pe-2 text-sm shadow-xs transition-[color,box-shadow] focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 data-[size=default]:h-9 data-[size=sm]:h-8 *:data-[slot=select-value]:gap-1.5 flex w-fit items-center justify-between whitespace-nowrap outline-none disabled:cursor-not-allowed disabled:opacity-50 *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0";
  /** The icon in the trigger, in `hlm-select-trigger.ts`'s template. */
  readonly triggerIcon: "text-muted-foreground text-[length:--spacing(4)] ms-auto";
  readonly content: "bg-popover no-scrollbar text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 max-h-72 min-w-36 flex-col rounded-md shadow-md ring-1 duration-100 relative flex w-(--brn-select-width) overflow-x-hidden overflow-y-auto";
  readonly item: "data-highlighted:bg-accent data-highlighted:text-accent-foreground not-data-[variant=destructive]:data-highlighted:**:text-accent-foreground gap-2 rounded-sm py-1.5 ps-2 pe-8 text-sm *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2 relative flex w-full cursor-default items-center outline-hidden select-none data-disabled:pointer-events-none data-disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0";
  /** The check on the picked item, in `hlm-select-item.ts`'s template. */
  readonly itemCheck: "absolute end-2 flex items-center justify-center text-[length:--spacing(4)]";
};
/**
 * A choice of one value from a list, with no free text:
 *
 * ```html
 * <neat-select label="Source" placeholder="Pick a source" [options]="sources" [(value)]="source" />
 * ```
 *
 * `label` is the accessible name of the select and of its list. `showLabel` also shows it above
 * the select. `labelPosition="inline"` shows it before the select on the same row instead, for a
 * select in a toolbar or a heading. A click on the shown label opens the list.
 *
 * The shown label is drawn as `neat-field`'s is, and `size` matches `neatInput`'s and
 * `neatButton`'s. So a select in a row of fields and buttons of the same size lines up with them.
 *
 * `options` are `{ value, label, disabled? }`. The selected value is `value`, `null` while there is
 * none. The trigger shows the selected option's label or, without one, `placeholder`. A value that
 * is not among the options shows the placeholder as well, in its muted color. That is a deleted
 * file, say, or options that load later.
 *
 * The select fills its container's width, or inline the width its label leaves. Its list is as
 * wide as the select.
 *
 * It follows the WAI-ARIA select-only combobox. Focus stays on the trigger throughout, and
 * `aria-activedescendant` names the active option.
 * - On the trigger, Down, Up, Enter and Space open the list.
 * - In the open list, Down, Up, Home, End, Page Up and Page Down move through the options,
 *   skipping disabled ones. Typing a few letters jumps to the option whose label starts with them.
 * - Enter or Space picks the active option. Tab closes the list and moves on. Escape closes it
 *   without picking.
 *
 * Escape is handled here first. An open select takes it, closes, and stops it there. So a dialog
 * around the select, or a page shortcut on Escape, never sees the key that closed the list. With
 * the list closed, Escape goes on to whatever is listening.
 *
 * The list is a popup on the overlay layer, above a dialog that holds the select.
 */
export declare class NeatSelect<T> {
  /**
   * The accessible name of the select and its list; shown with `showLabel`, or always when
   * `labelPosition` is `inline`.
   */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The choices in the order listed, each a value with the label it shows; one may be disabled. */
  readonly options: import("@angular/core").InputSignal<readonly NeatSelectOption<T>[]>;
  /** The selected option's value; `null` while there is none. Options are matched with `Object.is`. */
  readonly value: import("@angular/core").ModelSignal<T | null>;
  /** What the trigger shows while no option is selected. */
  readonly placeholder: import("@angular/core").InputSignal<string>;
  /** Shows `label` above the select. */
  readonly showLabel: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * Where the label sits: `above` (the default) or `inline`.
   *
   * `above` places it as a field's, and only with `showLabel`. `inline` shows it before the
   * trigger, on its row, by itself. It is the same `label` element, for the trigger, either way.
   */
  readonly labelPosition: import("@angular/core").InputSignal<NeatSelectLabelPosition>;
  /** Turns the whole select off: it cannot be opened or changed. */
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The trigger's height: `medium` (2.25rem) or `small` (2rem), as the kit's input and button. */
  readonly size: import("@angular/core").InputSignal<NeatSelectSize>;
  protected readonly layout: import("@angular/core").Signal<{
    host: string;
    label: string;
    select: string;
  }>;
  /** Inline is a visible label by definition; above is one only when asked for. */
  protected readonly labelShown: import("@angular/core").Signal<boolean>;
  protected readonly helmSize: import("@angular/core").Signal<"default" | "sm">;
  protected readonly triggerId: string;
  protected readonly triggerClasses: string;
  protected readonly triggerIconClasses: string;
  protected readonly contentClasses: string;
  protected readonly itemClasses: string;
  protected readonly checkClasses: string;
  protected readonly selectedLabel: import("@angular/core").Signal<string | undefined>;
  /** An option's label, which brain's type-ahead matches typed letters against. */
  protected readonly labelOf: (value: T) => string;
  /** Brain emits only the values of the options it was given. */
  protected pick(value: unknown): void;
  private optionOf;
  protected closeOnEscape(event: Event, select: BrnSelect<T>): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSelect<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSelect<any>, "neat-select", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "showLabel": {
      "alias": "showLabel";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
export type { NeatSelectLabelPosition, NeatSelectOption, NeatSelectSize };