import * as i0 from "@angular/core";
/**
 * What a code block does with a line wider than itself: `wrap` breaks it, `scroll` keeps it whole
 * and scrolls the block sideways.
 */
type NeatCodeOverflow = 'wrap' | 'scroll';
/**
 * Code set apart on the muted fill, as written, with an optional Copy button at its end.
 *
 * ```html
 * <neat-code-block [code]="command" copy="install command" />
 * ```
 *
 * For a command to run, a file to paste or a URL to copy. For a name or a path in running text,
 * use `code[neatCode]` instead.
 *
 * `copy` names what the code is and adds a `NeatCopyButton` beside the code. "install command"
 * names the button "Copy install command". Without `copy` the block has no button.
 *
 * `overflow` is `wrap` by default, for short code such as a command, which then breaks anywhere.
 * Use `scroll` for a whole file, whose lines keep their shape and scroll sideways.
 *
 * The code is plain text in the kit's monospace font, with no syntax colors. An app that colors
 * its code (spans from a highlighter run at build time) puts them inside the element. They are
 * shown in place of `code`, which stays what Copy copies, so they must spell the same text:
 *
 * ```html
 * <neat-code-block [code]="source" copy="app.ts">
 *   @for (run of runs; track $index) {
 *     <span [class]="run.kind">{{ run.text }}</span>
 *   }
 * </neat-code-block>
 * ```
 *
 * Angular leaves out the line breaks between a template's elements, so only the spans' own text
 * shows, as written.
 */
export declare class NeatCodeBlock {
  /** The code, as text: shown, and copied by the Copy button. */
  readonly code: import("@angular/core").InputSignal<string>;
  /** What the code is, which adds a Copy button named after it ("Copy install command"). */
  readonly copy: import("@angular/core").InputSignal<string | undefined>;
  /** Whether a long line wraps or scrolls sideways (a `NeatCodeOverflow`). */
  readonly overflow: import("@angular/core").InputSignal<NeatCodeOverflow>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCodeBlock, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCodeBlock, "neat-code-block", never, {
    "code": {
      "alias": "code";
      "required": true;
      "isSignal": true;
    };
    "copy": {
      "alias": "copy";
      "required": false;
      "isSignal": true;
    };
    "overflow": {
      "alias": "overflow";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * A small Copy button that puts `text` on the clipboard and says whether it did.
 *
 * ```html
 * <code neatCode>{{ url }}</code>
 * <neat-copy-button [text]="url" what="stream URL" />
 * ```
 *
 * `NeatCodeBlock` shows one beside its code. Use this part on its own for text shown some other
 * way: a URL in running text, or code whose Copy button sits outside it (above a set of tabs).
 *
 * After a click the button says "Copied", with a check, or "Could not copy". It says the same in a
 * polite live region, and offers to copy again after 2.5 s.
 *
 * Its accessible name is "Copy" and `what`: "Copy stream URL", so a page with several buttons
 * does not read as a list of "Copy". The name starts with the visible caption, so a voice user can
 * say what they see.
 *
 * It needs a secure context. A browser gives the clipboard to pages served over https and from
 * localhost only, so on a page served over plain http the button says it could not copy. It has
 * no fallback.
 */
export declare class NeatCopyButton {
  /** The text the button copies. */
  readonly text: import("@angular/core").InputSignal<string>;
  /** What the text is, for the button's name: `install command` names it "Copy install command". */
  readonly what: import("@angular/core").InputSignal<string>;
  private readonly state;
  protected readonly caption: import("@angular/core").Signal<string>;
  protected readonly icon: import("@angular/core").Signal<"check" | "copy">;
  protected readonly name: import("@angular/core").Signal<string>;
  protected readonly announcement: import("@angular/core").Signal<string>;
  private timer;
  constructor();
  protected copy(): Promise<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCopyButton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCopyButton, "neat-copy-button", never, {
    "text": {
      "alias": "text";
      "required": true;
      "isSignal": true;
    };
    "what": {
      "alias": "what";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type { NeatCodeOverflow };