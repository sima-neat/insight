import * as i1 from "@spartan-ng/brain/collapsible";
import { BrnCollapsible } from "@spartan-ng/brain/collapsible";
import * as i0 from "@angular/core";
/**
 * A section that a full-width button opens and closes, such as a panel's "Details":
 *
 * ```html
 * <neat-collapsible label="Details" [summary]="mode()" [(open)]="detailsOpen">…</neat-collapsible>
 * ```
 *
 * The trigger shows the `next` chevron, turned a quarter while open, and `label`. Only while
 * closed, it also shows `summary` in muted text that truncates, for what the section holds at a
 * glance.
 *
 * The trigger is a native button. It names the content in `aria-controls`, and says whether it is
 * open in `aria-expanded`. Enter and Space work as on any button. `open` is two-way bound.
 *
 * With `headingLevel`, the button sits in a heading of that level, as in the WAI-ARIA disclosure
 * and accordion patterns. So the section's title is in the page's outline.
 *
 * The content stays instantiated while closed, hidden and `inert`, so its state survives a close.
 * Gate expensive content, such as a live preview, on `open` with an `@if` of your own.
 *
 * When the section closes with the focus inside it, the focus moves to the trigger. Inert content
 * would otherwise drop it to the page. That happens on a Save that closes the section, say, or
 * when the app sets `open` to false. It happens too when the focus was on an end control that the
 * close removed, one shown only while open. An end control that stays keeps the focus.
 *
 * Elements marked `neatCollapsibleEnd` sit at the end of the trigger's row, outside the trigger and
 * its heading. They are the section's own controls, which act without opening or closing it: a
 * copy button over a code sample, a file choice.
 *
 * The trigger takes the rest of the row. The controls drop to a second line where they would
 * leave the label and summary no room. The trigger's width is both in full, so a long summary
 * wraps the controls before it truncates.
 *
 * The end controls show whether the section is open or closed. An app shows them only while open
 * with an `@if`.
 *
 * @input open Whether the section is open; closed by default. Bind it two-way, `[(open)]`, to
 * keep the state in the page or to open or close the section from code.
 */
export declare class NeatCollapsible {
  /** The trigger's text, which names the section. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** What the section holds, shown beside the label while it is closed; none if empty. */
  readonly summary: import("@angular/core").InputSignal<string>;
  /**
   * The level of the heading the trigger sits in, for a section that is part of an outline.
   *
   * System Info's sections have one. Leave it unset, the default, for a disclosure such as a
   * panel's "Details".
   */
  readonly headingLevel: import("@angular/core").InputSignal<2 | 3 | 4 | 5 | 6 | null>;
  protected readonly brain: BrnCollapsible;
  protected readonly triggerClasses: "group flex w-full min-w-0 cursor-pointer items-center gap-(--neat-space-2) rounded-(--radius) py-1 text-start text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring";
  protected readonly chevronClasses: "shrink-0 text-muted-foreground transition-transform duration-(--neat-transition-duration) group-hover:text-foreground motion-reduce:transition-none";
  protected readonly labelClasses: "shrink-0 font-medium";
  protected readonly summaryClasses: "min-w-0 truncate text-muted-foreground";
  protected readonly contentClasses: "pt-(--neat-space-2) data-closed:hidden";
  protected readonly rowClasses = "flex flex-wrap items-center gap-(--neat-space-2)";
  protected readonly headingClasses = "min-w-0 grow";
  /** The end control that has the focus, kept to tell whether a close removed it. */
  private endFocus;
  private readonly trigger;
  private readonly content;
  constructor();
  protected noteFocus(event: FocusEvent): void;
  /**
   * A move of the focus to another element. A focusout with no `relatedTarget` is the focus
   * leaving the page or, in Chrome, an element being removed while it still has the focus (still
   * connected, so `isConnected` cannot tell): the note stays, for the close to see.
   */
  protected forgetFocus(event: FocusEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCollapsible, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCollapsible, "neat-collapsible", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "summary": {
      "alias": "summary";
      "required": false;
      "isSignal": true;
    };
    "headingLevel": {
      "alias": "headingLevel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[neatCollapsibleEnd]", "*"], true, [{
    directive: typeof i1.BrnCollapsible;
    inputs: {
      "expanded": "open";
    };
    outputs: {
      "expandedChange": "openChange";
    };
  }]>;
}