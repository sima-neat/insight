import { NeatTone } from "@sima/neat-ui";
import * as i0 from "@angular/core";
import { Signal, TemplateRef } from "@angular/core";
/** A side of a node, where edges meet it. */
type NeatDiagramSide = 'left' | 'right' | 'top' | 'bottom';
/**
 * What a node is in the drawing: `frame` holds other nodes (drawn behind the edges, its title and
 * detail top left), `block` is a card (label, detail, chips), `band` a strip such as a cable or a
 * bus (its label along it), `bracket` spans a row of siblings below them (a curly line and a
 * label).
 */
type NeatDiagramRole = 'frame' | 'block' | 'band' | 'bracket';
/**
 * How a node is drawn within its role: `accent` is the primary tint (e.g. the main device),
 * `dashed` a group, `ghost` dashed, transparent and quiet (a part that is not running), `muted`
 * filled with `--muted`.
 */
type NeatDiagramLook = 'default' | 'accent' | 'dashed' | 'ghost' | 'muted';
/** How an edge ends: plain, with an arrowhead, or with a dot. */
type NeatDiagramTip = 'none' | 'arrow' | 'dot';
/**
 * What dims the rest of a diagram while the pointer or the keyboard is on a part: `none`, nothing;
 * `edges`, an edge's two blocks, its notes and itself stay and the rest dims; `all`, the same for
 * a block and the edges that join it too.
 */
type NeatDiagramHighlight = 'none' | 'edges' | 'all';
/** How an edge's line is drawn. */
type NeatDiagramLine = 'solid' | 'dashed' | 'ghost';
/**
 * A short fact on a block, drawn as the kit's status chip in its tone. Where a part runs is said
 * in one convention, so every diagram reads alike: `HW` (the hardware decoder) in `success`,
 * `EV74` in `highlight`, `MLA` in `info` and `A65` in `neutral`.
 */
interface NeatDiagramChip {
  readonly label: string;
  readonly tone: NeatTone;
}
/**
 * One node of a diagram level: a frame, block, band or bracket (`role`), placed by hand at `x`,
 * `y` with the size `w` by `h`, in diagram units. A node with a `parent` sits inside it and is
 * placed relative to it; a block with `opens` is a button that opens that level. The kit never
 * reads `data`: it is the app's, handed back to the app's templates.
 */
interface NeatDiagramNode {
  readonly id: string;
  readonly label: string;
  /** A second line: what it is or where it runs. */
  readonly detail?: string;
  /** The node it sits in; `x` and `y` are relative to it. */
  readonly parent?: string;
  readonly x: number;
  readonly y: number;
  readonly w: number;
  readonly h: number;
  readonly role: NeatDiagramRole;
  /** Unset: `default`. */
  readonly look?: NeatDiagramLook;
  readonly chips?: readonly NeatDiagramChip[];
  /**
   * Whether what the card shows is stale (the node's diagnostics stopped): the whole card, its
   * label, chips and the app's content, takes the look of `[neatStale]`, faded and grey with no
   * transition, and the hidden list says "stale". The app says in words why, in the card's
   * content. Blocks and brackets only.
   */
  readonly stale?: boolean;
  /** The id of the level (`NeatDiagramSet.levels`) this block opens. */
  readonly opens?: string;
  /**
   * The side its incoming (`inSide`) or outgoing (`outSide`) edges meet it on; unset, each edge
   * end goes on the side that faces the other end.
   */
  readonly inSide?: NeatDiagramSide;
  readonly outSide?: NeatDiagramSide;
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/**
 * A line between two nodes of a level, which the kit routes: its colour is a charts series
 * (`series`), its look `line`, its ends `start` and `end`, with an optional `label` on it. The app
 * does not place it, only names the nodes it joins. The kit never reads `data`: it is the app's.
 */
interface NeatDiagramEdge {
  readonly id: string;
  /** The node it leaves. */
  readonly from: string;
  /** The node it enters. */
  readonly to: string;
  /** Its colour, the charts' series colour 1 to 8; unset, or on a `ghost` line, muted. */
  readonly series?: number;
  /** Unset: `solid`. */
  readonly line?: NeatDiagramLine;
  /** Its tip at `from`; unset, `none`. */
  readonly start?: NeatDiagramTip;
  /** Its tip at `to`; unset, `arrow`. */
  readonly end?: NeatDiagramTip;
  /** A short label on the edge, at `labelAt`. */
  readonly label?: string;
  /** Where the label sits along the edge, 0 at `from` to 1 at `to`; unset, 0.5. */
  readonly labelAt?: number;
  /**
   * The side of `from` this edge leaves on, over the node's `outSide` for this edge only; unset,
   * the node's `outSide`, else the side facing the other end. The route and the label follow it.
   * An end inside a frame stays on the frame's border nearest the node, as the node's sides do.
   */
  readonly fromSide?: NeatDiagramSide;
  /** The side of `to` this edge enters on, as `fromSide` is for the leaving end (`inSide`). */
  readonly toSide?: NeatDiagramSide;
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/**
 * A box of the app's content (a template matched by the note's id or `data`), joined by a dotted
 * leader to its anchor: a point along its edges, or a point of its own. A note anchored by
 * `anchor` alone belongs to no edge, so it is never in focus with one: it dims whenever anything
 * is in focus.
 */
interface NeatDiagramNote {
  readonly id: string;
  /** The edges it is about; the anchor is the mean of their points at `along`. */
  readonly edges?: readonly string[];
  /** Where along its edges the anchor lies, 0 at their start to 1 at their end; unset, 0.5. */
  readonly along?: number;
  /**
   * The anchor as a point instead (a node's side, for a note about the node); without `x`, the
   * edges' mean x, for a leader into the middle of a bundle of parallel edges.
   */
  readonly anchor?: {
    readonly x?: number;
    readonly y: number;
  };
  /** The box's centre, per axis; unset, the anchor moved by `dx` and `dy`. */
  readonly x?: number;
  readonly y?: number;
  readonly dx?: number;
  readonly dy?: number;
  /**
   * Where the leader meets the box: its nearest point (unset; level or upright where it can be),
   * or its centre, under the box (`centre`; a slanted leader then meets no rounded corner).
   */
  readonly leaderTo?: 'centre';
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/** One level: nodes, the edges between them and the notes on them. */
interface NeatDiagram {
  readonly nodes: readonly NeatDiagramNode[];
  readonly edges: readonly NeatDiagramEdge[];
  readonly notes?: readonly NeatDiagramNote[];
}
/**
 * A diagram with its drill-down levels, each placed by hand: a block whose `opens` names a level
 * opens it, and a level may open further levels.
 */
interface NeatDiagramSet {
  readonly overview: NeatDiagram;
  readonly levels?: Readonly<Record<string, NeatDiagram>>;
}
interface Point {
  x: number;
  y: number;
}
/**
 * The corners of the edge from `source` (leaving through `sourceSide`) to `target` (entering
 * through `targetSide`), ends included. One turn when the sides are at right angles (an L), two
 * when they face each other (a Z, its middle run `jog` further along the way than halfway; 0
 * when the ports are level, a straight line), and stubs out of both ports when the target lies
 * behind the source.
 */
declare function routePoints(source: Point, sourceSide: NeatDiagramSide, target: Point, targetSide: NeatDiagramSide, jog?: number): Point[];
/** A piece of a drawn edge: a straight run to `line`, or a turn (cubic bezier) to `curve[2]`. */
type Piece = {
  line: Point;
} | {
  curve: [Point, Point, Point];
};
/**
 * The corners rounded: each turn's legs are `bend` long, at most the shorter of its two runs
 * (half of a run between two turns, so neighbouring turns never overlap).
 */
declare function roundCorners(points: Point[], bend?: number): Piece[];
/** The SVG path through a route's corners (`routePoints`), drawn in the rounded shape. */
declare function pathThrough(points: Point[]): string;
/** Points along the pieces from `start` (each turn in `steps` parts): the drawn shape, sampled. */
declare function sampleRoute(start: Point, pieces: Piece[], steps?: number): Point[];
/**
 * The point `t` of the way along the drawn shape of the route through `points` (its corners, as
 * `routePoints` gives them), by length: 0 at its start, 1 at its end, clamped. Measured on the
 * rounded shape rather than on the corners, so an edge label or a note's anchor near a turn sits
 * on the line that is drawn.
 */
declare function pointAlong(points: Point[], t: number): Point;
interface Rect extends Point {
  w: number;
  h: number;
}
/** An edge as drawn: its ports and their sides, and its route in the rounded shape. */
interface EdgeLayout {
  /**
   * Its port on `from`, in the level's coordinates, and the side of `from` it leaves through. An
   * edge between a frame and a node inside it has its frame end on the border nearest the node and
   * runs inward: that end's side is the way it runs (`top` for a port on the bottom border).
   */
  source: Point;
  sourceSide: NeatDiagramSide;
  /** Its port on `to` and the side of `to` it enters through (for a frame, as above). */
  target: Point;
  targetSide: NeatDiagramSide;
  /** The SVG path of its rounded shape. */
  path: string;
  /** Its route's corners, ends included, along which `pointAlong` measures. */
  points: Point[];
}
/**
 * Each node's rectangle in the level's coordinates: its position plus those of the nodes it sits
 * in, however deep. A node whose parent is not on the level, or that lies inside itself, is left
 * out with what sits in it, so the rest of a broken diagram still draws; so is a node whose id an
 * earlier node already has.
 */
declare function absoluteRects(diagram: NeatDiagram): Map<string, Rect>;
/**
 * Per side: `t`, the way its ports are spread (offset grows along it), `n`, the way out of the
 * node.
 */
declare const SIDE_AXES: Record<NeatDiagramSide, {
  t: Point;
  n: Point;
}>;
/**
 * Each edge as drawn, by id: its ends on the sides that face each other (or that its nodes name),
 * spread along each side so a fan does not cross itself, and its rounded route, Z routes that
 * share a corridor spread apart. An edge with an end that is not a node on the level (or one left
 * out), or whose id an earlier edge already has, is left out.
 */
declare function layoutEdges(diagram: NeatDiagram): Map<string, EdgeLayout>;
/**
 * The pairs of edges (by id) whose straight port-to-port lines cross: a measure of how tangled a
 * level reads (the drawn curves leave and enter their ports the same way).
 */
declare function crossings(diagram: NeatDiagram): [string, string][];
/** True when the segments p1-p2 and p3-p4 cross properly (touching does not count). */
declare function intersect(p1: Point, p2: Point, p3: Point, p4: Point): boolean;
/** A node as drawn. */
interface DrawnNode {
  readonly node: NeatDiagramNode;
  /** In the level's coordinates. */
  readonly rect: Rect;
  readonly look: NeatDiagramLook;
  /** A block whose `opens` names a level that exists: it shows the open affordance. */
  readonly opens: boolean;
  /** A bracket's brace, in its own box (`BRACE_HEIGHT` high); null for the other roles. */
  readonly brace: string | null;
}
/** An edge's tip: an arrowhead (a closed path) or a dot, at the edge's `start` or `end`. */
type DrawnTip = {
  readonly end: 'start' | 'end';
  readonly shape: 'arrow';
  readonly d: string;
} | {
  readonly end: 'start' | 'end';
  readonly shape: 'dot';
  readonly cx: number;
  readonly cy: number;
  readonly r: number;
};
/** An edge as drawn. */
interface DrawnEdge {
  readonly id: string;
  /** The app's edge, for its tip's template and its words. */
  readonly edge: NeatDiagramEdge;
  readonly path: string;
  /** Its route's corners, ends included (`EdgeLayout.points`): what the messages sample. */
  readonly points: readonly Point[];
  /** The CSS colour its line and tips take. */
  readonly colour: string;
  readonly line: NeatDiagramLine;
  readonly tips: readonly DrawnTip[];
  /** Its label and the point of the route it is centred on. */
  readonly label: {
    readonly text: string;
    readonly at: Point;
  } | null;
}
interface DrawnLevel {
  /** Frames and bands, drawn behind the edges; a frame after the frames it sits in. */
  readonly behind: readonly DrawnNode[];
  /** Blocks and brackets, drawn in front of the edges. */
  readonly front: readonly DrawnNode[];
  readonly edges: readonly DrawnEdge[];
  /** Each drawn edge's layout, by id, which the notes are placed along. */
  readonly layouts: ReadonlyMap<string, EdgeLayout>;
}
/** How tall a bracket's brace is (diagram units); its label sits below it. */
declare const BRACE_HEIGHT = 18;
/**
 * The colour of an edge without a series, or with one the palette lacks: its custom property's
 * name, which the messaging layer's dots resolve too, and the same for CSS.
 */
declare const MUTED_TOKEN = "--muted-foreground";
/**
 * The level as drawn. `levels` are the ids of the levels that exist, which a block's `opens`
 * must name to show the open affordance. A part the layout cannot place (an id that names
 * nothing) is left out, named once in dev mode, and the rest is drawn.
 */
declare function drawLevel(diagram: NeatDiagram, levels: ReadonlySet<string>): DrawnLevel;
/**
 * The colour of a line, an edge's or a legend sample's: its series' token, else the muted colour.
 * A ghost is muted whatever its series: it is a part that does not run here, and stays quiet
 * beside the edges that do. `part` names what has the line in the dev-mode message.
 */
declare function lineColour(series: number | undefined, line: NeatDiagramLine | undefined, part: string): string;
/**
 * The palette index (from 0, as `NeatSeriesSwatch` and the kit's token rule count) of a diagram
 * series (from 1, as an edge's `series`): the one place the diagram converts between the two.
 * Null for a series that is not 1 to 8, which is named once in dev mode and drawn muted.
 */
declare function seriesIndex(series: number, part: string): number | null;
/** A drawn part in words, for the list that says the picture without it. */
interface DescribedPart {
  readonly id: string;
  readonly text: string;
}
/**
 * The level in words: each node by its label, detail and chips ("Decode, H.264, HW"), each edge
 * by its ends and label ("Camera to Decode, image"). Only what is drawn, so the words and the
 * picture say the same.
 */
declare function describeLevel(level: DrawnLevel): {
  readonly nodes: readonly DescribedPart[];
  readonly edges: readonly DescribedPart[];
};
/** A note as drawn: its box, the point it is about, and its leader (none under the box). */
interface NotePlacement {
  box: Rect;
  anchor: Point;
  /** From the anchor to the box; null while the anchor is under the box. */
  leader: [Point, Point] | null;
}
/**
 * Each note's placement, by id. `edges` are the level's laid-out edges (`layoutEdges`) and
 * `sizes` each note's measured box: a note not measured yet is not placed (the renderer places
 * it once it has its size). A note with nothing to anchor it is left out; an edge it names that
 * is not on its level is ignored, each named once. An edge on the level that the layout left
 * out is ignored quietly: the layout has named it.
 */
declare function placeNotes(diagram: NeatDiagram, edges: ReadonlyMap<string, EdgeLayout>, sizes: ReadonlyMap<string, {
  w: number;
  h: number;
}>): Map<string, NotePlacement>;
/** What the pointer or the keyboard is on. */
interface DiagramFocus {
  readonly kind: 'block' | 'edge';
  readonly id: string;
}
/** The parts that stay as they are while something is in focus; the rest is dimmed. */
interface FocusedParts {
  readonly nodes: ReadonlySet<string>;
  readonly edges: ReadonlySet<string>;
  readonly notes: ReadonlySet<string>;
}
/** The gap between the pointer and its tip, px on screen (the demo's). */
declare const TIP_GAP = 14;
/**
 * What `highlight` lets dim the diagram out of `focus`: nothing for `none`, an edge only for
 * `edges`, anything for `all`. The tip of an edge follows the pointer whatever this answers.
 */
declare function highlighted(focus: DiagramFocus | null, highlight: NeatDiagramHighlight): DiagramFocus | null;
/**
 * The parts in focus on `level`: a block with the edges that enter or leave it, an edge with the
 * nodes at its ends; with either, the notes on those edges. Null while nothing is in focus.
 */
declare function focusedParts(level: NeatDiagram, focus: DiagramFocus | null): FocusedParts | null;
/**
 * Where a tip of `size` goes for the pointer `at`, in a box of `box` (px from its corner): below
 * and right of the pointer, a gap away; on the other side on an axis where that leaves the box;
 * and pushed into the box where neither side has room, so it is never cut off.
 */
declare function placeTip(at: Point, size: {
  readonly w: number;
  readonly h: number;
}, box: {
  readonly w: number;
  readonly h: number;
}): {
  left: number;
  top: number;
};
/**
 * What the pointer and the keyboard put in focus on one diagram's box, found by delegation (the
 * parts' `data-node` and `data-edge`), so no listener runs per part. Created outside the zone; its
 * listeners write a signal only when what is in focus changes.
 */
declare class DiagramHover {
  private readonly box;
  /** The tip's element while it is rendered. */
  private readonly tip;
  private readonly pointer;
  /** The block whose open button has the focus. */
  private readonly keyboard;
  /** The pointer, px from the box's padding corner, for the tip. */
  private at;
  /** The pointer's part, else the keyboard's block. */
  readonly focus: import("@angular/core").Signal<DiagramFocus | null>;
  /** The edge whose tip shows: the one under the pointer. */
  readonly tipEdge: import("@angular/core").Signal<string | null>;
  constructor(box: HTMLElement,
  /** The tip's element while it is rendered. */
  tip: () => HTMLElement | undefined);
  /** Puts the tip by the pointer, inside the box. Called on each move and once it renders. */
  place(): void;
  /** Nothing is in focus: a new level has other parts. */
  clear(): void;
  destroy(): void;
  /**
   * The part under a mouse or a pen. Touch has no hover, and a held button is a drag of the
   * view, whose parts slide under the pointer: neither puts anything in focus.
   */
  private readonly over;
  private readonly leave;
  /**
   * An open button the keyboard focuses. A press on a block focuses its button too (d3-zoom lets
   * the press through), and after a pan from it the block would stay in focus with the rest
   * dimmed and no ring to say why; `:focus-visible` is the browser's word for the keyboard's.
   */
  private readonly focusIn;
  private readonly focusOut;
  /** `element` if it is one of this box's parts, not an ancestor of the box's. */
  private inBox;
}
/** What a block's template is given: the block. */
interface NeatDiagramBlockContext {
  readonly $implicit: NeatDiagramNode;
}
/** What the edge tip's template is given: the edge. */
interface NeatDiagramEdgeTipContext {
  readonly $implicit: NeatDiagramEdge;
}
/** What a note's template is given: the note. */
interface NeatDiagramNoteContext {
  readonly $implicit: NeatDiagramNote;
}
/**
 * The body of the diagram's blocks, below each block's label (the demo's live figures):
 *
 * ```html
 * <ng-template neatDiagramBlock let-node>
 *   @if (node.id === 'decode') { <span>{{ fps() }} fps</span> }
 * </ng-template>
 * ```
 *
 * The card keeps the node's size, so the app sizes the node's `h` (and `w`) for the body. A block
 * it renders nothing for keeps its card as it is. A bracket renders it too, after its label and
 * detail (the stage's live time over a row of blocks, say): `node.role` tells the two apart, and
 * a template that matches by id never meets the other.
 */
export declare class NeatDiagramBlockTemplate {
  /**
   * @internal The template the diagram renders; apps never read it.
   */
  readonly template: TemplateRef<NeatDiagramBlockContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramBlockTemplate, context: unknown): context is NeatDiagramBlockContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramBlockTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramBlockTemplate, "ng-template[neatDiagramBlock]", never, {}, {}, never, never, true, never>;
}
/**
 * The content of the diagram's notes, in a box joined to its anchor by a dotted leader:
 *
 * ```html
 * <ng-template neatDiagramNote let-note>
 *   @if (note.id === 'rate') { <b>Camera → Decode</b> {{ rate() }} msg/s }
 * </ng-template>
 * ```
 *
 * A note it renders nothing for is not drawn, nor its leader; without the template no note is. A
 * note anchored by `anchor` alone belongs to no edge, so it dims whenever anything is in focus.
 */
export declare class NeatDiagramNoteTemplate {
  /**
   * @internal The template the diagram renders; apps never read it.
   */
  readonly template: TemplateRef<NeatDiagramNoteContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramNoteTemplate, context: unknown): context is NeatDiagramNoteContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramNoteTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramNoteTemplate, "ng-template[neatDiagramNote]", never, {}, {}, never, never, true, never>;
}
/**
 * The tip of the edge under the pointer, by the pointer, in the popover's colours and kept inside
 * the diagram's box:
 *
 * ```html
 * <ng-template neatDiagramEdgeTip let-edge>
 *   <b>{{ edge.label }}</b> {{ rate(edge.id) }} msg/s
 * </ng-template>
 * ```
 *
 * It follows a mouse or a pen, never touch (which has no hover), and is hidden from assistive
 * technology: the diagram's hidden list says each edge in words, so a tip must not hold anything
 * a reader needs that the list or a note does not say. An edge it renders nothing for shows no
 * tip.
 */
export declare class NeatDiagramEdgeTipTemplate {
  /**
   * @internal The template the diagram renders; apps never read it.
   */
  readonly template: TemplateRef<NeatDiagramEdgeTipContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramEdgeTipTemplate, context: unknown): context is NeatDiagramEdgeTipContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramEdgeTipTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramEdgeTipTemplate, "ng-template[neatDiagramEdgeTip]", never, {}, {}, never, never, true, never>;
}
/**
 * A hand-placed diagram in the kit's look:
 *
 * ```html
 * <neat-diagram [diagram]="system" label="The demo's system" [(level)]="level">
 *   <ng-template neatDiagramNote let-note>…</ng-template>
 * </neat-diagram>
 * ```
 *
 * Frames and bands are drawn behind one SVG of edges, blocks, brackets, edge labels and notes in
 * front of it, all in one container (what pan and zoom move). Every part is keyed by its id, so a
 * new diagram object with the same content (an app recomputing it on every poll) changes nothing
 * in the DOM, and a moved node is the same element, moved. A part whose ids name nothing is left
 * out and named once in dev mode; the rest is drawn.
 *
 * The host is a `figure` named by `label`; it fills the box the app gives it and clips what lies
 * outside. Chips are the kit's status chips; a block's body, the notes' content and the tip of
 * the edge under the pointer are the app's templates (`neatDiagramBlock`, `neatDiagramNote`,
 * `neatDiagramEdgeTip`). A visually hidden list after the drawing says the level's nodes and
 * edges in words.
 *
 * With `highlight` set, a block or an edge under the pointer, or a block whose open button has the
 * focus, is in focus with what it is joined to; the rest is dimmed. A block that opens a level is
 * a button that opens it; `level` is the path of open levels, which an app can bind to its route,
 * and the bar over the drawing goes back and shows the path. A path that leads nowhere (a stale
 * route) is cut to the part that does, and the model is set to it; so render the diagram once its
 * data is there, since a routed path is checked against the diagram given, a placeholder too.
 *
 * The user pans and zooms it (drag, wheel, pinch, double-click; with the box focused, the arrow
 * keys, `+`, `-` and `0`); it fits its level to the box by itself until they do, and `fit()` fits
 * it again. It takes the wheel and touch over its box (`touch-action: none`), so
 * give it a bounded box, not a long stretch of a scrolling page.
 *
 * A `neat-diagram-messages` projected into it draws the messages moving along its edges, over the
 * drawing; the diagram gives it the level, its edges and the pan and zoom it draws by.
 */
export declare class NeatDiagramView {
  /** The overview and its drill-down levels. */
  readonly diagram: import("@angular/core").InputSignal<NeatDiagramSet>;
  /** The figure's accessible name: what the diagram shows. */
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * The path of open levels, ids of `diagram().levels`, each opened by a block of the level before
   * it; `[]` for the overview. Set by the open buttons, the back button and the breadcrumbs.
   */
  readonly level: import("@angular/core").ModelSignal<string[]>;
  /**
   * What dims the rest while something is under the pointer: nothing by default, since dimming
   * without a reason to look is noise that every pass of the pointer over the drawing makes;
   * `edges` for a drawing whose links are what the reader follows (the dim then says which blocks
   * a link joins); `all` when a block's links are worth tracing too. An edge's tip shows whatever
   * this is.
   */
  readonly highlight: import("@angular/core").InputSignal<NeatDiagramHighlight>;
  protected readonly blockTemplate: import("@angular/core").Signal<NeatDiagramBlockTemplate | undefined>;
  protected readonly noteTemplate: import("@angular/core").Signal<NeatDiagramNoteTemplate | undefined>;
  private readonly edgeTipTemplate;
  private readonly noteSizes;
  private readonly content;
  private readonly edges;
  private readonly tipBox;
  private readonly bar;
  private readonly host;
  private readonly injector;
  private readonly zone;
  private zoom;
  /** The messaging layer's listeners for a new transform (`DiagramMessagesContext`). */
  private readonly transformListeners;
  private readonly hover;
  protected readonly BRACE_HEIGHT = 18;
  /** The look of `[neatStale]`, for a node with `stale`. */
  protected readonly staleClasses = "opacity-55 grayscale";
  private readonly walked;
  /** The path as far as it leads: the levels shown. */
  private readonly path;
  /** The level shown: the one at the end of the path. */
  private readonly shown;
  /**
   * Each level of the path as a crumb, named by the block that opens it: its label, and on the
   * last crumb (where the user is) its detail, muted.
   */
  protected readonly crumbs: import("@angular/core").Signal<{
    label: string;
    detail: string | undefined;
  }[]>;
  /** What the back button goes to: the level before this one, or the overview. */
  protected readonly backTo: import("@angular/core").Signal<string>;
  protected readonly drawn: import("@angular/core").Signal<DrawnLevel>;
  /** The level's notes, each drawn (and measured) only while the app has a note template. */
  protected readonly notes: import("@angular/core").Signal<import("@sima/neat-ui/diagram").NeatDiagramNote[]>;
  /** Where each measured note goes, by id. */
  protected readonly placements: import("@angular/core").Signal<Map<string, NotePlacement>>;
  /** What a fit frames: the level's nodes, edges and placed notes. */
  private readonly extent;
  /** The parts in focus while something is (the rest is dimmed); null while nothing is. */
  protected readonly focused: import("@angular/core").Signal<FocusedParts | null>;
  /** The tip of the edge under the pointer, while the app has a tip template. */
  protected readonly edgeTip: import("@angular/core").Signal<{
    template: import("@angular/core").TemplateRef<NeatDiagramEdgeTipContext>;
    edge: import("@sima/neat-ui/diagram").NeatDiagramEdge;
  } | null>;
  /** The level in words, for the hidden list. */
  protected readonly described: import("@angular/core").Signal<{
    readonly nodes: readonly DescribedPart[];
    readonly edges: readonly DescribedPart[];
  }>;
  constructor();
  /** Fits the level to the box, animated unless reduced motion; it then fits by itself again. */
  fit(): void;
  /**
   * What a messaging layer projected into the diagram draws by: the level shown (another path is
   * another level), its blocks and placed notes as the cards dots pass behind, every edge id of
   * the set, the edges in focus, and the transform with a hook for each change of it.
   */
  private messagesContext;
  /** Opens the level `block` opens, one deeper than the level shown. */
  protected open(block: NeatDiagramNode): void;
  /** Goes back to the level before this one. */
  protected back(): void;
  /** Goes to the level at `index` of the path (a breadcrumb). */
  protected goTo(index: number): void;
  /**
   * The control pressed may leave with its level (an open button, the last level's breadcrumb,
   * the bar on the way to the overview); the focus then stays in the diagram, on its box, instead
   * of falling to the page.
   */
  private go;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramView, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramView, "neat-diagram", never, {
    "diagram": {
      "alias": "diagram";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "level": {
      "alias": "level";
      "required": false;
      "isSignal": true;
    };
    "highlight": {
      "alias": "highlight";
      "required": false;
      "isSignal": true;
    };
  }, {
    "level": "levelChange";
  }, ["blockTemplate", "noteTemplate", "edgeTipTemplate"], ["neat-diagram-messages"], true, never>;
}
/** One entry of a diagram's legend: what a series colour or a line look stands for. */
interface NeatDiagramLegendItem {
  /** The series (1 to 8) whose colour it names, as an edge's `series`; unset, muted. */
  readonly series?: number;
  /** The line look it names, as an edge's `line`; unset, the series' swatch instead. */
  readonly line?: NeatDiagramLine;
  readonly label: string;
}
/**
 * What a diagram's colours and lines stand for, as the Autoware demo's legend chip:
 *
 * ```html
 * <neat-diagram-legend [items]="[
 *   { series: 1, label: 'image' },
 *   { series: 4, label: 'results' },
 *   { line: 'ghost', label: 'not run here' },
 * ]" />
 * ```
 *
 * A series without a `line` shows the kit's `NeatSeriesSwatch` for it, as the charts' legends do.
 * Any other item shows a short sample of its line (solid when unset), drawn by the edges' own
 * rules in the colour its edges take: muted for a ghost, without a series, or for a
 * series that is not 1 to 8. Samples and swatches are `aria-hidden`: the label
 * names what they stand for, and a colour alone is not a name.
 */
export declare class NeatDiagramLegend {
  /** The entries, in the order shown. */
  readonly items: import("@angular/core").InputSignal<readonly NeatDiagramLegendItem[]>;
  protected readonly drawn: import("@angular/core").Signal<{
    label: string;
    swatch: number | null;
    line: NeatDiagramLine;
    colour: string | null;
  }[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramLegend, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramLegend, "neat-diagram-legend", never, {
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The level that opens on `blockId`: the block as its frame at the origin, sized to its children
 * with a padding, and everything inside the block, however deep, as placed (positions are
 * relative to the parent, so nothing moves); the nodes the edges from inside reach, in a column
 * left of the frame (senders) and right of it (receivers), vertically centred on it; and the edges
 * with an end inside. A node that both sends and receives goes in the senders' column only, so it
 * is on the level once. The outside nodes and the frame get their sides afresh (an overview's
 * `inSide` and `outSide` suit its placement, not this one), and the frame opens nothing (it is the
 * level). The diagram's notes are left behind: they are placed for it. A block that is not on the
 * diagram or holds nothing gives an empty level, named once.
 */
export declare function neatDrillDownLevel(diagram: NeatDiagram, blockId: string): NeatDiagram;
/**
 * How long a dot takes along an edge without a time of its own (`DotModel.travelMs`). Edges with a
 * length take length / speed (`travelTime`), so every dot moves at the same speed: the real
 * latency is a number, not the motion.
 */
declare const TRAVEL_MS = 1200;
/**
 * The shortest and longest time a dot takes along an edge: a tiny edge's dot stays visible long
 * enough to see; the longest is only a guard and must stay above every edge's length / speed, or
 * long edges run faster than the rest (the demo's 3 s cap made its widest edges 1.5x too fast).
 */
declare const MIN_TRAVEL_MS = 120;
declare const MAX_TRAVEL_MS = 20000;
/** How long a dot takes along an edge of `length` (diagram units) at `speed` (units per second). */
declare function travelTime(length: number, speed: number): number;
/** A dot's radius by its message's size: 2 up to 1 kB, +1.5 per tenfold, at most 7. */
declare function dotRadius(bytes: number): number;
/** A dot on its way this frame. The objects are the model's own and reused: read, do not keep. */
interface Dot {
  edge: string;
  /** How far along its edge, 0 to 1. */
  t: number;
  /** Its radius in diagram units. */
  r: number;
  /**
   * The caller's colour, passed on to the step dots it starts: a whole number from 0 to 255, since
   * the pool keeps it in a byte (the layer's series 1 to 8 fit).
   */
  colour: number;
}
/** Told every dot spawned (step dots too), with the time it starts and its message's bytes. */
type SpawnListener = (edge: string, atMs: number, bytes: number) => void;
/**
 * How many dots the model holds, on their way and waiting to start. A drill-down at 4 s travel
 * holds about 72 msg/s · 4 s · (1 + 2 + … + 6) ≈ 6000 (each step's dot waits for those before
 * it); the cap is what keeps a burst (thousands of pushes in one tick) from growing memory.
 */
declare const MAX_DOTS = 16384;
/**
 * How many dots one message may place, itself and its step dots together: a guard against steps
 * that loop, and against steps that fan out and loop, whose placements grow with every round. A
 * chain of the demo's size (six steps) is far inside it.
 */
declare const MAX_CHAIN = 32;
/**
 * A fixed pool of dots. `spawn` places a dot that starts at `atMs` (now, or soon: a batch spreads
 * its messages, see `neatBatchTimes`), `advance` gives the dots on their way at a time and forgets
 * those that arrived. A full pool drops its oldest dot and counts it in `dropped`: the newest
 * messages are the ones worth showing, and the listener still hears every spawn, so the rates
 * stay exact however many dots are dropped.
 *
 * The pool is a ring in placement order, so dropping the oldest is one step, not a shift of every
 * dot.
 *
 * Step dots (`setChain`): a dot on an edge that leads into a node's steps starts a dot on each
 * following step once it has arrived and that step's time has passed, and so on along the chain,
 * so the dots inside a node follow the real input's rhythm and the measured stage times. They are
 * placed at once, with their later start times, from the stage times of that moment.
 */
declare class DotModel {
  readonly capacity: number;
  private readonly onSpawn?;
  private readonly edges;
  private readonly starts;
  private readonly radii;
  private readonly colours;
  private readonly shown;
  private readonly out;
  private readonly frame;
  /** Where the oldest dot is in the ring. */
  private head;
  private count;
  /** How many of those are `shown` (placed with `visible`). */
  private shownCount;
  /** What the message being placed may still place, step dots included. */
  private budget;
  private next;
  private delayOf;
  private travel;
  /** Dots dropped, the oldest first, because the pool was full. */
  dropped: number;
  /** Dots placed with `visible`, step dots included. */
  spawned: number;
  /** How long a dot takes along an edge without an entry in `setTravel`. */
  travelMs: number;
  constructor(capacity?: number, onSpawn?: SpawnListener | undefined);
  /** Dots placed and not yet arrived, those still to start included. */
  get size(): number;
  /**
   * Dots placed with `visible` and not yet arrived, those still to start included: what a frame
   * is for. Dots placed hidden (`DotEvery`) are in `size` and not here.
   */
  get visibleSize(): number;
  /**
   * The step dots: `next` maps an edge id to the steps that follow it (`chainOf`), `delayMs` gives
   * a step's stage time, read when the dot before it is spawned.
   */
  setChain(next: ReadonlyMap<string, readonly string[]>, delayMs: (edge: string) => number): void;
  /** Each edge's travel time (ms, by edge id); applies to the dots on their way too. */
  setTravel(travel: ReadonlyMap<string, number>): void;
  /**
   * A message on `edge` that starts at `atMs`. A message whose time is not a finite number gets
   * no dot and is not told to the listener: it could never arrive, so it would hold a slot until
   * the pool dropped it, and no rate window holds it. With `visible` false (a message that gets
   * no dot, see `DotEvery`) it is placed all the same, with its step dots, so the listener counts
   * it, but `advance` does not return it.
   */
  spawn(edge: string, atMs: number, bytes: number, colour?: number, visible?: boolean): void;
  /**
   * The dots on their way at `nowMs`, in the order they were placed (on one edge, the order they
   * started: the first is the furthest along); arrived ones are forgotten. Allocates nothing: the
   * array and its dots are the model's own, rewritten on the next call.
   */
  advance(nowMs: number): readonly Dot[];
  clear(): void;
  /** The ring position of the `k`th oldest dot. */
  private slot;
  /** The `n`th reused dot object, made the first time a frame holds that many. */
  private dotAt;
  private travelOf;
  private place;
}
/**
 * An edge drawn inside a block's drill-down whose dots no message feeds: they follow the dots that
 * enter the step's `from` side, timed by a measured stage. The layer's `steps` input maps an edge
 * id to one of these.
 */
interface NeatDiagramMessageStep {
  /** The node whose stage times this step (the id the app passes to `stageMs`). */
  readonly from: string;
  /** The stage of `from` whose time a dot waits before it starts along this step. */
  readonly stage: string;
  /**
   * How many steps share the stage's time, each taking an even part, when one measured stage spans
   * several steps one after another. Unset: this step takes the whole stage.
   */
  readonly shares?: number;
}
/**
 * Which steps follow each edge, by edge id: an edge (fed or a step) is followed by the steps that
 * leave the node it enters. Edges that lead to no step are not in the
 * map; a step whose id is not among `edges` (a stale config) is not followed.
 */
declare function chainOf(edges: readonly Pick<NeatDiagramEdge, 'id' | 'from' | 'to'>[], steps: Readonly<Record<string, NeatDiagramMessageStep>>): Map<string, string[]>;
/**
 * The most a batch may spread its messages over. A batch is messages the app received together
 * that happened over a short time (the demo's gateway sent one every 50 ms); a stalled source's
 * batch spreads no wider than this, so its dots do not trail behind for seconds.
 */
declare const BATCH_SPREAD_MS = 200;
/**
 * The start times of a batch's messages: the batch's arrival (`arrivalMs`) for its earliest
 * message, and the others after it as far apart as their own times (`offsetsMs`, on any clock in
 * ms) say, at most 200 ms. A message without a finite time of its own starts
 * at the arrival. For an app whose transport delivers messages in batches: pass each time as the
 * `atMs` of its `push`, with `performance.now()` as the arrival:
 *
 * ```ts
 * const at = neatBatchTimes(batch.map((m) => m.sourceMs), performance.now());
 * batch.forEach((m, i) => messages.push(m.edge, m.bytes, at[i]));
 * ```
 */
export declare function neatBatchTimes(offsetsMs: readonly number[], arrivalMs: number): number[];
/**
 * Which messages get a dot ("messages per dot", N): on each edge, every Nth message does, counted
 * per edge, so it is deterministic and one busy edge does not decide for the others. The first
 * message after a start or a change of N gets one, so a quiet edge shows a dot at once. The
 * messages in between still count in the rates (`DotModel.spawn` with `visible` false).
 */
declare class DotEvery {
  private every;
  private readonly seen;
  /** Sets N (a whole number, at least 1); a change starts every edge's count again. */
  set(n: number): void;
  /** Counts a message on `edge`; true when it gets a dot. */
  take(edge: string): boolean;
}
/** How the layer animates its dots: tuning only, the numbers count every message regardless. */
interface NeatDiagramMessageSettings {
  /** How fast a dot moves along any edge, in diagram units per second: a long edge takes longer. */
  readonly speed: number;
  /** A factor on each dot's radius (which grows with its message's size). */
  readonly size: number;
  /**
   * Messages per dot, a whole number: each edge shows a dot for every Nth message on it (1: every
   * message), so a busy edge shows gaps instead of a solid band.
   */
  readonly every: number;
  /** Whether dots go on through the blocks' steps (the layer's `steps`). */
  readonly steps: boolean;
}
/** The demo's settings: its median overview edge takes about 1.2 s at this speed. */
export declare const NEAT_DIAGRAM_MESSAGE_DEFAULTS: NeatDiagramMessageSettings;
/** An edge's messages and bytes per second over the last second, and its messages per second. */
interface NeatDiagramEdgeRate {
  readonly msgsPerSec: number;
  readonly bytesPerSec: number;
  /** Messages in each whole second before this one, oldest first, at most the last 60. */
  readonly history: readonly number[];
}
/** How long a message's mark shows at its edge's end under reduced motion. */
declare const MARK_MS = 400;
/**
 * The messages moving through a diagram, projected into it:
 *
 * ```html
 * <neat-diagram [diagram]="system" label="The demo's system">
 *   <neat-diagram-messages [steps]="steps" [settings]="settings()" />
 * </neat-diagram>
 * ```
 *
 * The app feeds it by id: `push(edgeId, bytes)` for each message on an edge, and
 * `stageMs(nodeId, stage, ms)` for the stage times its step dots take. A message on an edge drawn
 * now is a dot along it, sized by its bytes, as long on its way as the edge's length at `speed`
 * (every Nth message with `every`); its colour is its edge's (`colours` picks another series). A
 * step (`steps`, keyed by edge id) is an edge inside a block that no message feeds: a dot arriving
 * at its start goes on along it once the stage's time has passed, and so on along the chain, so the
 * dots inside a block follow its real input and its measured stages. The edges in `passive` (a
 * fed edge or a step) end their messages where they enter, starting no steps.
 *
 * `rate(edgeId)` is the edge's messages and bytes per second and its history, for the notes an app
 * fills (`rate(['a', 'b'])` their sum, for a note over several edges), refreshed at 12 Hz while
 * something reads it. A push counts on any edge of any level, drawn
 * or not, so a level opens with its numbers; the step edges are the exception, counted only while
 * their level is drawn and the page is visible, as it is their dots that count them. An id that is
 * no edge of the diagram is ignored, so the rates' memory stays bounded by the diagram's edges.
 *
 * At most 16 384 dots exist at once and the oldest are dropped past that, while the rates still
 * count every message: a burst (10 000 pushes in one tick) costs the cap's worth of dots, not
 * the burst's, so an app pushes each message as it arrives and does not sample or drop any to
 * protect the page.
 *
 * All dots are drawn on one canvas over the drawing, sized to this element's box (it fills the
 * diagram's), at the device's pixel ratio, scaled with the zoom and behind the cards; dots of
 * edges out of focus fade with them. The frames run only while a dot is on its way and stop while
 * the page is hidden (its messages then still count, without dots). Under reduced motion no dot
 * travels: each message shows as a brief mark at its edge's end.
 */
export declare class NeatDiagramMessages {
  /** The steps, keyed by edge id: whose stage times each and what follows it. */
  readonly steps: import("@angular/core").InputSignal<Readonly<Record<string, NeatDiagramMessageStep>>>;
  /**
   * Edges whose messages end where they enter, starting no step dots (a side input): fed edges
   * and steps alike.
   */
  readonly passive: import("@angular/core").InputSignal<readonly string[]>;
  /** A series (1 to 8) per edge id for its dots, in place of the edge's own colour. */
  readonly colours: import("@angular/core").InputSignal<Readonly<Record<string, number>>>;
  /**
   * How the dots animate: speed, size, messages per dot and whether they follow the steps. The
   * rates and counts do not depend on it. Defaults to `NEAT_DIAGRAM_MESSAGE_DEFAULTS`; give the
   * `neat-diagram-animation-settings` panel's model to let the user tune it.
   */
  readonly settings: import("@angular/core").InputSignal<NeatDiagramMessageSettings>;
  private readonly diagram;
  private readonly probe;
  private readonly host;
  private readonly document;
  private readonly zone;
  private readonly canvasElement;
  /** Read again on a scheme change, so the next frame paints the new colours. */
  private readonly theme;
  private readonly palette;
  /** Read by the canvas once it has a box to draw in: resolving the colours draws on a canvas. */
  private readonly readPalette;
  private readonly rates;
  /** The rates hear every dot placed, step dots and dots the pool drops included. */
  private readonly model;
  /** When the push under way was made, for the rates: its step dots start later than that. */
  private pushedAt;
  private readonly every;
  /** The latest stage times, by node and stage. */
  private readonly stages;
  /**
   * Under reduced motion, each drawn edge's latest message, shown at its end: by edge, and in a
   * list for the frames (an array's for-of is optimised away; a Map's iterator would be an object
   * per frame).
   */
  private readonly marks;
  private readonly markList;
  private marksUntil;
  /** Its `matches` is read at each frame, so a setting changed on an open page applies. */
  private readonly motion;
  private canvas;
  private frame;
  /** The latest time drawn for, so a frame never goes back. */
  private lastNow;
  private destroyed;
  /** What the model was last given: the level's key, its chain and travel times. */
  private levelKey;
  private chainGiven;
  private travelGiven;
  /** Ticks at 12 Hz while the rates are read (`rate`); each rate signal reads it. */
  private readonly numbers;
  private numbersTimer;
  /** Whether a rate signal was read since the last tick. */
  private numbersRead;
  private readonly rateSignals;
  /** Each drawn edge's shape, sampled once per layout (a new level value). */
  private readonly geometry;
  private readonly speed;
  private readonly travel;
  private readonly stepsOn;
  /** What follows each drawn edge: the steps leaving the node it enters, unless it is passive. */
  private readonly chain;
  private readonly edgeColours;
  constructor();
  /**
   * A message of `bytes` on `edgeId`, starting at `atMs` (on the `performance.now()` clock; now
   * by default, or a little later to spread a batch received together). Counted in the edge's
   * rate, and drawn as a dot while the edge is drawn (a push for a level not drawn only counts).
   * A size that is not a number counts as no bytes; an id that is no edge of the diagram is
   * ignored.
   */
  push(edgeId: string, bytes: number, atMs?: number): void;
  /**
   * The time `stage` of `nodeId` takes now, in ms: what a step dot timed by it waits before it
   * starts (`steps`). A time that is not a number, or below 0, forgets the stage's time.
   */
  stageMs(nodeId: string, stage: string, ms: number): void;
  /**
   * `edgeIds`' messages and bytes per second over the last second and their history, refreshed
   * at 12 Hz while something reads it (a template, an effect); the same signal for the same id or
   * list of ids. Several ids give the sum: the rates added, and the histories added second by
   * second from the newest, so an edge whose messages began later adds nothing before its first
   * second. An id twice counts once; an id that is no edge counts nothing.
   */
  rate(edgeIds: string | readonly string[]): Signal<NeatDiagramEdgeRate>;
  /**
   * Keeps the 12 Hz tick going while the rates are read. A tick nobody read since the last stops
   * it; the tick left the signals stale, so the next read computes afresh and starts it again.
   */
  private numbersWanted;
  /**
   * Gives the model what the level and the inputs say, when they have changed: another level
   * clears the dots (its edges are other edges), the chain and the travel times follow the
   * layout and the settings. Answers the drawn edges' shapes. Called by each push and frame, so
   * a push right after a change of level already goes by the new one.
   */
  private sync;
  /** A step's wait: its stage's latest time, split evenly over the steps that share it. */
  private readonly stageDelay;
  private mark;
  private clear;
  /** Read at each push and frame, so a setting changed on an open page applies. */
  private reduced;
  /**
   * Whether a dot or a mark still has to be drawn after `now`. Dots the model holds for the rates
   * only (messages without a dot, see `every`) draw nothing, so only its visible ones count. Under
   * reduced motion only marks are: the model's dots are placed all the same (the rates hear them,
   * step dots included), but nothing draws them, so they keep no frames running; the first frame
   * with motion again forgets those that have arrived since.
   */
  private busy;
  private cancel;
  /** A frame, unless one is coming, the page is hidden or the layer is gone. */
  private request;
  /** A new transform or box: drawn again in the next frame, if anything is on the canvas. */
  private readonly wake;
  private readonly visibility;
  private readonly tick;
  /** This frame's dots or marks; null while there is nothing to draw on. */
  private draw;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramMessages, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramMessages, "neat-diagram-messages", never, {
    "steps": {
      "alias": "steps";
      "required": false;
      "isSignal": true;
    };
    "passive": {
      "alias": "passive";
      "required": false;
      "isSignal": true;
    };
    "colours": {
      "alias": "colours";
      "required": false;
      "isSignal": true;
    };
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * `raw` as settings: the known keys of the right type, the numbers clamped to the sliders' range
 * (`every` rounded to a whole number), and the defaults for the rest. For the parse of an app's
 * `neatStoredSignal`, which gets whatever an older version wrote:
 *
 * ```ts
 * readonly settings = neatStoredSignal('app.dots', NEAT_DIAGRAM_MESSAGE_DEFAULTS,
 *   neatParseMessageSettings);
 * ```
 */
export declare function neatParseMessageSettings(raw: unknown): NeatDiagramMessageSettings;
/**
 * The Animation panel for `neat-diagram-messages`: an icon button that opens sliders for the
 * dots' speed, size and messages per dot, a switch for the dots through the blocks' steps, and a
 * reset to the defaults:
 *
 * ```html
 * <neat-diagram-animation-settings [(settings)]="dots" />
 * <neat-diagram-messages [settings]="dots()" />
 * ```
 *
 * `settings` is the model both ways, and changes apply as the sliders move. The panel keeps
 * nothing: an app that remembers the choice per browser makes the model a `neatStoredSignal`
 * (parsed by `neatParseMessageSettings`). Place it in a toolbar or beside the diagram.
 */
export declare class NeatDiagramAnimationSettings {
  /** The dots' tuning; what the sliders and the switch write, and the layer's `settings`. */
  readonly settings: import("@angular/core").ModelSignal<NeatDiagramMessageSettings>;
  protected readonly limits: {
    readonly speed: {
      readonly min: 50;
      readonly max: 1000;
      readonly step: 10;
    };
    readonly size: {
      readonly min: 0.5;
      readonly max: 2;
      readonly step: 0.1;
    };
    readonly every: {
      readonly min: 1;
      readonly max: 10;
      readonly step: 1;
    };
  };
  protected readonly defaults: NeatDiagramMessageSettings;
  protected set(change: Partial<NeatDiagramMessageSettings>): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramAnimationSettings, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramAnimationSettings, "neat-diagram-animation-settings", never, {
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
  }, {
    "settings": "settingsChange";
  }, never, never, true, never>;
}
/**
 * An edge's live numbers, for a note of the diagram:
 *
 * ```html
 * <ng-template neatDiagramNote let-note>
 *   <neat-diagram-rate-card label="Tracker → Gateway" [rate]="messages.rate('tracker-gateway')()"
 *   />
 * </ng-template>
 * ```
 *
 * `showBytes` false leaves the megabytes out, for an app that pushes no sizes (its messages all
 * count 0 bytes, which would read "0.00 MB/s"); the messages and the sparkline stay.
 *
 * Give it `rate(['a', 'b'])` for a note over several edges: the card shows their sum. It shows the
 * label, the messages per second (whole) and the megabytes per second (two decimals,
 * from the bytes in units of 10 kB), and the history as a sparkline named for its messages per
 * second. `stageMs`, a block step's stage time, swaps the megabytes and the sparkline for the time
 * in milliseconds to a tenth: the dots of a step are made up, so they have no sizes. Anything an
 * app wants between the label and the numbers (the latest image of a camera, say) goes in the
 * `[neatRateCardThumbnails]` slot, which the app lays out itself.
 *
 * The note supplies the card's box (its border, fill and padding), so the card has none; its
 * content is 11.5 rem wide, or as wide as its stage line needs when it shows one. The stage line
 * says "Stage"; an app that wants the stage's name in it puts the name in `label`.
 */
export declare class NeatDiagramRateCard {
  /** What the numbers are of: the edge's or the step's name. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The edge's rate, or the sum over several: `NeatDiagramMessages.rate(edgeIds)`'s value. */
  readonly rate: import("@angular/core").InputSignal<NeatDiagramEdgeRate>;
  /**
   * The stage time of a step, in ms: the card then shows it in place of the megabytes and the
   * sparkline. A value that is not a number, or below 0, is no stage time.
   */
  readonly stageMs: import("@angular/core").InputSignal<number | undefined>;
  /**
   * Whether the megabytes per second show. False for an app that pushes no sizes, so the card
   * does not say "0.00 MB/s". A step's stage time shows in place of the megabytes either way.
   */
  readonly showBytes: import("@angular/core").InputSignal<boolean>;
  protected readonly perSecond: (value: number) => string;
  protected readonly msgs: import("@angular/core").Signal<string>;
  /** Bytes per second as megabytes, in hundredths: units of 10 kB, as the demo shows them. */
  protected readonly megabytes: import("@angular/core").Signal<string>;
  /** The stage time as shown, or null while the card has none. */
  protected readonly stage: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramRateCard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramRateCard, "neat-diagram-rate-card", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "rate": {
      "alias": "rate";
      "required": true;
      "isSignal": true;
    };
    "stageMs": {
      "alias": "stageMs";
      "required": false;
      "isSignal": true;
    };
    "showBytes": {
      "alias": "showBytes";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[neatRateCardThumbnails]"], true, never>;
}
export type { NeatDiagram, NeatDiagramChip, NeatDiagramEdge, NeatDiagramEdgeRate, NeatDiagramHighlight, NeatDiagramLegendItem, NeatDiagramLine, NeatDiagramLook, NeatDiagramMessageSettings, NeatDiagramMessageStep, NeatDiagramNode, NeatDiagramNote, NeatDiagramRole, NeatDiagramSet, NeatDiagramSide, NeatDiagramTip };