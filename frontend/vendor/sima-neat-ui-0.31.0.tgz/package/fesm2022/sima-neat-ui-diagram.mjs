import { NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, Directive, ElementRef, Injectable, InjectionToken, Injector, NgZone, TemplateRef, afterNextRender, afterRenderEffect, computed, contentChild, effect, inject, input, isDevMode, model, signal, untracked, viewChild } from "@angular/core";
import { NeatBreadcrumbs, NeatButton, NeatIcon, NeatSeriesSwatch, neatThemeColors, ɵSTALE_CLASSES, ɵseriesToken, ɵseriesTokenName } from "@sima/neat-ui";
import { NeatStatusChip } from "@sima/neat-ui/status-chip";
import { select } from "d3-selection";
import { zoom, zoomIdentity, zoomTransform } from "d3-zoom";
import { NeatPopover, NeatPopoverContent, NeatPopoverTrigger } from "@sima/neat-ui/popover";
import { NeatSlider } from "@sima/neat-ui/slider";
import { NeatSwitch } from "@sima/neat-ui/switch";
import { NeatSparkline } from "@sima/neat-ui/charts";
const reported = /* @__PURE__ */ new Set();
function reportLeftOut(problem) {
	if (!isDevMode() || reported.has(problem)) return;
	reported.add(problem);
	console.error(`neat-diagram: ${problem}`);
}
function firstOfEachId(parts, kind) {
	const seen = /* @__PURE__ */ new Set();
	return parts.filter((part) => {
		if (!seen.has(part.id)) {
			seen.add(part.id);
			return true;
		}
		reportLeftOut(`${kind} "${part.id}" is left out: an earlier ${kind} has the same id`);
		return false;
	});
}
const BEND = 60;
const STUB = 30;
const OUT = {
	left: {
		x: -1,
		y: 0
	},
	right: {
		x: 1,
		y: 0
	},
	top: {
		x: 0,
		y: -1
	},
	bottom: {
		x: 0,
		y: 1
	}
};
const sub = (a, b) => ({
	x: a.x - b.x,
	y: a.y - b.y
});
const dot$1 = (a, b) => a.x * b.x + a.y * b.y;
const length = (a) => Math.hypot(a.x, a.y);
function routePoints(source, sourceSide, target, targetSide, jog = 0) {
	const out = OUT[sourceSide];
	const back = OUT[targetSide];
	const horizontal = out.x !== 0;
	const ahead = (corner) => dot$1(sub(corner, source), out) > 0 && dot$1(sub(corner, target), back) > 0;
	if (dot$1(out, back) === 0) {
		const corner = horizontal ? {
			x: target.x,
			y: source.y
		} : {
			x: source.x,
			y: target.y
		};
		if (ahead(corner)) return [
			source,
			corner,
			target
		];
	} else if (dot$1(out, back) < 0 && dot$1(sub(target, source), out) > 0) {
		if (horizontal ? source.y === target.y : source.x === target.x) return [source, target];
		if (horizontal) {
			const x = (source.x + target.x) / 2 + jog * out.x;
			return [
				source,
				{
					x,
					y: source.y
				},
				{
					x,
					y: target.y
				},
				target
			];
		}
		const y = (source.y + target.y) / 2 + jog * out.y;
		return [
			source,
			{
				x: source.x,
				y
			},
			{
				x: target.x,
				y
			},
			target
		];
	} else if (dot$1(out, back) > 0) {
		if (horizontal) {
			const x = out.x > 0 ? Math.max(source.x, target.x) + STUB : Math.min(source.x, target.x) - STUB;
			return [
				source,
				{
					x,
					y: source.y
				},
				{
					x,
					y: target.y
				},
				target
			];
		}
		const y = out.y > 0 ? Math.max(source.y, target.y) + STUB : Math.min(source.y, target.y) - STUB;
		return [
			source,
			{
				x: source.x,
				y
			},
			{
				x: target.x,
				y
			},
			target
		];
	}
	const a = {
		x: source.x + out.x * STUB,
		y: source.y + out.y * STUB
	};
	const b = {
		x: target.x + back.x * STUB,
		y: target.y + back.y * STUB
	};
	if (dot$1(out, back) === 0) return simplify([
		source,
		a,
		horizontal ? {
			x: a.x,
			y: b.y
		} : {
			x: b.x,
			y: a.y
		},
		b,
		target
	]);
	return simplify([
		source,
		a,
		...horizontal ? [{
			x: a.x,
			y: (a.y + b.y) / 2
		}, {
			x: b.x,
			y: (a.y + b.y) / 2
		}] : [{
			x: (a.x + b.x) / 2,
			y: a.y
		}, {
			x: (a.x + b.x) / 2,
			y: b.y
		}],
		b,
		target
	]);
}
function simplify(points) {
	const kept = [];
	for (const p of points) {
		const last = kept[kept.length - 1];
		if (last && last.x === p.x && last.y === p.y) continue;
		const before = kept[kept.length - 2];
		if (before && last) {
			const d1 = sub(last, before);
			const d2 = sub(p, last);
			if (d1.x * d2.y - d1.y * d2.x === 0 && dot$1(d1, d2) > 0) kept.pop();
		}
		kept.push(p);
	}
	return kept;
}
const same = (a, b) => Math.abs(a.x - b.x) < 1e-6 && Math.abs(a.y - b.y) < 1e-6;
const endOf = (p) => "line" in p ? p.line : p.curve[2];
function roundCorners(points, bend = BEND) {
	const pieces = [];
	const last = points.length - 1;
	for (let i = 1; i < last; i++) {
		const corner = points[i];
		const inRun = sub(corner, points[i - 1]);
		const outRun = sub(points[i + 1], corner);
		const inLength = length(inRun) / (i - 1 > 0 ? 2 : 1);
		const outLength = length(outRun) / (i + 1 < last ? 2 : 1);
		const leg = Math.min(bend, inLength, outLength);
		const into = length(inRun);
		const away = length(outRun);
		const start = {
			x: corner.x - inRun.x / into * leg,
			y: corner.y - inRun.y / into * leg
		};
		const end = {
			x: corner.x + outRun.x / away * leg,
			y: corner.y + outRun.y / away * leg
		};
		pieces.push({ line: start }, { curve: [
			corner,
			corner,
			end
		] });
	}
	pieces.push({ line: points[last] });
	return pieces.filter((p, i) => !("line" in p) || !same(p.line, i === 0 ? points[0] : endOf(pieces[i - 1])));
}
const n$1 = (v) => Math.round(v * 100) / 100;
function pathThrough(points) {
	const [start] = points;
	let d = `M ${n$1(start.x)} ${n$1(start.y)}`;
	for (const piece of roundCorners(points)) if ("line" in piece) d += ` L ${n$1(piece.line.x)} ${n$1(piece.line.y)}`;
	else d += ` C ${piece.curve.map((p) => `${n$1(p.x)} ${n$1(p.y)}`).join(" ")}`;
	return d;
}
function sampleRoute(start, pieces, steps = 12) {
	const points = [start];
	let at = start;
	for (const piece of pieces) {
		if ("line" in piece) {
			points.push(piece.line);
			at = piece.line;
			continue;
		}
		const [c1, c2, to] = piece.curve;
		for (let k = 1; k <= steps; k++) {
			const t = k / steps;
			const u = 1 - t;
			const w = [
				u * u * u,
				3 * u * u * t,
				3 * u * t * t,
				t * t * t
			];
			points.push({
				x: w[0] * at.x + w[1] * c1.x + w[2] * c2.x + w[3] * to.x,
				y: w[0] * at.y + w[1] * c1.y + w[2] * c2.y + w[3] * to.y
			});
		}
		at = to;
	}
	return points;
}
function pointAlong(points, t) {
	const drawn = sampleRoute(points[0], roundCorners(points));
	const runs = drawn.slice(1).map((p, i) => length(sub(p, drawn[i])));
	let left = Math.min(Math.max(t, 0), 1) * runs.reduce((sum, run) => sum + run, 0);
	for (let i = 0; i < runs.length; i++) {
		if (left <= runs[i] && runs[i] > 0) {
			const f = left / runs[i];
			const a = drawn[i];
			const b = drawn[i + 1];
			return {
				x: a.x + (b.x - a.x) * f,
				y: a.y + (b.y - a.y) * f
			};
		}
		left -= runs[i];
	}
	return drawn[drawn.length - 1];
}
function absoluteRects(diagram) {
	const nodes = firstOfEachId(diagram.nodes, "node");
	const byId = new Map(nodes.map((node) => [node.id, node]));
	const corners = /* @__PURE__ */ new Map();
	const corner = (node, chain) => {
		const known = corners.get(node.id);
		if (known !== void 0) return known;
		const parent = node.parent === void 0 ? void 0 : byId.get(node.parent);
		let at = null;
		if (node.parent === void 0) at = {
			x: node.x,
			y: node.y
		};
		else if (!parent) reportLeftOut(`node "${node.id}" is left out: its parent "${node.parent}" is not on its level`);
		else if (chain.has(parent.id)) reportLeftOut(`node "${node.id}" is left out: its parent "${parent.id}" lies inside it`);
		else {
			const origin = corner(parent, new Set(chain).add(parent.id));
			at = origin && {
				x: origin.x + node.x,
				y: origin.y + node.y
			};
		}
		corners.set(node.id, at);
		return at;
	};
	const rects = /* @__PURE__ */ new Map();
	for (const node of nodes) {
		const at = corner(node, /* @__PURE__ */ new Set([node.id]));
		if (at) rects.set(node.id, {
			...at,
			w: node.w,
			h: node.h
		});
	}
	return rects;
}
const SIDE_AXES = {
	left: {
		t: {
			x: 0,
			y: 1
		},
		n: {
			x: -1,
			y: 0
		}
	},
	right: {
		t: {
			x: 0,
			y: 1
		},
		n: {
			x: 1,
			y: 0
		}
	},
	top: {
		t: {
			x: 1,
			y: 0
		},
		n: {
			x: 0,
			y: -1
		}
	},
	bottom: {
		t: {
			x: 1,
			y: 0
		},
		n: {
			x: 0,
			y: 1
		}
	}
};
const OPPOSITE = {
	left: "right",
	right: "left",
	top: "bottom",
	bottom: "top"
};
const dot = (a, b) => a.x * b.x + a.y * b.y;
const horizontal = (side) => side === "left" || side === "right";
const PORT_STEP = 10;
const PORT_SPAN = .8;
const JOG_STEP = 24;
function layoutEdges(diagram) {
	const rects = absoluteRects(diagram);
	const nodes = new Map(firstOfEachId(diagram.nodes, "node").map((node) => [node.id, node]));
	const edges = firstOfEachId(diagram.edges, "edge").filter((edge) => {
		const missing = [edge.from, edge.to].filter((id) => !rects.has(id));
		for (const id of missing) {
			const why = nodes.has(id) ? "is left out itself" : "is not on its level";
			reportLeftOut(`edge "${edge.id}" is left out: its end "${id}" ${why}`);
		}
		return missing.length === 0;
	});
	const rectOf = (id) => rects.get(id);
	const centre = (id) => {
		const r = rectOf(id);
		return {
			x: r.x + r.w / 2,
			y: r.y + r.h / 2
		};
	};
	const holds = (outer, inner) => {
		let parent = nodes.get(inner)?.parent;
		for (let steps = 0; parent !== void 0 && steps < nodes.size; steps++) {
			if (parent === outer) return true;
			parent = nodes.get(parent)?.parent;
		}
		return false;
	};
	const ends = edges.map((edge, order) => {
		const a = centre(edge.from);
		const b = centre(edge.to);
		const frame = holds(edge.from, edge.to) ? edge.from : holds(edge.to, edge.from) ? edge.to : null;
		const inward = frame === null ? null : frame === edge.from ? "source" : "target";
		const border = frame === null ? null : nearestBorder(rectOf(frame), rectOf(frame === edge.from ? edge.to : edge.from));
		const [out, into] = border === null ? facingSides(a, b) : [border, border];
		const along = {
			x: b.x - a.x,
			y: b.y - a.y
		};
		return {
			edge,
			source: {
				node: edge.from,
				side: inward === "source" ? out : edge.fromSide ?? nodes.get(edge.from)?.outSide ?? out,
				offset: 0,
				along,
				sign: 1,
				order
			},
			target: {
				node: edge.to,
				side: inward === "target" ? into : edge.toSide ?? nodes.get(edge.to)?.inSide ?? into,
				offset: 0,
				along,
				sign: -1,
				order
			},
			inward
		};
	});
	spreadPorts(ends.flatMap((e) => [e.source, e.target]), rects);
	const routes = ends.map(({ edge, source, target, inward }) => ({
		edge,
		source: portPoint(rectOf(source.node), source),
		sourceSide: inward === "source" ? OPPOSITE[source.side] : source.side,
		target: portPoint(rectOf(target.node), target),
		targetSide: inward === "target" ? OPPOSITE[target.side] : target.side,
		jog: 0
	}));
	spreadCorridors(routes);
	return new Map(routes.map(({ edge, source, sourceSide, target, targetSide, jog }) => {
		const points = routePoints(source, sourceSide, target, targetSide, jog);
		const path = pathThrough(points);
		return [edge.id, {
			source,
			sourceSide,
			target,
			targetSide,
			path,
			points
		}];
	}));
}
function spreadPorts(ends, rects) {
	const sides = /* @__PURE__ */ new Map();
	for (const end of ends) {
		const key = `${end.node}\u0000${end.side}`;
		sides.set(key, [...sides.get(key) ?? [], end]);
	}
	for (const onSide of sides.values()) {
		const { node, side } = onSide[0];
		const { t, n } = SIDE_AXES[side];
		const angle = (e) => Math.atan2(e.sign * dot(e.along, t), e.sign * dot(e.along, n));
		const tie = (e) => e.order * Math.sign(t.x * -e.along.y + t.y * e.along.x || 1);
		onSide.sort((p, q) => angle(p) - angle(q) || tie(p) - tie(q));
		const rect = rects.get(node);
		const length = horizontal(side) ? rect.h : rect.w;
		const step = onSide.length > 1 ? Math.min(PORT_STEP, length * PORT_SPAN / (onSide.length - 1)) : 0;
		onSide.forEach((e, i) => e.offset = (i - (onSide.length - 1) / 2) * step);
	}
}
function facingSides(a, b) {
	const dx = b.x - a.x;
	const dy = b.y - a.y;
	if (Math.abs(dx) >= Math.abs(dy) / 2) return dx >= 0 ? ["right", "left"] : ["left", "right"];
	return dy >= 0 ? ["bottom", "top"] : ["top", "bottom"];
}
function nearestBorder(outer, inner) {
	return [
		["bottom", outer.y + outer.h - (inner.y + inner.h)],
		["left", inner.x - outer.x],
		["right", outer.x + outer.w - (inner.x + inner.w)],
		["top", inner.y - outer.y]
	].reduce((best, side) => side[1] < best[1] ? side : best)[0];
}
function portPoint(rect, { side, offset }) {
	switch (side) {
		case "left": return {
			x: rect.x,
			y: rect.y + rect.h / 2 + offset
		};
		case "right": return {
			x: rect.x + rect.w,
			y: rect.y + rect.h / 2 + offset
		};
		case "top": return {
			x: rect.x + rect.w / 2 + offset,
			y: rect.y
		};
		case "bottom": return {
			x: rect.x + rect.w / 2 + offset,
			y: rect.y + rect.h
		};
	}
}
function spreadCorridors(routes) {
	const corridor = /* @__PURE__ */ new Map();
	const root = (route) => {
		let r = route;
		while (corridor.get(r) !== r) r = corridor.get(r);
		return r;
	};
	const bySide = /* @__PURE__ */ new Map();
	for (const route of routes) {
		if (!isZ(route)) continue;
		corridor.set(route, route);
		const { from, to } = route.edge;
		for (const key of [`${from}\u0000${route.sourceSide}`, `${to}\u0000${route.targetSide}`]) {
			const other = bySide.get(key);
			if (other === void 0) bySide.set(key, route);
			else corridor.set(root(route), root(other));
		}
	}
	const groups = /* @__PURE__ */ new Map();
	for (const route of corridor.keys()) groups.set(root(route), [...groups.get(root(route)) ?? [], route]);
	for (const list of groups.values()) {
		if (list.length < 2) continue;
		const across = (r) => horizontal(r.sourceSide) ? "y" : "x";
		const along = (r) => horizontal(r.sourceSide) ? "x" : "y";
		const key = (r) => r.source[across(r)] * Math.sign(r.target[across(r)] - r.source[across(r)]);
		const room = Math.min(...list.map((r) => Math.abs(r.target[along(r)] - r.source[along(r)])));
		const step = Math.min(JOG_STEP, room / (2 * (list.length + 1)));
		list.sort((p, q) => key(q) - key(p));
		list.forEach((r, i) => r.jog = (i - (list.length - 1) / 2) * step);
	}
}
function isZ(r) {
	if (OPPOSITE[r.sourceSide] !== r.targetSide) return false;
	const n = SIDE_AXES[r.sourceSide].n;
	const ahead = dot({
		x: r.target.x - r.source.x,
		y: r.target.y - r.source.y
	}, n) > 0;
	const level = horizontal(r.sourceSide) ? r.source.y === r.target.y : r.source.x === r.target.x;
	return ahead && !level;
}
const ARROW_LENGTH = 6;
const ARROW_HALF_WIDTH = 3;
const DOT_RADIUS = 3;
const MUTED_TOKEN = "--muted-foreground";
const MUTED = `var(${MUTED_TOKEN})`;
function drawLevel(diagram, levels) {
	const rects = absoluteRects(diagram);
	const nodes = firstOfEachId(diagram.nodes, "node").filter((node) => rects.has(node.id));
	const byId = new Map(nodes.map((node) => [node.id, node]));
	const depth = (node) => {
		const parent = node.parent === void 0 ? void 0 : byId.get(node.parent);
		return parent ? depth(parent) + 1 : 0;
	};
	const drawn = nodes.map((node) => drawNode(node, rects.get(node.id), levels));
	const behind = drawn.filter(({ node }) => node.role === "frame" || node.role === "band").map((part, order) => ({
		part,
		order,
		depth: depth(part.node)
	})).sort((a, b) => a.depth - b.depth || a.order - b.order).map(({ part }) => part);
	const front = drawn.filter(({ node }) => node.role === "block" || node.role === "bracket");
	const layouts = layoutEdges(diagram);
	return {
		behind,
		front,
		edges: firstOfEachId(diagram.edges, "edge").flatMap((edge) => {
			const layout = layouts.get(edge.id);
			return layout ? [drawEdge(edge, layout)] : [];
		}),
		layouts
	};
}
function drawNode(node, rect, levels) {
	let opens = false;
	if (node.role === "block" && node.opens !== void 0) {
		opens = levels.has(node.opens);
		if (!opens) reportLeftOut(`block "${node.id}" is drawn without its open control: "${node.opens}" is not a level`);
	}
	return {
		node,
		rect,
		look: node.look ?? "default",
		opens,
		brace: node.role === "bracket" ? bracePath(rect.w) : null
	};
}
function bracePath(w) {
	const h = 18;
	const r = h / 2 - 1;
	const m = w / 2;
	const mid = h / 2;
	return `M 1 1 Q 1 ${mid} 9 ${mid} L ${m - r} ${mid} Q ${m} ${mid} ${m} 17 Q ${m} ${mid} ${m + r} ${mid} L ${w - 1 - r} ${mid} Q ${w - 1} ${mid} ${w - 1} 1`;
}
function drawEdge(edge, layout) {
	const tips = [tip(edge.start ?? "none", "start", layout.source, layout.sourceSide), tip(edge.end ?? "arrow", "end", layout.target, layout.targetSide)].filter((t) => t !== null);
	return {
		id: edge.id,
		edge,
		path: layout.path,
		points: layout.points,
		colour: lineColour(edge.series, edge.line, `edge "${edge.id}"`),
		line: edge.line ?? "solid",
		tips,
		label: edge.label === void 0 ? null : {
			text: edge.label,
			at: pointAlong(layout.points, edge.labelAt ?? .5)
		}
	};
}
function lineColour(series, line, part) {
	if (series === void 0 || line === "ghost") return MUTED;
	const index = seriesIndex(series, part);
	return index === null ? MUTED : ɵseriesToken(index);
}
function seriesIndex(series, part) {
	if (Number.isInteger(series) && series >= 1 && series <= 8) return series - 1;
	reportLeftOut(`${part} is drawn in the muted colour: its series ${series} is not 1 to 8`);
	return null;
}
function describeLevel(level) {
	const drawnNodes = [...level.behind, ...level.front].map(({ node }) => node);
	const labels = new Map(drawnNodes.map((node) => [node.id, node.label]));
	const words = (...parts) => parts.filter((part) => part !== void 0 && part !== "").join(", ");
	return {
		nodes: drawnNodes.map((node) => ({
			id: node.id,
			text: words(node.label, node.detail, ...(node.chips ?? []).map((chip) => chip.label), node.stale ? "stale" : void 0)
		})),
		edges: level.edges.map(({ id, edge }) => ({
			id,
			text: words(`${labels.get(edge.from)} to ${labels.get(edge.to)}`, edge.label)
		}))
	};
}
const n = (v) => Math.round(v * 100) / 100;
function tip(kind, end, port, side) {
	const { t, n: out } = SIDE_AXES[side];
	if (kind === "dot") return {
		end,
		shape: "dot",
		cx: n(port.x + out.x * DOT_RADIUS),
		cy: n(port.y + out.y * DOT_RADIUS),
		r: DOT_RADIUS
	};
	if (kind !== "arrow") return null;
	const base = {
		x: port.x + out.x * ARROW_LENGTH,
		y: port.y + out.y * ARROW_LENGTH
	};
	const a = {
		x: base.x + t.x * ARROW_HALF_WIDTH,
		y: base.y + t.y * ARROW_HALF_WIDTH
	};
	const b = {
		x: base.x - t.x * ARROW_HALF_WIDTH,
		y: base.y - t.y * ARROW_HALF_WIDTH
	};
	return {
		end,
		shape: "arrow",
		d: `M ${n(port.x)} ${n(port.y)} L ${n(a.x)} ${n(a.y)} L ${n(b.x)} ${n(b.y)} Z`
	};
}
const ZOOM_LIMITS = [.2, 3];
function fitTransform(bounds, box, margin = 24, limits = ZOOM_LIMITS) {
	if (box.w <= 0 || box.h <= 0) return null;
	const scale = (room, length) => length > 0 ? Math.max(room, 0) / length : Infinity;
	const fits = Math.min(scale(box.w - 2 * margin, bounds.w), scale(box.h - 2 * margin, bounds.h));
	const k = Math.min(Math.max(fits, limits[0]), limits[1]);
	return {
		k,
		x: box.w / 2 - k * (bounds.x + bounds.w / 2),
		y: box.h / 2 - k * (bounds.y + bounds.h / 2)
	};
}
function levelExtent(level, notes) {
	let x0 = Infinity;
	let y0 = Infinity;
	let x1 = -Infinity;
	let y1 = -Infinity;
	const take = (x, y, w = 0, h = 0) => {
		x0 = Math.min(x0, x);
		y0 = Math.min(y0, y);
		x1 = Math.max(x1, x + w);
		y1 = Math.max(y1, y + h);
	};
	for (const { rect } of [...level.behind, ...level.front]) take(rect.x, rect.y, rect.w, rect.h);
	for (const { points } of level.layouts.values()) for (const p of points) take(p.x, p.y);
	for (const box of notes) take(box.x, box.y, box.w, box.h);
	return x0 === Infinity ? null : {
		x: x0,
		y: y0,
		w: x1 - x0,
		h: y1 - y0
	};
}
function highlighted(focus, highlight) {
	if (highlight === "all") return focus;
	return highlight === "edges" && focus?.kind === "edge" ? focus : null;
}
function focusedParts(level, focus) {
	if (!focus) return null;
	const nodes = /* @__PURE__ */ new Set();
	const edges = /* @__PURE__ */ new Set();
	if (focus.kind === "block") {
		nodes.add(focus.id);
		for (const edge of level.edges) if (edge.from === focus.id || edge.to === focus.id) edges.add(edge.id);
	} else {
		edges.add(focus.id);
		const edge = level.edges.find((e) => e.id === focus.id);
		if (edge) nodes.add(edge.from).add(edge.to);
	}
	return {
		nodes,
		edges,
		notes: new Set((level.notes ?? []).filter((note) => note.edges?.some((id) => edges.has(id))).map((note) => note.id))
	};
}
function placeTip(at, size, box) {
	const axis = (p, length, room) => {
		const after = p + 14;
		if (after + length <= room) return after;
		const before = p - 14 - length;
		if (before >= 0) return before;
		return Math.max(0, Math.min(after, room - length));
	};
	return {
		left: axis(at.x, size.w, box.w),
		top: axis(at.y, size.h, box.h)
	};
}
const sameFocus = (a, b) => a?.kind === b?.kind && a?.id === b?.id;
var DiagramHover = class {
	box;
	tip;
	pointer = signal(null, {
		...ngDevMode ? { debugName: "pointer" } : /* istanbul ignore next */ {},
		equal: sameFocus
	});
	keyboard = signal(null, ...ngDevMode ? [{ debugName: "keyboard" }] : /* istanbul ignore next */ []);
	at = {
		x: 0,
		y: 0
	};
	focus = computed(() => {
		const block = this.keyboard();
		return this.pointer() ?? (block === null ? null : {
			kind: "block",
			id: block
		});
	}, ...ngDevMode ? [{ debugName: "focus" }] : /* istanbul ignore next */ []);
	tipEdge = computed(() => {
		const focus = this.pointer();
		return focus?.kind === "edge" ? focus.id : null;
	}, ...ngDevMode ? [{ debugName: "tipEdge" }] : /* istanbul ignore next */ []);
	constructor(box, tip) {
		this.box = box;
		this.tip = tip;
		box.addEventListener("pointerover", this.over, { passive: true });
		box.addEventListener("pointermove", this.over, { passive: true });
		box.addEventListener("pointerleave", this.leave);
		box.addEventListener("focusin", this.focusIn);
		box.addEventListener("focusout", this.focusOut);
	}
	place() {
		const tip = this.tip();
		if (!tip) return;
		const size = {
			w: tip.offsetWidth,
			h: tip.offsetHeight
		};
		const { left, top } = placeTip(this.at, size, {
			w: this.box.clientWidth,
			h: this.box.clientHeight
		});
		tip.style.left = `${left}px`;
		tip.style.top = `${top}px`;
	}
	clear() {
		this.pointer.set(null);
		this.keyboard.set(null);
	}
	destroy() {
		this.box.removeEventListener("pointerover", this.over);
		this.box.removeEventListener("pointermove", this.over);
		this.box.removeEventListener("pointerleave", this.leave);
		this.box.removeEventListener("focusin", this.focusIn);
		this.box.removeEventListener("focusout", this.focusOut);
	}
	over = (event) => {
		if (event.pointerType === "touch" || event.buttons !== 0) return this.leave();
		const target = event.target instanceof Element ? event.target : null;
		const edge = this.inBox(target?.closest("[data-edge]"))?.getAttribute("data-edge");
		if (edge) {
			const corner = this.box.getBoundingClientRect();
			this.at = {
				x: event.clientX - corner.left - this.box.clientLeft,
				y: event.clientY - corner.top - this.box.clientTop
			};
			this.pointer.set({
				kind: "edge",
				id: edge
			});
			this.place();
			return;
		}
		const block = this.inBox(target?.closest(".block[data-node]"))?.getAttribute("data-node");
		this.pointer.set(block ? {
			kind: "block",
			id: block
		} : null);
	};
	leave = () => this.pointer.set(null);
	focusIn = (event) => {
		const target = event.target instanceof Element ? event.target : null;
		const keyboard = target?.matches(".block[data-node]:focus-visible");
		this.keyboard.set(keyboard ? target.getAttribute("data-node") : null);
	};
	focusOut = () => this.keyboard.set(null);
	inBox(element) {
		return element && element !== this.box && this.box.contains(element) ? element : null;
	}
};
function walkLevels(set, asked) {
	const path = [];
	const openers = [];
	let shown = set.overview;
	for (const id of asked) {
		const next = set.levels && Object.hasOwn(set.levels, id) ? set.levels[id] : void 0;
		const opener = shown.nodes.find((node) => node.role === "block" && node.opens === id);
		if (!next || !opener) break;
		path.push(id);
		openers.push(opener);
		shown = next;
	}
	return {
		path,
		openers,
		shown
	};
}
function samePath(a, b) {
	return a.length === b.length && a.every((id, i) => id === b[i]);
}
const IDENTITY_TRANSFORM = Object.freeze({
	k: 1,
	x: 0,
	y: 0
});
const DIAGRAM_MESSAGES_CONTEXT = new InjectionToken("the diagram neat-diagram-messages draws over");
var DiagramMessagesSlot = class DiagramMessagesSlot {
	context = null;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DiagramMessagesSlot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DiagramMessagesSlot
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DiagramMessagesSlot,
	decorators: [{ type: Injectable }]
});
function provideDiagramMessagesContext() {
	return [DiagramMessagesSlot, {
		provide: DIAGRAM_MESSAGES_CONTEXT,
		useFactory: () => inject(DiagramMessagesSlot).context
	}];
}
const DOT_FRAME_PROBE = new InjectionToken("DOT_FRAME_PROBE");
var NoteSizes = class NoteSizes {
	measured = signal(/* @__PURE__ */ new Map(), ...ngDevMode ? [{ debugName: "measured" }] : /* istanbul ignore next */ []);
	sizes = this.measured.asReadonly();
	ids = /* @__PURE__ */ new Map();
	zone = inject(NgZone);
	observer = null;
	observe(box, id) {
		this.ids.set(box, id);
		this.observer ??= this.zone.runOutsideAngular(() => new ResizeObserver((entries) => this.read(entries)));
		this.observer.observe(box, { box: "border-box" });
	}
	unobserve(box) {
		const id = this.ids.get(box);
		this.ids.delete(box);
		this.observer?.unobserve(box);
		if (id !== void 0) this.write([[id, null]]);
	}
	ngOnDestroy() {
		this.observer?.disconnect();
	}
	read(entries) {
		this.write(entries.flatMap((entry) => {
			const id = this.ids.get(entry.target);
			return id === void 0 ? [] : [[id, sizeOf(entry)]];
		}));
	}
	write(changes) {
		let next = null;
		for (const [id, size] of changes) {
			const known = (next ?? this.measured()).get(id);
			if (known?.w === size?.w && known?.h === size?.h) continue;
			next ??= new Map(this.measured());
			if (size) next.set(id, size);
			else next.delete(id);
		}
		if (next) this.measured.set(next);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NoteSizes,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NoteSizes
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NoteSizes,
	decorators: [{ type: Injectable }]
});
function sizeOf(entry) {
	const [border] = entry.borderBoxSize ?? [];
	if (!border || border.inlineSize <= 0 || border.blockSize <= 0) return null;
	return Array.from(entry.target.childNodes).some((child) => child.nodeType === Node.ELEMENT_NODE || child.nodeType === Node.TEXT_NODE && child.textContent?.trim()) ? {
		w: border.inlineSize,
		h: border.blockSize
	} : null;
}
var NoteBox = class NoteBox {
	id = input.required({
		...ngDevMode ? { debugName: "id" } : /* istanbul ignore next */ {},
		alias: "neatDiagramNoteBox"
	});
	box = inject(ElementRef).nativeElement;
	sizes = inject(NoteSizes);
	ngOnInit() {
		this.sizes.observe(this.box, this.id());
	}
	ngOnDestroy() {
		this.sizes.unobserve(this.box);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NoteBox,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NoteBox,
		isStandalone: true,
		selector: "[neatDiagramNoteBox]",
		inputs: { id: {
			classPropertyName: "id",
			publicName: "neatDiagramNoteBox",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NoteBox,
	decorators: [{
		type: Directive,
		args: [{ selector: "[neatDiagramNoteBox]" }]
	}],
	propDecorators: { id: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "neatDiagramNoteBox",
			required: true
		}]
	}] }
});
function placeNotes(diagram, edges, sizes) {
	const edgeIds = new Set(diagram.edges.map((edge) => edge.id));
	const placed = /* @__PURE__ */ new Map();
	for (const note of firstOfEachId(diagram.notes ?? [], "note")) {
		for (const id of note.edges ?? []) if (!edgeIds.has(id)) reportLeftOut(`note "${note.id}" ignores its edge "${id}": it is not on its level`);
		const anchor = anchorOf(note, edges);
		if (!anchor) {
			reportLeftOut(`note "${note.id}" is left out: it needs a drawn edge or an anchor with x and y`);
			continue;
		}
		const size = sizes.get(note.id);
		if (size) placed.set(note.id, place(note, anchor, size));
	}
	return placed;
}
function anchorOf(note, edges) {
	const along = note.along ?? .5;
	const points = (note.edges ?? []).flatMap((id) => {
		const edge = edges.get(id);
		return edge ? [pointAlong(edge.points, along)] : [];
	});
	const mean = (axis) => points.length ? points.reduce((sum, p) => sum + p[axis], 0) / points.length : void 0;
	const x = note.anchor?.x ?? mean("x");
	const y = note.anchor ? note.anchor.y : mean("y");
	return x === void 0 || y === void 0 ? null : {
		x,
		y
	};
}
function place(note, anchor, size) {
	const cx = note.x ?? anchor.x + (note.dx ?? 0);
	const cy = note.y ?? anchor.y + (note.dy ?? 0);
	const box = {
		x: cx - size.w / 2,
		y: cy - size.h / 2,
		w: size.w,
		h: size.h
	};
	const clamp = (v, low, high) => Math.min(Math.max(v, low), high);
	const under = anchor.x >= box.x && anchor.x <= box.x + box.w && anchor.y >= box.y && anchor.y <= box.y + box.h;
	const end = note.leaderTo === "centre" ? {
		x: cx,
		y: cy
	} : {
		x: clamp(anchor.x, box.x, box.x + box.w),
		y: clamp(anchor.y, box.y, box.y + box.h)
	};
	return {
		box,
		anchor,
		leader: under ? null : [anchor, end]
	};
}
var NeatDiagramBlockTemplate = class NeatDiagramBlockTemplate {
	template = inject(TemplateRef);
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramBlockTemplate,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatDiagramBlockTemplate,
		isStandalone: true,
		selector: "ng-template[neatDiagramBlock]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramBlockTemplate,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatDiagramBlock]" }]
	}]
});
var NeatDiagramNoteTemplate = class NeatDiagramNoteTemplate {
	template = inject(TemplateRef);
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramNoteTemplate,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatDiagramNoteTemplate,
		isStandalone: true,
		selector: "ng-template[neatDiagramNote]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramNoteTemplate,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatDiagramNote]" }]
	}]
});
var NeatDiagramEdgeTipTemplate = class NeatDiagramEdgeTipTemplate {
	template = inject(TemplateRef);
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramEdgeTipTemplate,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatDiagramEdgeTipTemplate,
		isStandalone: true,
		selector: "ng-template[neatDiagramEdgeTip]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramEdgeTipTemplate,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatDiagramEdgeTip]" }]
	}]
});
const ANIMATION_MS = 250;
const PAN_STEP = 48;
const ZOOM_STEP = 1.25;
const CLICK_DISTANCE = 3;
const REDUCED_MOTION$1 = "(prefers-reduced-motion: reduce)";
const PAN_KEYS = {
	ArrowLeft: [PAN_STEP, 0],
	ArrowRight: [-48, 0],
	ArrowUp: [0, PAN_STEP],
	ArrowDown: [0, -48]
};
const ZOOM_KEYS = {
	"+": ZOOM_STEP,
	"=": ZOOM_STEP,
	"-": 1 / ZOOM_STEP
};
function pointOf(event) {
	if (event instanceof MouseEvent) return {
		x: event.clientX,
		y: event.clientY
	};
	if (typeof TouchEvent === "function" && event instanceof TouchEvent) {
		const [touch, more] = Array.from(event.touches);
		return touch && !more ? {
			x: touch.clientX,
			y: touch.clientY
		} : null;
	}
	return null;
}
function shiftInto(start, end, room) {
	const low = 24;
	const high = room - 24;
	let shift = 0;
	if (start < low) shift = low - start;
	else if (end > high) shift = Math.max(high - end, low - start);
	return Math.abs(shift) < 1 ? 0 : shift;
}
const easeInOut = (t) => t < .5 ? 4 * t ** 3 : 1 - (-2 * t + 2) ** 3 / 2;
var DiagramZoom = class {
	box;
	content;
	edges;
	onDraw;
	behavior;
	selection;
	observer;
	motion = typeof matchMedia === "function" ? matchMedia(REDUCED_MOTION$1) : null;
	extent = null;
	topInset = null;
	userMoved = false;
	ownMove = false;
	press = null;
	animation = null;
	constructor(box, content, edges, onDraw = () => void 0) {
		this.box = box;
		this.content = content;
		this.edges = edges;
		this.onDraw = onDraw;
		this.behavior = zoom().scaleExtent([ZOOM_LIMITS[0], ZOOM_LIMITS[1]]).clickDistance(CLICK_DISTANCE).on("start", (event) => {
			this.press = event.sourceEvent ? pointOf(event.sourceEvent) : null;
		}).on("zoom", (event) => {
			if (event.sourceEvent && !this.ownMove && this.isUsers(event.sourceEvent)) this.moved();
			this.draw(event.transform);
		}).on("end", () => this.press = null);
		this.syncDuration();
		this.motion?.addEventListener("change", this.syncDuration);
		this.selection = select(box).call(this.behavior);
		box.addEventListener("keydown", this.keydown);
		box.addEventListener("focusin", this.focusIn);
		this.observer = new ResizeObserver(() => this.autoFit());
		this.observer.observe(box);
	}
	get transform() {
		return zoomTransform(this.box);
	}
	setExtent(extent) {
		const known = this.extent;
		if (known?.x === extent?.x && known?.y === extent?.y && known?.w === extent?.w && known?.h === extent?.h) return;
		this.extent = extent;
		this.autoFit();
	}
	setTopInset(element) {
		if (element === this.topInset) return;
		if (this.topInset) this.observer.unobserve(this.topInset);
		this.topInset = element;
		if (element) this.observer.observe(element);
		this.autoFit();
	}
	fit() {
		this.userMoved = false;
		const to = this.fitted();
		if (to) this.animate(to);
	}
	levelChanged() {
		this.userMoved = false;
		this.autoFit();
	}
	destroy() {
		this.stopAnimation();
		this.jump(zoomTransform(this.box));
		this.observer.disconnect();
		this.box.removeEventListener("keydown", this.keydown);
		this.box.removeEventListener("focusin", this.focusIn);
		this.motion?.removeEventListener("change", this.syncDuration);
		this.selection.on(".zoom", null);
	}
	autoFit() {
		if (this.userMoved) return;
		const to = this.fitted();
		if (!to) return;
		this.stopAnimation();
		this.jump(to);
	}
	fitted() {
		if (!this.extent) return null;
		const inset = this.insetHeight();
		const box = {
			w: this.box.clientWidth,
			h: this.box.clientHeight - inset
		};
		const fit = fitTransform(this.extent, box);
		return fit && zoomIdentity.translate(fit.x, fit.y + inset).scale(fit.k);
	}
	insetHeight() {
		const height = this.topInset?.offsetHeight ?? 0;
		return height < this.box.clientHeight ? height : 0;
	}
	isUsers(source) {
		if (!this.press || source.type !== "mousemove" && source.type !== "touchmove") return true;
		const at = pointOf(source);
		if (!at) return true;
		if (Math.hypot(at.x - this.press.x, at.y - this.press.y) <= CLICK_DISTANCE) return false;
		this.press = null;
		return true;
	}
	moved() {
		this.userMoved = true;
		this.stopAnimation();
	}
	draw({ k, x, y }) {
		this.content.style.transform = `translate(${x}px, ${y}px) scale(${k})`;
		this.edges.style.setProperty("--diagram-zoom", String(k));
		this.onDraw();
	}
	jump(to) {
		this.ownMove = true;
		try {
			this.behavior.transform(this.selection, to);
		} finally {
			this.ownMove = false;
		}
	}
	animate(to) {
		this.stopAnimation();
		if (this.motion?.matches) return this.jump(to);
		const from = zoomTransform(this.box);
		const start = performance.now();
		const step = () => {
			const t = Math.min((performance.now() - start) / ANIMATION_MS, 1);
			if (t === 1) {
				this.animation = null;
				return this.jump(to);
			}
			const e = easeInOut(t);
			const at = (a, b) => a + (b - a) * e;
			this.jump(zoomIdentity.translate(at(from.x, to.x), at(from.y, to.y)).scale(at(from.k, to.k)));
			this.animation = {
				to,
				frame: requestAnimationFrame(step)
			};
		};
		this.animation = {
			to,
			frame: requestAnimationFrame(step)
		};
	}
	stopAnimation() {
		if (this.animation) cancelAnimationFrame(this.animation.frame);
		this.animation = null;
	}
	syncDuration = () => {
		this.behavior.duration(this.motion?.matches ? 0 : ANIMATION_MS);
	};
	keydown = (event) => {
		if (event.target !== this.box || event.ctrlKey || event.metaKey || event.altKey) return;
		const pan = PAN_KEYS[event.key];
		const by = ZOOM_KEYS[event.key];
		if (pan) {
			this.moved();
			const { k, x, y } = zoomTransform(this.box);
			this.jump(zoomIdentity.translate(x + pan[0], y + pan[1]).scale(k));
		} else if (by) {
			const from = this.animation?.to ?? zoomTransform(this.box);
			this.moved();
			this.animate(this.scaledAboutCentre(from, by));
		} else if (event.key === "0") this.fit();
		else return;
		event.preventDefault();
	};
	focusIn = (event) => {
		const part = event.target;
		if (!(part instanceof Element) || !this.content.contains(part)) return;
		if (!part.matches(":focus-visible")) return;
		const box = this.box.getBoundingClientRect();
		const rect = part.getBoundingClientRect();
		const left = box.left + this.box.clientLeft;
		const top = box.top + this.box.clientTop;
		const dx = shiftInto(rect.left - left, rect.right - left, this.box.clientWidth);
		const inset = this.insetHeight();
		const height = this.box.clientHeight - inset;
		const dy = shiftInto(rect.top - top - inset, rect.bottom - top - inset, height);
		if (dx === 0 && dy === 0) return;
		this.moved();
		const { k, x, y } = zoomTransform(this.box);
		this.jump(zoomIdentity.translate(x + dx, y + dy).scale(k));
	};
	scaledAboutCentre(from, by) {
		const k = Math.min(Math.max(from.k * by, ZOOM_LIMITS[0]), ZOOM_LIMITS[1]);
		const centre = [this.box.clientWidth / 2, this.box.clientHeight / 2];
		const [px, py] = from.invert(centre);
		return zoomIdentity.translate(centre[0] - px * k, centre[1] - py * k).scale(k);
	}
};
var NeatDiagramView = class NeatDiagramView {
	diagram = input.required(...ngDevMode ? [{ debugName: "diagram" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	level = model([], ...ngDevMode ? [{ debugName: "level" }] : /* istanbul ignore next */ []);
	highlight = input("none", ...ngDevMode ? [{ debugName: "highlight" }] : /* istanbul ignore next */ []);
	blockTemplate = contentChild(NeatDiagramBlockTemplate, ...ngDevMode ? [{ debugName: "blockTemplate" }] : /* istanbul ignore next */ []);
	noteTemplate = contentChild(NeatDiagramNoteTemplate, ...ngDevMode ? [{ debugName: "noteTemplate" }] : /* istanbul ignore next */ []);
	edgeTipTemplate = contentChild(NeatDiagramEdgeTipTemplate, ...ngDevMode ? [{ debugName: "edgeTipTemplate" }] : /* istanbul ignore next */ []);
	noteSizes = inject(NoteSizes);
	content = viewChild.required("content", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	edges = viewChild.required("edges", ...ngDevMode ? [{ debugName: "edges" }] : /* istanbul ignore next */ []);
	tipBox = viewChild("tip", ...ngDevMode ? [{ debugName: "tipBox" }] : /* istanbul ignore next */ []);
	bar = viewChild("bar", ...ngDevMode ? [{ debugName: "bar" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef).nativeElement;
	injector = inject(Injector);
	zone = inject(NgZone);
	zoom = null;
	transformListeners = /* @__PURE__ */ new Set();
	hover = this.zone.runOutsideAngular(() => new DiagramHover(this.host, () => this.tipBox()?.nativeElement));
	BRACE_HEIGHT = 18;
	staleClasses = ɵSTALE_CLASSES;
	walked = computed(() => walkLevels(this.diagram(), this.level()), ...ngDevMode ? [{ debugName: "walked" }] : /* istanbul ignore next */ []);
	path = computed(() => this.walked().path, {
		...ngDevMode ? { debugName: "path" } : /* istanbul ignore next */ {},
		equal: samePath
	});
	shown = computed(() => this.walked().shown, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	crumbs = computed(() => this.walked().openers.map((opener) => ({
		label: opener.label,
		detail: opener.detail
	})), ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	backTo = computed(() => this.crumbs().at(-2)?.label ?? "Overview", ...ngDevMode ? [{ debugName: "backTo" }] : /* istanbul ignore next */ []);
	drawn = computed(() => drawLevel(this.shown(), new Set(Object.keys(this.diagram().levels ?? {}))), ...ngDevMode ? [{ debugName: "drawn" }] : /* istanbul ignore next */ []);
	notes = computed(() => firstOfEachId(this.shown().notes ?? [], "note"), ...ngDevMode ? [{ debugName: "notes" }] : /* istanbul ignore next */ []);
	placements = computed(() => placeNotes(this.shown(), this.drawn().layouts, this.noteSizes.sizes()), ...ngDevMode ? [{ debugName: "placements" }] : /* istanbul ignore next */ []);
	extent = computed(() => levelExtent(this.drawn(), [...this.placements().values()].map((placement) => placement.box)), ...ngDevMode ? [{ debugName: "extent" }] : /* istanbul ignore next */ []);
	focused = computed(() => focusedParts(this.shown(), highlighted(this.hover.focus(), this.highlight())), ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	edgeTip = computed(() => {
		const template = this.edgeTipTemplate()?.template;
		const id = this.hover.tipEdge();
		const edge = this.drawn().edges.find((drawn) => drawn.id === id)?.edge;
		return template && edge ? {
			template,
			edge
		} : null;
	}, ...ngDevMode ? [{ debugName: "edgeTip" }] : /* istanbul ignore next */ []);
	described = computed(() => describeLevel(this.drawn()), ...ngDevMode ? [{ debugName: "described" }] : /* istanbul ignore next */ []);
	constructor() {
		inject(DiagramMessagesSlot).context = this.messagesContext();
		effect(() => {
			const path = this.path();
			if (!samePath(path, this.level())) this.level.set([...path]);
		});
		let shownPath = null;
		afterRenderEffect(() => {
			const extent = this.extent();
			const path = this.path();
			const bar = this.bar()?.nativeElement ?? null;
			untracked(() => {
				this.zoom ??= this.zone.runOutsideAngular(() => new DiagramZoom(this.host, this.content().nativeElement, this.edges().nativeElement, () => this.transformListeners.forEach((listener) => listener())));
				this.zoom.setTopInset(bar);
				this.zoom.setExtent(extent);
				if (shownPath !== null && path !== shownPath) {
					this.hover.clear();
					this.zoom.levelChanged();
				}
				shownPath = path;
			});
		});
		afterRenderEffect(() => {
			this.edgeTip();
			untracked(() => this.hover.place());
		});
		inject(DestroyRef).onDestroy(() => {
			this.zoom?.destroy();
			this.hover.destroy();
		});
	}
	fit() {
		this.zone.runOutsideAngular(() => this.zoom?.fit());
	}
	messagesContext() {
		return {
			level: computed(() => ({
				key: JSON.stringify(this.path()),
				edges: this.drawn().edges.map(({ id, edge, line, points }) => ({
					id,
					from: edge.from,
					to: edge.to,
					series: edge.series,
					line,
					points
				}))
			})),
			covers: computed(() => [...this.drawn().front.filter(({ node }) => node.role === "block").map(({ rect }) => rect), ...[...this.placements().values()].map(({ box }) => box)]),
			edgeIds: computed(() => {
				const { overview, levels } = this.diagram();
				const all = [overview, ...Object.values(levels ?? {})];
				return new Set(all.flatMap((level) => level.edges.map((edge) => edge.id)));
			}),
			focus: computed(() => this.focused()?.edges ?? null),
			transform: () => this.zoom?.transform ?? IDENTITY_TRANSFORM,
			onTransform: (listener) => {
				this.transformListeners.add(listener);
				return () => this.transformListeners.delete(listener);
			}
		};
	}
	open(block) {
		if (block.opens !== void 0) this.go([...this.path(), block.opens]);
	}
	back() {
		this.go(this.path().slice(0, -1));
	}
	goTo(index) {
		this.go(this.path().slice(0, index + 1));
	}
	go(path) {
		this.level.set(path);
		afterNextRender(() => {
			if (!this.host.contains(document.activeElement)) this.host.focus({ preventScroll: true });
		}, { injector: this.injector });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramView,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatDiagramView,
		isStandalone: true,
		selector: "neat-diagram",
		inputs: {
			diagram: {
				classPropertyName: "diagram",
				publicName: "diagram",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			highlight: {
				classPropertyName: "highlight",
				publicName: "highlight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { level: "levelChange" },
		host: {
			attributes: {
				"role": "figure",
				"tabindex": "0"
			},
			properties: { "attr.aria-label": "label()" }
		},
		providers: [NoteSizes, provideDiagramMessagesContext()],
		queries: [
			{
				propertyName: "blockTemplate",
				first: true,
				predicate: NeatDiagramBlockTemplate,
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "noteTemplate",
				first: true,
				predicate: NeatDiagramNoteTemplate,
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "edgeTipTemplate",
				first: true,
				predicate: NeatDiagramEdgeTipTemplate,
				descendants: true,
				isSignal: true
			}
		],
		viewQueries: [
			{
				propertyName: "content",
				first: true,
				predicate: ["content"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "edges",
				first: true,
				predicate: ["edges"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tipBox",
				first: true,
				predicate: ["tip"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "bar",
				first: true,
				predicate: ["bar"],
				descendants: true,
				isSignal: true
			}
		],
		ngImport: i0,
		template: "@let focus = focused();\n<!-- Over the drawing, unscaled, and first in the tab order: back a level and where you are. -->\n@if (crumbs().length > 0) {\n  <!-- A press on its controls is theirs: no pan starts and a double-click does not zoom. -->\n  <div\n    #bar\n    class=\"bar\"\n    (mousedown)=\"$event.stopPropagation()\"\n    (touchstart)=\"$event.stopPropagation()\"\n    (dblclick)=\"$event.stopPropagation()\"\n  >\n    <button\n      neatButton\n      variant=\"outlined\"\n      size=\"small\"\n      type=\"button\"\n      [attr.aria-label]=\"'Back to ' + backTo()\"\n      (click)=\"back()\"\n    >\n      <neat-icon name=\"previous\" [size]=\"16\" />\n      {{ backTo() }}\n    </button>\n    <neat-breadcrumbs class=\"crumbs\" label=\"Levels\" [crumbs]=\"crumbs()\" (go)=\"goTo($event)\" />\n  </div>\n}\n\n<!-- One container for every layer, so pan and zoom move one element. -->\n<div class=\"content\" #content>\n  <div class=\"behind\">\n    @for (part of drawn().behind; track part.node.id) {\n      @if (part.node.role === 'frame') {\n        <div\n          class=\"frame\"\n          [attr.data-node]=\"part.node.id\"\n          [attr.data-look]=\"part.look\"\n          [style.left.px]=\"part.rect.x\"\n          [style.top.px]=\"part.rect.y\"\n          [style.width.px]=\"part.rect.w\"\n          [style.height.px]=\"part.rect.h\"\n        >\n          <div class=\"title\">{{ part.node.label }}</div>\n          @if (part.node.detail) {\n            <div class=\"detail\">{{ part.node.detail }}</div>\n          }\n        </div>\n      } @else {\n        <div\n          class=\"band\"\n          [class.upright]=\"part.rect.h > part.rect.w\"\n          [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n          [attr.data-node]=\"part.node.id\"\n          [style.left.px]=\"part.rect.x\"\n          [style.top.px]=\"part.rect.y\"\n          [style.width.px]=\"part.rect.w\"\n          [style.height.px]=\"part.rect.h\"\n        >\n          {{ part.node.label }}\n        </div>\n      }\n    }\n  </div>\n\n  <svg class=\"edges\" #edges aria-hidden=\"true\" focusable=\"false\">\n    @for (edge of drawn().edges; track edge.id) {\n      <g\n        class=\"edge\"\n        [class.dim]=\"focus !== null && !focus.edges.has(edge.id)\"\n        [attr.data-edge]=\"edge.id\"\n        [attr.data-line]=\"edge.line\"\n        [style.--edge]=\"edge.colour\"\n      >\n        <path class=\"hit\" [attr.d]=\"edge.path\" />\n        <path class=\"line\" [attr.d]=\"edge.path\" />\n        @for (tip of edge.tips; track tip.end) {\n          @if (tip.shape === 'arrow') {\n            <path class=\"tip\" data-shape=\"arrow\" [attr.data-tip]=\"tip.end\" [attr.d]=\"tip.d\" />\n          } @else {\n            <circle\n              class=\"tip\"\n              data-shape=\"dot\"\n              [attr.data-tip]=\"tip.end\"\n              [attr.cx]=\"tip.cx\"\n              [attr.cy]=\"tip.cy\"\n              [attr.r]=\"tip.r\"\n            />\n          }\n        }\n      </g>\n    }\n    @for (note of notes(); track note.id) {\n      @if (placements().get(note.id)?.leader; as leader) {\n        <g\n          class=\"leader\"\n          [class.dim]=\"focus !== null && !focus.notes.has(note.id)\"\n          [attr.data-note]=\"note.id\"\n        >\n          <line\n            [attr.x1]=\"leader[0].x\"\n            [attr.y1]=\"leader[0].y\"\n            [attr.x2]=\"leader[1].x\"\n            [attr.y2]=\"leader[1].y\"\n          />\n          <circle [attr.cx]=\"leader[0].x\" [attr.cy]=\"leader[0].y\" r=\"2.5\" />\n        </g>\n      }\n    }\n  </svg>\n\n  <div class=\"front\">\n    @for (part of drawn().front; track part.node.id) {\n      @if (part.node.role === 'block') {\n        @if (part.opens) {\n          <button\n            type=\"button\"\n            class=\"block\"\n            data-opens\n            [class]=\"part.node.stale ? staleClasses : ''\"\n            [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n            [attr.data-node]=\"part.node.id\"\n            [attr.data-look]=\"part.look\"\n            [attr.aria-label]=\"'Open ' + part.node.label\"\n            [style.left.px]=\"part.rect.x\"\n            [style.top.px]=\"part.rect.y\"\n            [style.width.px]=\"part.rect.w\"\n            [style.height.px]=\"part.rect.h\"\n            (click)=\"open(part.node)\"\n          >\n            <ng-container *ngTemplateOutlet=\"blockContent; context: { $implicit: part.node }\" />\n            <span class=\"more\" aria-hidden=\"true\">›</span>\n          </button>\n        } @else {\n          <div\n            class=\"block\"\n            [class]=\"part.node.stale ? staleClasses : ''\"\n            [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n            [attr.data-node]=\"part.node.id\"\n            [attr.data-look]=\"part.look\"\n            [style.left.px]=\"part.rect.x\"\n            [style.top.px]=\"part.rect.y\"\n            [style.width.px]=\"part.rect.w\"\n            [style.height.px]=\"part.rect.h\"\n          >\n            <ng-container *ngTemplateOutlet=\"blockContent; context: { $implicit: part.node }\" />\n          </div>\n        }\n      } @else {\n        <div\n          class=\"bracket\"\n          [class]=\"part.node.stale ? staleClasses : ''\"\n          [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n          [attr.data-node]=\"part.node.id\"\n          [style.left.px]=\"part.rect.x\"\n          [style.top.px]=\"part.rect.y\"\n          [style.width.px]=\"part.rect.w\"\n          [style.height.px]=\"part.rect.h\"\n        >\n          <svg\n            [attr.viewBox]=\"'0 0 ' + part.rect.w + ' ' + BRACE_HEIGHT\"\n            [attr.height]=\"BRACE_HEIGHT\"\n            preserveAspectRatio=\"none\"\n            aria-hidden=\"true\"\n            focusable=\"false\"\n          >\n            <path [attr.d]=\"part.brace\" />\n          </svg>\n          <span class=\"bracket-text\">\n            <span class=\"label\">{{ part.node.label }}</span>\n            @if (part.node.detail) {\n              <!-- Spaced in the text too, so it reads as words where it is not seen. -->\n              <span class=\"separator\"> · </span>\n              <span>{{ part.node.detail }}</span>\n            }\n            @if (blockTemplate(); as body) {\n              <ng-container *ngTemplateOutlet=\"body.template; context: { $implicit: part.node }\" />\n            }\n          </span>\n        </div>\n      }\n    }\n\n    @for (edge of drawn().edges; track edge.id) {\n      @if (edge.label; as label) {\n        <code\n          class=\"edge-label\"\n          [class.dim]=\"focus !== null && !focus.edges.has(edge.id)\"\n          [attr.data-edge]=\"edge.id\"\n          [style.left.px]=\"label.at.x\"\n          [style.top.px]=\"label.at.y\"\n          >{{ label.text }}</code\n        >\n      }\n    }\n\n    @if (noteTemplate(); as content) {\n      @for (note of notes(); track note.id) {\n        @let placement = placements().get(note.id);\n        <div\n          class=\"note\"\n          [neatDiagramNoteBox]=\"note.id\"\n          [attr.data-note]=\"note.id\"\n          [class.placed]=\"placement !== undefined\"\n          [class.dim]=\"focus !== null && !focus.notes.has(note.id)\"\n          [style.left.px]=\"placement?.box?.x ?? 0\"\n          [style.top.px]=\"placement?.box?.y ?? 0\"\n        >\n          <ng-container *ngTemplateOutlet=\"content.template; context: { $implicit: note }\" />\n        </div>\n      }\n    }\n  </div>\n</div>\n\n<!--\n  The messaging layer, over the whole drawing in the box's own coordinates (it maps through the\n  transform itself), under the bar and the tip.\n-->\n<ng-content select=\"neat-diagram-messages\" />\n\n<!--\n  A block's card: its label, detail, the app's body and its chips. Spans only, since an open\n  block's card is a button, which holds phrasing content.\n-->\n<ng-template #blockContent let-node>\n  <span class=\"text\">\n    <span class=\"label\">{{ node.label }}</span>\n    @if (node.detail) {\n      <span class=\"detail\">{{ node.detail }}</span>\n    }\n    @if (blockTemplate(); as body) {\n      <span class=\"body\">\n        <ng-container *ngTemplateOutlet=\"body.template; context: { $implicit: node }\" />\n      </span>\n    }\n  </span>\n  @for (chip of node.chips ?? []; track $index) {\n    <neat-status-chip [tone]=\"chip.tone\" variant=\"tinted\">{{ chip.label }}</neat-status-chip>\n  }\n</ng-template>\n\n<!-- The level in words, after the drawing, so the picture is not only visual. -->\n<div class=\"sr-only\">\n  <ul aria-label=\"Parts\">\n    @for (part of described().nodes; track part.id) {\n      <li>{{ part.text }}</li>\n    }\n  </ul>\n  @if (described().edges.length > 0) {\n    <ul aria-label=\"Connections\">\n      @for (edge of described().edges; track edge.id) {\n        <li>{{ edge.text }}</li>\n      }\n    </ul>\n  }\n</div>\n\n<!-- Placed by the pointer (hover.ts), in the box; presentational, as the list has the words. -->\n@if (edgeTip(); as tip) {\n  <div class=\"edge-tip\" #tip aria-hidden=\"true\">\n    <ng-container *ngTemplateOutlet=\"tip.template; context: { $implicit: tip.edge }\" />\n  </div>\n}\n",
		styles: [
			".frame{position:absolute;box-sizing:border-box;padding:var(--neat-space-2) var(--neat-space-3);border:var(--frame-line) var(--frame-edge);border-radius:var(--radius);background:var(--frame-fill)}.frame[data-look=default]{--frame-line: 1px solid;--frame-edge: var(--border);--frame-fill: color-mix(in oklab, var(--muted) 35%, transparent);--frame-ink: var(--foreground);--frame-weight: 600}.frame[data-look=accent]{--frame-line: 1px solid;--frame-edge: color-mix(in oklab, var(--primary) 45%, transparent);--frame-fill: color-mix(in oklab, var(--primary) 5%, transparent);--frame-ink: var(--foreground);--frame-weight: 600}.frame[data-look=dashed]{--frame-line: 1px dashed;--frame-edge: var(--border);--frame-fill: color-mix(in oklab, var(--card) 60%, transparent);--frame-ink: var(--foreground);--frame-weight: 600}.frame[data-look=ghost]{--frame-line: 2px dashed;--frame-edge: var(--muted-foreground);--frame-fill: transparent;--frame-ink: var(--muted-foreground);--frame-weight: 400}.frame[data-look=muted]{--frame-line: 1px solid;--frame-edge: var(--border);--frame-fill: var(--muted);--frame-ink: var(--muted-foreground);--frame-weight: 600}.frame .title{font-size:var(--neat-text-base);font-weight:var(--frame-weight);color:var(--frame-ink)}.frame .detail{font-size:var(--neat-text-xs);color:var(--muted-foreground)}.band{position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;border:1px dashed var(--border);border-radius:var(--radius);font-size:var(--neat-text-xs);color:var(--muted-foreground);white-space:nowrap}.band.upright{writing-mode:vertical-rl}\n",
			".block{position:absolute;box-sizing:border-box;display:flex;align-items:center;gap:var(--neat-space-2);padding:calc(var(--neat-space-2) - var(--block-open-inset, 0px)) calc(var(--neat-space-3) - var(--block-open-inset, 0px));border:var(--block-open-line, var(--block-line)) var(--block-open-edge, var(--block-edge));border-radius:var(--radius);background:var(--block-fill);color:var(--block-ink);box-shadow:var(--block-shadow)}.block[data-look=default]{--block-line: 1px solid;--block-edge: var(--border);--block-fill: var(--card);--block-ink: var(--card-foreground);--block-shadow: var(--diagram-card-shadow);--block-weight: 600}.block[data-look=accent]{--block-line: 1px solid;--block-edge: color-mix(in oklab, var(--primary) 45%, transparent);--block-fill: color-mix(in oklab, var(--primary) 5%, var(--card));--block-ink: var(--card-foreground);--block-shadow: var(--diagram-card-shadow);--block-weight: 600}.block[data-look=dashed]{--block-line: 1px dashed;--block-edge: var(--border);--block-fill: var(--card);--block-ink: var(--card-foreground);--block-shadow: none;--block-weight: 600}.block[data-look=ghost]{--block-line: 2px dashed;--block-edge: var(--muted-foreground);--block-fill: transparent;--block-ink: var(--muted-foreground);--block-shadow: none;--block-weight: 500}.block[data-look=muted]{--block-line: 1px solid;--block-edge: var(--border);--block-fill: var(--muted);--block-ink: var(--muted-foreground);--block-shadow: none;--block-weight: 600}.block[data-opens]{--block-open-line: 2px solid;--block-open-edge: var(--primary);--block-open-inset: 1px}.block .text{flex:1;min-width:0;display:grid;gap:calc(var(--neat-space-2) / 2);justify-items:start}.block .label{font-size:var(--neat-text-sm);font-weight:var(--block-weight);line-height:1.2}.block .detail{font-size:var(--neat-text-xs);color:var(--muted-foreground);line-height:1.25}.body:empty{display:none}.more{color:var(--primary)}.bracket{position:absolute;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;gap:calc(var(--neat-space-2) / 2)}.bracket svg{display:block;width:100%;flex:none;overflow:visible}.bracket path{fill:none;stroke:var(--muted-foreground);stroke-width:1.5;stroke-linecap:round;vector-effect:non-scaling-stroke}.bracket-text{display:flex;align-items:baseline;gap:var(--neat-space-2);font-size:var(--neat-text-sm);white-space:nowrap}.bracket-text .label{font-weight:600}.separator{color:var(--muted-foreground)}\n",
			".line{fill:none;stroke:var(--edge);stroke-width:var(--edge-width);stroke-dasharray:var(--edge-dash);stroke-opacity:var(--edge-opacity)}[data-line=solid]{--edge-width: 1.5;--edge-dash: none;--edge-opacity: .75}[data-line=dashed]{--edge-width: 1.5;--edge-dash: 4 4;--edge-opacity: .75}[data-line=ghost]{--edge-width: 2;--edge-dash: 8 6;--edge-opacity: .9}\n",
			":host{--diagram-card-shadow: 0 1px 2px color-mix(in oklab, var(--foreground) 8%, transparent);--diagram-dim: .25;display:block;position:relative;overflow:clip;touch-action:none}:host(:focus-visible){outline:2px solid var(--ring);outline-offset:2px}.content{position:absolute;top:0;left:0;transform-origin:0 0}.edge-label,.note{width:max-content}.edges{--diagram-zoom: 1;position:absolute;top:0;left:0;width:1px;height:1px;overflow:visible;pointer-events:none}.hit{fill:none;stroke:transparent;stroke-width:calc(12px / var(--diagram-zoom));pointer-events:stroke}.tip{fill:var(--edge);fill-opacity:.85}.leader line{stroke:var(--muted-foreground);stroke-width:1;stroke-dasharray:2 3}.leader circle{fill:var(--muted-foreground)}.edge-label{position:absolute;transform:translate(-50%,-50%);padding:0 calc(var(--neat-space-2) / 2);border:1px solid var(--border);border-radius:calc(var(--radius) / 2);background:var(--card);color:var(--muted-foreground);font-size:var(--neat-text-xs);line-height:1.4;white-space:nowrap}.note{position:absolute;box-sizing:border-box;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--card);color:var(--card-foreground);font-size:var(--neat-text-xs);line-height:1.3;box-shadow:var(--diagram-card-shadow)}.note:not(.placed){visibility:hidden}.dim{opacity:var(--diagram-dim)}button.block{margin:0;font:inherit;text-align:start;cursor:pointer}button.block:focus-visible{outline:2px solid var(--ring);outline-offset:2px}.bar{position:absolute;z-index:1;top:0;left:0;display:flex;flex-wrap:wrap;align-items:center;gap:var(--neat-space-3);padding:var(--neat-space-2) var(--neat-space-3);pointer-events:none}.bar>*{pointer-events:auto}.crumbs{padding:calc(var(--neat-space-2) / 2) var(--neat-space-2);border-radius:var(--radius);background:color-mix(in oklab,var(--neat-surface) 85%,transparent)}.edge-tip{--neat-surface: var(--popover);position:absolute;z-index:1;top:0;left:0;box-sizing:border-box;max-width:min(16rem,100%);width:max-content;padding:var(--neat-space-2) var(--neat-space-3);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);line-height:1.35;pointer-events:none}.edge-tip:empty{display:none}\n"
		],
		dependencies: [
			{
				kind: "component",
				type: NeatBreadcrumbs,
				selector: "neat-breadcrumbs",
				inputs: ["label", "crumbs"],
				outputs: ["go"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatStatusChip,
				selector: "neat-status-chip",
				inputs: ["tone", "variant"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "directive",
				type: NoteBox,
				selector: "[neatDiagramNoteBox]",
				inputs: ["neatDiagramNoteBox"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramView,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-diagram",
			imports: [
				NeatBreadcrumbs,
				NeatButton,
				NeatIcon,
				NeatStatusChip,
				NgTemplateOutlet,
				NoteBox
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [NoteSizes, provideDiagramMessagesContext()],
			host: {
				role: "figure",
				"[attr.aria-label]": "label()",
				tabindex: "0"
			},
			template: "@let focus = focused();\n<!-- Over the drawing, unscaled, and first in the tab order: back a level and where you are. -->\n@if (crumbs().length > 0) {\n  <!-- A press on its controls is theirs: no pan starts and a double-click does not zoom. -->\n  <div\n    #bar\n    class=\"bar\"\n    (mousedown)=\"$event.stopPropagation()\"\n    (touchstart)=\"$event.stopPropagation()\"\n    (dblclick)=\"$event.stopPropagation()\"\n  >\n    <button\n      neatButton\n      variant=\"outlined\"\n      size=\"small\"\n      type=\"button\"\n      [attr.aria-label]=\"'Back to ' + backTo()\"\n      (click)=\"back()\"\n    >\n      <neat-icon name=\"previous\" [size]=\"16\" />\n      {{ backTo() }}\n    </button>\n    <neat-breadcrumbs class=\"crumbs\" label=\"Levels\" [crumbs]=\"crumbs()\" (go)=\"goTo($event)\" />\n  </div>\n}\n\n<!-- One container for every layer, so pan and zoom move one element. -->\n<div class=\"content\" #content>\n  <div class=\"behind\">\n    @for (part of drawn().behind; track part.node.id) {\n      @if (part.node.role === 'frame') {\n        <div\n          class=\"frame\"\n          [attr.data-node]=\"part.node.id\"\n          [attr.data-look]=\"part.look\"\n          [style.left.px]=\"part.rect.x\"\n          [style.top.px]=\"part.rect.y\"\n          [style.width.px]=\"part.rect.w\"\n          [style.height.px]=\"part.rect.h\"\n        >\n          <div class=\"title\">{{ part.node.label }}</div>\n          @if (part.node.detail) {\n            <div class=\"detail\">{{ part.node.detail }}</div>\n          }\n        </div>\n      } @else {\n        <div\n          class=\"band\"\n          [class.upright]=\"part.rect.h > part.rect.w\"\n          [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n          [attr.data-node]=\"part.node.id\"\n          [style.left.px]=\"part.rect.x\"\n          [style.top.px]=\"part.rect.y\"\n          [style.width.px]=\"part.rect.w\"\n          [style.height.px]=\"part.rect.h\"\n        >\n          {{ part.node.label }}\n        </div>\n      }\n    }\n  </div>\n\n  <svg class=\"edges\" #edges aria-hidden=\"true\" focusable=\"false\">\n    @for (edge of drawn().edges; track edge.id) {\n      <g\n        class=\"edge\"\n        [class.dim]=\"focus !== null && !focus.edges.has(edge.id)\"\n        [attr.data-edge]=\"edge.id\"\n        [attr.data-line]=\"edge.line\"\n        [style.--edge]=\"edge.colour\"\n      >\n        <path class=\"hit\" [attr.d]=\"edge.path\" />\n        <path class=\"line\" [attr.d]=\"edge.path\" />\n        @for (tip of edge.tips; track tip.end) {\n          @if (tip.shape === 'arrow') {\n            <path class=\"tip\" data-shape=\"arrow\" [attr.data-tip]=\"tip.end\" [attr.d]=\"tip.d\" />\n          } @else {\n            <circle\n              class=\"tip\"\n              data-shape=\"dot\"\n              [attr.data-tip]=\"tip.end\"\n              [attr.cx]=\"tip.cx\"\n              [attr.cy]=\"tip.cy\"\n              [attr.r]=\"tip.r\"\n            />\n          }\n        }\n      </g>\n    }\n    @for (note of notes(); track note.id) {\n      @if (placements().get(note.id)?.leader; as leader) {\n        <g\n          class=\"leader\"\n          [class.dim]=\"focus !== null && !focus.notes.has(note.id)\"\n          [attr.data-note]=\"note.id\"\n        >\n          <line\n            [attr.x1]=\"leader[0].x\"\n            [attr.y1]=\"leader[0].y\"\n            [attr.x2]=\"leader[1].x\"\n            [attr.y2]=\"leader[1].y\"\n          />\n          <circle [attr.cx]=\"leader[0].x\" [attr.cy]=\"leader[0].y\" r=\"2.5\" />\n        </g>\n      }\n    }\n  </svg>\n\n  <div class=\"front\">\n    @for (part of drawn().front; track part.node.id) {\n      @if (part.node.role === 'block') {\n        @if (part.opens) {\n          <button\n            type=\"button\"\n            class=\"block\"\n            data-opens\n            [class]=\"part.node.stale ? staleClasses : ''\"\n            [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n            [attr.data-node]=\"part.node.id\"\n            [attr.data-look]=\"part.look\"\n            [attr.aria-label]=\"'Open ' + part.node.label\"\n            [style.left.px]=\"part.rect.x\"\n            [style.top.px]=\"part.rect.y\"\n            [style.width.px]=\"part.rect.w\"\n            [style.height.px]=\"part.rect.h\"\n            (click)=\"open(part.node)\"\n          >\n            <ng-container *ngTemplateOutlet=\"blockContent; context: { $implicit: part.node }\" />\n            <span class=\"more\" aria-hidden=\"true\">›</span>\n          </button>\n        } @else {\n          <div\n            class=\"block\"\n            [class]=\"part.node.stale ? staleClasses : ''\"\n            [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n            [attr.data-node]=\"part.node.id\"\n            [attr.data-look]=\"part.look\"\n            [style.left.px]=\"part.rect.x\"\n            [style.top.px]=\"part.rect.y\"\n            [style.width.px]=\"part.rect.w\"\n            [style.height.px]=\"part.rect.h\"\n          >\n            <ng-container *ngTemplateOutlet=\"blockContent; context: { $implicit: part.node }\" />\n          </div>\n        }\n      } @else {\n        <div\n          class=\"bracket\"\n          [class]=\"part.node.stale ? staleClasses : ''\"\n          [class.dim]=\"focus !== null && !focus.nodes.has(part.node.id)\"\n          [attr.data-node]=\"part.node.id\"\n          [style.left.px]=\"part.rect.x\"\n          [style.top.px]=\"part.rect.y\"\n          [style.width.px]=\"part.rect.w\"\n          [style.height.px]=\"part.rect.h\"\n        >\n          <svg\n            [attr.viewBox]=\"'0 0 ' + part.rect.w + ' ' + BRACE_HEIGHT\"\n            [attr.height]=\"BRACE_HEIGHT\"\n            preserveAspectRatio=\"none\"\n            aria-hidden=\"true\"\n            focusable=\"false\"\n          >\n            <path [attr.d]=\"part.brace\" />\n          </svg>\n          <span class=\"bracket-text\">\n            <span class=\"label\">{{ part.node.label }}</span>\n            @if (part.node.detail) {\n              <!-- Spaced in the text too, so it reads as words where it is not seen. -->\n              <span class=\"separator\"> · </span>\n              <span>{{ part.node.detail }}</span>\n            }\n            @if (blockTemplate(); as body) {\n              <ng-container *ngTemplateOutlet=\"body.template; context: { $implicit: part.node }\" />\n            }\n          </span>\n        </div>\n      }\n    }\n\n    @for (edge of drawn().edges; track edge.id) {\n      @if (edge.label; as label) {\n        <code\n          class=\"edge-label\"\n          [class.dim]=\"focus !== null && !focus.edges.has(edge.id)\"\n          [attr.data-edge]=\"edge.id\"\n          [style.left.px]=\"label.at.x\"\n          [style.top.px]=\"label.at.y\"\n          >{{ label.text }}</code\n        >\n      }\n    }\n\n    @if (noteTemplate(); as content) {\n      @for (note of notes(); track note.id) {\n        @let placement = placements().get(note.id);\n        <div\n          class=\"note\"\n          [neatDiagramNoteBox]=\"note.id\"\n          [attr.data-note]=\"note.id\"\n          [class.placed]=\"placement !== undefined\"\n          [class.dim]=\"focus !== null && !focus.notes.has(note.id)\"\n          [style.left.px]=\"placement?.box?.x ?? 0\"\n          [style.top.px]=\"placement?.box?.y ?? 0\"\n        >\n          <ng-container *ngTemplateOutlet=\"content.template; context: { $implicit: note }\" />\n        </div>\n      }\n    }\n  </div>\n</div>\n\n<!--\n  The messaging layer, over the whole drawing in the box's own coordinates (it maps through the\n  transform itself), under the bar and the tip.\n-->\n<ng-content select=\"neat-diagram-messages\" />\n\n<!--\n  A block's card: its label, detail, the app's body and its chips. Spans only, since an open\n  block's card is a button, which holds phrasing content.\n-->\n<ng-template #blockContent let-node>\n  <span class=\"text\">\n    <span class=\"label\">{{ node.label }}</span>\n    @if (node.detail) {\n      <span class=\"detail\">{{ node.detail }}</span>\n    }\n    @if (blockTemplate(); as body) {\n      <span class=\"body\">\n        <ng-container *ngTemplateOutlet=\"body.template; context: { $implicit: node }\" />\n      </span>\n    }\n  </span>\n  @for (chip of node.chips ?? []; track $index) {\n    <neat-status-chip [tone]=\"chip.tone\" variant=\"tinted\">{{ chip.label }}</neat-status-chip>\n  }\n</ng-template>\n\n<!-- The level in words, after the drawing, so the picture is not only visual. -->\n<div class=\"sr-only\">\n  <ul aria-label=\"Parts\">\n    @for (part of described().nodes; track part.id) {\n      <li>{{ part.text }}</li>\n    }\n  </ul>\n  @if (described().edges.length > 0) {\n    <ul aria-label=\"Connections\">\n      @for (edge of described().edges; track edge.id) {\n        <li>{{ edge.text }}</li>\n      }\n    </ul>\n  }\n</div>\n\n<!-- Placed by the pointer (hover.ts), in the box; presentational, as the list has the words. -->\n@if (edgeTip(); as tip) {\n  <div class=\"edge-tip\" #tip aria-hidden=\"true\">\n    <ng-container *ngTemplateOutlet=\"tip.template; context: { $implicit: tip.edge }\" />\n  </div>\n}\n",
			styles: [
				".frame{position:absolute;box-sizing:border-box;padding:var(--neat-space-2) var(--neat-space-3);border:var(--frame-line) var(--frame-edge);border-radius:var(--radius);background:var(--frame-fill)}.frame[data-look=default]{--frame-line: 1px solid;--frame-edge: var(--border);--frame-fill: color-mix(in oklab, var(--muted) 35%, transparent);--frame-ink: var(--foreground);--frame-weight: 600}.frame[data-look=accent]{--frame-line: 1px solid;--frame-edge: color-mix(in oklab, var(--primary) 45%, transparent);--frame-fill: color-mix(in oklab, var(--primary) 5%, transparent);--frame-ink: var(--foreground);--frame-weight: 600}.frame[data-look=dashed]{--frame-line: 1px dashed;--frame-edge: var(--border);--frame-fill: color-mix(in oklab, var(--card) 60%, transparent);--frame-ink: var(--foreground);--frame-weight: 600}.frame[data-look=ghost]{--frame-line: 2px dashed;--frame-edge: var(--muted-foreground);--frame-fill: transparent;--frame-ink: var(--muted-foreground);--frame-weight: 400}.frame[data-look=muted]{--frame-line: 1px solid;--frame-edge: var(--border);--frame-fill: var(--muted);--frame-ink: var(--muted-foreground);--frame-weight: 600}.frame .title{font-size:var(--neat-text-base);font-weight:var(--frame-weight);color:var(--frame-ink)}.frame .detail{font-size:var(--neat-text-xs);color:var(--muted-foreground)}.band{position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;border:1px dashed var(--border);border-radius:var(--radius);font-size:var(--neat-text-xs);color:var(--muted-foreground);white-space:nowrap}.band.upright{writing-mode:vertical-rl}\n",
				".block{position:absolute;box-sizing:border-box;display:flex;align-items:center;gap:var(--neat-space-2);padding:calc(var(--neat-space-2) - var(--block-open-inset, 0px)) calc(var(--neat-space-3) - var(--block-open-inset, 0px));border:var(--block-open-line, var(--block-line)) var(--block-open-edge, var(--block-edge));border-radius:var(--radius);background:var(--block-fill);color:var(--block-ink);box-shadow:var(--block-shadow)}.block[data-look=default]{--block-line: 1px solid;--block-edge: var(--border);--block-fill: var(--card);--block-ink: var(--card-foreground);--block-shadow: var(--diagram-card-shadow);--block-weight: 600}.block[data-look=accent]{--block-line: 1px solid;--block-edge: color-mix(in oklab, var(--primary) 45%, transparent);--block-fill: color-mix(in oklab, var(--primary) 5%, var(--card));--block-ink: var(--card-foreground);--block-shadow: var(--diagram-card-shadow);--block-weight: 600}.block[data-look=dashed]{--block-line: 1px dashed;--block-edge: var(--border);--block-fill: var(--card);--block-ink: var(--card-foreground);--block-shadow: none;--block-weight: 600}.block[data-look=ghost]{--block-line: 2px dashed;--block-edge: var(--muted-foreground);--block-fill: transparent;--block-ink: var(--muted-foreground);--block-shadow: none;--block-weight: 500}.block[data-look=muted]{--block-line: 1px solid;--block-edge: var(--border);--block-fill: var(--muted);--block-ink: var(--muted-foreground);--block-shadow: none;--block-weight: 600}.block[data-opens]{--block-open-line: 2px solid;--block-open-edge: var(--primary);--block-open-inset: 1px}.block .text{flex:1;min-width:0;display:grid;gap:calc(var(--neat-space-2) / 2);justify-items:start}.block .label{font-size:var(--neat-text-sm);font-weight:var(--block-weight);line-height:1.2}.block .detail{font-size:var(--neat-text-xs);color:var(--muted-foreground);line-height:1.25}.body:empty{display:none}.more{color:var(--primary)}.bracket{position:absolute;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;gap:calc(var(--neat-space-2) / 2)}.bracket svg{display:block;width:100%;flex:none;overflow:visible}.bracket path{fill:none;stroke:var(--muted-foreground);stroke-width:1.5;stroke-linecap:round;vector-effect:non-scaling-stroke}.bracket-text{display:flex;align-items:baseline;gap:var(--neat-space-2);font-size:var(--neat-text-sm);white-space:nowrap}.bracket-text .label{font-weight:600}.separator{color:var(--muted-foreground)}\n",
				".line{fill:none;stroke:var(--edge);stroke-width:var(--edge-width);stroke-dasharray:var(--edge-dash);stroke-opacity:var(--edge-opacity)}[data-line=solid]{--edge-width: 1.5;--edge-dash: none;--edge-opacity: .75}[data-line=dashed]{--edge-width: 1.5;--edge-dash: 4 4;--edge-opacity: .75}[data-line=ghost]{--edge-width: 2;--edge-dash: 8 6;--edge-opacity: .9}\n",
				":host{--diagram-card-shadow: 0 1px 2px color-mix(in oklab, var(--foreground) 8%, transparent);--diagram-dim: .25;display:block;position:relative;overflow:clip;touch-action:none}:host(:focus-visible){outline:2px solid var(--ring);outline-offset:2px}.content{position:absolute;top:0;left:0;transform-origin:0 0}.edge-label,.note{width:max-content}.edges{--diagram-zoom: 1;position:absolute;top:0;left:0;width:1px;height:1px;overflow:visible;pointer-events:none}.hit{fill:none;stroke:transparent;stroke-width:calc(12px / var(--diagram-zoom));pointer-events:stroke}.tip{fill:var(--edge);fill-opacity:.85}.leader line{stroke:var(--muted-foreground);stroke-width:1;stroke-dasharray:2 3}.leader circle{fill:var(--muted-foreground)}.edge-label{position:absolute;transform:translate(-50%,-50%);padding:0 calc(var(--neat-space-2) / 2);border:1px solid var(--border);border-radius:calc(var(--radius) / 2);background:var(--card);color:var(--muted-foreground);font-size:var(--neat-text-xs);line-height:1.4;white-space:nowrap}.note{position:absolute;box-sizing:border-box;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--card);color:var(--card-foreground);font-size:var(--neat-text-xs);line-height:1.3;box-shadow:var(--diagram-card-shadow)}.note:not(.placed){visibility:hidden}.dim{opacity:var(--diagram-dim)}button.block{margin:0;font:inherit;text-align:start;cursor:pointer}button.block:focus-visible{outline:2px solid var(--ring);outline-offset:2px}.bar{position:absolute;z-index:1;top:0;left:0;display:flex;flex-wrap:wrap;align-items:center;gap:var(--neat-space-3);padding:var(--neat-space-2) var(--neat-space-3);pointer-events:none}.bar>*{pointer-events:auto}.crumbs{padding:calc(var(--neat-space-2) / 2) var(--neat-space-2);border-radius:var(--radius);background:color-mix(in oklab,var(--neat-surface) 85%,transparent)}.edge-tip{--neat-surface: var(--popover);position:absolute;z-index:1;top:0;left:0;box-sizing:border-box;max-width:min(16rem,100%);width:max-content;padding:var(--neat-space-2) var(--neat-space-3);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);line-height:1.35;pointer-events:none}.edge-tip:empty{display:none}\n"
			]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		diagram: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "diagram",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["levelChange"]
		}],
		highlight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "highlight",
				required: false
			}]
		}],
		blockTemplate: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatDiagramBlockTemplate), { isSignal: true }]
		}],
		noteTemplate: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatDiagramNoteTemplate), { isSignal: true }]
		}],
		edgeTipTemplate: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatDiagramEdgeTipTemplate), { isSignal: true }]
		}],
		content: [{
			type: i0.ViewChild,
			args: ["content", { isSignal: true }]
		}],
		edges: [{
			type: i0.ViewChild,
			args: ["edges", { isSignal: true }]
		}],
		tipBox: [{
			type: i0.ViewChild,
			args: ["tip", { isSignal: true }]
		}],
		bar: [{
			type: i0.ViewChild,
			args: ["bar", { isSignal: true }]
		}]
	}
});
var NeatDiagramLegend = class NeatDiagramLegend {
	items = input.required(...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	drawn = computed(() => this.items().map((item) => {
		const part = `legend item "${item.label}"`;
		const swatch = item.line === void 0 && item.series !== void 0 ? seriesIndex(item.series, part) : null;
		return {
			label: item.label,
			swatch,
			line: item.line ?? "solid",
			colour: swatch === null ? lineColour(item.series, item.line, part) : null
		};
	}), ...ngDevMode ? [{ debugName: "drawn" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramLegend,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatDiagramLegend,
		isStandalone: true,
		selector: "neat-diagram-legend",
		inputs: { items: {
			classPropertyName: "items",
			publicName: "items",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0,
		template: `
    <ul aria-label="Legend">
      @for (item of drawn(); track $index) {
        <li [style.--edge]="item.colour">
          @if (item.swatch !== null) {
            <neat-series-swatch [index]="item.swatch" />
          } @else {
            <svg
              class="sample"
              [attr.data-line]="item.line"
              viewBox="0 0 24 4"
              aria-hidden="true"
              focusable="false"
            >
              <line class="line" x1="0" y1="2" x2="24" y2="2" />
            </svg>
          }
          {{ item.label }}
        </li>
      }
    </ul>
  `,
		isInline: true,
		styles: [".line{fill:none;stroke:var(--edge);stroke-width:var(--edge-width);stroke-dasharray:var(--edge-dash);stroke-opacity:var(--edge-opacity)}[data-line=solid]{--edge-width: 1.5;--edge-dash: none;--edge-opacity: .75}[data-line=dashed]{--edge-width: 1.5;--edge-dash: 4 4;--edge-opacity: .75}[data-line=ghost]{--edge-width: 2;--edge-dash: 8 6;--edge-opacity: .9}\n", ":host{display:flex}ul{margin:0;padding:calc(var(--neat-space-2) / 2) var(--neat-space-3);list-style:none;display:flex;flex-wrap:wrap;gap:calc(var(--neat-space-2) / 2) var(--neat-space-4);border:1px solid var(--border);border-radius:calc(infinity * 1px);background:color-mix(in oklab,var(--card) 85%,transparent);font-size:var(--neat-text-xs);color:var(--muted-foreground)}li{display:flex;align-items:center;gap:var(--neat-space-2)}.sample{flex:none;width:1.5rem;height:.25rem;overflow:visible}\n"],
		dependencies: [{
			kind: "component",
			type: NeatSeriesSwatch,
			selector: "neat-series-swatch",
			inputs: ["index"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramLegend,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-diagram-legend",
			imports: [NeatSeriesSwatch],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <ul aria-label="Legend">
      @for (item of drawn(); track $index) {
        <li [style.--edge]="item.colour">
          @if (item.swatch !== null) {
            <neat-series-swatch [index]="item.swatch" />
          } @else {
            <svg
              class="sample"
              [attr.data-line]="item.line"
              viewBox="0 0 24 4"
              aria-hidden="true"
              focusable="false"
            >
              <line class="line" x1="0" y1="2" x2="24" y2="2" />
            </svg>
          }
          {{ item.label }}
        </li>
      }
    </ul>
  `,
			styles: [".line{fill:none;stroke:var(--edge);stroke-width:var(--edge-width);stroke-dasharray:var(--edge-dash);stroke-opacity:var(--edge-opacity)}[data-line=solid]{--edge-width: 1.5;--edge-dash: none;--edge-opacity: .75}[data-line=dashed]{--edge-width: 1.5;--edge-dash: 4 4;--edge-opacity: .75}[data-line=ghost]{--edge-width: 2;--edge-dash: 8 6;--edge-opacity: .9}\n", ":host{display:flex}ul{margin:0;padding:calc(var(--neat-space-2) / 2) var(--neat-space-3);list-style:none;display:flex;flex-wrap:wrap;gap:calc(var(--neat-space-2) / 2) var(--neat-space-4);border:1px solid var(--border);border-radius:calc(infinity * 1px);background:color-mix(in oklab,var(--card) 85%,transparent);font-size:var(--neat-text-xs);color:var(--muted-foreground)}li{display:flex;align-items:center;gap:var(--neat-space-2)}.sample{flex:none;width:1.5rem;height:.25rem;overflow:visible}\n"]
		}]
	}],
	propDecorators: { items: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "items",
			required: true
		}]
	}] }
});
const FRAME_PAD = 40;
const OUTSIDE_W = 300;
const OUTSIDE_H = 64;
const OUTSIDE_SPACING = 24;
const OUTSIDE_GAP = 220;
function neatDrillDownLevel(diagram, blockId) {
	const block = diagram.nodes.find((node) => node.id === blockId);
	const children = diagram.nodes.filter((node) => node.parent === blockId);
	if (!block || children.length === 0) {
		reportLeftOut(block ? `block "${blockId}" has nothing inside to drill into` : `block "${blockId}" to drill into is not on the diagram`);
		return {
			nodes: [],
			edges: []
		};
	}
	const inside = within(diagram.nodes, blockId);
	const frame = {
		...placed(block, 0, 0, Math.max(...children.map((child) => child.x + child.w)) + FRAME_PAD, Math.max(...children.map((child) => child.y + child.h)) + FRAME_PAD),
		role: "frame",
		opens: void 0
	};
	const edges = diagram.edges.filter((edge) => inside.has(edge.from) || inside.has(edge.to));
	const senders = new Set(edges.filter((edge) => !inside.has(edge.from)).map((edge) => edge.from));
	const receivers = new Set(edges.filter((edge) => !inside.has(edge.to) && !senders.has(edge.to)).map((edge) => edge.to));
	const column = (ids, x) => {
		const nodes = [...ids].flatMap((id) => {
			const node = diagram.nodes.find((n) => n.id === id);
			return node && id !== blockId ? [node] : [];
		});
		const total = nodes.length * 88 - OUTSIDE_SPACING;
		const top = (frame.h - total) / 2;
		return nodes.map((node, i) => placed(node, x, top + i * 88, OUTSIDE_W, OUTSIDE_H));
	};
	return {
		nodes: [
			frame,
			...diagram.nodes.filter((node) => inside.has(node.id)),
			...column(senders, -520),
			...column(receivers, frame.w + OUTSIDE_GAP)
		],
		edges
	};
}
function placed(node, x, y, w, h) {
	return {
		...node,
		parent: void 0,
		x,
		y,
		w,
		h,
		inSide: void 0,
		outSide: void 0
	};
}
function within(nodes, blockId) {
	const found = /* @__PURE__ */ new Set();
	let added = true;
	while (added) {
		added = false;
		for (const node of nodes) {
			const parent = node.parent;
			if (parent === void 0 || node.id === blockId || found.has(node.id)) continue;
			if (parent === blockId || found.has(parent)) {
				found.add(node.id);
				added = true;
			}
		}
	}
	return found;
}
const TRAVEL_MS = 1200;
const MAX_TRAVEL_MS = 2e4;
function travelTime(length, speed) {
	if (!(speed > 0) || !Number.isFinite(length)) return TRAVEL_MS;
	return Math.min(MAX_TRAVEL_MS, Math.max(120, length / speed * 1e3));
}
function dotRadius(bytes) {
	const r = 2 + 1.5 * Math.log10(Math.max(bytes, 1) / 1e3);
	return Math.min(7, Math.max(2, r));
}
const MAX_DOTS = 16384;
var DotModel = class {
	capacity;
	onSpawn;
	edges;
	starts;
	radii;
	colours;
	shown;
	out = [];
	frame = [];
	head = 0;
	count = 0;
	shownCount = 0;
	budget = 0;
	next = /* @__PURE__ */ new Map();
	delayOf = () => 0;
	travel = /* @__PURE__ */ new Map();
	dropped = 0;
	spawned = 0;
	travelMs = TRAVEL_MS;
	constructor(capacity = MAX_DOTS, onSpawn) {
		this.capacity = capacity;
		this.onSpawn = onSpawn;
		this.edges = new Array(capacity).fill("");
		this.starts = new Float64Array(capacity);
		this.radii = new Float32Array(capacity);
		this.colours = new Uint8Array(capacity);
		this.shown = new Uint8Array(capacity);
	}
	get size() {
		return this.count;
	}
	get visibleSize() {
		return this.shownCount;
	}
	setChain(next, delayMs) {
		this.next = next;
		this.delayOf = delayMs;
	}
	setTravel(travel) {
		this.travel = travel;
	}
	spawn(edge, atMs, bytes, colour = 0, visible = true) {
		this.budget = 32;
		this.place(edge, atMs, dotRadius(bytes), colour, bytes, visible);
	}
	advance(nowMs) {
		const frame = this.frame;
		let n = 0;
		let kept = 0;
		for (let k = 0; k < this.count; k++) {
			const i = this.slot(k);
			const t = (nowMs - this.starts[i]) / this.travelOf(this.edges[i]);
			if (!(t < 1)) {
				this.shownCount -= this.shown[i];
				continue;
			}
			const to = this.slot(kept);
			if (to !== i) {
				this.edges[to] = this.edges[i];
				this.starts[to] = this.starts[i];
				this.radii[to] = this.radii[i];
				this.colours[to] = this.colours[i];
				this.shown[to] = this.shown[i];
			}
			if (t >= 0 && this.shown[to]) {
				const dot = this.dotAt(n);
				dot.edge = this.edges[to];
				dot.t = t;
				dot.r = this.radii[to];
				dot.colour = this.colours[to];
				frame[n++] = dot;
			}
			kept++;
		}
		this.count = kept;
		if (frame.length !== n) frame.length = n;
		return frame;
	}
	clear() {
		this.count = 0;
		this.shownCount = 0;
		this.head = 0;
	}
	slot(k) {
		const i = this.head + k;
		return i < this.capacity ? i : i - this.capacity;
	}
	dotAt(n) {
		if (n === this.out.length) this.out.push({
			edge: "",
			t: 0,
			r: 0,
			colour: 0
		});
		return this.out[n];
	}
	travelOf(edge) {
		return this.travel.get(edge) ?? this.travelMs;
	}
	place(edge, atMs, r, colour, bytes, visible) {
		if (!Number.isFinite(atMs) || this.budget === 0) return;
		this.budget--;
		if (this.count === this.capacity) {
			this.shownCount -= this.shown[this.head];
			this.head = this.slot(1);
			this.count--;
			this.dropped++;
		}
		const i = this.slot(this.count++);
		this.edges[i] = edge;
		this.starts[i] = atMs;
		this.radii[i] = r;
		this.colours[i] = colour;
		this.shown[i] = visible ? 1 : 0;
		if (visible) {
			this.spawned++;
			this.shownCount++;
		}
		this.onSpawn?.(edge, atMs, bytes);
		const following = this.next.get(edge);
		if (!following) return;
		const arrival = atMs + this.travelOf(edge);
		for (const step of following) {
			const delay = this.delayOf(step);
			const start = arrival + (Number.isFinite(delay) ? delay : 0);
			this.place(step, start, r, colour, bytes, visible);
		}
	}
};
function chainOf(edges, steps) {
	const leaving = /* @__PURE__ */ new Map();
	for (const edge of edges) {
		if (!Object.hasOwn(steps, edge.id)) continue;
		const from = leaving.get(edge.from);
		if (from) from.push(edge.id);
		else leaving.set(edge.from, [edge.id]);
	}
	const next = /* @__PURE__ */ new Map();
	for (const edge of edges) {
		const following = leaving.get(edge.to);
		if (following) next.set(edge.id, following);
	}
	return next;
}
function neatBatchTimes(offsetsMs, arrivalMs) {
	let first = Infinity;
	for (const ms of offsetsMs) if (ms < first) first = ms;
	return offsetsMs.map((ms) => Number.isFinite(ms) ? arrivalMs + Math.min(200, ms - first) : arrivalMs);
}
var DotEvery = class {
	every = 1;
	seen = /* @__PURE__ */ new Map();
	set(n) {
		const every = Math.max(1, Math.round(n) || 1);
		if (every === this.every) return;
		this.every = every;
		this.seen.clear();
	}
	take(edge) {
		if (this.every === 1) return true;
		const n = this.seen.get(edge) ?? 0;
		this.seen.set(edge, n + 1 === this.every ? 0 : n + 1);
		return n === 0;
	}
};
const REFERENCE_ZOOM = .75;
const SPRITE_DETAIL = 4;
const CORE_MIX = .55;
const CORE_SIZE = .45;
const SIZE_PER_RADIUS = 2;
const DIM_FALLBACK = .25;
const RADIUS_FALLBACK = 8;
var DotCanvas = class {
	canvas;
	host;
	context = null;
	boxWidth = 0;
	boxHeight = 0;
	width = 0;
	height = 0;
	ratio = 0;
	sprites = [];
	palette = null;
	spriteRatio = 0;
	dim = DIM_FALLBACK;
	radius = RADIUS_FALLBACK;
	mapped = /* @__PURE__ */ new Map();
	source = null;
	k = NaN;
	x = NaN;
	y = NaN;
	alpha = 1;
	point = {
		x: 0,
		y: 0
	};
	constructor(canvas, host) {
		this.canvas = canvas;
		this.host = host;
	}
	size(width, height) {
		this.boxWidth = width;
		this.boxHeight = height;
	}
	begin(ratio, readPalette, geometry, transform) {
		if (this.boxWidth === 0 || this.boxHeight === 0) return false;
		if (this.boxWidth !== this.width || this.boxHeight !== this.height || ratio !== this.ratio) {
			this.width = this.boxWidth;
			this.height = this.boxHeight;
			this.ratio = ratio;
			this.canvas.width = Math.round(this.width * ratio);
			this.canvas.height = Math.round(this.height * ratio);
		}
		this.context ??= this.canvas.getContext("2d");
		const context = this.context;
		if (!context) return false;
		const palette = readPalette();
		if (palette !== this.palette || ratio !== this.spriteRatio) this.paint(palette, ratio);
		const { k, x, y } = transform;
		if (geometry !== this.source || k !== this.k || x !== this.x || y !== this.y) this.map(geometry, transform);
		context.setTransform(ratio, 0, 0, ratio, 0, 0);
		context.clearRect(0, 0, this.width, this.height);
		return true;
	}
	drawDots(dots, size, focus, covers) {
		const context = this.start();
		const scale = size * this.k / REFERENCE_ZOOM;
		let drawn = 0;
		for (const dot of dots) if (this.sprite(context, dot.edge, dot.t, dot.r * scale, dot.colour, focus)) drawn++;
		this.erase(context, covers);
		return drawn;
	}
	drawMarks(marks, since, now, size, focus, covers) {
		const context = this.start();
		const scale = size * this.k / REFERENCE_ZOOM;
		let drawn = 0;
		for (const mark of marks) {
			if (mark.at <= since || mark.at > now) continue;
			const length = this.mapped.get(mark.edge)?.geometry.length ?? 0;
			const t = length > 0 ? 1 - mark.r * scale / this.k / length : 1;
			if (this.sprite(context, mark.edge, t, mark.r * scale, mark.colour, focus)) drawn++;
		}
		this.erase(context, covers);
		return drawn;
	}
	start() {
		const context = this.context;
		context.globalAlpha = this.alpha = 1;
		return context;
	}
	erase(context, covers) {
		if (covers.length === 0) return;
		const { k, x, y } = this;
		context.globalAlpha = this.alpha = 1;
		context.globalCompositeOperation = "destination-out";
		context.beginPath();
		for (const c of covers) context.roundRect(c.x * k + x, c.y * k + y, c.w * k, c.h * k, this.radius * k);
		context.fill();
		context.globalCompositeOperation = "source-over";
	}
	sprite(context, edge, t, r, colour, focus) {
		const mapped = this.mapped.get(edge);
		const sprite = this.sprites[colour] ?? this.sprites[0];
		if (!mapped || !sprite) return false;
		const at = mapped.geometry.at(t, this.point, mapped.screen);
		const alpha = focus === null || focus.has(edge) ? 1 : this.dim;
		if (alpha !== this.alpha) context.globalAlpha = this.alpha = alpha;
		const size = SIZE_PER_RADIUS * r;
		context.drawImage(sprite, at.x - size / 2, at.y - size / 2, size, size);
		return true;
	}
	map(geometry, { k, x, y }) {
		if (geometry !== this.source) {
			this.mapped.clear();
			for (const [id, edge] of geometry) this.mapped.set(id, {
				geometry: edge,
				screen: new Float32Array(edge.xy.length)
			});
			this.source = geometry;
		}
		for (const { geometry: edge, screen } of this.mapped.values()) {
			const { xy } = edge;
			for (let i = 0; i < xy.length; i += 2) {
				screen[i] = xy[i] * k + x;
				screen[i + 1] = xy[i + 1] * k + y;
			}
		}
		this.k = k;
		this.x = x;
		this.y = y;
	}
	paint(palette, ratio) {
		this.palette = palette;
		this.spriteRatio = ratio;
		const style = getComputedStyle(this.host);
		const dim = parseFloat(style.getPropertyValue("--diagram-dim"));
		this.dim = Number.isFinite(dim) ? dim : DIM_FALLBACK;
		this.radius = pixels(style.getPropertyValue("--radius")) ?? RADIUS_FALLBACK;
		const muted = palette[0];
		this.sprites = palette.map((colour) => {
			const fill = colour ?? muted;
			return fill ? sprite(fill, ratio * SPRITE_DETAIL) : null;
		});
	}
};
function sprite(fill, ratio) {
	const size = 14;
	const canvas = document.createElement("canvas");
	canvas.width = canvas.height = Math.ceil(size * ratio);
	const context = canvas.getContext("2d");
	if (!context) return canvas;
	context.scale(ratio, ratio);
	const c = size / 2;
	context.fillStyle = css(fill);
	context.beginPath();
	context.arc(c, c, 6, 0, 2 * Math.PI);
	context.fill();
	const [red, green, blue] = fill;
	const core = (v) => v + (1 - v) * CORE_MIX;
	context.fillStyle = css([
		core(red),
		core(green),
		core(blue)
	]);
	context.beginPath();
	context.arc(c, c, 6 * CORE_SIZE, 0, 2 * Math.PI);
	context.fill();
	return canvas;
}
function css([red, green, blue]) {
	const byte = (v) => Math.round(v * 255);
	return `rgb(${byte(red)} ${byte(green)} ${byte(blue)})`;
}
function pixels(value) {
	const n = parseFloat(value);
	if (!Number.isFinite(n)) return null;
	if (value.trim().endsWith("rem")) return n * parseFloat(getComputedStyle(document.documentElement).fontSize || "16");
	return value.trim().endsWith("px") ? n : null;
}
var EdgeGeometry = class EdgeGeometry {
	length;
	lut;
	xy;
	constructor(length, lut, xy) {
		this.length = length;
		this.lut = lut;
		this.xy = xy;
	}
	static fromPoints(points) {
		const drawn = points.length > 1 ? sampleRoute(points[0], roundCorners([...points])) : points;
		const lut = new Float32Array(drawn.length);
		const xy = new Float32Array(2 * drawn.length);
		let length = 0;
		drawn.forEach((p, i) => {
			if (i > 0) length += Math.hypot(p.x - drawn[i - 1].x, p.y - drawn[i - 1].y);
			lut[i] = length;
			xy[2 * i] = p.x;
			xy[2 * i + 1] = p.y;
		});
		return new EdgeGeometry(length, lut, xy);
	}
	at(t, into, xy = this.xy) {
		const { lut } = this;
		const last = lut.length - 1;
		const target = (t > 0 ? Math.min(t, 1) : 0) * this.length;
		if (last < 1 || target <= 0) {
			into.x = xy[0];
			into.y = xy[1];
			return into;
		}
		let lo = 1;
		let hi = last;
		while (lo < hi) {
			const mid = lo + hi >> 1;
			if (lut[mid] < target) lo = mid + 1;
			else hi = mid;
		}
		const run = lut[lo] - lut[lo - 1];
		const f = run > 0 ? Math.min(1, (target - lut[lo - 1]) / run) : 1;
		into.x = xy[2 * lo - 2] + (xy[2 * lo] - xy[2 * lo - 2]) * f;
		into.y = xy[2 * lo - 1] + (xy[2 * lo + 1] - xy[2 * lo - 1]) * f;
		return into;
	}
};
const RATE_WINDOW_MS = 1e3;
const BUCKETS = 256;
const FIRST_RING = 32;
const NO_HISTORY = Object.freeze([]);
var EdgeRates = class {
	capacity;
	tracks = /* @__PURE__ */ new Map();
	constructor(capacity = 4096) {
		this.capacity = capacity;
	}
	count(edge, bytes, atMs, nowMs = atMs) {
		if (!Number.isFinite(atMs)) return;
		const track = this.tracks.get(edge) ?? this.track(edge);
		if (track.size === track.at.length && track.size < this.capacity && track.at[track.next] > nowMs - 1e3) grow(track, this.capacity);
		track.at[track.next] = atMs;
		track.bytes[track.next] = bytes;
		track.next = (track.next + 1) % track.at.length;
		track.size = Math.min(track.size + 1, track.at.length);
		const second = Math.floor(atMs / 1e3);
		const bucket = bucketOf(second);
		if (track.seconds[bucket] > second) return;
		if (track.seconds[bucket] !== second) {
			track.seconds[bucket] = second;
			track.counts[bucket] = 0;
		}
		track.counts[bucket]++;
		if (second < track.first) track.first = second;
		if (second <= track.historyTo) track.historyTo = NaN;
	}
	snapshot(edge, nowMs, into = {
		msgsPerSec: 0,
		bytesPerSec: 0
	}) {
		let msgs = 0;
		let bytes = 0;
		const track = this.tracks.get(edge);
		if (track) {
			const from = nowMs - RATE_WINDOW_MS;
			for (let i = 0; i < track.size; i++) {
				const at = track.at[i];
				if (at > from && at <= nowMs) {
					msgs++;
					bytes += track.bytes[i];
				}
			}
		}
		const perSecond = 1e3 / RATE_WINDOW_MS;
		into.msgsPerSec = msgs * perSecond;
		into.bytesPerSec = bytes * perSecond;
		return into;
	}
	history(edge, nowMs) {
		const track = this.tracks.get(edge);
		if (!track) return NO_HISTORY;
		const last = Math.floor(nowMs / 1e3) - 1;
		if (last === track.historyTo) return track.history;
		const values = [];
		for (let s = Math.max(track.first, last - 60 + 1); s <= last; s++) {
			const bucket = bucketOf(s);
			values.push(track.seconds[bucket] === s ? track.counts[bucket] : 0);
		}
		track.history = values;
		track.historyTo = last;
		return values;
	}
	ringLength(edge) {
		return this.tracks.get(edge)?.at.length ?? 0;
	}
	clear() {
		this.tracks.clear();
	}
	track(edge) {
		const track = {
			at: new Float64Array(Math.min(FIRST_RING, this.capacity)),
			bytes: new Float64Array(Math.min(FIRST_RING, this.capacity)),
			next: 0,
			size: 0,
			counts: new Float64Array(BUCKETS),
			seconds: new Float64Array(BUCKETS).fill(NaN),
			first: Infinity,
			history: NO_HISTORY,
			historyTo: NaN
		};
		this.tracks.set(edge, track);
		return track;
	}
};
function grow(track, capacity) {
	const length = Math.min(2 * track.at.length, capacity);
	const at = new Float64Array(length);
	const bytes = new Float64Array(length);
	const { next } = track;
	at.set(track.at.subarray(next));
	at.set(track.at.subarray(0, next), track.at.length - next);
	bytes.set(track.bytes.subarray(next));
	bytes.set(track.bytes.subarray(0, next), track.bytes.length - next);
	track.next = track.at.length;
	track.at = at;
	track.bytes = bytes;
}
function bucketOf(second) {
	return (second % BUCKETS + BUCKETS) % BUCKETS;
}
function sumHistories(histories, previous) {
	if (previous && previous.parts.length === histories.length && previous.parts.every((part, i) => part === histories[i])) return previous;
	if (histories.length === 1) return {
		parts: histories,
		sum: histories[0]
	};
	const length = Math.max(0, ...histories.map((history) => history.length));
	const sum = new Array(length).fill(0);
	for (const history of histories) {
		const offset = length - history.length;
		for (let i = 0; i < history.length; i++) sum[offset + i] += history[i];
	}
	return {
		parts: histories,
		sum
	};
}
const NEAT_DIAGRAM_MESSAGE_DEFAULTS = Object.freeze({
	speed: 270,
	size: 1,
	every: 1,
	steps: true
});
const NUMBERS_MS = 80;
const REDUCED_MOTION = "(prefers-reduced-motion: reduce)";
const PALETTE_ORDER = ["muted", ...Array.from({ length: 8 }, (_, i) => `series${i + 1}`)];
const PALETTE_TOKENS = Object.fromEntries(PALETTE_ORDER.map((name, i) => [name, i === 0 ? MUTED_TOKEN : ɵseriesTokenName(i - 1)]));
const NO_DOTS = [];
const NO_CHAIN = /* @__PURE__ */ new Map();
const isSeries = (n) => typeof n === "number" && Number.isInteger(n) && n >= 1 && n <= 8;
function colourOf(edge, chosen) {
	if (isSeries(chosen)) return chosen;
	return edge.line !== "ghost" && isSeries(edge.series) ? edge.series : 0;
}
const sameRate = (a, b) => a.msgsPerSec === b.msgsPerSec && a.bytesPerSec === b.bytesPerSec && a.history === b.history;
var NeatDiagramMessages = class NeatDiagramMessages {
	steps = input({}, ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	passive = input([], ...ngDevMode ? [{ debugName: "passive" }] : /* istanbul ignore next */ []);
	colours = input({}, ...ngDevMode ? [{ debugName: "colours" }] : /* istanbul ignore next */ []);
	settings = input(NEAT_DIAGRAM_MESSAGE_DEFAULTS, ...ngDevMode ? [{ debugName: "settings" }] : /* istanbul ignore next */ []);
	diagram = inject(DIAGRAM_MESSAGES_CONTEXT);
	probe = inject(DOT_FRAME_PROBE, { optional: true });
	host = inject(ElementRef).nativeElement;
	document = inject(DOCUMENT);
	zone = inject(NgZone);
	canvasElement = viewChild.required("canvas", ...ngDevMode ? [{ debugName: "canvasElement" }] : /* istanbul ignore next */ []);
	theme = neatThemeColors(PALETTE_TOKENS, () => this.host);
	palette = computed(() => {
		const colours = this.theme();
		return PALETTE_ORDER.map((name) => colours[name]);
	}, ...ngDevMode ? [{ debugName: "palette" }] : /* istanbul ignore next */ []);
	readPalette = () => this.palette();
	rates = new EdgeRates();
	model = new DotModel(MAX_DOTS, (edge, atMs, bytes) => this.rates.count(edge, bytes, atMs, this.pushedAt));
	pushedAt = 0;
	every = new DotEvery();
	stages = /* @__PURE__ */ new Map();
	marks = /* @__PURE__ */ new Map();
	markList = [];
	marksUntil = -Infinity;
	motion = typeof matchMedia === "function" ? matchMedia(REDUCED_MOTION) : null;
	canvas = null;
	frame = 0;
	lastNow = -Infinity;
	destroyed = false;
	levelKey = null;
	chainGiven = null;
	travelGiven = null;
	numbers = signal(0, ...ngDevMode ? [{ debugName: "numbers" }] : /* istanbul ignore next */ []);
	numbersTimer;
	numbersRead = false;
	rateSignals = /* @__PURE__ */ new Map();
	geometry = computed(() => new Map(this.diagram.level().edges.map((edge) => [edge.id, EdgeGeometry.fromPoints(edge.points)])), ...ngDevMode ? [{ debugName: "geometry" }] : /* istanbul ignore next */ []);
	speed = computed(() => this.settings().speed, ...ngDevMode ? [{ debugName: "speed" }] : /* istanbul ignore next */ []);
	travel = computed(() => {
		const speed = this.speed();
		const travel = /* @__PURE__ */ new Map();
		for (const [id, edge] of this.geometry()) travel.set(id, travelTime(edge.length, speed));
		return travel;
	}, ...ngDevMode ? [{ debugName: "travel" }] : /* istanbul ignore next */ []);
	stepsOn = computed(() => this.settings().steps, ...ngDevMode ? [{ debugName: "stepsOn" }] : /* istanbul ignore next */ []);
	chain = computed(() => {
		if (!this.stepsOn()) return NO_CHAIN;
		const next = chainOf(this.diagram.level().edges, this.steps());
		for (const id of this.passive()) next.delete(id);
		return next;
	}, ...ngDevMode ? [{ debugName: "chain" }] : /* istanbul ignore next */ []);
	edgeColours = computed(() => {
		const chosen = this.colours();
		return new Map(this.diagram.level().edges.map((edge) => [edge.id, colourOf(edge, Object.hasOwn(chosen, edge.id) ? chosen[edge.id] : void 0)]));
	}, ...ngDevMode ? [{ debugName: "edgeColours" }] : /* istanbul ignore next */ []);
	constructor() {
		const stopTransform = this.diagram.onTransform(this.wake);
		let observer = null;
		afterNextRender(() => this.zone.runOutsideAngular(() => {
			if (this.destroyed) return;
			this.canvas = new DotCanvas(this.canvasElement().nativeElement, this.host);
			observer = new ResizeObserver((entries) => {
				const box = entries.at(-1)?.borderBoxSize?.[0];
				if (!box) return;
				this.canvas?.size(box.inlineSize, box.blockSize);
				this.wake();
			});
			observer.observe(this.host);
			this.document.addEventListener("visibilitychange", this.visibility);
		}));
		inject(DestroyRef).onDestroy(() => {
			this.destroyed = true;
			this.cancel();
			stopTransform();
			observer?.disconnect();
			this.document.removeEventListener("visibilitychange", this.visibility);
			clearInterval(this.numbersTimer);
			this.numbersTimer = void 0;
			this.model.clear();
		});
	}
	push(edgeId, bytes, atMs = performance.now()) {
		if (this.destroyed) return;
		untracked(() => {
			if (!this.diagram.edgeIds().has(edgeId)) return;
			const size = Number.isFinite(bytes) && bytes > 0 ? bytes : 0;
			const drawn = this.sync().has(edgeId);
			this.pushedAt = performance.now();
			if (!drawn || this.document.hidden) {
				this.rates.count(edgeId, size, atMs, this.pushedAt);
				return;
			}
			this.every.set(this.settings().every);
			const colour = this.edgeColours().get(edgeId) ?? 0;
			this.model.spawn(edgeId, atMs, size, colour, this.every.take(edgeId));
			if (this.reduced()) this.mark(edgeId, atMs, size, colour);
			this.request();
		});
	}
	stageMs(nodeId, stage, ms) {
		const stages = this.stages.get(nodeId) ?? /* @__PURE__ */ new Map();
		this.stages.set(nodeId, stages);
		if (Number.isFinite(ms) && ms >= 0) stages.set(stage, ms);
		else stages.delete(stage);
	}
	rate(edgeIds) {
		const ids = [...new Set(typeof edgeIds === "string" ? [edgeIds] : edgeIds)];
		const key = JSON.stringify(ids);
		let rate = this.rateSignals.get(key);
		if (!rate) {
			let summed;
			rate = computed(() => {
				this.numbers();
				this.numbersWanted();
				const now = performance.now();
				let msgsPerSec = 0;
				let bytesPerSec = 0;
				for (const id of ids) {
					const edge = this.rates.snapshot(id, now);
					msgsPerSec += edge.msgsPerSec;
					bytesPerSec += edge.bytesPerSec;
				}
				summed = sumHistories(ids.map((id) => this.rates.history(id, now)), summed);
				return {
					msgsPerSec,
					bytesPerSec,
					history: summed.sum
				};
			}, { equal: sameRate });
			this.rateSignals.set(key, rate);
		}
		return rate;
	}
	numbersWanted() {
		this.numbersRead = true;
		if (this.numbersTimer !== void 0 || this.destroyed) return;
		this.numbersTimer = this.zone.runOutsideAngular(() => setInterval(() => {
			if (!this.numbersRead) {
				clearInterval(this.numbersTimer);
				this.numbersTimer = void 0;
				return;
			}
			this.numbersRead = false;
			this.numbers.update((n) => n + 1);
		}, NUMBERS_MS));
	}
	sync() {
		const level = this.diagram.level();
		if (level.key !== this.levelKey) {
			if (this.levelKey !== null) this.clear();
			this.levelKey = level.key;
		}
		const chain = this.chain();
		if (chain !== this.chainGiven) {
			this.model.setChain(chain, this.stageDelay);
			this.chainGiven = chain;
		}
		const travel = this.travel();
		if (travel !== this.travelGiven) {
			this.model.setTravel(travel);
			this.travelGiven = travel;
		}
		return this.geometry();
	}
	stageDelay = (step) => {
		const steps = this.steps();
		if (!Object.hasOwn(steps, step)) return 0;
		const { from, stage, shares } = steps[step];
		const ms = this.stages.get(from)?.get(stage) ?? 0;
		return shares !== void 0 && Number.isFinite(shares) && shares > 0 ? ms / shares : ms;
	};
	mark(edge, at, bytes, colour) {
		let mark = this.marks.get(edge);
		if (!mark) {
			mark = {
				edge,
				at,
				r: 0,
				colour
			};
			this.marks.set(edge, mark);
			this.markList.push(mark);
		}
		mark.at = at;
		mark.r = dotRadius(bytes);
		mark.colour = colour;
		this.marksUntil = Math.max(this.marksUntil, at + 400);
	}
	clear() {
		this.model.clear();
		this.marks.clear();
		this.markList.length = 0;
		this.marksUntil = -Infinity;
	}
	reduced() {
		return this.motion?.matches ?? false;
	}
	busy(now) {
		return this.marksUntil > now || !this.reduced() && this.model.visibleSize > 0;
	}
	cancel() {
		if (this.frame !== 0) cancelAnimationFrame(this.frame);
		this.frame = 0;
	}
	request() {
		if (this.frame !== 0 || this.destroyed || this.document.hidden) return;
		this.frame = this.zone.runOutsideAngular(() => requestAnimationFrame(this.tick));
	}
	wake = () => {
		if (this.busy(this.lastNow)) this.request();
	};
	visibility = () => {
		if (this.document.hidden) {
			this.cancel();
			this.clear();
		} else this.request();
	};
	tick = (time) => {
		this.frame = 0;
		if (this.destroyed) return;
		const started = this.probe ? performance.now() : 0;
		const drawn = this.draw(time);
		if (drawn !== null) this.probe?.(performance.now() - started, drawn);
		if (this.busy(this.lastNow)) this.request();
	};
	draw(time) {
		const now = Math.max(time, this.lastNow);
		this.lastNow = now;
		const geometry = this.sync();
		const reduced = this.reduced();
		const dots = reduced ? NO_DOTS : this.model.advance(now);
		const ratio = typeof devicePixelRatio === "number" && devicePixelRatio > 0 ? devicePixelRatio : 1;
		const canvas = this.canvas;
		if (!canvas?.begin(ratio, this.readPalette, geometry, this.diagram.transform())) return null;
		const size = this.settings().size;
		const scale = Number.isFinite(size) && size > 0 ? size : 1;
		const focus = this.diagram.focus();
		const covers = this.diagram.covers();
		return reduced ? canvas.drawMarks(this.markList, now - 400, now, scale, focus, covers) : canvas.drawDots(dots, scale, focus, covers);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramMessages,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatDiagramMessages,
		isStandalone: true,
		selector: "neat-diagram-messages",
		inputs: {
			steps: {
				classPropertyName: "steps",
				publicName: "steps",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			passive: {
				classPropertyName: "passive",
				publicName: "passive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			colours: {
				classPropertyName: "colours",
				publicName: "colours",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			settings: {
				classPropertyName: "settings",
				publicName: "settings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "aria-hidden": "true" } },
		viewQueries: [{
			propertyName: "canvasElement",
			first: true,
			predicate: ["canvas"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<canvas #canvas></canvas>",
		isInline: true,
		styles: [":host{position:absolute;inset:0;display:block;pointer-events:none}canvas{position:absolute;inset:0;display:block;width:100%;height:100%}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramMessages,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-diagram-messages",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "aria-hidden": "true" },
			template: "<canvas #canvas></canvas>",
			styles: [":host{position:absolute;inset:0;display:block;pointer-events:none}canvas{position:absolute;inset:0;display:block;width:100%;height:100%}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		steps: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steps",
				required: false
			}]
		}],
		passive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "passive",
				required: false
			}]
		}],
		colours: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "colours",
				required: false
			}]
		}],
		settings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "settings",
				required: false
			}]
		}],
		canvasElement: [{
			type: i0.ViewChild,
			args: ["canvas", { isSignal: true }]
		}]
	}
});
const LIMITS = {
	speed: {
		min: 50,
		max: 1e3,
		step: 10
	},
	size: {
		min: .5,
		max: 2,
		step: .1
	},
	every: {
		min: 1,
		max: 10,
		step: 1
	}
};
function neatParseMessageSettings(raw) {
	if (typeof raw !== "object" || raw === null) return NEAT_DIAGRAM_MESSAGE_DEFAULTS;
	const record = raw;
	const pick = (key) => {
		const value = record[key];
		if (typeof value !== "number" || !Number.isFinite(value)) return NEAT_DIAGRAM_MESSAGE_DEFAULTS[key];
		const { min, max } = LIMITS[key];
		return Math.min(max, Math.max(min, key === "every" ? Math.round(value) : value));
	};
	return {
		speed: pick("speed"),
		size: pick("size"),
		every: pick("every"),
		steps: typeof record["steps"] === "boolean" ? record["steps"] : NEAT_DIAGRAM_MESSAGE_DEFAULTS.steps
	};
}
var NeatDiagramAnimationSettings = class NeatDiagramAnimationSettings {
	settings = model(NEAT_DIAGRAM_MESSAGE_DEFAULTS, ...ngDevMode ? [{ debugName: "settings" }] : /* istanbul ignore next */ []);
	limits = LIMITS;
	defaults = NEAT_DIAGRAM_MESSAGE_DEFAULTS;
	set(change) {
		this.settings.update((settings) => ({
			...settings,
			...change
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramAnimationSettings,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatDiagramAnimationSettings,
		isStandalone: true,
		selector: "neat-diagram-animation-settings",
		inputs: { settings: {
			classPropertyName: "settings",
			publicName: "settings",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		outputs: { settings: "settingsChange" },
		ngImport: i0,
		template: `
    <neat-popover label="Animation" align="end">
      <button
        neatButton
        neatPopoverTrigger
        variant="text"
        size="small"
        iconOnly
        type="button"
        aria-label="Animation"
      >
        <neat-icon name="palette" [size]="16" />
      </button>
      <ng-template neatPopoverContent>
        @let s = settings();
        <div class="tuning">
          <div class="heading">Animation</div>
          <div class="row">
            <span>Speed</span><span class="value">{{ s.speed }} px/s</span>
          </div>
          <neat-slider
            label="Speed of the dots"
            [min]="limits.speed.min"
            [max]="limits.speed.max"
            [step]="limits.speed.step"
            [value]="s.speed"
            (valueChange)="set({ speed: $event })"
          />
          <div class="row">
            <span>Dot size</span><span class="value">× {{ s.size.toFixed(1) }}</span>
          </div>
          <neat-slider
            label="Dot size"
            [min]="limits.size.min"
            [max]="limits.size.max"
            [step]="limits.size.step"
            [value]="s.size"
            (valueChange)="set({ size: $event })"
          />
          <div class="row">
            <span>Messages per dot</span>
            <span class="value">1 dot = {{ s.every }} {{ s.every === 1 ? 'msg' : 'msgs' }}</span>
          </div>
          <neat-slider
            label="Messages per dot: an edge shows a dot for every Nth message on it"
            [min]="limits.every.min"
            [max]="limits.every.max"
            [step]="limits.every.step"
            [value]="s.every"
            (valueChange)="set({ every: $event })"
          />
          <button
            neatSwitch
            type="button"
            [checked]="s.steps"
            (checkedChange)="set({ steps: $event })"
          >
            Dots inside the blocks
          </button>
          <button
            neatButton
            variant="outlined"
            size="small"
            type="button"
            (click)="settings.set(defaults)"
          >
            Reset to defaults
          </button>
        </div>
      </ng-template>
    </neat-popover>
  `,
		isInline: true,
		styles: [":host{display:contents}.tuning{display:flex;flex-direction:column;gap:var(--neat-space-2);font-size:var(--neat-text-sm)}.heading{font-weight:var(--font-weight-semibold)}.row{display:flex;justify-content:space-between;margin-top:var(--neat-space-2);color:var(--muted-foreground)}.value{color:var(--foreground);font-variant-numeric:tabular-nums}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatPopover,
				selector: "neat-popover",
				inputs: ["open", "label"],
				outputs: ["openChange"]
			},
			{
				kind: "directive",
				type: NeatPopoverContent,
				selector: "ng-template[neatPopoverContent]"
			},
			{
				kind: "directive",
				type: NeatPopoverTrigger,
				selector: "button[neatPopoverTrigger]"
			},
			{
				kind: "component",
				type: NeatSlider,
				selector: "neat-slider",
				inputs: [
					"value",
					"min",
					"max",
					"step",
					"label",
					"describedBy"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: NeatSwitch,
				selector: "button[neatSwitch]",
				inputs: ["checked", "disabled"],
				outputs: ["checkedChange"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramAnimationSettings,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-diagram-animation-settings",
			imports: [
				NeatButton,
				NeatIcon,
				NeatPopover,
				NeatPopoverContent,
				NeatPopoverTrigger,
				NeatSlider,
				NeatSwitch
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <neat-popover label="Animation" align="end">
      <button
        neatButton
        neatPopoverTrigger
        variant="text"
        size="small"
        iconOnly
        type="button"
        aria-label="Animation"
      >
        <neat-icon name="palette" [size]="16" />
      </button>
      <ng-template neatPopoverContent>
        @let s = settings();
        <div class="tuning">
          <div class="heading">Animation</div>
          <div class="row">
            <span>Speed</span><span class="value">{{ s.speed }} px/s</span>
          </div>
          <neat-slider
            label="Speed of the dots"
            [min]="limits.speed.min"
            [max]="limits.speed.max"
            [step]="limits.speed.step"
            [value]="s.speed"
            (valueChange)="set({ speed: $event })"
          />
          <div class="row">
            <span>Dot size</span><span class="value">× {{ s.size.toFixed(1) }}</span>
          </div>
          <neat-slider
            label="Dot size"
            [min]="limits.size.min"
            [max]="limits.size.max"
            [step]="limits.size.step"
            [value]="s.size"
            (valueChange)="set({ size: $event })"
          />
          <div class="row">
            <span>Messages per dot</span>
            <span class="value">1 dot = {{ s.every }} {{ s.every === 1 ? 'msg' : 'msgs' }}</span>
          </div>
          <neat-slider
            label="Messages per dot: an edge shows a dot for every Nth message on it"
            [min]="limits.every.min"
            [max]="limits.every.max"
            [step]="limits.every.step"
            [value]="s.every"
            (valueChange)="set({ every: $event })"
          />
          <button
            neatSwitch
            type="button"
            [checked]="s.steps"
            (checkedChange)="set({ steps: $event })"
          >
            Dots inside the blocks
          </button>
          <button
            neatButton
            variant="outlined"
            size="small"
            type="button"
            (click)="settings.set(defaults)"
          >
            Reset to defaults
          </button>
        </div>
      </ng-template>
    </neat-popover>
  `,
			styles: [":host{display:contents}.tuning{display:flex;flex-direction:column;gap:var(--neat-space-2);font-size:var(--neat-text-sm)}.heading{font-weight:var(--font-weight-semibold)}.row{display:flex;justify-content:space-between;margin-top:var(--neat-space-2);color:var(--muted-foreground)}.value{color:var(--foreground);font-variant-numeric:tabular-nums}\n"]
		}]
	}],
	propDecorators: { settings: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "settings",
			required: false
		}]
	}, {
		type: i0.Output,
		args: ["settingsChange"]
	}] }
});
const perSecond = (value) => `${Math.round(value)} msg/s`;
var NeatDiagramRateCard = class NeatDiagramRateCard {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	rate = input.required(...ngDevMode ? [{ debugName: "rate" }] : /* istanbul ignore next */ []);
	stageMs = input(void 0, ...ngDevMode ? [{ debugName: "stageMs" }] : /* istanbul ignore next */ []);
	showBytes = input(true, ...ngDevMode ? [{ debugName: "showBytes" }] : /* istanbul ignore next */ []);
	perSecond = perSecond;
	msgs = computed(() => String(Math.round(this.rate().msgsPerSec)), ...ngDevMode ? [{ debugName: "msgs" }] : /* istanbul ignore next */ []);
	megabytes = computed(() => (Math.round(this.rate().bytesPerSec / 1e4) / 100).toFixed(2), ...ngDevMode ? [{ debugName: "megabytes" }] : /* istanbul ignore next */ []);
	stage = computed(() => {
		const ms = this.stageMs();
		return ms !== void 0 && Number.isFinite(ms) && ms >= 0 ? ms.toFixed(1) : null;
	}, ...ngDevMode ? [{ debugName: "stage" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatDiagramRateCard,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatDiagramRateCard,
		isStandalone: true,
		selector: "neat-diagram-rate-card",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			rate: {
				classPropertyName: "rate",
				publicName: "rate",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			stageMs: {
				classPropertyName: "stageMs",
				publicName: "stageMs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showBytes: {
				classPropertyName: "showBytes",
				publicName: "showBytes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "class.timed": "stage() !== null" } },
		ngImport: i0,
		template: `
    <div class="label">{{ label() }}</div>
    <ng-content select="[neatRateCardThumbnails]" />
    <div class="numbers">
      <span
        ><span class="value">{{ msgs() }}</span> msg/s</span
      >
      @if (stage() === null && showBytes()) {
        <span
          ><span class="value">{{ megabytes() }}</span> MB/s</span
        >
      }
    </div>
    @if (stage(); as ms) {
      <div class="stage">
        Stage <span class="value">{{ ms }}</span> ms
      </div>
    } @else {
      <neat-sparkline
        [values]="rate().history"
        [label]="label() + ', messages per second'"
        [format]="perSecond"
      />
    }
  `,
		isInline: true,
		styles: [":host{box-sizing:border-box;width:11.5rem;display:flex;flex-direction:column;gap:calc(var(--neat-space-2) / 2)}:host(.timed){width:max-content;min-width:8.5rem}.label{font-weight:var(--font-weight-semibold);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.numbers{display:flex;justify-content:space-between;gap:var(--neat-space-2);color:var(--muted-foreground)}.value{color:var(--foreground);font-weight:var(--font-weight-semibold);font-variant-numeric:tabular-nums}.stage{white-space:nowrap;color:var(--muted-foreground);font-variant-numeric:tabular-nums}\n"],
		dependencies: [{
			kind: "component",
			type: NeatSparkline,
			selector: "neat-sparkline",
			inputs: [
				"values",
				"label",
				"format",
				"tone"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatDiagramRateCard,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-diagram-rate-card",
			imports: [NeatSparkline],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class.timed]": "stage() !== null" },
			template: `
    <div class="label">{{ label() }}</div>
    <ng-content select="[neatRateCardThumbnails]" />
    <div class="numbers">
      <span
        ><span class="value">{{ msgs() }}</span> msg/s</span
      >
      @if (stage() === null && showBytes()) {
        <span
          ><span class="value">{{ megabytes() }}</span> MB/s</span
        >
      }
    </div>
    @if (stage(); as ms) {
      <div class="stage">
        Stage <span class="value">{{ ms }}</span> ms
      </div>
    } @else {
      <neat-sparkline
        [values]="rate().history"
        [label]="label() + ', messages per second'"
        [format]="perSecond"
      />
    }
  `,
			styles: [":host{box-sizing:border-box;width:11.5rem;display:flex;flex-direction:column;gap:calc(var(--neat-space-2) / 2)}:host(.timed){width:max-content;min-width:8.5rem}.label{font-weight:var(--font-weight-semibold);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.numbers{display:flex;justify-content:space-between;gap:var(--neat-space-2);color:var(--muted-foreground)}.value{color:var(--foreground);font-weight:var(--font-weight-semibold);font-variant-numeric:tabular-nums}.stage{white-space:nowrap;color:var(--muted-foreground);font-variant-numeric:tabular-nums}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		rate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rate",
				required: true
			}]
		}],
		stageMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stageMs",
				required: false
			}]
		}],
		showBytes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showBytes",
				required: false
			}]
		}]
	}
});
export { NEAT_DIAGRAM_MESSAGE_DEFAULTS, NeatDiagramAnimationSettings, NeatDiagramBlockTemplate, NeatDiagramEdgeTipTemplate, NeatDiagramLegend, NeatDiagramMessages, NeatDiagramNoteTemplate, NeatDiagramRateCard, NeatDiagramView, neatBatchTimes, neatDrillDownLevel, neatParseMessageSettings };

//# sourceMappingURL=sima-neat-ui-diagram.mjs.map