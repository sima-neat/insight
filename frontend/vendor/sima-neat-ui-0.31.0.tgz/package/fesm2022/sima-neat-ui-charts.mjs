import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ElementRef, booleanAttribute, computed, effect, inject, input, linkedSignal, output, signal, untracked, viewChild } from "@angular/core";
import { NeatCard } from "@sima/neat-ui/card";
import { scaleLinear } from "d3-scale";
import { area, line } from "d3-shape";
import { NeatSeriesSwatch, NeatSeriesSwatch as NeatSeriesSwatch$1, neatSecondsAgo, ɵBROWSER_CLOCK, ɵreducedMotion, ɵseriesToken as seriesToken } from "@sima/neat-ui";
const CONTROLS = "a[href], button, input, select, textarea, summary, [contenteditable=\"true\"]";
var NeatChartCard = class NeatChartCard {
	heading = input.required(...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	unit = input("", ...ngDevMode ? [{ debugName: "unit" }] : /* istanbul ignore next */ []);
	caption = input("", ...ngDevMode ? [{ debugName: "caption" }] : /* istanbul ignore next */ []);
	selectable = input(false, {
		...ngDevMode ? { debugName: "selectable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	selected = input(false, {
		...ngDevMode ? { debugName: "selected" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	activate = output();
	host = inject(ElementRef).nativeElement;
	onClick(event) {
		if (!this.selectable() || this.inControl(event.target)) return;
		this.activate.emit();
	}
	inControl(target) {
		const control = target instanceof Element ? target.closest(CONTROLS) : null;
		return control !== null && this.host.contains(control) && !control.classList.contains("activator");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatChartCard,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatChartCard,
		isStandalone: true,
		selector: "neat-chart-card",
		inputs: {
			heading: {
				classPropertyName: "heading",
				publicName: "heading",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			unit: {
				classPropertyName: "unit",
				publicName: "unit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caption: {
				classPropertyName: "caption",
				publicName: "caption",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectable: {
				classPropertyName: "selectable",
				publicName: "selectable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { activate: "activate" },
		host: {
			listeners: { "click": "onClick($event)" },
			properties: {
				"attr.data-selectable": "selectable() ? \"\" : null",
				"attr.data-selected": "selectable() && selected() ? \"\" : null"
			}
		},
		ngImport: i0,
		template: `
    <neat-card class="card">
      @if (selectable()) {
        <button
          type="button"
          neatCardTitle
          class="activator"
          [attr.aria-current]="selected() ? 'true' : null"
        >
          {{ heading() }}
        </button>
      } @else {
        <span neatCardTitle>{{ heading() }}</span>
      }
      <span neatCardActions class="chip-slot">
        <ng-content select="[neatChartCardChip]" />
      </span>
      <div class="body">
        @if (value()) {
          <div class="value">
            {{ value() }}
            @if (unit()) {
              <span class="unit">{{ unit() }}</span>
            }
          </div>
        }
        @if (caption()) {
          <div class="caption">{{ caption() }}</div>
        }
        <ng-content />
      </div>
    </neat-card>
  `,
		isInline: true,
		styles: [":host{display:flex;flex-direction:column;min-width:0}.card{--neat-card-header-min-height: 0;flex:1}:host([data-selectable]) .card{cursor:pointer}:host([data-selected]) .card{border-color:var(--primary);box-shadow:inset 0 0 0 1px var(--primary)}.chip-slot{display:flex;align-items:center;min-height:1lh;font-size:var(--neat-text-sm);line-height:1.5}.body{display:flex;flex-direction:column;gap:var(--neat-space-2);min-width:0}.activator{padding:0;border:0;background:none;font:inherit;color:inherit;text-align:start;cursor:pointer}.activator:focus-visible{outline:2px solid var(--ring);outline-offset:2px}.value{font-size:1.5rem;font-weight:600;line-height:1.2;font-variant-numeric:tabular-nums}.unit{font-size:var(--neat-text-sm);font-weight:400;color:var(--muted-foreground)}.caption{line-height:1.5;font-size:var(--neat-text-xs);color:var(--muted-foreground)}\n"],
		dependencies: [{
			kind: "component",
			type: NeatCard,
			selector: "neat-card",
			inputs: [
				"title",
				"headingLevel",
				"region",
				"subtitle"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatChartCard,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-chart-card",
			imports: [NeatCard],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-selectable]": "selectable() ? \"\" : null",
				"[attr.data-selected]": "selectable() && selected() ? \"\" : null",
				"(click)": "onClick($event)"
			},
			template: `
    <neat-card class="card">
      @if (selectable()) {
        <button
          type="button"
          neatCardTitle
          class="activator"
          [attr.aria-current]="selected() ? 'true' : null"
        >
          {{ heading() }}
        </button>
      } @else {
        <span neatCardTitle>{{ heading() }}</span>
      }
      <span neatCardActions class="chip-slot">
        <ng-content select="[neatChartCardChip]" />
      </span>
      <div class="body">
        @if (value()) {
          <div class="value">
            {{ value() }}
            @if (unit()) {
              <span class="unit">{{ unit() }}</span>
            }
          </div>
        }
        @if (caption()) {
          <div class="caption">{{ caption() }}</div>
        }
        <ng-content />
      </div>
    </neat-card>
  `,
			styles: [":host{display:flex;flex-direction:column;min-width:0}.card{--neat-card-header-min-height: 0;flex:1}:host([data-selectable]) .card{cursor:pointer}:host([data-selected]) .card{border-color:var(--primary);box-shadow:inset 0 0 0 1px var(--primary)}.chip-slot{display:flex;align-items:center;min-height:1lh;font-size:var(--neat-text-sm);line-height:1.5}.body{display:flex;flex-direction:column;gap:var(--neat-space-2);min-width:0}.activator{padding:0;border:0;background:none;font:inherit;color:inherit;text-align:start;cursor:pointer}.activator:focus-visible{outline:2px solid var(--ring);outline-offset:2px}.value{font-size:1.5rem;font-weight:600;line-height:1.2;font-variant-numeric:tabular-nums}.unit{font-size:var(--neat-text-sm);font-weight:400;color:var(--muted-foreground)}.caption{line-height:1.5;font-size:var(--neat-text-xs);color:var(--muted-foreground)}\n"]
		}]
	}],
	propDecorators: {
		heading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "heading",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		unit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unit",
				required: false
			}]
		}],
		caption: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caption",
				required: false
			}]
		}],
		selectable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectable",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}],
		activate: [{
			type: i0.Output,
			args: ["activate"]
		}]
	}
});
const WIDTH = 600;
const HEIGHT = 100;
const DIGITS = 2;
const MINUTES_FROM = 120;
const isNumber = (value) => typeof value === "number" && Number.isFinite(value);
function evenFractions(length) {
	return Array.from({ length }, (_, index) => index / Math.max(1, length - 1));
}
function orderedTimes(times, length) {
	if (length < 2 || times.length !== length) return null;
	const ordered = [];
	for (const time of times) {
		if (!isNumber(time) || time < (ordered.at(-1) ?? -Infinity)) return null;
		ordered.push(time);
	}
	return ordered[length - 1] > ordered[0] ? ordered : null;
}
function timeFractions(times, length) {
	const ordered = orderedTimes(times, length);
	if (!ordered) return evenFractions(length);
	const start = ordered[0];
	const span = ordered[length - 1] - start;
	return ordered.map((time) => (time - start) / span);
}
function indexAt(fraction, length, fractions) {
	if (!length) return -1;
	const at = fractions.length === length ? fractions : evenFractions(length);
	let nearest = 0;
	at.forEach((position, index) => {
		if (Math.abs(position - fraction) <= Math.abs(at[nearest] - fraction)) nearest = index;
	});
	return nearest;
}
function yScale(domain) {
	return scaleLinear().domain(domain).range([HEIGHT, 0]).clamp(true);
}
function yAt(value, domain) {
	return round(yScale(domain)(value));
}
function linePaths(values, fractions, domain) {
	const y = yScale(domain);
	const at = fractions.length === values.length ? fractions : evenFractions(values.length);
	const x = (_, index) => at[index] * WIDTH;
	const joined = (_, index) => isNumber(values[index]) && (isNumber(values[index - 1]) || isNumber(values[index + 1]));
	const newest = values.at(-1);
	return {
		line: line().defined(joined).x(x).y((value) => y(value)).digits(DIGITS)(values) ?? "",
		area: area().defined(joined).x(x).y0(HEIGHT).y1((value) => y(value)).digits(DIGITS)(values) ?? "",
		last: isNumber(newest) ? {
			x: round(at[values.length - 1] * WIDTH),
			y: round(y(newest))
		} : null
	};
}
function round(value) {
	return Number(value.toFixed(DIGITS));
}
function stackedPaths(lists, fractions, domain) {
	const y = yScale(domain);
	const length = Math.max(0, ...lists.map((list) => list.length));
	const at = fractions.length === length ? fractions : evenFractions(length);
	const complete = at.map((_, index) => lists.every((list) => isNumber(list[index])));
	const joined = (index) => complete[index] && (complete[index - 1] || complete[index + 1]);
	const top = at.map(() => 0);
	return lists.map((list) => {
		const bottom = top.slice();
		complete.forEach((whole, index) => {
			if (whole) top[index] += list[index];
		});
		return area().defined((_, index) => joined(index)).x((_, index) => at[index] * WIDTH).y0((_, index) => y(bottom[index])).y1((_, index) => y(top[index])).digits(DIGITS)(top) ?? "";
	});
}
function gridTicks(domain) {
	return scaleLinear().domain(domain).ticks(3);
}
function axisLabel(value) {
	if (!isNumber(value)) return "";
	if (Math.abs(value) >= 1e3) return Math.round(value).toLocaleString("en-US");
	return String(Number(value.toFixed(value < 10 ? 1 : 0)));
}
function duration(seconds) {
	const whole = Math.round(seconds);
	return whole < MINUTES_FROM ? `${whole} s` : `${Math.round(seconds / 60)} min`;
}
function elapsedText(seconds) {
	const tenths = Math.round(seconds * 10) / 10;
	return tenths < 60 ? `${tenths} s` : `${Math.round(seconds / 60)} min`;
}
function axisTimeLabel(secondsBefore) {
	const whole = Math.round(secondsBefore);
	if (whole === 0) return "now";
	return whole < 60 ? `−${whole} s` : `−${Math.round(secondsBefore / 60)} min`;
}
function timeSpan(times, length) {
	const ordered = orderedTimes(times, length);
	return ordered ? (ordered[length - 1] - ordered[0]) / 1e3 : null;
}
function windowText(times, length, axis = "recent") {
	const span = timeSpan(times, length);
	if (span !== null) return axis === "elapsed" ? elapsedText(span) : duration(span);
	return `${length} ${length === 1 ? "sample" : "samples"}`;
}
const MAX_SERIES = 8;
function foldSeries(series) {
	if (series.length <= MAX_SERIES) return [...series];
	const means = series.map((entry) => {
		const numbers = entry.values.filter(isNumber);
		return numbers.length ? numbers.reduce((sum, value) => sum + value, 0) / numbers.length : -Infinity;
	});
	const kept = new Set(series.map((_, index) => index).sort((a, b) => means[b] - means[a] || a - b).slice(0, 7));
	const folded = series.filter((_, index) => !kept.has(index));
	const length = Math.max(...folded.map((entry) => entry.values.length));
	const sums = Array.from({ length }, (_, index) => {
		const values = folded.map((entry) => entry.values[index]);
		return values.every(isNumber) ? values.reduce((sum, value) => sum + value, 0) : null;
	});
	return [...series.filter((_, index) => kept.has(index)), {
		key: "other",
		label: "Other",
		values: sums
	}];
}
const PLOT_REM = {
	compact: 3.5,
	medium: 6,
	large: 9.5
};
const LABEL_REM = .75;
const LABEL_GAP_REM = .125;
function labelSpan(y, size) {
	const unit = 100 / PLOT_REM[size];
	const [height, gap] = [LABEL_REM * unit, LABEL_GAP_REM * unit];
	return y < 14 ? [y + gap, y + gap + height] : [y - gap - height, y - gap];
}
const overlap = ([top, bottom], [from, to]) => top < to && from < bottom;
function roomyGridMarks(marks, size, taken = []) {
	const kept = [];
	let below = null;
	for (const mark of marks) {
		const span = labelSpan(mark.y, size);
		if (taken.some((other) => overlap(span, other))) continue;
		if (below && overlap(span, below)) continue;
		kept.push(mark);
		below = span;
	}
	return kept;
}
function gridMarks(domain) {
	return gridTicks(domain).map((value) => ({
		value,
		y: yAt(value, domain),
		text: axisLabel(value)
	}));
}
function timeAxis(times, length, axis = "recent") {
	if (!length) return [];
	const span = timeSpan(times, length);
	if (span === null) return axis === "elapsed" ? [{
		at: 0,
		text: elapsedText(0)
	}] : [{
		at: length > 1 ? 1 : 0,
		text: axisTimeLabel(0)
	}];
	return [
		0,
		.5,
		1
	].map((at) => ({
		at,
		text: axis === "elapsed" ? elapsedText(span * at) : axisTimeLabel(span * (1 - at))
	}));
}
function chartName(label, current, times, length, axis = "recent") {
	const over = axis === "elapsed" ? "over" : "over the last";
	return `${label}${current ? `: ${current}` : ""}, ${over} ${windowText(times, length, axis)}`;
}
function columnSamples(length, columns, times) {
	return times ? byTime(times, columns) : byCount(length, columns);
}
function byCount(length, columns) {
	const count = Math.min(length, columns);
	const size = length / count;
	const samples = Array.from({ length: count }, () => []);
	for (let index = 0; index < length; index += 1) samples[Math.min(count - 1, Math.max(0, Math.ceil((index + 1) / size - 1e-9) - 1))].push(index);
	return samples;
}
function byTime(times, columns) {
	const start = times[0];
	const last = times.length - 1;
	const span = times[last] - start;
	const step = samplingInterval(times);
	const instants = Math.round(span / step) + 1;
	const count = Math.min(columns, instants);
	const centred = count === instants;
	const samples = Array.from({ length: count }, () => []);
	times.forEach((time, index) => {
		const place = (time - start) / span;
		const column = centred ? Math.round(place * (count - 1)) : Math.min(count - 1, Math.floor(place * count));
		samples[column].push(index);
	});
	let after = 1;
	for (let column = 1; column < count; column += 1) {
		if (samples[column].length) continue;
		const centre = start + span * (centred ? column / (count - 1) : (column + .5) / count);
		while (after < last && times[after] < centre) after += 1;
		if (times[after] - times[after - 1] <= 2 * step) samples[column] = samples[column - 1];
	}
	return samples;
}
function samplingInterval(times) {
	const gaps = [];
	for (let index = 1; index < times.length; index += 1) {
		const gap = times[index] - times[index - 1];
		if (gap > 0) gaps.push(gap);
	}
	gaps.sort((a, b) => a - b);
	return gaps[Math.floor((gaps.length - 1) / 2)];
}
function columnMeans(values, columns = 48, times = []) {
	const ordered = orderedTimes(times, values.length);
	return columnSamples(values.length, columns, ordered).map((indices) => {
		const numbers = indices.map((index) => values[index]).filter(isNumber);
		return numbers.length ? numbers.reduce((sum, value) => sum + value, 0) / numbers.length : null;
	});
}
function newestInColumn(column, length, columns, times = []) {
	return columnSamples(length, columns, orderedTimes(times, length))[column]?.at(-1) ?? -1;
}
function lineToken(tone) {
	return tone === "default" ? "var(--neat-line)" : `var(--neat-line-${tone})`;
}
function textToken(tone) {
	return tone === "default" ? "var(--foreground)" : lineToken(tone);
}
function describe(value, format) {
	return isNumber(value) ? format(value) : "—";
}
function whenText(times, length, index, axis = "recent") {
	const taken = times[index];
	if (axis === "elapsed") {
		const first = times[0];
		return isNumber(first) && isNumber(taken) && taken >= first ? `at ${elapsedText((taken - first) / 1e3)}` : null;
	}
	const newest = times[length - 1];
	return isNumber(newest) && isNumber(taken) && newest >= taken ? neatSecondsAgo((newest - taken) / 1e3) : null;
}
function fractionAcross(event, element) {
	const box = element.getBoundingClientRect();
	return box.width ? Math.min(1, Math.max(0, (event.clientX - box.left) / box.width)) : null;
}
function readoutAt(at, when, rows) {
	return {
		at,
		when,
		rows,
		spoken: [when, ...rows.map((row) => `${row.label} ${row.value}`)].filter(Boolean).join(", ")
	};
}
function sampleAfter(key, current, length) {
	const last = length - 1;
	if (last < 0) return null;
	switch (key) {
		case "ArrowLeft": return current === null ? last : Math.max(0, current - 1);
		case "ArrowRight": return current === null ? last : Math.min(last, current + 1);
		case "Home": return 0;
		case "End": return last;
		default: return null;
	}
}
function sampleCursor(chart) {
	return new ReadoutCursor({
		under: (pointer) => {
			const index = indexAt(pointer, chart.length(), chart.fractions());
			return index < 0 ? null : index;
		},
		fit: (index) => chart.length() ? Math.min(index, chart.length() - 1) : null,
		start: () => chart.length() ? chart.length() - 1 : null,
		after: (key, current) => sampleAfter(key, current, chart.length()),
		spoken: chart.spoken
	});
}
var ReadoutCursor = class {
	shape;
	pointer = signal(null, ...ngDevMode ? [{ debugName: "pointer" }] : /* istanbul ignore next */ []);
	keyed = signal(null, ...ngDevMode ? [{ debugName: "keyed" }] : /* istanbul ignore next */ []);
	announcement = signal("", ...ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []);
	active = computed(() => {
		const keyed = this.keyed();
		if (keyed !== null) return this.shape.fit(keyed);
		const pointer = this.pointer();
		return pointer === null ? null : this.shape.under(pointer);
	}, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	constructor(shape) {
		this.shape = shape;
	}
	pointerTo(pointer) {
		this.keyed.set(null);
		this.pointer.set(pointer);
	}
	pointerLeave() {
		this.pointer.set(null);
	}
	focus() {
		if (this.active() !== null) return;
		const start = this.shape.start();
		if (start !== null) this.keyed.set(start);
	}
	blur() {
		this.keyed.set(null);
		this.announcement.set("");
	}
	keydown(event) {
		const current = this.active();
		if (event.key === "Escape") {
			if (current === null) return;
			event.preventDefault();
			event.stopPropagation();
			this.pointer.set(null);
			this.keyed.set(null);
			this.announcement.set("");
			return;
		}
		const next = this.shape.after(event.key, current);
		if (next === null) return;
		event.preventDefault();
		this.keyed.set(next);
		const now = this.active();
		this.announcement.set(now === null ? "" : this.shape.spoken(now));
	}
};
var NeatHeatmap = class NeatHeatmap {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	headline = input("", ...ngDevMode ? [{ debugName: "headline" }] : /* istanbul ignore next */ []);
	rows = input.required(...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	times = input([], ...ngDevMode ? [{ debugName: "times" }] : /* istanbul ignore next */ []);
	domain = input([0, 100], ...ngDevMode ? [{ debugName: "domain" }] : /* istanbul ignore next */ []);
	format = input(String, ...ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []);
	cells = computed(() => {
		const times = this.times();
		return this.rows().map((row) => columnMeans(row.values, 48, times));
	}, ...ngDevMode ? [{ debugName: "cells" }] : /* istanbul ignore next */ []);
	shown = computed(() => {
		const domain = this.domain();
		const cells = this.cells();
		return this.rows().map((row, index) => ({
			key: row.key,
			label: row.label,
			end: row.end,
			tone: textToken(row.endTone),
			fills: cells[index].map((mean) => fillOf(mean, domain))
		}));
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	columns = computed(() => Math.max(0, ...this.cells().map((cells) => cells.length)), ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	length = computed(() => Math.max(0, ...this.rows().map((row) => row.values.length)), ...ngDevMode ? [{ debugName: "length" }] : /* istanbul ignore next */ []);
	scaleStart = computed(() => this.format()(this.domain()[0]), ...ngDevMode ? [{ debugName: "scaleStart" }] : /* istanbul ignore next */ []);
	scaleEnd = computed(() => this.format()(this.domain()[1]), ...ngDevMode ? [{ debugName: "scaleEnd" }] : /* istanbul ignore next */ []);
	axis = computed(() => timeAxis(this.times(), this.length()), ...ngDevMode ? [{ debugName: "axis" }] : /* istanbul ignore next */ []);
	name = computed(() => chartName(this.label(), this.headline(), this.times(), this.length()), ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	cursor = new ReadoutCursor({
		under: (pointer) => {
			const row = Math.min(this.rows().length - 1, pointer.row);
			const count = this.cells()[row]?.length ?? 0;
			return count ? {
				row,
				column: Math.min(count - 1, Math.floor(pointer.fraction * count))
			} : null;
		},
		fit: (cell) => {
			const row = Math.min(this.rows().length - 1, cell.row);
			const count = this.cells()[row]?.length ?? 0;
			return count ? {
				row,
				column: Math.min(count - 1, cell.column)
			} : null;
		},
		start: () => this.newestOf(0),
		after: (key, current) => this.cellAfter(key, current),
		spoken: (cell) => {
			const { head, value } = this.readoutFor(cell);
			return `${head}: ${value}`;
		}
	});
	readout = computed(() => {
		const cell = this.cursor.active();
		return cell === null ? null : this.readoutFor(cell);
	}, ...ngDevMode ? [{ debugName: "readout" }] : /* istanbul ignore next */ []);
	newestOf(row) {
		const count = this.cells()[row]?.length ?? 0;
		return count ? {
			row,
			column: count - 1
		} : null;
	}
	cellAfter(key, current) {
		const cells = this.cells();
		const row = current?.row ?? 0;
		const count = cells[row]?.length ?? 0;
		if (!count) return null;
		switch (key) {
			case "Home": return {
				row,
				column: 0
			};
			case "End": return {
				row,
				column: count - 1
			};
			case "ArrowLeft":
			case "ArrowRight":
			case "ArrowUp":
			case "ArrowDown": return current === null ? this.newestOf(0) : this.step(key, current);
			default: return null;
		}
	}
	step(key, from) {
		const cells = this.cells();
		const inRow = (row) => ({
			row,
			column: Math.min(from.column, Math.max(0, cells[row].length - 1))
		});
		switch (key) {
			case "ArrowLeft": return {
				row: from.row,
				column: Math.max(0, from.column - 1)
			};
			case "ArrowRight": return {
				row: from.row,
				column: Math.min(cells[from.row].length - 1, from.column + 1)
			};
			case "ArrowUp": return inRow(Math.max(0, from.row - 1));
			case "ArrowDown": return inRow(Math.min(cells.length - 1, from.row + 1));
		}
	}
	readoutFor({ row, column }) {
		const { label, values } = this.rows()[row];
		const means = this.cells()[row];
		const mean = means[column];
		const newest = newestInColumn(column, values.length, means.length, this.times());
		const when = newest < 0 ? null : whenText(this.times(), values.length, newest);
		return {
			row,
			column,
			at: (column + .5) / means.length,
			head: when ? `${label} · ${when}` : label,
			value: isNumber(mean) ? `${describe(mean, this.format())} average` : "no data"
		};
	}
	onPointerMove(event, row) {
		const fraction = fractionAcross(event, event.currentTarget);
		if (fraction !== null) this.cursor.pointerTo({
			row,
			fraction
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatHeatmap,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatHeatmap,
		isStandalone: true,
		selector: "neat-heatmap",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			headline: {
				classPropertyName: "headline",
				publicName: "headline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			times: {
				classPropertyName: "times",
				publicName: "times",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			domain: {
				classPropertyName: "domain",
				publicName: "domain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    @let active = cursor.active();
    <div class="head">
      <span class="title">{{ label() }}</span>
      @if (headline()) {
        <span class="headline">{{ headline() }}</span>
      }
      <span class="scale" aria-hidden="true">
        <span>{{ scaleStart() }}</span>
        <span class="ramp"></span>
        <span>{{ scaleEnd() }}</span>
      </span>
    </div>
    <div
      class="grid"
      tabindex="0"
      role="group"
      aria-roledescription="heatmap"
      [attr.aria-label]="name()"
      [style.--rows]="shown().length"
      [style.--columns]="columns()"
      (pointerleave)="cursor.pointerLeave()"
      (focus)="cursor.focus()"
      (blur)="cursor.blur()"
      (keydown)="cursor.keydown($event)"
    >
      @for (row of shown(); track row.key; let r = $index) {
        <span class="name">{{ row.label }}</span>
        <div class="cells" (pointermove)="onPointerMove($event, r)">
          @for (fill of row.fills; track $index; let c = $index) {
            <span
              class="cell"
              [style.--cell]="fill"
              [attr.data-cursor]="active?.row === r && active?.column === c ? '' : null"
            ></span>
          }
          @if (readout(); as readout) {
            @if (readout.row === r) {
              <span
                class="readout"
                aria-hidden="true"
                [attr.data-flip]="readout.at > 0.5 ? '' : null"
                [style.--at]="readout.at"
              >
                <span class="when">{{ readout.head }}</span>
                <span class="row">{{ readout.value }}</span>
              </span>
            }
          }
        </div>
        <span class="end" [style.--tone]="row.tone">{{ row.end }}</span>
      }
      @if (shown().length) {
        <span></span>
        <div class="axis" aria-hidden="true">
          @for (tick of axis(); track tick.at) {
            <span [style.--at]="tick.at">{{ tick.text }}</span>
          }
        </div>
        <span></span>
      }
    </div>
    <span class="sr-only" aria-live="polite">{{ cursor.announcement() }}</span>
  `,
		isInline: true,
		styles: [":host{position:relative;display:block;font-size:var(--neat-text-sm)}.head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:var(--neat-space-2);margin-block-end:var(--neat-space-2)}.title{color:var(--muted-foreground)}.headline{font-weight:600;font-variant-numeric:tabular-nums}.readout{position:absolute;top:0;left:calc(var(--at) * 100%);z-index:1;display:flex;flex-direction:column;gap:.125rem;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}.readout:not([data-flip]){transform:translate(var(--neat-space-2))}.readout[data-flip]{transform:translate(calc(-100% - var(--neat-space-2)))}.when{color:var(--muted-foreground)}.row{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.axis{position:relative;flex-shrink:0;height:1rem;margin-block-start:.25rem;font-size:var(--neat-text-xs);color:var(--muted-foreground)}.axis span{position:absolute;left:calc(var(--at) * 100%);transform:translate(calc(var(--at) * -100%));white-space:nowrap}\n", ".scale{display:inline-flex;align-items:center;gap:var(--neat-space-2);color:var(--muted-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums}.ramp{width:6rem;height:.5rem;border-radius:2px;background:linear-gradient(in oklab 90deg,var(--neat-heat-low),var(--neat-heat-high))}.grid{display:grid;grid-template-columns:max-content minmax(0,1fr) max-content;grid-template-rows:repeat(var(--rows),1.5rem);grid-auto-rows:auto;align-items:center;column-gap:var(--neat-space-3);row-gap:.125rem}.grid:focus-visible{outline:2px solid var(--ring);outline-offset:2px}.name{color:var(--muted-foreground);white-space:nowrap}.end{color:var(--tone);font-variant-numeric:tabular-nums;text-align:end;white-space:nowrap}.cells{position:relative;display:grid;grid-template-columns:repeat(var(--columns),minmax(0,1fr));gap:.125rem;height:100%;touch-action:pan-y}.cell{border-radius:2px;background:var(--cell)}.cell[data-cursor]{outline:2px solid var(--foreground);outline-offset:1px}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatHeatmap,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-heatmap",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    @let active = cursor.active();
    <div class="head">
      <span class="title">{{ label() }}</span>
      @if (headline()) {
        <span class="headline">{{ headline() }}</span>
      }
      <span class="scale" aria-hidden="true">
        <span>{{ scaleStart() }}</span>
        <span class="ramp"></span>
        <span>{{ scaleEnd() }}</span>
      </span>
    </div>
    <div
      class="grid"
      tabindex="0"
      role="group"
      aria-roledescription="heatmap"
      [attr.aria-label]="name()"
      [style.--rows]="shown().length"
      [style.--columns]="columns()"
      (pointerleave)="cursor.pointerLeave()"
      (focus)="cursor.focus()"
      (blur)="cursor.blur()"
      (keydown)="cursor.keydown($event)"
    >
      @for (row of shown(); track row.key; let r = $index) {
        <span class="name">{{ row.label }}</span>
        <div class="cells" (pointermove)="onPointerMove($event, r)">
          @for (fill of row.fills; track $index; let c = $index) {
            <span
              class="cell"
              [style.--cell]="fill"
              [attr.data-cursor]="active?.row === r && active?.column === c ? '' : null"
            ></span>
          }
          @if (readout(); as readout) {
            @if (readout.row === r) {
              <span
                class="readout"
                aria-hidden="true"
                [attr.data-flip]="readout.at > 0.5 ? '' : null"
                [style.--at]="readout.at"
              >
                <span class="when">{{ readout.head }}</span>
                <span class="row">{{ readout.value }}</span>
              </span>
            }
          }
        </div>
        <span class="end" [style.--tone]="row.tone">{{ row.end }}</span>
      }
      @if (shown().length) {
        <span></span>
        <div class="axis" aria-hidden="true">
          @for (tick of axis(); track tick.at) {
            <span [style.--at]="tick.at">{{ tick.text }}</span>
          }
        </div>
        <span></span>
      }
    </div>
    <span class="sr-only" aria-live="polite">{{ cursor.announcement() }}</span>
  `,
			styles: [":host{position:relative;display:block;font-size:var(--neat-text-sm)}.head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:var(--neat-space-2);margin-block-end:var(--neat-space-2)}.title{color:var(--muted-foreground)}.headline{font-weight:600;font-variant-numeric:tabular-nums}.readout{position:absolute;top:0;left:calc(var(--at) * 100%);z-index:1;display:flex;flex-direction:column;gap:.125rem;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}.readout:not([data-flip]){transform:translate(var(--neat-space-2))}.readout[data-flip]{transform:translate(calc(-100% - var(--neat-space-2)))}.when{color:var(--muted-foreground)}.row{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.axis{position:relative;flex-shrink:0;height:1rem;margin-block-start:.25rem;font-size:var(--neat-text-xs);color:var(--muted-foreground)}.axis span{position:absolute;left:calc(var(--at) * 100%);transform:translate(calc(var(--at) * -100%));white-space:nowrap}\n", ".scale{display:inline-flex;align-items:center;gap:var(--neat-space-2);color:var(--muted-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums}.ramp{width:6rem;height:.5rem;border-radius:2px;background:linear-gradient(in oklab 90deg,var(--neat-heat-low),var(--neat-heat-high))}.grid{display:grid;grid-template-columns:max-content minmax(0,1fr) max-content;grid-template-rows:repeat(var(--rows),1.5rem);grid-auto-rows:auto;align-items:center;column-gap:var(--neat-space-3);row-gap:.125rem}.grid:focus-visible{outline:2px solid var(--ring);outline-offset:2px}.name{color:var(--muted-foreground);white-space:nowrap}.end{color:var(--tone);font-variant-numeric:tabular-nums;text-align:end;white-space:nowrap}.cells{position:relative;display:grid;grid-template-columns:repeat(var(--columns),minmax(0,1fr));gap:.125rem;height:100%;touch-action:pan-y}.cell{border-radius:2px;background:var(--cell)}.cell[data-cursor]{outline:2px solid var(--foreground);outline-offset:1px}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		headline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headline",
				required: false
			}]
		}],
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: true
			}]
		}],
		times: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "times",
				required: false
			}]
		}],
		domain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "domain",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}]
	}
});
function fillOf(mean, domain) {
	if (!isNumber(mean)) return "transparent";
	const [low, high] = domain;
	const place = high > low ? (mean - low) / (high - low) : 0;
	return `color-mix(in oklab, var(--neat-heat-high) ${Number((Math.min(1, Math.max(0, place)) * 100).toFixed(2))}%, var(--neat-heat-low))`;
}
const PALETTE_SIZE = 8;
function neatLabelColour(label, labels, quiet) {
	if (quiet.includes(label)) return "var(--muted-foreground)";
	const index = labels.indexOf(label);
	return index < 0 ? "var(--neat-chip-neutral)" : seriesToken(index % PALETTE_SIZE);
}
const NAMED_SHARE = .12;
const TICKS = 3;
const MAX_AHEAD_MS = 1e3;
const QUIET_FILL = "var(--muted)";
const inSeconds = (ms) => Number((ms / 1e3).toFixed(1));
var NeatLabelTimeline = class NeatLabelTimeline {
	runs = input.required(...ngDevMode ? [{ debugName: "runs" }] : /* istanbul ignore next */ []);
	nowMs = input.required(...ngDevMode ? [{ debugName: "nowMs" }] : /* istanbul ignore next */ []);
	windowMs = input(3e4, ...ngDevMode ? [{ debugName: "windowMs" }] : /* istanbul ignore next */ []);
	labels = input([], ...ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []);
	quiet = input([], ...ngDevMode ? [{ debugName: "quiet" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	motion = input("step", ...ngDevMode ? [{ debugName: "motion" }] : /* istanbul ignore next */ []);
	drawn = linkedSignal({
		...ngDevMode ? { debugName: "drawn" } : /* istanbul ignore next */ {},
		source: () => ({
			now: this.nowMs(),
			motion: this.motion()
		}),
		computation: ({ now, motion }, previous) => {
			const smooth = motion === "smooth" && !ɵreducedMotion();
			const last = previous?.value;
			return {
				smooth,
				now: smooth && last?.smooth && last.now - now <= MAX_AHEAD_MS ? Math.max(last.now, now) : now,
				from: now,
				arrivedAt: ɵBROWSER_CLOCK.now(),
				update: (last?.update ?? 0) + 1
			};
		}
	});
	drawnNow = computed(() => this.drawn().smooth ? this.drawn().now : this.nowMs(), ...ngDevMode ? [{ debugName: "drawnNow" }] : /* istanbul ignore next */ []);
	loopFor = computed(() => this.drawn().smooth ? this.drawn().update : -1, ...ngDevMode ? [{ debugName: "loopFor" }] : /* istanbul ignore next */ []);
	constructor() {
		effect((onCleanup) => {
			if (this.loopFor() < 0) return;
			let handle;
			const frame = () => {
				const { arrivedAt } = untracked(this.drawn);
				const elapsed = ɵBROWSER_CLOCK.now() - arrivedAt;
				this.drawn.update((state) => {
					const now = Math.max(state.now, state.from + Math.min(MAX_AHEAD_MS, elapsed));
					return now === state.now ? state : {
						...state,
						now
					};
				});
				handle = elapsed < MAX_AHEAD_MS ? ɵBROWSER_CLOCK.request(frame) : void 0;
			};
			handle = ɵBROWSER_CLOCK.request(frame);
			onCleanup(() => {
				if (handle !== void 0) ɵBROWSER_CLOCK.cancel(handle);
			});
		});
	}
	bars = computed(() => {
		const now = this.drawnNow();
		const window = this.windowMs();
		if (!isNumber(now) || !isNumber(window) || window <= 0) return [];
		const from = now - window;
		const order = this.labels().length > 0 ? this.labels() : [...new Set(this.runs().map((run) => run.label))];
		const quiet = this.quiet();
		const bars = [];
		for (const { label, startMs, endMs } of this.runs()) {
			if (!isNumber(startMs) || !isNumber(endMs)) continue;
			const start = Math.max(startMs, from);
			const end = Math.min(endMs, now);
			if (end <= start) continue;
			const width = (end - start) / window;
			bars.push({
				label,
				left: (start - from) / window * 100,
				width: width * 100,
				colour: quiet.includes(label) ? QUIET_FILL : neatLabelColour(label, order, quiet),
				named: width >= NAMED_SHARE && !quiet.includes(label),
				span: spoken(label, now - start, now - end)
			});
		}
		return bars;
	}, ...ngDevMode ? [{ debugName: "bars" }] : /* istanbul ignore next */ []);
	ticks = computed(() => {
		const window = this.windowMs();
		if (!isNumber(window) || window <= 0) return [];
		return Array.from({ length: 4 }, (_, index) => index === TICKS ? "now" : `−${inSeconds(window * (TICKS - index) / TICKS)} s`);
	}, ...ngDevMode ? [{ debugName: "ticks" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLabelTimeline,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatLabelTimeline,
		isStandalone: true,
		selector: "neat-label-timeline",
		inputs: {
			runs: {
				classPropertyName: "runs",
				publicName: "runs",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			nowMs: {
				classPropertyName: "nowMs",
				publicName: "nowMs",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			windowMs: {
				classPropertyName: "windowMs",
				publicName: "windowMs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			quiet: {
				classPropertyName: "quiet",
				publicName: "quiet",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			motion: {
				classPropertyName: "motion",
				publicName: "motion",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "role": "group" },
			properties: { "attr.aria-label": "label()" }
		},
		ngImport: i0,
		template: `
    <ul class="runs" role="list">
      @for (bar of bars(); track $index) {
        <li
          class="run"
          data-slot="label-timeline-run"
          [attr.data-label]="bar.label"
          [style.left.%]="bar.left"
          [style.width.%]="bar.width"
          [style.--run]="bar.colour"
        >
          <span class="sr-only">{{ bar.span }}</span>
          @if (bar.named) {
            <span class="name" aria-hidden="true">{{ bar.label }}</span>
          }
        </li>
      }
    </ul>
    <div class="axis" aria-hidden="true">
      @for (tick of ticks(); track $index) {
        <span data-slot="label-timeline-tick">{{ tick }}</span>
      }
    </div>
  `,
		isInline: true,
		styles: [":host{display:block}.runs{position:relative;height:64px;margin:0;padding:0;list-style:none}.run{position:absolute;top:0;height:28px;background:var(--run);border-right:2px solid var(--neat-surface)}.name{position:absolute;top:34px;left:0;padding-left:4px;border-left:1px solid var(--border);font-size:var(--neat-text-xs);line-height:2.4;color:var(--muted-foreground);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.axis{display:flex;justify-content:space-between;font-size:var(--neat-text-xs);color:var(--muted-foreground)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLabelTimeline,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-label-timeline",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				role: "group",
				"[attr.aria-label]": "label()"
			},
			template: `
    <ul class="runs" role="list">
      @for (bar of bars(); track $index) {
        <li
          class="run"
          data-slot="label-timeline-run"
          [attr.data-label]="bar.label"
          [style.left.%]="bar.left"
          [style.width.%]="bar.width"
          [style.--run]="bar.colour"
        >
          <span class="sr-only">{{ bar.span }}</span>
          @if (bar.named) {
            <span class="name" aria-hidden="true">{{ bar.label }}</span>
          }
        </li>
      }
    </ul>
    <div class="axis" aria-hidden="true">
      @for (tick of ticks(); track $index) {
        <span data-slot="label-timeline-tick">{{ tick }}</span>
      }
    </div>
  `,
			styles: [":host{display:block}.runs{position:relative;height:64px;margin:0;padding:0;list-style:none}.run{position:absolute;top:0;height:28px;background:var(--run);border-right:2px solid var(--neat-surface)}.name{position:absolute;top:34px;left:0;padding-left:4px;border-left:1px solid var(--border);font-size:var(--neat-text-xs);line-height:2.4;color:var(--muted-foreground);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.axis{display:flex;justify-content:space-between;font-size:var(--neat-text-xs);color:var(--muted-foreground)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		runs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "runs",
				required: true
			}]
		}],
		nowMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nowMs",
				required: true
			}]
		}],
		windowMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "windowMs",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		quiet: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "quiet",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		motion: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "motion",
				required: false
			}]
		}]
	}
});
function spoken(label, startAgo, endAgo) {
	const from = inSeconds(startAgo);
	const to = inSeconds(endAgo);
	return to === 0 ? `${label}, ${from} s ago to now` : `${label}, ${from} s to ${to} s ago`;
}
var NeatScoreBars = class NeatScoreBars {
	scores = input.required(...ngDevMode ? [{ debugName: "scores" }] : /* istanbul ignore next */ []);
	labels = input([], ...ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []);
	quiet = input([], ...ngDevMode ? [{ debugName: "quiet" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const scores = this.scores();
		const order = this.labels().length > 0 ? this.labels() : [...new Set(scores.map((score) => score.label))];
		return scores.map(({ label, value }) => {
			const clamped = isNumber(value) ? Math.min(1, Math.max(0, value)) : 0;
			return {
				label,
				clamped,
				numeric: isNumber(value),
				text: isNumber(value) ? clamped.toFixed(2) : "–",
				colour: neatLabelColour(label, order, this.quiet())
			};
		});
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	top = computed(() => {
		let best = -1;
		this.scores().forEach(({ value }, index) => {
			if (isNumber(value) && (best < 0 || value > this.scores()[best].value)) best = index;
		});
		return best;
	}, ...ngDevMode ? [{ debugName: "top" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatScoreBars,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatScoreBars,
		isStandalone: true,
		selector: "neat-score-bars",
		inputs: {
			scores: {
				classPropertyName: "scores",
				publicName: "scores",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			quiet: {
				classPropertyName: "quiet",
				publicName: "quiet",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: {
			attributes: { "role": "group" },
			properties: { "attr.aria-label": "label()" }
		},
		ngImport: i0,
		template: `
    @for (row of rows(); track $index) {
      <div class="row" data-slot="score-bars-row" [attr.data-top]="$index === top() ? '' : null">
        <span class="name">{{ row.label }}</span>
        <span
          class="track"
          role="meter"
          aria-valuemin="0"
          aria-valuemax="1"
          [attr.aria-valuenow]="row.clamped"
          [attr.aria-valuetext]="row.numeric ? null : 'no value'"
          [attr.aria-label]="row.label"
        >
          <span class="fill" [style.width.%]="row.clamped * 100" [style.--fill]="row.colour"></span>
        </span>
        <span class="value">{{ row.text }}</span>
      </div>
    }
  `,
		isInline: true,
		styles: [":host{display:grid;grid-template-columns:max-content minmax(0,1fr) 3em;align-items:center;column-gap:var(--neat-space-2);row-gap:2px;font-size:var(--neat-text-sm)}.row{display:contents}.name{white-space:nowrap;color:var(--muted-foreground)}.row[data-top] .name{color:var(--foreground);font-weight:600}.track{display:block;height:10px;border-radius:999px;background:var(--muted);overflow:hidden}.fill{display:block;height:100%;border-radius:999px;background:var(--fill)}.value{text-align:right;color:var(--muted-foreground);font-variant-numeric:tabular-nums}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatScoreBars,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-score-bars",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				role: "group",
				"[attr.aria-label]": "label()"
			},
			template: `
    @for (row of rows(); track $index) {
      <div class="row" data-slot="score-bars-row" [attr.data-top]="$index === top() ? '' : null">
        <span class="name">{{ row.label }}</span>
        <span
          class="track"
          role="meter"
          aria-valuemin="0"
          aria-valuemax="1"
          [attr.aria-valuenow]="row.clamped"
          [attr.aria-valuetext]="row.numeric ? null : 'no value'"
          [attr.aria-label]="row.label"
        >
          <span class="fill" [style.width.%]="row.clamped * 100" [style.--fill]="row.colour"></span>
        </span>
        <span class="value">{{ row.text }}</span>
      </div>
    }
  `,
			styles: [":host{display:grid;grid-template-columns:max-content minmax(0,1fr) 3em;align-items:center;column-gap:var(--neat-space-2);row-gap:2px;font-size:var(--neat-text-sm)}.row{display:contents}.name{white-space:nowrap;color:var(--muted-foreground)}.row[data-top] .name{color:var(--foreground);font-weight:600}.track{display:block;height:10px;border-radius:999px;background:var(--muted);overflow:hidden}.fill{display:block;height:100%;border-radius:999px;background:var(--fill)}.value{text-align:right;color:var(--muted-foreground);font-variant-numeric:tabular-nums}\n"]
		}]
	}],
	propDecorators: {
		scores: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scores",
				required: true
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		quiet: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "quiet",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}]
	}
});
var NeatSparkline = class NeatSparkline {
	values = input.required(...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	format = input(String, ...ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []);
	tone = input("default", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	numbers = computed(() => this.values().filter((value) => value !== null && Number.isFinite(value)), ...ngDevMode ? [{ debugName: "numbers" }] : /* istanbul ignore next */ []);
	stroke = computed(() => lineToken(this.tone()), ...ngDevMode ? [{ debugName: "stroke" }] : /* istanbul ignore next */ []);
	path = computed(() => {
		const numbers = this.numbers();
		if (numbers.length < 2) return "";
		const values = this.values();
		return linePaths(values, evenFractions(values.length), [Math.min(...numbers), Math.max(...numbers)]).line;
	}, ...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	description = computed(() => {
		const numbers = this.numbers();
		if (numbers.length < 2) return `${this.label()}: no recent samples`;
		const format = this.format();
		return `${this.label()}: ${numbers.length} recent samples, ${format(Math.min(...numbers))} to ${format(Math.max(...numbers))}`;
	}, ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSparkline,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSparkline,
		isStandalone: true,
		selector: "neat-sparkline",
		inputs: {
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "role": "img" },
			properties: {
				"attr.aria-label": "description()",
				"style.--sparkline-stroke": "stroke()"
			}
		},
		ngImport: i0,
		template: `
    <svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
      @if (path(); as d) {
        <path [attr.d]="d" />
      }
    </svg>
  `,
		isInline: true,
		styles: [":host{display:block;height:1.75rem}svg{display:block;width:100%;height:100%;overflow:visible}path{fill:none;stroke:var(--sparkline-stroke);stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSparkline,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-sparkline",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				role: "img",
				"[attr.aria-label]": "description()",
				"[style.--sparkline-stroke]": "stroke()"
			},
			template: `
    <svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
      @if (path(); as d) {
        <path [attr.d]="d" />
      }
    </svg>
  `,
			styles: [":host{display:block;height:1.75rem}svg{display:block;width:100%;height:100%;overflow:visible}path{fill:none;stroke:var(--sparkline-stroke);stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}\n"]
		}]
	}],
	propDecorators: {
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}]
	}
});
var NeatStackedChart = class NeatStackedChart {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	headline = input("", ...ngDevMode ? [{ debugName: "headline" }] : /* istanbul ignore next */ []);
	series = input.required(...ngDevMode ? [{ debugName: "series" }] : /* istanbul ignore next */ []);
	times = input.required(...ngDevMode ? [{ debugName: "times" }] : /* istanbul ignore next */ []);
	domain = input.required(...ngDevMode ? [{ debugName: "domain" }] : /* istanbul ignore next */ []);
	size = input("large", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	headless = input(false, {
		...ngDevMode ? { debugName: "headless" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	valueLabels = input(true, {
		...ngDevMode ? { debugName: "valueLabels" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	format = input(String, ...ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []);
	plot = viewChild.required("plot", ...ngDevMode ? [{ debugName: "plot" }] : /* istanbul ignore next */ []);
	flipBelow = 14;
	labelled = computed(() => this.size() !== "compact", ...ngDevMode ? [{ debugName: "labelled" }] : /* istanbul ignore next */ []);
	lines = computed(() => foldSeries(this.series()), ...ngDevMode ? [{ debugName: "lines" }] : /* istanbul ignore next */ []);
	length = computed(() => Math.max(0, ...this.lines().map((entry) => entry.values.length)), ...ngDevMode ? [{ debugName: "length" }] : /* istanbul ignore next */ []);
	fractions = computed(() => timeFractions(this.times(), this.length()), ...ngDevMode ? [{ debugName: "fractions" }] : /* istanbul ignore next */ []);
	bands = computed(() => {
		const lines = this.lines();
		const paths = stackedPaths(lines.map((entry) => entry.values), this.fractions(), this.domain());
		return lines.map((entry, index) => ({
			key: entry.key,
			color: seriesToken(index),
			path: paths[index]
		}));
	}, ...ngDevMode ? [{ debugName: "bands" }] : /* istanbul ignore next */ []);
	totalAt(index) {
		const values = this.lines().map((entry) => entry.values[index]);
		return values.every(isNumber) ? values.reduce((sum, value) => sum + value, 0) : null;
	}
	legend = computed(() => {
		const format = this.format();
		const current = this.length() - 1;
		const total = this.totalAt(current);
		return this.lines().map((entry, index) => {
			const value = entry.values[current];
			return {
				key: entry.key,
				label: entry.label,
				index,
				value: describe(value, format),
				share: total && isNumber(value) ? `${Math.round(value / total * 100)}%` : "—"
			};
		});
	}, ...ngDevMode ? [{ debugName: "legend" }] : /* istanbul ignore next */ []);
	plotHeight = computed(() => `${PLOT_REM[this.size()]}rem`, ...ngDevMode ? [{ debugName: "plotHeight" }] : /* istanbul ignore next */ []);
	grid = computed(() => gridMarks(this.domain()), ...ngDevMode ? [{ debugName: "grid" }] : /* istanbul ignore next */ []);
	gridLabels = computed(() => roomyGridMarks(this.grid(), this.size()), ...ngDevMode ? [{ debugName: "gridLabels" }] : /* istanbul ignore next */ []);
	axis = computed(() => timeAxis(this.times(), this.length()), ...ngDevMode ? [{ debugName: "axis" }] : /* istanbul ignore next */ []);
	name = computed(() => chartName(this.label(), this.headline(), this.times(), this.length()), ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	cursor = sampleCursor({
		length: this.length,
		fractions: this.fractions,
		spoken: (index) => this.readoutFor(index).spoken
	});
	readout = computed(() => {
		const index = this.cursor.active();
		return index === null ? null : this.readoutFor(index);
	}, ...ngDevMode ? [{ debugName: "readout" }] : /* istanbul ignore next */ []);
	readoutFor(index) {
		const format = this.format();
		return readoutAt(this.fractions()[index], whenText(this.times(), this.length(), index), [{
			key: "total",
			label: "Total",
			value: describe(this.totalAt(index), format),
			series: null
		}, ...this.lines().map((entry, line) => ({
			key: entry.key,
			label: entry.label,
			value: describe(entry.values[index], format),
			series: line
		}))]);
	}
	onPointerMove(event) {
		const fraction = fractionAcross(event, this.plot().nativeElement);
		if (fraction !== null) this.cursor.pointerTo(fraction);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatStackedChart,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatStackedChart,
		isStandalone: true,
		selector: "neat-stacked-chart",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			headline: {
				classPropertyName: "headline",
				publicName: "headline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			series: {
				classPropertyName: "series",
				publicName: "series",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			times: {
				classPropertyName: "times",
				publicName: "times",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			domain: {
				classPropertyName: "domain",
				publicName: "domain",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headless: {
				classPropertyName: "headless",
				publicName: "headless",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			valueLabels: {
				classPropertyName: "valueLabels",
				publicName: "valueLabels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "style.--plot-height": "plotHeight()" } },
		viewQueries: [{
			propertyName: "plot",
			first: true,
			predicate: ["plot"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (!headless()) {
      <div class="head">
        <span class="title">{{ label() }}</span>
        @if (headline()) {
          <span class="headline">{{ headline() }}</span>
        }
      </div>
    }
    @if (legend().length) {
      <ul class="legend">
        @for (item of legend(); track item.key) {
          <li>
            <neat-series-swatch [index]="item.index" />
            <span>{{ item.label }}</span>
            <strong>{{ item.value }}</strong>
            <span class="share">{{ item.share }}</span>
          </li>
        }
      </ul>
    }
    <div
      #plot
      class="plot"
      tabindex="0"
      role="group"
      aria-roledescription="chart"
      [attr.aria-label]="name()"
      (pointermove)="onPointerMove($event)"
      (pointerleave)="cursor.pointerLeave()"
      (focus)="cursor.focus()"
      (blur)="cursor.blur()"
      (keydown)="cursor.keydown($event)"
    >
      <svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
        @for (tick of grid(); track tick.value) {
          <line class="grid" x1="0" x2="600" [attr.y1]="tick.y" [attr.y2]="tick.y" />
        }
        @for (band of bands(); track band.key) {
          <path class="band" [attr.d]="band.path" [style.--series]="band.color" />
        }
      </svg>
      @if (labelled() && valueLabels()) {
        @for (tick of gridLabels(); track tick.value) {
          <span
            class="tag grid-label"
            data-side="start"
            aria-hidden="true"
            [style.top.%]="tick.y"
            [attr.data-below]="tick.y < flipBelow ? '' : null"
            >{{ tick.text }}</span
          >
        }
      }
      @if (readout(); as readout) {
        <span class="crosshair" aria-hidden="true" [style.left.%]="readout.at * 100"></span>
        <span
          class="readout"
          aria-hidden="true"
          [attr.data-flip]="readout.at > 0.5 ? '' : null"
          [style.--at]="readout.at"
        >
          @if (readout.when) {
            <span class="when">{{ readout.when }}</span>
          }
          @for (row of readout.rows; track $index) {
            <span class="row">
              @if (row.series !== null) {
                <neat-series-swatch [index]="row.series" />
              }
              {{ row.label }} {{ row.value }}
            </span>
          }
        </span>
      }
    </div>
    @if (labelled()) {
      <div class="axis" aria-hidden="true">
        @for (tick of axis(); track tick.at) {
          <span [style.--at]="tick.at">{{ tick.text }}</span>
        }
      </div>
    }
    <span class="sr-only" aria-live="polite">{{ cursor.announcement() }}</span>
  `,
		isInline: true,
		styles: [
			":host{position:relative;display:block;font-size:var(--neat-text-sm)}.head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:var(--neat-space-2);margin-block-end:var(--neat-space-2)}.title{color:var(--muted-foreground)}.headline{font-weight:600;font-variant-numeric:tabular-nums}.readout{position:absolute;top:0;left:calc(var(--at) * 100%);z-index:1;display:flex;flex-direction:column;gap:.125rem;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}.readout:not([data-flip]){transform:translate(var(--neat-space-2))}.readout[data-flip]{transform:translate(calc(-100% - var(--neat-space-2)))}.when{color:var(--muted-foreground)}.row{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.axis{position:relative;flex-shrink:0;height:1rem;margin-block-start:.25rem;font-size:var(--neat-text-xs);color:var(--muted-foreground)}.axis span{position:absolute;left:calc(var(--at) * 100%);transform:translate(calc(var(--at) * -100%));white-space:nowrap}\n",
			".plot{position:relative;height:var(--plot-height);touch-action:pan-y}.plot:focus-visible{outline:2px solid var(--ring);outline-offset:2px}svg{display:block;width:100%;height:100%;overflow:visible}.grid{stroke:var(--border);stroke-width:1;vector-effect:non-scaling-stroke}.tag{position:absolute;padding-inline:.25rem;font-size:var(--neat-text-xs);line-height:1;white-space:nowrap;color:var(--muted-foreground);text-shadow:0 0 2px var(--neat-surface),0 0 2px var(--neat-surface);pointer-events:none}.tag:not([data-below]){transform:translateY(calc(-100% - 2px))}.tag[data-below]{transform:translateY(2px)}.tag[data-side=start]{inset-inline-start:0}.tag[data-side=end]{inset-inline-end:0}.crosshair{position:absolute;top:0;bottom:0;width:1px;background:var(--muted-foreground);pointer-events:none}\n",
			".legend{display:grid;grid-template-columns:auto minmax(6rem,max-content) auto auto;justify-content:start;align-items:center;gap:var(--neat-space-2) var(--neat-space-3);margin:0 0 var(--neat-space-2);padding:0;list-style:none}.legend li{display:grid;grid-column:1 / -1;grid-template-columns:subgrid;align-items:center}.legend strong,.share{text-align:end;font-variant-numeric:tabular-nums}.legend strong{font-weight:600}.share{color:var(--muted-foreground)}.band{fill:var(--series);fill-opacity:.85;stroke:var(--neat-surface);stroke-width:1;stroke-linejoin:round;vector-effect:non-scaling-stroke}\n"
		],
		dependencies: [{
			kind: "component",
			type: NeatSeriesSwatch$1,
			selector: "neat-series-swatch",
			inputs: ["index"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatStackedChart,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-stacked-chart",
			imports: [NeatSeriesSwatch$1],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[style.--plot-height]": "plotHeight()" },
			template: `
    @if (!headless()) {
      <div class="head">
        <span class="title">{{ label() }}</span>
        @if (headline()) {
          <span class="headline">{{ headline() }}</span>
        }
      </div>
    }
    @if (legend().length) {
      <ul class="legend">
        @for (item of legend(); track item.key) {
          <li>
            <neat-series-swatch [index]="item.index" />
            <span>{{ item.label }}</span>
            <strong>{{ item.value }}</strong>
            <span class="share">{{ item.share }}</span>
          </li>
        }
      </ul>
    }
    <div
      #plot
      class="plot"
      tabindex="0"
      role="group"
      aria-roledescription="chart"
      [attr.aria-label]="name()"
      (pointermove)="onPointerMove($event)"
      (pointerleave)="cursor.pointerLeave()"
      (focus)="cursor.focus()"
      (blur)="cursor.blur()"
      (keydown)="cursor.keydown($event)"
    >
      <svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
        @for (tick of grid(); track tick.value) {
          <line class="grid" x1="0" x2="600" [attr.y1]="tick.y" [attr.y2]="tick.y" />
        }
        @for (band of bands(); track band.key) {
          <path class="band" [attr.d]="band.path" [style.--series]="band.color" />
        }
      </svg>
      @if (labelled() && valueLabels()) {
        @for (tick of gridLabels(); track tick.value) {
          <span
            class="tag grid-label"
            data-side="start"
            aria-hidden="true"
            [style.top.%]="tick.y"
            [attr.data-below]="tick.y < flipBelow ? '' : null"
            >{{ tick.text }}</span
          >
        }
      }
      @if (readout(); as readout) {
        <span class="crosshair" aria-hidden="true" [style.left.%]="readout.at * 100"></span>
        <span
          class="readout"
          aria-hidden="true"
          [attr.data-flip]="readout.at > 0.5 ? '' : null"
          [style.--at]="readout.at"
        >
          @if (readout.when) {
            <span class="when">{{ readout.when }}</span>
          }
          @for (row of readout.rows; track $index) {
            <span class="row">
              @if (row.series !== null) {
                <neat-series-swatch [index]="row.series" />
              }
              {{ row.label }} {{ row.value }}
            </span>
          }
        </span>
      }
    </div>
    @if (labelled()) {
      <div class="axis" aria-hidden="true">
        @for (tick of axis(); track tick.at) {
          <span [style.--at]="tick.at">{{ tick.text }}</span>
        }
      </div>
    }
    <span class="sr-only" aria-live="polite">{{ cursor.announcement() }}</span>
  `,
			styles: [
				":host{position:relative;display:block;font-size:var(--neat-text-sm)}.head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:var(--neat-space-2);margin-block-end:var(--neat-space-2)}.title{color:var(--muted-foreground)}.headline{font-weight:600;font-variant-numeric:tabular-nums}.readout{position:absolute;top:0;left:calc(var(--at) * 100%);z-index:1;display:flex;flex-direction:column;gap:.125rem;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}.readout:not([data-flip]){transform:translate(var(--neat-space-2))}.readout[data-flip]{transform:translate(calc(-100% - var(--neat-space-2)))}.when{color:var(--muted-foreground)}.row{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.axis{position:relative;flex-shrink:0;height:1rem;margin-block-start:.25rem;font-size:var(--neat-text-xs);color:var(--muted-foreground)}.axis span{position:absolute;left:calc(var(--at) * 100%);transform:translate(calc(var(--at) * -100%));white-space:nowrap}\n",
				".plot{position:relative;height:var(--plot-height);touch-action:pan-y}.plot:focus-visible{outline:2px solid var(--ring);outline-offset:2px}svg{display:block;width:100%;height:100%;overflow:visible}.grid{stroke:var(--border);stroke-width:1;vector-effect:non-scaling-stroke}.tag{position:absolute;padding-inline:.25rem;font-size:var(--neat-text-xs);line-height:1;white-space:nowrap;color:var(--muted-foreground);text-shadow:0 0 2px var(--neat-surface),0 0 2px var(--neat-surface);pointer-events:none}.tag:not([data-below]){transform:translateY(calc(-100% - 2px))}.tag[data-below]{transform:translateY(2px)}.tag[data-side=start]{inset-inline-start:0}.tag[data-side=end]{inset-inline-end:0}.crosshair{position:absolute;top:0;bottom:0;width:1px;background:var(--muted-foreground);pointer-events:none}\n",
				".legend{display:grid;grid-template-columns:auto minmax(6rem,max-content) auto auto;justify-content:start;align-items:center;gap:var(--neat-space-2) var(--neat-space-3);margin:0 0 var(--neat-space-2);padding:0;list-style:none}.legend li{display:grid;grid-column:1 / -1;grid-template-columns:subgrid;align-items:center}.legend strong,.share{text-align:end;font-variant-numeric:tabular-nums}.legend strong{font-weight:600}.share{color:var(--muted-foreground)}.band{fill:var(--series);fill-opacity:.85;stroke:var(--neat-surface);stroke-width:1;stroke-linejoin:round;vector-effect:non-scaling-stroke}\n"
			]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		headline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headline",
				required: false
			}]
		}],
		series: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "series",
				required: true
			}]
		}],
		times: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "times",
				required: true
			}]
		}],
		domain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "domain",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		headless: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headless",
				required: false
			}]
		}],
		valueLabels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "valueLabels",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		plot: [{
			type: i0.ViewChild,
			args: ["plot", { isSignal: true }]
		}]
	}
});
const REFERENCE_TOKEN = "var(--muted-foreground)";
var NeatTimeChart = class NeatTimeChart {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	headline = input("", ...ngDevMode ? [{ debugName: "headline" }] : /* istanbul ignore next */ []);
	series = input.required(...ngDevMode ? [{ debugName: "series" }] : /* istanbul ignore next */ []);
	times = input.required(...ngDevMode ? [{ debugName: "times" }] : /* istanbul ignore next */ []);
	domain = input.required(...ngDevMode ? [{ debugName: "domain" }] : /* istanbul ignore next */ []);
	thresholds = input([], ...ngDevMode ? [{ debugName: "thresholds" }] : /* istanbul ignore next */ []);
	reference = input(null, ...ngDevMode ? [{ debugName: "reference" }] : /* istanbul ignore next */ []);
	tone = input("default", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	axis = input("recent", ...ngDevMode ? [{ debugName: "axis" }] : /* istanbul ignore next */ []);
	headless = input(false, {
		...ngDevMode ? { debugName: "headless" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	valueLabels = input(true, {
		...ngDevMode ? { debugName: "valueLabels" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	format = input(String, ...ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []);
	plot = viewChild.required("plot", ...ngDevMode ? [{ debugName: "plot" }] : /* istanbul ignore next */ []);
	flipBelow = 14;
	frameSize = computed(() => {
		const size = this.size();
		return size === "fill" ? "medium" : size;
	}, ...ngDevMode ? [{ debugName: "frameSize" }] : /* istanbul ignore next */ []);
	labelled = computed(() => this.size() !== "compact", ...ngDevMode ? [{ debugName: "labelled" }] : /* istanbul ignore next */ []);
	valueLabelled = computed(() => this.labelled() && this.valueLabels(), ...ngDevMode ? [{ debugName: "valueLabelled" }] : /* istanbul ignore next */ []);
	lines = computed(() => foldSeries(this.series()), ...ngDevMode ? [{ debugName: "lines" }] : /* istanbul ignore next */ []);
	length = computed(() => Math.max(0, ...this.lines().map((entry) => entry.values.length)), ...ngDevMode ? [{ debugName: "length" }] : /* istanbul ignore next */ []);
	fractions = computed(() => timeFractions(this.times(), this.length()), ...ngDevMode ? [{ debugName: "fractions" }] : /* istanbul ignore next */ []);
	several = computed(() => this.lines().length > 1, ...ngDevMode ? [{ debugName: "several" }] : /* istanbul ignore next */ []);
	colors = computed(() => this.several() ? this.lines().map((_, index) => seriesToken(index)) : [lineToken(this.tone())], ...ngDevMode ? [{ debugName: "colors" }] : /* istanbul ignore next */ []);
	drawn = computed(() => {
		const lines = this.lines();
		const fractions = this.fractions();
		const domain = this.domain();
		return lines.map((entry, index) => {
			const paths = linePaths(entry.values, fractions, domain);
			return {
				key: entry.key,
				color: this.colors()[index],
				line: paths.line,
				area: this.several() ? "" : paths.area,
				last: paths.last
			};
		});
	}, ...ngDevMode ? [{ debugName: "drawn" }] : /* istanbul ignore next */ []);
	legend = computed(() => {
		if (!this.several()) return [];
		const format = this.format();
		return this.lines().map((entry, index) => ({
			key: entry.key,
			label: entry.label,
			index,
			value: describe(entry.values.at(-1), format)
		}));
	}, ...ngDevMode ? [{ debugName: "legend" }] : /* istanbul ignore next */ []);
	plotHeight = computed(() => `${PLOT_REM[this.frameSize()]}rem`, ...ngDevMode ? [{ debugName: "plotHeight" }] : /* istanbul ignore next */ []);
	grid = computed(() => gridMarks(this.domain()), ...ngDevMode ? [{ debugName: "grid" }] : /* istanbul ignore next */ []);
	gridLabels = computed(() => {
		const size = this.frameSize();
		const taken = this.levels().filter((level) => level.side === "start").map((level) => labelSpan(level.y, size));
		return roomyGridMarks(this.grid(), size, taken);
	}, ...ngDevMode ? [{ debugName: "gridLabels" }] : /* istanbul ignore next */ []);
	levels = computed(() => {
		const domain = this.domain();
		const inside = (value) => domain[0] <= value && value <= domain[1];
		const reference = this.reference();
		return [...this.thresholds().filter((threshold) => inside(threshold.value)).map((threshold) => ({
			y: yAt(threshold.value, domain),
			color: lineToken(threshold.tone),
			label: threshold.label,
			side: threshold.tone === "danger" ? "end" : "start"
		})), ...reference && inside(reference.value) ? [{
			y: yAt(reference.value, domain),
			color: REFERENCE_TOKEN,
			label: reference.label,
			side: "start"
		}] : []];
	}, ...ngDevMode ? [{ debugName: "levels" }] : /* istanbul ignore next */ []);
	timeTicks = computed(() => timeAxis(this.times(), this.length(), this.axis()), ...ngDevMode ? [{ debugName: "timeTicks" }] : /* istanbul ignore next */ []);
	name = computed(() => {
		const format = this.format();
		const current = this.headline() || this.lines().map((entry) => describe(entry.values.at(-1), format)).join(", ");
		return chartName(this.label(), current, this.times(), this.length(), this.axis());
	}, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	cursor = sampleCursor({
		length: this.length,
		fractions: this.fractions,
		spoken: (index) => this.readoutFor(index).spoken
	});
	readout = computed(() => {
		const index = this.cursor.active();
		return index === null ? null : this.readoutFor(index);
	}, ...ngDevMode ? [{ debugName: "readout" }] : /* istanbul ignore next */ []);
	readoutFor(index) {
		const format = this.format();
		const several = this.several();
		return readoutAt(this.fractions()[index], whenText(this.times(), this.length(), index, this.axis()), this.lines().map((entry, line) => ({
			key: entry.key,
			label: entry.label,
			value: describe(entry.values[index], format),
			series: several ? line : null
		})));
	}
	onPointerMove(event) {
		const fraction = fractionAcross(event, this.plot().nativeElement);
		if (fraction !== null) this.cursor.pointerTo(fraction);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTimeChart,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatTimeChart,
		isStandalone: true,
		selector: "neat-time-chart",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			headline: {
				classPropertyName: "headline",
				publicName: "headline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			series: {
				classPropertyName: "series",
				publicName: "series",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			times: {
				classPropertyName: "times",
				publicName: "times",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			domain: {
				classPropertyName: "domain",
				publicName: "domain",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			thresholds: {
				classPropertyName: "thresholds",
				publicName: "thresholds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reference: {
				classPropertyName: "reference",
				publicName: "reference",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			axis: {
				classPropertyName: "axis",
				publicName: "axis",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headless: {
				classPropertyName: "headless",
				publicName: "headless",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			valueLabels: {
				classPropertyName: "valueLabels",
				publicName: "valueLabels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"style.--plot-height": "plotHeight()",
			"attr.data-fill": "size() === 'fill' ? '' : null"
		} },
		viewQueries: [{
			propertyName: "plot",
			first: true,
			predicate: ["plot"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (!headless()) {
      <div class="head">
        <span class="title">{{ label() }}</span>
        @if (headline()) {
          <span class="headline">{{ headline() }}</span>
        }
      </div>
    }
    @if (legend().length) {
      <ul class="legend">
        @for (item of legend(); track item.key) {
          <li>
            <neat-series-swatch [index]="item.index" />
            <span>{{ item.label }}</span>
            <strong>{{ item.value }}</strong>
          </li>
        }
      </ul>
    }
    <div
      #plot
      class="plot"
      tabindex="0"
      role="group"
      aria-roledescription="chart"
      [attr.aria-label]="name()"
      (pointermove)="onPointerMove($event)"
      (pointerleave)="cursor.pointerLeave()"
      (focus)="cursor.focus()"
      (blur)="cursor.blur()"
      (keydown)="cursor.keydown($event)"
    >
      <svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
        @for (tick of grid(); track tick.value) {
          <line class="grid" x1="0" x2="600" [attr.y1]="tick.y" [attr.y2]="tick.y" />
        }
        @for (level of levels(); track $index) {
          <line
            class="level"
            x1="0"
            x2="600"
            [attr.y1]="level.y"
            [attr.y2]="level.y"
            stroke-dasharray="6 4"
            [style.--level]="level.color"
          />
        }
        @for (entry of drawn(); track entry.key) {
          <g class="series" [style.--series]="entry.color">
            @if (entry.area) {
              <path class="area" [attr.d]="entry.area" />
            }
            @if (entry.line) {
              <path class="line" [attr.d]="entry.line" />
            }
          </g>
        }
      </svg>
      @if (valueLabelled()) {
        @for (tick of gridLabels(); track tick.value) {
          <span
            class="tag grid-label"
            data-side="start"
            aria-hidden="true"
            [style.top.%]="tick.y"
            [attr.data-below]="tick.y < flipBelow ? '' : null"
            >{{ tick.text }}</span
          >
        }
        @for (level of levels(); track $index) {
          <span
            class="tag level-tag"
            aria-hidden="true"
            [attr.data-side]="level.side"
            [style.top.%]="level.y"
            [style.--level]="level.color"
            [attr.data-below]="level.y < flipBelow ? '' : null"
            >{{ level.label }}</span
          >
        }
      }
      @for (entry of drawn(); track entry.key) {
        @if (entry.last; as last) {
          <span
            class="dot"
            aria-hidden="true"
            [style.left.%]="last.x / 6"
            [style.top.%]="last.y"
            [style.--series]="entry.color"
          ></span>
        }
      }
      @if (readout(); as readout) {
        <span class="crosshair" aria-hidden="true" [style.left.%]="readout.at * 100"></span>
        <span
          class="readout"
          aria-hidden="true"
          [attr.data-flip]="readout.at > 0.5 ? '' : null"
          [style.--at]="readout.at"
        >
          @if (readout.when) {
            <span class="when">{{ readout.when }}</span>
          }
          @for (row of readout.rows; track row.key) {
            <span class="row">
              @if (row.series !== null) {
                <neat-series-swatch [index]="row.series" />
              }
              {{ row.label }} {{ row.value }}
            </span>
          }
        </span>
      }
    </div>
    @if (labelled()) {
      <div class="axis" aria-hidden="true">
        @for (tick of timeTicks(); track tick.at) {
          <span [style.--at]="tick.at">{{ tick.text }}</span>
        }
      </div>
    }
    <span class="sr-only" aria-live="polite">{{ cursor.announcement() }}</span>
  `,
		isInline: true,
		styles: [
			":host{position:relative;display:block;font-size:var(--neat-text-sm)}.head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:var(--neat-space-2);margin-block-end:var(--neat-space-2)}.title{color:var(--muted-foreground)}.headline{font-weight:600;font-variant-numeric:tabular-nums}.readout{position:absolute;top:0;left:calc(var(--at) * 100%);z-index:1;display:flex;flex-direction:column;gap:.125rem;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}.readout:not([data-flip]){transform:translate(var(--neat-space-2))}.readout[data-flip]{transform:translate(calc(-100% - var(--neat-space-2)))}.when{color:var(--muted-foreground)}.row{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.axis{position:relative;flex-shrink:0;height:1rem;margin-block-start:.25rem;font-size:var(--neat-text-xs);color:var(--muted-foreground)}.axis span{position:absolute;left:calc(var(--at) * 100%);transform:translate(calc(var(--at) * -100%));white-space:nowrap}\n",
			".plot{position:relative;height:var(--plot-height);touch-action:pan-y}.plot:focus-visible{outline:2px solid var(--ring);outline-offset:2px}svg{display:block;width:100%;height:100%;overflow:visible}.grid{stroke:var(--border);stroke-width:1;vector-effect:non-scaling-stroke}.tag{position:absolute;padding-inline:.25rem;font-size:var(--neat-text-xs);line-height:1;white-space:nowrap;color:var(--muted-foreground);text-shadow:0 0 2px var(--neat-surface),0 0 2px var(--neat-surface);pointer-events:none}.tag:not([data-below]){transform:translateY(calc(-100% - 2px))}.tag[data-below]{transform:translateY(2px)}.tag[data-side=start]{inset-inline-start:0}.tag[data-side=end]{inset-inline-end:0}.crosshair{position:absolute;top:0;bottom:0;width:1px;background:var(--muted-foreground);pointer-events:none}\n",
			":host([data-fill]){display:flex;flex-direction:column}:host([data-fill]) .plot{flex:1 1 0;min-height:var(--plot-height)}.legend{display:flex;flex-wrap:wrap;gap:var(--neat-space-2) var(--neat-space-4);margin:0 0 var(--neat-space-2);padding:0;list-style:none}.legend li{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.legend strong{font-weight:600;font-variant-numeric:tabular-nums}.level{stroke:var(--level);stroke-width:1;vector-effect:non-scaling-stroke}.area{fill:var(--series);fill-opacity:.12;stroke:none}.line{fill:none;stroke:var(--series);stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}.level-tag{color:var(--level)}.dot{position:absolute;width:.5rem;height:.5rem;border-radius:50%;background:var(--series);transform:translate(-50%,-50%);pointer-events:none}\n"
		],
		dependencies: [{
			kind: "component",
			type: NeatSeriesSwatch$1,
			selector: "neat-series-swatch",
			inputs: ["index"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTimeChart,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-time-chart",
			imports: [NeatSeriesSwatch$1],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[style.--plot-height]": "plotHeight()",
				"[attr.data-fill]": "size() === 'fill' ? '' : null"
			},
			template: `
    @if (!headless()) {
      <div class="head">
        <span class="title">{{ label() }}</span>
        @if (headline()) {
          <span class="headline">{{ headline() }}</span>
        }
      </div>
    }
    @if (legend().length) {
      <ul class="legend">
        @for (item of legend(); track item.key) {
          <li>
            <neat-series-swatch [index]="item.index" />
            <span>{{ item.label }}</span>
            <strong>{{ item.value }}</strong>
          </li>
        }
      </ul>
    }
    <div
      #plot
      class="plot"
      tabindex="0"
      role="group"
      aria-roledescription="chart"
      [attr.aria-label]="name()"
      (pointermove)="onPointerMove($event)"
      (pointerleave)="cursor.pointerLeave()"
      (focus)="cursor.focus()"
      (blur)="cursor.blur()"
      (keydown)="cursor.keydown($event)"
    >
      <svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
        @for (tick of grid(); track tick.value) {
          <line class="grid" x1="0" x2="600" [attr.y1]="tick.y" [attr.y2]="tick.y" />
        }
        @for (level of levels(); track $index) {
          <line
            class="level"
            x1="0"
            x2="600"
            [attr.y1]="level.y"
            [attr.y2]="level.y"
            stroke-dasharray="6 4"
            [style.--level]="level.color"
          />
        }
        @for (entry of drawn(); track entry.key) {
          <g class="series" [style.--series]="entry.color">
            @if (entry.area) {
              <path class="area" [attr.d]="entry.area" />
            }
            @if (entry.line) {
              <path class="line" [attr.d]="entry.line" />
            }
          </g>
        }
      </svg>
      @if (valueLabelled()) {
        @for (tick of gridLabels(); track tick.value) {
          <span
            class="tag grid-label"
            data-side="start"
            aria-hidden="true"
            [style.top.%]="tick.y"
            [attr.data-below]="tick.y < flipBelow ? '' : null"
            >{{ tick.text }}</span
          >
        }
        @for (level of levels(); track $index) {
          <span
            class="tag level-tag"
            aria-hidden="true"
            [attr.data-side]="level.side"
            [style.top.%]="level.y"
            [style.--level]="level.color"
            [attr.data-below]="level.y < flipBelow ? '' : null"
            >{{ level.label }}</span
          >
        }
      }
      @for (entry of drawn(); track entry.key) {
        @if (entry.last; as last) {
          <span
            class="dot"
            aria-hidden="true"
            [style.left.%]="last.x / 6"
            [style.top.%]="last.y"
            [style.--series]="entry.color"
          ></span>
        }
      }
      @if (readout(); as readout) {
        <span class="crosshair" aria-hidden="true" [style.left.%]="readout.at * 100"></span>
        <span
          class="readout"
          aria-hidden="true"
          [attr.data-flip]="readout.at > 0.5 ? '' : null"
          [style.--at]="readout.at"
        >
          @if (readout.when) {
            <span class="when">{{ readout.when }}</span>
          }
          @for (row of readout.rows; track row.key) {
            <span class="row">
              @if (row.series !== null) {
                <neat-series-swatch [index]="row.series" />
              }
              {{ row.label }} {{ row.value }}
            </span>
          }
        </span>
      }
    </div>
    @if (labelled()) {
      <div class="axis" aria-hidden="true">
        @for (tick of timeTicks(); track tick.at) {
          <span [style.--at]="tick.at">{{ tick.text }}</span>
        }
      </div>
    }
    <span class="sr-only" aria-live="polite">{{ cursor.announcement() }}</span>
  `,
			styles: [
				":host{position:relative;display:block;font-size:var(--neat-text-sm)}.head{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:var(--neat-space-2);margin-block-end:var(--neat-space-2)}.title{color:var(--muted-foreground)}.headline{font-weight:600;font-variant-numeric:tabular-nums}.readout{position:absolute;top:0;left:calc(var(--at) * 100%);z-index:1;display:flex;flex-direction:column;gap:.125rem;padding:var(--neat-space-2);border:1px solid var(--border);border-radius:var(--radius);background:var(--popover);color:var(--popover-foreground);font-size:var(--neat-text-xs);font-variant-numeric:tabular-nums;white-space:nowrap;pointer-events:none}.readout:not([data-flip]){transform:translate(var(--neat-space-2))}.readout[data-flip]{transform:translate(calc(-100% - var(--neat-space-2)))}.when{color:var(--muted-foreground)}.row{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.axis{position:relative;flex-shrink:0;height:1rem;margin-block-start:.25rem;font-size:var(--neat-text-xs);color:var(--muted-foreground)}.axis span{position:absolute;left:calc(var(--at) * 100%);transform:translate(calc(var(--at) * -100%));white-space:nowrap}\n",
				".plot{position:relative;height:var(--plot-height);touch-action:pan-y}.plot:focus-visible{outline:2px solid var(--ring);outline-offset:2px}svg{display:block;width:100%;height:100%;overflow:visible}.grid{stroke:var(--border);stroke-width:1;vector-effect:non-scaling-stroke}.tag{position:absolute;padding-inline:.25rem;font-size:var(--neat-text-xs);line-height:1;white-space:nowrap;color:var(--muted-foreground);text-shadow:0 0 2px var(--neat-surface),0 0 2px var(--neat-surface);pointer-events:none}.tag:not([data-below]){transform:translateY(calc(-100% - 2px))}.tag[data-below]{transform:translateY(2px)}.tag[data-side=start]{inset-inline-start:0}.tag[data-side=end]{inset-inline-end:0}.crosshair{position:absolute;top:0;bottom:0;width:1px;background:var(--muted-foreground);pointer-events:none}\n",
				":host([data-fill]){display:flex;flex-direction:column}:host([data-fill]) .plot{flex:1 1 0;min-height:var(--plot-height)}.legend{display:flex;flex-wrap:wrap;gap:var(--neat-space-2) var(--neat-space-4);margin:0 0 var(--neat-space-2);padding:0;list-style:none}.legend li{display:inline-flex;align-items:center;gap:var(--neat-space-2)}.legend strong{font-weight:600;font-variant-numeric:tabular-nums}.level{stroke:var(--level);stroke-width:1;vector-effect:non-scaling-stroke}.area{fill:var(--series);fill-opacity:.12;stroke:none}.line{fill:none;stroke:var(--series);stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}.level-tag{color:var(--level)}.dot{position:absolute;width:.5rem;height:.5rem;border-radius:50%;background:var(--series);transform:translate(-50%,-50%);pointer-events:none}\n"
			]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		headline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headline",
				required: false
			}]
		}],
		series: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "series",
				required: true
			}]
		}],
		times: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "times",
				required: true
			}]
		}],
		domain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "domain",
				required: true
			}]
		}],
		thresholds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "thresholds",
				required: false
			}]
		}],
		reference: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reference",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		axis: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "axis",
				required: false
			}]
		}],
		headless: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headless",
				required: false
			}]
		}],
		valueLabels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "valueLabels",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		plot: [{
			type: i0.ViewChild,
			args: ["plot", { isSignal: true }]
		}]
	}
});
export { NeatChartCard, NeatHeatmap, NeatLabelTimeline, NeatScoreBars, NeatSeriesSwatch, NeatSparkline, NeatStackedChart, NeatTimeChart, neatLabelColour };

//# sourceMappingURL=sima-neat-ui-charts.mjs.map