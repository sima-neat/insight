import { NeatTone } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/**
 * A note set apart on a status tint, with an optional heading and a row of actions:
 *
 * ```html
 * <neat-callout tone="warning" heading="Board changed" announce="status">
 *   The board at 192.168.1.20 replaced the previous one.
 *   <button neatButton neatCalloutActions type="button">Refresh</button>
 * </neat-callout>
 * ```
 *
 * For a banner over a page, a problem or a guide in a dialog, a note in a panel. `tone` (a
 * `NeatTone`, `info` by default) picks the fill, the start border and the icon: `error` for
 * danger, `warning`, `check` for success, `info` otherwise. The content is the body; elements
 * marked `neatCalloutActions` go to a row under it.
 *
 * The heading is a real heading (`role="heading"`), at `headingLevel`, 3 by default. That puts it
 * under a dialog's title (a level 2) or a page's section, where heading navigation finds it. Pick
 * the level that fits where the callout stands.
 *
 * The fill is the page's color mixed with the tone, so in a dialog it differs from the dialog's own
 * surface. A neutral callout in a dark dialog shows by its border and icon.
 *
 * `region` makes the callout a landmark, for a notice a user should be able to jump to, such as
 * the Viewer's late notice. The heading names it. Without a heading the callout takes no role,
 * since a region with no name is no landmark.
 *
 * `announce` instead gives the host a live role, to say the note with when it appears. Use
 * `status` for news that can wait, and `alert` for a failure that needs attention now. It wins over
 * `region`, since a host has one role.
 *
 * A callout with a role is labeled by its heading (`aria-labelledby`). One without a role is a
 * plain note. A live region speaks what is added to it, so render the callout when its news
 * happens (an `@if`), not hidden beforehand.
 */
export declare class NeatCallout {
  /** The kind of note: sets the fill, the start border and the icon. */
  readonly tone: import("@angular/core").InputSignal<NeatTone>;
  /** A short heading over the body; none if empty. */
  readonly heading: import("@angular/core").InputSignal<string>;
  /** The heading's level in the page's outline. */
  readonly headingLevel: import("@angular/core").InputSignal<2 | 3 | 4 | 5 | 6>;
  /**
   * Whether the callout is a landmark, named by its heading (none without one); a live role wins
   * over it.
   */
  readonly region: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The live role the note is said with when it appears; none by default. */
  readonly announce: import("@angular/core").InputSignal<"status" | "alert" | null>;
  protected readonly headingId: string;
  protected readonly role: import("@angular/core").Signal<"status" | "alert" | "region" | null>;
  protected readonly classes: import("@angular/core").Signal<string>;
  protected readonly icon: import("@angular/core").Signal<"warning" | "info" | "home" | "media" | "streaming" | "viewer" | "peripherals" | "camera" | "microphone" | "lidar" | "device" | "stats" | "board" | "sun" | "moon" | "kiosk-enter" | "kiosk-exit" | "expand-window" | "rail-expand" | "rail-collapse" | "side-panel" | "palette" | "shapes" | "blocks" | "document" | "previous" | "next" | "close" | "check" | "copy" | "expand" | "collapse" | "minus" | "plus" | "aspect-wide" | "aspect-square" | "search" | "more" | "fit-all" | "upload" | "folder" | "file" | "error" | "refresh" | "spinner" | "terminal" | "pause" | "play" | "stop">;
  /** Level with the first line of text (`text-sm` is 20px high, the icon 16px). */
  protected readonly iconClasses: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCallout, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCallout, "neat-callout", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "heading": {
      "alias": "heading";
      "required": false;
      "isSignal": true;
    };
    "headingLevel": {
      "alias": "headingLevel";
      "required": false;
      "isSignal": true;
    };
    "region": {
      "alias": "region";
      "required": false;
      "isSignal": true;
    };
    "announce": {
      "alias": "announce";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[neatCalloutActions]"], true, never>;
}