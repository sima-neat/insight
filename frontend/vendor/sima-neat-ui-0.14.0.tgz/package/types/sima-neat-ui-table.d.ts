import * as i0 from "@angular/core";
/**
 * A data table's look, on a native `table` whose rows and cells the app writes:
 *
 * ```html
 * <table neatTable aria-label="Metrics of the run">
 *   <thead>
 *     <tr><th scope="col">Metric</th><th scope="col" neatNumeric>Mean</th></tr>
 *   </thead>
 *   <tbody>
 *     <tr><th scope="row">Power</th><td neatNumeric>12.5 W</td></tr>
 *   </tbody>
 * </table>
 * ```
 *
 * It sets the look only: the columns, what a cell holds and how a table gives up a column when
 * its container is narrow are the app's (the kit cannot know the container, or which columns
 * matter). The table's name for assistive technology is the app's too (`aria-label`).
 */
export declare class NeatTable {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTable, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTable, "table[neatTable]", never, {}, {}, never, never, true, never>;
}
/**
 * A figure's cell or heading, `th` or `td` of a `neatTable`: end-aligned, on one line, with tabular
 * digits so that the figures of a column line up. It only marks the cell; the look is the table's,
 * which is why the cell does nothing outside one. Put it on a column's heading as well as on its
 * cells so that the heading sits over the figures.
 */
export declare class NeatNumeric {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNumeric, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatNumeric, "td[neatNumeric], th[neatNumeric]", never, {}, {}, never, never, true, never>;
}