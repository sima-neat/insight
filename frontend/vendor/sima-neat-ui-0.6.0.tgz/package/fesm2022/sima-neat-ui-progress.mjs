import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, input } from "@angular/core";
import { BrnProgress, BrnProgressIndicator } from "@spartan-ng/brain/progress";
import { ɵhlm } from "@sima/neat-ui";
const PROGRESS_HELM_CLASSES = {
	track: "bg-muted h-1.5 rounded-full relative inline-flex w-full overflow-hidden",
	indicator: "bg-primary h-full w-full flex-1 transition-all"
};
const TRACK_CLASSES = ɵhlm(PROGRESS_HELM_CLASSES.track, "ring-1 ring-input");
const INDETERMINATE_CLASSES = `animate-indeterminate motion-reduce:animate-none motion-reduce:bg-transparent motion-reduce:bg-[repeating-linear-gradient(135deg,var(--primary)_0_6px,transparent_6px_12px)]`;
var NeatProgress = class NeatProgress {
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	trackClasses = TRACK_CLASSES;
	shown = computed(() => {
		const value = this.value();
		return value === null || !Number.isFinite(value) ? null : Math.min(100, Math.max(0, value));
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	indicatorClasses = computed(() => ɵhlm(PROGRESS_HELM_CLASSES.indicator, this.shown() === null ? INDETERMINATE_CLASSES : ""), ...ngDevMode ? [{ debugName: "indicatorClasses" }] : /* istanbul ignore next */ []);
	transform = computed(() => `translateX(-${100 - (this.shown() ?? 100)}%)`, ...ngDevMode ? [{ debugName: "transform" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatProgress,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatProgress,
		isStandalone: true,
		selector: "neat-progress",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { classAttribute: "block" },
		ngImport: i0,
		template: `
    <brn-progress
      data-slot="progress"
      [class]="trackClasses"
      [value]="shown()"
      [attr.aria-label]="label()"
    >
      <brn-progress-indicator
        data-slot="progress-indicator"
        [class]="indicatorClasses()"
        [style.transform]="transform()"
      />
    </brn-progress>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: BrnProgress,
			selector: "brn-progress",
			inputs: [
				"value",
				"max",
				"getValueLabel"
			],
			exportAs: ["brnProgress"]
		}, {
			kind: "directive",
			type: BrnProgressIndicator,
			selector: "brn-progress-indicator",
			exportAs: ["brnProgressIndicator"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatProgress,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-progress",
			imports: [BrnProgress, BrnProgressIndicator],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "block" },
			template: `
    <brn-progress
      data-slot="progress"
      [class]="trackClasses"
      [value]="shown()"
      [attr.aria-label]="label()"
    >
      <brn-progress-indicator
        data-slot="progress-indicator"
        [class]="indicatorClasses()"
        [style.transform]="transform()"
      />
    </brn-progress>
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}]
	}
});
export { NeatProgress };

//# sourceMappingURL=sima-neat-ui-progress.mjs.map