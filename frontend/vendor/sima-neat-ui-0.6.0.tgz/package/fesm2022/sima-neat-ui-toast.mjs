import { Overlay } from "@angular/cdk/overlay";
import { TemplatePortal } from "@angular/cdk/portal";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, ViewContainerRef, afterNextRender, computed, effect, inject, signal, untracked, viewChild } from "@angular/core";
import { NeatProgress } from "@sima/neat-ui/progress";
const ERROR_TOAST_MS = 4600;
const STATUS_TOAST_MS = 3200;
function visibleToasts(entries) {
	let excess = entries.length - 3;
	if (excess <= 0) return entries;
	const hidden = /* @__PURE__ */ new Set();
	const newest = entries.at(-1);
	for (const transient of [true, false]) for (const entry of entries) if (excess > 0 && entry !== newest && entry.kind !== "progress" === transient) {
		hidden.add(entry.id);
		excess--;
	}
	return entries.filter((entry) => !hidden.has(entry.id));
}
function wholePercent(percent) {
	if (percent === null || !Number.isFinite(percent)) return null;
	return Math.round(Math.min(100, Math.max(0, percent)));
}
var ToastStore = class ToastStore {
	state = signal([], ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	timers = /* @__PURE__ */ new Set();
	nextId = 1;
	entries = this.state.asReadonly();
	constructor() {
		inject(DestroyRef).onDestroy(() => this.timers.forEach((timer) => clearTimeout(timer)));
	}
	show(kind, message) {
		const id = this.nextId++;
		this.state.update((entries) => [...entries, {
			id,
			kind,
			message
		}]);
		const timer = setTimeout(() => {
			this.timers.delete(timer);
			this.remove(id);
		}, kind === "error" ? ERROR_TOAST_MS : STATUS_TOAST_MS);
		this.timers.add(timer);
	}
	startProgress(title) {
		const id = this.nextId++;
		this.state.update((entries) => [...entries, {
			id,
			kind: "progress",
			title,
			detail: "",
			percent: null
		}]);
		return id;
	}
	updateProgress(id, detail, percent) {
		this.state.update((entries) => entries.map((entry) => entry.id === id && entry.kind === "progress" ? {
			...entry,
			detail,
			percent: wholePercent(percent)
		} : entry));
	}
	settleProgress(id, kind, message) {
		if (!this.state().some((entry) => entry.id === id)) return;
		this.remove(id);
		this.show(kind, message);
	}
	remove(id) {
		this.state.update((entries) => entries.filter((entry) => entry.id !== id));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ToastStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
const SCREEN_INSET = "1rem";
const SURFACE = "bg-popover ring-1 rounded-md shadow-md p-3 text-sm animate-in fade-in-0 slide-in-from-bottom-2 duration-200 motion-reduce:animate-none";
const NEUTRAL = `${SURFACE} text-popover-foreground ring-border`;
const TOAST_CLASSES = {
	status: NEUTRAL,
	progress: NEUTRAL,
	error: `${SURFACE} text-destructive ring-destructive`
};
var NeatToastHost = class NeatToastHost {
	store = inject(ToastStore);
	announcer = viewChild.required("announcer", ...ngDevMode ? [{ debugName: "announcer" }] : /* istanbul ignore next */ []);
	stack = viewChild.required("stack", ...ngDevMode ? [{ debugName: "stack" }] : /* istanbul ignore next */ []);
	stackOverlay;
	newestShown = 0;
	classes = TOAST_CLASSES;
	announced = this.store.entries;
	visible = computed(() => visibleToasts(this.store.entries()), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	constructor() {
		const overlay = inject(Overlay);
		const viewContainer = inject(ViewContainerRef);
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			const announcement = overlay.create({ positionStrategy: overlay.position().global() });
			announcement.attach(new TemplatePortal(this.announcer(), viewContainer));
			const stack = overlay.create({ positionStrategy: overlay.position().global().bottom(SCREEN_INSET).right(SCREEN_INSET) });
			stack.attach(new TemplatePortal(this.stack(), viewContainer));
			for (const layer of [announcement, stack]) layer.overlayElement.style.pointerEvents = "none";
			this.stackOverlay = stack;
			destroyRef.onDestroy(() => {
				announcement.dispose();
				stack.dispose();
			});
		});
		effect(() => {
			const newest = this.store.entries().at(-1)?.id ?? 0;
			untracked(() => {
				if (newest > this.newestShown) {
					this.newestShown = newest;
					this.bringToFront();
				}
			});
		});
	}
	bringToFront() {
		const host = this.stackOverlay?.hostElement;
		if (!host) return;
		if (host.hasAttribute("popover")) {
			host.hidePopover();
			host.showPopover();
		} else host.parentElement?.append(host);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatToastHost,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatToastHost,
		isStandalone: true,
		selector: "neat-toast-host",
		viewQueries: [{
			propertyName: "announcer",
			first: true,
			predicate: ["announcer"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "stack",
			first: true,
			predicate: ["stack"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #announcer>
      <div aria-live="polite" class="sr-only" data-slot="toast-announcer">
        @for (toast of announced(); track toast.id) {
          <div data-slot="toast-announcement">
            @if (toast.kind === 'progress') {
              {{ toast.title }}
              <span aria-live="off">
                {{ toast.detail }}
                @if (toast.percent !== null) {
                  {{ toast.percent }}%
                }
              </span>
            } @else {
              @if (toast.kind === 'error') {
                Error:
              }
              {{ toast.message }}
            }
          </div>
        }
      </div>
    </ng-template>
    <ng-template #stack>
      <div aria-hidden="true" class="flex w-[min(22.5rem,calc(100vw-2rem))] flex-col gap-2">
        @for (toast of visible(); track toast.id) {
          <div data-slot="toast" [attr.data-kind]="toast.kind" [class]="classes[toast.kind]">
            @if (toast.kind === 'progress') {
              <p class="m-0 font-medium">{{ toast.title }}</p>
              <div
                class="text-muted-foreground mt-1 flex justify-between gap-3 text-(length:--neat-text-xs)"
              >
                <span class="truncate" [attr.title]="toast.detail">{{ toast.detail }}</span>
                @if (toast.percent !== null) {
                  <span>{{ toast.percent }}%</span>
                }
              </div>
              <neat-progress class="mt-2" [label]="toast.title" [value]="toast.percent" />
            } @else {
              <p class="m-0">{{ toast.message }}</p>
            }
          </div>
        }
      </div>
    </ng-template>
  `,
		isInline: true,
		styles: [":host{display:none}\n"],
		dependencies: [{
			kind: "component",
			type: NeatProgress,
			selector: "neat-progress",
			inputs: ["value", "label"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatToastHost,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-toast-host",
			imports: [NeatProgress],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <ng-template #announcer>
      <div aria-live="polite" class="sr-only" data-slot="toast-announcer">
        @for (toast of announced(); track toast.id) {
          <div data-slot="toast-announcement">
            @if (toast.kind === 'progress') {
              {{ toast.title }}
              <span aria-live="off">
                {{ toast.detail }}
                @if (toast.percent !== null) {
                  {{ toast.percent }}%
                }
              </span>
            } @else {
              @if (toast.kind === 'error') {
                Error:
              }
              {{ toast.message }}
            }
          </div>
        }
      </div>
    </ng-template>
    <ng-template #stack>
      <div aria-hidden="true" class="flex w-[min(22.5rem,calc(100vw-2rem))] flex-col gap-2">
        @for (toast of visible(); track toast.id) {
          <div data-slot="toast" [attr.data-kind]="toast.kind" [class]="classes[toast.kind]">
            @if (toast.kind === 'progress') {
              <p class="m-0 font-medium">{{ toast.title }}</p>
              <div
                class="text-muted-foreground mt-1 flex justify-between gap-3 text-(length:--neat-text-xs)"
              >
                <span class="truncate" [attr.title]="toast.detail">{{ toast.detail }}</span>
                @if (toast.percent !== null) {
                  <span>{{ toast.percent }}%</span>
                }
              </div>
              <neat-progress class="mt-2" [label]="toast.title" [value]="toast.percent" />
            } @else {
              <p class="m-0">{{ toast.message }}</p>
            }
          </div>
        }
      </div>
    </ng-template>
  `,
			styles: [":host{display:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		announcer: [{
			type: i0.ViewChild,
			args: ["announcer", { isSignal: true }]
		}],
		stack: [{
			type: i0.ViewChild,
			args: ["stack", { isSignal: true }]
		}]
	}
});
var NeatToasts = class NeatToasts {
	store = inject(ToastStore);
	error(message) {
		this.store.show("error", message);
	}
	status(message) {
		this.store.show("status", message);
	}
	progress(title) {
		const id = this.store.startProgress(title);
		return {
			update: (detail, percent) => this.store.updateProgress(id, detail, percent),
			done: (message) => this.store.settleProgress(id, "status", message),
			fail: (message) => this.store.settleProgress(id, "error", message)
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatToasts,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatToasts,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatToasts,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
export { NeatToastHost, NeatToasts };

//# sourceMappingURL=sima-neat-ui-toast.mjs.map