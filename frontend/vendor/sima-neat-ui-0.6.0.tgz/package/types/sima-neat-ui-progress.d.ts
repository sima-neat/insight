import * as i0 from "@angular/core";
/**
 * Helm's progress classes (`lib/ui/progress/src/lib/hlm-progress.ts` and
 * `hlm-progress-indicator.ts`), copied because helm keeps them inline. progress.spec checks that
 * each string still appears in the vendored helm, so a helm update that changes one fails until
 * this table is reviewed.
 */
declare const PROGRESS_HELM_CLASSES: {
  readonly track: "bg-muted h-1.5 rounded-full relative inline-flex w-full overflow-hidden";
  readonly indicator: "bg-primary h-full w-full flex-1 transition-all";
};
/**
 * A horizontal progress bar: `<neat-progress label="Uploading clip.mp4" [value]="percent" />`.
 * `value` is 0 to 100, or `null` while the work cannot say how far along it is (the bar then
 * moves on its own). A value outside the range is held to it, and one that is not a number counts
 * as unknown, so a sloppy caller gets a bar, not an error.
 *
 * `label` is the accessible name. The bar is `role="progressbar"` with `aria-valuenow` (left out
 * while unknown), `aria-valuemin` and `aria-valuemax`, and a percent as `aria-valuetext`. It
 * announces nothing as it changes, which is a progressbar's way; a status that must be announced
 * belongs in a live region of its own, as the toasts' is. It fills the width its container
 * gives it, from the left: the kit has no right-to-left layout.
 *
 * Brain's progress is the element inside, which owns the role and the values; its range check
 * throws for a value out of range, which is why the kit's own input, held to the range, feeds it.
 */
export declare class NeatProgress {
  /** 0 to 100, or `null` while unknown. */
  readonly value: import("@angular/core").InputSignal<number | null>;
  /** The accessible name, announced with the value. */
  readonly label: import("@angular/core").InputSignal<string>;
  protected readonly trackClasses: string;
  /** The value the bar shows: within the range, or `null` when unknown. */
  protected readonly shown: import("@angular/core").Signal<number | null>;
  protected readonly indicatorClasses: import("@angular/core").Signal<string>;
  /**
   * The fill is as wide as the track and pushed out of it by the part that is not done. This and
   * the unknown state's class switch re-implement helm's `HlmProgressIndicator`; the drift spec
   * covers helm's class strings only, so a change to its logic needs a look at this by hand.
   */
  protected readonly transform: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatProgress, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatProgress, "neat-progress", never, {
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export {};