import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
/**
 * One column of a `neat-select-list`, as a template for the cells in it:
 *
 * ```html
 * <ng-template neatColumn="state" header="State" width="6rem" let-slot>{{ slot.state }}</ng-template>
 * ```
 *
 * The key names the column, `header` is the label over it (no label on any column: no header row),
 * and `width` is its CSS track size in the row's grid, `1fr` by default. The template gets the
 * item as its implicit context. A cell is a block that may shrink to nothing, so a long text
 * truncates in the cell rather than pushing the next column out.
 */
export declare class NeatColumn {
  readonly key: import("@angular/core").InputSignal<string>;
  readonly header: import("@angular/core").InputSignal<string>;
  readonly width: import("@angular/core").InputSignal<string>;
  readonly template: TemplateRef<unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatColumn, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatColumn, "ng-template[neatColumn]", never, {
    "key": {
      "alias": "neatColumn";
      "required": true;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** A row: the item, its key, the element id the listbox points at, and its cells' context. */
interface Row<T> {
  readonly item: T;
  readonly key: unknown;
  readonly id: string;
  readonly context: {
    readonly $implicit: T;
  };
}
/**
 * A list of items, one row each, in columns that the app lays out with templates; one row is
 * selected:
 *
 * ```html
 * <neat-select-list label="Streaming slots" [items]="slots()" [trackBy]="slotId" [(selected)]="slot">
 *   <ng-template neatColumn="name" header="Slot" let-slot>{{ slot.name }}</ng-template>
 *   <ng-template neatColumn="state" header="State" width="6rem" let-slot>…</ng-template>
 * </neat-select-list>
 * ```
 *
 * It fills its container (the container needs a height) and scrolls its rows inside, under a header
 * that stays put. `trackBy` gives an item's identity, unique in the list: the selection follows
 * the item with the same key when `items` is replaced by new objects (a poll's answer), and rows,
 * with the state in their cells, are kept rather than rebuilt. It is called once per item whenever
 * `items` changes, never while the list is only checked or the selection moves.
 *
 * It is a single-select `listbox` named by `label`, whose `option` rows are `aria-selected`.
 * Selection follows focus: the listbox is the one tab stop, holds the focus, and names the
 * selected row in `aria-activedescendant`; ArrowDown and ArrowUp move the selection (the first
 * press picks the first or last row when nothing is selected), Home and End jump to the ends, and
 * the selected row scrolls into view. Enter, and a click on a row, tell `activated` with the row's
 * item. A click on a control in a cell, and every key pressed while one has the focus, are that
 * control's: they neither select nor activate. Controls in cells are ordinary tab stops after
 * the listbox.
 *
 * The header repeats the columns' labels for the eye and is hidden from assistive technology: the
 * rows read as the text of their cells in order, as a listbox's options do (a listbox cannot
 * name its columns).
 *
 * `hint` is read as the listbox's description, for keys the app adds on top of these.
 *
 * Typing a letter to jump to a row, Page Up and Page Down, a selection of several rows and a
 * disabled row are not offered; none is needed yet.
 */
export declare class NeatSelectList<T> {
  /** The accessible name of the list. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly items: import("@angular/core").InputSignal<readonly T[]>;
  /** An item's identity, unique in the list. */
  readonly trackBy: import("@angular/core").InputSignal<(item: T) => unknown>;
  /** The selected item; `null` while there is none. */
  readonly selected: import("@angular/core").ModelSignal<T | null>;
  /** What to say, in place of rows, while there are no items. */
  readonly emptyLabel: import("@angular/core").InputSignal<string>;
  /**
   * Text for assistive technology that says what the keys do beyond the listbox's own, such as
   * "Press Space to check a file"; it describes the listbox, and is not shown.
   */
  readonly hint: import("@angular/core").InputSignal<string>;
  /** The item of the row that was clicked or that had Enter pressed on it. */
  readonly activated: import("@angular/core").OutputEmitterRef<T>;
  protected readonly headerClasses = "shrink-0 overflow-y-hidden border-b border-border text-xs font-medium text-muted-foreground [scrollbar-gutter:stable]";
  protected readonly headerLineClasses = "grid grid-cols-(--neat-select-list-columns) items-center gap-x-(--neat-space-3) border-s-2 border-transparent px-(--neat-space-3) py-1";
  protected readonly scrollerClasses = "min-h-0 flex-1 overflow-x-hidden overflow-y-auto [scrollbar-gutter:stable] has-[[role=listbox]:focus-visible]:outline-2 has-[[role=listbox]:focus-visible]:-outline-offset-2 has-[[role=listbox]:focus-visible]:outline-ring";
  protected readonly rowClasses = "grid grid-cols-(--neat-select-list-columns) items-center gap-x-(--neat-space-3) border-s-2 border-transparent px-(--neat-space-3) min-h-9 cursor-default py-1 text-sm hover:bg-accent aria-selected:border-primary aria-selected:bg-accent";
  private readonly id;
  protected readonly emptyId: string;
  protected readonly hintId: string;
  protected readonly columns: import("@angular/core").Signal<readonly NeatColumn[]>;
  private readonly listbox;
  private readonly scroller;
  protected readonly hasHeader: import("@angular/core").Signal<boolean>;
  protected readonly gridColumns: import("@angular/core").Signal<string>;
  /**
   * Everything a row needs, worked out once per `items`: the key (a call of the app's function),
   * the id and the cells' context. Change detection then reads these and calls nothing.
   */
  protected readonly rows: import("@angular/core").Signal<readonly Row<T>[]>;
  protected readonly isEmpty: import("@angular/core").Signal<boolean>;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  protected readonly selectedKey: import("@angular/core").Signal<unknown>;
  private readonly selectedIndex;
  protected readonly activeId: import("@angular/core").Signal<string>;
  /** The key of the row last scrolled to, so that a row that only moved is not scrolled to again. */
  private revealed;
  constructor();
  /** Scrolls the selected row into view unless that row was the last one scrolled to. */
  private revealSelected;
  /**
   * Scrolls back to the top, as a different set of rows (another folder) needs, or to the selected
   * row when there is one in the list. Call it once the new rows are rendered.
   */
  resetScroll(): void;
  /** Puts the keyboard focus on the list, where the arrow keys work. */
  focus(): void;
  protected onKeydown(event: KeyboardEvent): void;
  /** One listener on the listbox serves every row: the rows are found from the event's target. */
  protected onClick(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSelectList<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSelectList<any>, "neat-select-list", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
    "trackBy": {
      "alias": "trackBy";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "emptyLabel": {
      "alias": "emptyLabel";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "activated": "activated";
  }, ["columns"], never, true, never>;
}
export {};