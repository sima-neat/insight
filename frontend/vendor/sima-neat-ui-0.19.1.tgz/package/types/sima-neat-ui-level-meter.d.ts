import * as i0 from "@angular/core";
/** Which part of the bar a segment is in, as a level meter reads: low, nearly full, at the end. */
type MeterTone = 'low' | 'mid' | 'high';
/** How many of `count` meter segments a level lights. */
declare function meterSegments(levelDbfs: number | null | undefined, count: number): number;
/** Green for most of the bar, amber near the top, red at the end, as a level meter reads. */
declare function segmentTone(index: number, count: number): MeterTone;
/**
 * A live audio level as a bar of segments, from -50 dBFS (dark) to full scale (all lit), green to
 * 70 % of the bar, amber to 90 %, red above:
 *
 * ```html
 * <neat-level-meter [sample]="micTest.level" />
 * ```
 *
 * `sample` reads the current level in dBFS, or null for none (the meter is dark). While it is set
 * and the meter is rendered, the meter calls it once per animation frame, so one input serves a
 * value the app polls and keeps in a field as well as a Web Audio analyser read on demand. Pass
 * null to stop. The meter calls the function on its own, never as a method of the app's object:
 * give it an arrow function (`readonly level = () => this.lastLevel`), not a method. Return null
 * when the source is gone (an audio context closed) rather than throw: the loop outlives a throw,
 * so a sample that keeps throwing reports an error every frame.
 *
 * A meter that is rendered samples even where it cannot be seen (under a `display: none`
 * ancestor, in a closed collapsible), so render it only while there is a level to show
 * (`@if (recording || playing)`) instead of hiding it.
 *
 * Each frame writes the segments straight to the DOM, outside change detection: sixty change
 * detections a second for a bar of colour would cost more than everything else on the page.
 *
 * The meter is `aria-hidden`: a level read out every frame would be noise. Say what is happening
 * (recording, playing, silence) in text beside it.
 */
export declare class NeatLevelMeter {
  /** Reads the level in dBFS, once per frame; null leaves the meter dark. */
  readonly sample: import("@angular/core").InputSignal<(() => number | null) | null>;
  protected readonly segments: unknown[];
  private readonly segmentElements;
  /** How many segments are lit now, so a frame touches only the segments that change. */
  private lit;
  constructor();
  /** Lights the first `lit` segments and darkens the rest, writing only the ones that change. */
  private show;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatLevelMeter, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatLevelMeter, "neat-level-meter", never, {
    "sample": {
      "alias": "sample";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export {};