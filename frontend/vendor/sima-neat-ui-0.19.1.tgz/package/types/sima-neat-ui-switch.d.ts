import * as i0 from "@angular/core";
/**
 * Helm's switch classes (`lib/ui/switch`), copied because helm keeps them inline rather than as
 * constants. switch.spec checks that each string still appears in the vendored helm, so a helm
 * update that changes one fails until this table is reviewed.
 *
 * Helm puts the track classes on its focusable button. Here the host button holds the label as
 * well, so the track is a span inside it, and the track's focus and validation classes never
 * match: the host draws the focus ring instead.
 */
declare const SWITCH_HELM_CLASSES: {
  /** `hlm-switch.ts`: the track, which carries `data-state` and `data-size` as brain's button does. */
  readonly track: "data-checked:bg-primary data-unchecked:bg-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 dark:data-unchecked:bg-input/80 rounded-full border border-transparent shadow-xs focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 data-[size=default]:h-[18.4px] data-[size=default]:w-[32px] data-[size=sm]:h-[14px] data-[size=sm]:w-[24px] group/switch inline-flex shrink-0 items-center transition-all outline-none data-disabled:cursor-not-allowed data-disabled:opacity-50";
  /** `hlm-switch-thumb.ts` */
  readonly thumb: "bg-background dark:data-unchecked:bg-foreground dark:data-checked:bg-primary-foreground rounded-full group-data-[size=default]/switch:size-4 group-data-[size=sm]/switch:size-3 data-unchecked:translate-x-0 data-checked:ltr:translate-x-[calc(100%-2px)] data-checked:rtl:-translate-x-[calc(100%-2px)] pointer-events-none block ring-0 transition-transform";
};
/**
 * An on/off switch on a native button: `<button neatSwitch [(checked)]="bars">Bars</button>`. The
 * content is the visible label and the accessible name; without content, give it an `aria-label`.
 * Space and Enter toggle it as they click any button.
 *
 * A component rather than a directive on brain's switch: brain's switch is itself a component that
 * renders its own button, so it cannot sit on this one. The host is the native button, which
 * brings focus, keyboard activation and `disabled`; the switch adds the role, the state and the
 * track drawn with helm's classes.
 */
export declare class NeatSwitch {
  readonly checked: import("@angular/core").ModelSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly hostClasses: string;
  protected readonly trackClasses: string;
  protected readonly thumbClasses: string;
  protected readonly state: import("@angular/core").Signal<"checked" | "unchecked">;
  protected toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSwitch, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSwitch, "button[neatSwitch]", never, {
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checkedChange";
  }, never, ["*"], true, never>;
}
export {};