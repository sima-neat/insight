import * as i0 from "@angular/core";
/**
 * Facts about the selected thing, as a side panel shows them: a native description list whose
 * terms are muted and whose values sit beside them:
 *
 * ```html
 * <dl neatDetails>
 *   <dt>Stream</dt><dd>{{ status.stream }}</dd>
 *   @if (source(); as source) {
 *     <dt>Source</dt><dd><code>{{ source }}</code></dd>
 *   }
 * </dl>
 * ```
 *
 * It sets the look only; the pairs, their words and what a value holds (a code span, an inline
 * button beside a URL) are the app's. Write each `dt` and `dd` as a direct child of the list, one
 * value per term: the two columns are the list's grid.
 */
export declare class NeatDetails {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDetails, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDetails, "dl[neatDetails]", never, {}, {}, never, never, true, never>;
}