import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
import * as i1 from "@spartan-ng/brain/slider";
/**
 * Helm's slider classes (`lib/ui/slider/src/lib/hlm-slider.ts`), copied because helm keeps them
 * inline in its template. slider.spec checks that each string still appears in the vendored helm,
 * so a helm update that changes one fails until this table is reviewed. The kit's slider is
 * horizontal with one thumb and no ticks; helm's vertical and tick classes stay as they are.
 */
declare const SLIDER_HELM_CLASSES: {
  readonly root: "group flex w-full touch-none flex-col select-none data-vertical:h-full data-vertical:min-h-40 data-vertical:w-auto data-vertical:flex-row data-[disabled]:pointer-events-none data-[disabled]:opacity-50";
  readonly frame: "relative flex w-full items-center group-data-vertical:w-auto group-data-vertical:flex-col";
  readonly track: "bg-muted rounded-full data-horizontal:h-1.5 data-horizontal:w-full data-vertical:h-full data-vertical:w-1.5 relative grow overflow-hidden";
  readonly range: "bg-primary absolute select-none data-draggable-range:cursor-move data-horizontal:h-full data-vertical:w-full";
  readonly thumb: "border-primary ring-ring/50 size-4 rounded-full border bg-white shadow-sm transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden absolute block shrink-0 select-none after:absolute after:-inset-2";
};
/**
 * A horizontal slider for one number: `<neat-slider label="Tile width" [min]="120" [max]="480"
 * [step]="10" [(value)]="width" />`. `label` is the accessible name (it is not displayed); arrows
 * step, Page Up and Down and Shift step by ten, Home and End jump to the ends.
 *
 * `value` changes on every step of a drag, not only when the pointer is released, so whatever it
 * drives (the tile grid's repacking, for one) previews live. A value outside `min`..`max` is shown
 * clamped and stays as it is until the user moves the slider.
 *
 * `describedBy` is the id of the element that describes the slider (a note on where its value
 * applies, say); it goes on the thumb, the focusable element, like the name. The disabled state is
 * mirrored on the thumb as `aria-disabled` too: brain sets it on the root only, which assistive
 * technology never reaches from the thumb.
 *
 * Brain's slider is the host directive; its track, range and thumb directives draw it with helm's
 * classes. Brain holds a list of values (it also does ranges), so the kit's single number is kept
 * in step with it here.
 */
export declare class NeatSlider {
  readonly value: import("@angular/core").ModelSignal<number>;
  readonly min: import("@angular/core").InputSignal<number>;
  readonly max: import("@angular/core").InputSignal<number>;
  readonly step: import("@angular/core").InputSignal<number>;
  /** The accessible name, announced with the value. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The id of the element that describes the slider; announced after the name and value. */
  readonly describedBy: import("@angular/core").InputSignal<string | undefined>;
  protected readonly rootClasses: string;
  protected readonly frameClasses: string;
  protected readonly trackClasses: string;
  protected readonly rangeClasses: string;
  protected readonly thumbClasses: string;
  /** Brain's disabled state (also set by forms), as the attribute the thumb mirrors. */
  protected readonly disabledAttr: Signal<'true' | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSlider, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSlider, "neat-slider", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": true;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": true;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "describedBy": {
      "alias": "describedBy";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, [{
    directive: typeof i1.BrnSlider;
    inputs: {
      "min": "min";
      "max": "max";
      "step": "step";
      "disabled": "disabled";
      "aria-label": "label";
    };
    outputs: {};
  }]>;
}
export {};