import * as i1 from "@spartan-ng/brain/collapsible";
import { BrnCollapsible } from "@spartan-ng/brain/collapsible";
import * as i0 from "@angular/core";
/**
 * A section that a full-width button opens and closes, such as a panel's "Details":
 *
 * ```html
 * <neat-collapsible label="Details" [summary]="mode()" [(open)]="detailsOpen">…</neat-collapsible>
 * ```
 *
 * The trigger shows the `next` chevron (turned a quarter while open), `label` and, only while
 * closed, `summary` in muted text that truncates, for what the section holds at a glance. It is a
 * native button that names the content in `aria-controls` and says whether it is open in
 * `aria-expanded`; Enter and Space work as on any button. `open` is two-way bound. With
 * `headingLevel`, the button sits in a heading of that level (the WAI-ARIA disclosure and accordion
 * patterns), so the section's title is in the page's outline.
 *
 * The content stays instantiated while closed (hidden and `inert`), so its state survives a close;
 * gate expensive content (a live preview) on `open` with an `@if` of your own. When the section
 * closes with the focus inside it (a Save that closes it, the app setting `open` to false), the
 * focus moves to the trigger: inert content would otherwise drop it to the page.
 *
 * Brain's collapsible is the host directive and its trigger and content directives sit in the
 * template; `open` is brain's `expanded` under the kit's name.
 */
export declare class NeatCollapsible {
  /** The trigger's text, which names the section. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** What the section holds, shown beside the label while it is closed; none if empty. */
  readonly summary: import("@angular/core").InputSignal<string>;
  /**
   * The level of the heading the trigger sits in, for a section that is part of an outline (System
   * Info's); none by default, for a disclosure such as a panel's "Details".
   */
  readonly headingLevel: import("@angular/core").InputSignal<2 | 3 | 4 | 5 | 6 | null>;
  protected readonly brain: BrnCollapsible;
  protected readonly triggerClasses = "group flex w-full min-w-0 cursor-pointer items-center gap-(--neat-space-2) rounded-(--radius) py-1 text-start text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring";
  protected readonly chevronClasses = "shrink-0 text-muted-foreground transition-transform duration-(--neat-transition-duration) group-hover:text-foreground motion-reduce:transition-none";
  protected readonly contentClasses = "pt-(--neat-space-2) data-closed:hidden";
  private readonly trigger;
  private readonly content;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCollapsible, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCollapsible, "neat-collapsible", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "summary": {
      "alias": "summary";
      "required": false;
      "isSignal": true;
    };
    "headingLevel": {
      "alias": "headingLevel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, [{
    directive: typeof i1.BrnCollapsible;
    inputs: {
      "expanded": "open";
    };
    outputs: {
      "expandedChange": "openChange";
    };
  }]>;
}