import { NeatTone } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/**
 * A short status on one of the theme's status fills, the text being the content:
 * `<neat-status-chip tone="success">Live</neat-status-chip>`. For a state in a list's cell or over
 * a panel (Live, Idle, External), or a fact to note beside a value (a codec that cannot be
 * decoded). `highlight` is for a state that is none of the statuses but should stand out (a stream
 * that someone else publishes); a `neat-select-list` row can take the same tone as its chip
 * (`rowTone`). The words are the app's; the colour repeats them and is never the only way a state is
 * told.
 */
export declare class NeatStatusChip {
  readonly tone: import("@angular/core").InputSignal<NeatTone>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatStatusChip, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatStatusChip, "neat-status-chip", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * The chip as a button, for a status that opens more about itself, such as a video tile's
 * "Metadata late" that shows why: `<button neatStatusChip tone="warning" type="button">`. It looks
 * like the chip of its tone and stays a native button (focus, Enter and Space, `disabled`), with a
 * pointer and a focus outline. Its name is its text.
 */
export declare class NeatStatusChipButton {
  readonly tone: import("@angular/core").InputSignal<NeatTone>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatStatusChipButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatStatusChipButton, "button[neatStatusChip]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}