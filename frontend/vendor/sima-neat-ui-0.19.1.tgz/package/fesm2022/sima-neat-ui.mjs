import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, Directive, ElementRef, HostAttributeToken, Injectable, InjectionToken, Injector, PLATFORM_ID, TemplateRef, ViewContainerRef, afterNextRender, booleanAttribute, computed, contentChildren, effect, inject, input, isDevMode, linkedSignal, makeEnvironmentProviders, model, output, provideEnvironmentInitializer, runInInjectionContext, signal, viewChild } from "@angular/core";
import { LucideDynamicIcon } from "@lucide/angular";
import { Activity, Blocks, Cable, Camera, Check, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, CircleAlert, CircuitBoard, Cpu, Ellipsis, File, FileText, Folder, FolderOpen, Info, LayoutGrid, LoaderCircle, Maximize, Maximize2, Mic, Minimize, Moon, Palette, PanelLeftClose, PanelLeftOpen, PanelRight, Pause, Play, Radar, RadioTower, RectangleHorizontal, RefreshCw, Search, Shapes, Square, SquareTerminal, Sun, TriangleAlert, Upload, X } from "lucide";
import { CdkPortalOutlet, TemplatePortal } from "@angular/cdk/portal";
import { Router, RouterLink, RouterLinkActive, containsTree } from "@angular/router";
import * as i1$2 from "@spartan-ng/brain/button";
import { BrnButton } from "@spartan-ng/brain/button";
import { isPlatformBrowser } from "@angular/common";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import "@angular/cdk/overlay";
import { cva } from "class-variance-authority";
import * as i1$1 from "@spartan-ng/brain/tooltip";
import { BrnTooltip, provideBrnTooltipDefaultOptions } from "@spartan-ng/brain/tooltip";
import * as i1 from "@spartan-ng/brain/tabs";
import { BrnTabs, BrnTabsContent, BrnTabsContentLazy, BrnTabsList, BrnTabsPaginatedList, BrnTabsTrigger } from "@spartan-ng/brain/tabs";
import { CdkObserveContent } from "@angular/cdk/observers";
import { toObservable } from "@angular/core/rxjs-interop";
const HEX_PATTERN = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i;
function parseHex(hex) {
	const match = HEX_PATTERN.exec(hex);
	if (!match) throw new Error(`Expected a #RRGGBB colour, got "${hex}"`);
	return [
		parseInt(match[1], 16) / 255,
		parseInt(match[2], 16) / 255,
		parseInt(match[3], 16) / 255
	];
}
function formatHex(rgb) {
	const channel = (value) => Math.round(Math.min(1, Math.max(0, value)) * 255).toString(16).padStart(2, "0");
	return `#${rgb.map(channel).join("")}`.toUpperCase();
}
function toLinear(channel) {
	return channel <= .04045 ? channel / 12.92 : ((channel + .055) / 1.055) ** 2.4;
}
function fromLinear(channel) {
	return channel <= .0031308 ? channel * 12.92 : 1.055 * channel ** (1 / 2.4) - .055;
}
function linearToOklab([r, g, b]) {
	const l = Math.cbrt(.4122214708 * r + .5363325363 * g + .0514459929 * b);
	const m = Math.cbrt(.2119034982 * r + .6806995451 * g + .1073969566 * b);
	const s = Math.cbrt(.0883024619 * r + .2817188376 * g + .6299787005 * b);
	return [
		.2104542553 * l + .793617785 * m - .0040720468 * s,
		1.9779984951 * l - 2.428592205 * m + .4505937099 * s,
		.0259040371 * l + .7827717662 * m - .808675766 * s
	];
}
function oklabToLinear([lightness, a, b]) {
	const l = (lightness + .3963377774 * a + .2158037573 * b) ** 3;
	const m = (lightness - .1055613458 * a - .0638541728 * b) ** 3;
	const s = (lightness - .0894841775 * a - 1.291485548 * b) ** 3;
	return [
		4.0767416621 * l - 3.3077115913 * m + .2309699292 * s,
		-1.2684380046 * l + 2.6097574011 * m - .3413193965 * s,
		-.0041960863 * l - .7034186147 * m + 1.707614701 * s
	];
}
function normalizeHex(hex) {
	return formatHex(parseHex(hex));
}
function hexToLinear(hex) {
	const [r, g, b] = parseHex(hex);
	return [
		toLinear(r),
		toLinear(g),
		toLinear(b)
	];
}
function linearToHex([r, g, b]) {
	return formatHex([
		fromLinear(r),
		fromLinear(g),
		fromLinear(b)
	]);
}
function hexToOklab(hex) {
	return linearToOklab(hexToLinear(hex));
}
function oklabToHex(lab) {
	return linearToHex(oklabToLinear(lab));
}
function oklchToOklab({ l, c, h }) {
	const radians = h * Math.PI / 180;
	return [
		l,
		c * Math.cos(radians),
		c * Math.sin(radians)
	];
}
function hexToOklch(hex) {
	const [l, a, b] = hexToOklab(hex);
	const h = Math.atan2(b, a) * 180 / Math.PI;
	return {
		l,
		c: Math.hypot(a, b),
		h: h < 0 ? h + 360 : h
	};
}
function oklchToHex(color) {
	return oklabToHex(oklchToOklab(color));
}
function isInSrgbGamut(color) {
	return oklabToLinear(oklchToOklab(color)).every((channel) => channel >= -1e-6 && channel <= 1.000001);
}
function relativeLuminance(hex) {
	const [r, g, b] = hexToLinear(hex);
	return .2126 * r + .7152 * g + .0722 * b;
}
function contrastRatio(a, b) {
	const [lighter, darker] = [relativeLuminance(a), relativeLuminance(b)].sort((x, y) => y - x);
	return (lighter + .05) / (darker + .05);
}
const SIMA_PALETTE = {
	text: "#010F0E",
	background: "#F3F4F5",
	backgroundAlt: "#E8E9EB",
	white: "#FFFFFF",
	orange: "#D26728",
	purple: "#D1CEE6",
	blue: "#5998DD",
	mint: "#C0E8DB",
	green: "#2A9C4F",
	lime: "#A4CC2D"
};
const NEAT_PRIMARY_BASE = SIMA_PALETTE.orange;
const NEAT_DANGER_BASE = "#C8372D";
const NEAT_WARN_BASE = "#E9A23B";
const NEAT_HIGHLIGHT_BASE = "#9D93D6";
const NEAT_SERIES_TEAL_BASE = "#2A8C9A";
const NEAT_NEAR_BLACK = "#101010";
const LIGHTEST_L = .985;
const DARKEST_L = .13;
const LIGHTER_FRACTIONS = {
	50: .92,
	100: .8,
	200: .62,
	300: .42,
	400: .2
};
const DARKER_FRACTIONS = {
	600: .15,
	700: .32,
	800: .5,
	900: .66,
	950: .8
};
const CHROMA_FALLOFF = .6;
const GAMUT_SEARCH_ROUNDS = 24;
const SURFACE_FRACTIONS = {
	200: .1,
	300: .22,
	400: .36,
	500: .5,
	600: .62,
	700: .73,
	800: .83,
	900: .92
};
function fitToSrgb(color) {
	if (isInSrgbGamut(color)) return color;
	let inside = 0;
	let outside = color.c;
	for (let round = 0; round < GAMUT_SEARCH_ROUNDS; round++) {
		const c = (inside + outside) / 2;
		if (isInSrgbGamut({
			...color,
			c
		})) inside = c;
		else outside = c;
	}
	return {
		...color,
		c: inside
	};
}
function shade(base, targetL, fraction) {
	return oklchToHex(fitToSrgb({
		l: base.l + (targetL - base.l) * fraction,
		c: base.c * (1 - CHROMA_FALLOFF * fraction),
		h: base.h
	}));
}
function buildColorScale(base) {
	const oklch = hexToOklch(base);
	const lighter = (step) => shade(oklch, LIGHTEST_L, LIGHTER_FRACTIONS[step]);
	const darker = (step) => shade(oklch, DARKEST_L, DARKER_FRACTIONS[step]);
	return {
		50: lighter(50),
		100: lighter(100),
		200: lighter(200),
		300: lighter(300),
		400: lighter(400),
		500: normalizeHex(base),
		600: darker(600),
		700: darker(700),
		800: darker(800),
		900: darker(900),
		950: darker(950)
	};
}
function surfaceRamp({ background, backgroundAlt, darkest }) {
	const from = hexToOklab(backgroundAlt);
	const to = hexToOklab(darkest);
	const between = (step) => {
		const t = SURFACE_FRACTIONS[step];
		const mix = (channel) => from[channel] + (to[channel] - from[channel]) * t;
		return oklabToHex([
			mix(0),
			mix(1),
			mix(2)
		]);
	};
	return {
		0: SIMA_PALETTE.white,
		50: background,
		100: backgroundAlt,
		200: between(200),
		300: between(300),
		400: between(400),
		500: between(500),
		600: between(600),
		700: between(700),
		800: between(800),
		900: between(900),
		950: darkest
	};
}
function grey(hex) {
	return oklabToHex([
		hexToOklab(hex)[0],
		0,
		0
	]);
}
function buildSurfaceScale() {
	return surfaceRamp({
		background: SIMA_PALETTE.background,
		backgroundAlt: SIMA_PALETTE.backgroundAlt,
		darkest: SIMA_PALETTE.text
	});
}
function buildNeutralSurfaceScale() {
	return surfaceRamp({
		background: grey(SIMA_PALETTE.background),
		backgroundAlt: grey(SIMA_PALETTE.backgroundAlt),
		darkest: NEAT_NEAR_BLACK
	});
}
const safeStorage = {
	get(key) {
		try {
			return localStorage.getItem(key);
		} catch {
			return null;
		}
	},
	set(key, value) {
		try {
			localStorage.setItem(key, value);
		} catch {}
	}
};
const STORAGE_KEY = "neat-ui:color-scheme";
const NEAT_DARK_CLASS = "neat-dark";
var ThemeService = class ThemeService {
	root = inject(DOCUMENT).documentElement;
	current = signal(safeStorage.get(STORAGE_KEY) === "dark" ? "dark" : "light", ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	scheme = this.current.asReadonly();
	constructor() {
		this.apply(this.current());
	}
	setScheme(scheme, { persist = true } = {}) {
		this.current.set(scheme);
		this.apply(scheme);
		if (persist) safeStorage.set(STORAGE_KEY, scheme);
	}
	toggle() {
		this.setScheme(this.current() === "dark" ? "light" : "dark");
	}
	apply(scheme) {
		this.root.classList.toggle(NEAT_DARK_CLASS, scheme === "dark");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ThemeService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function provideNeatUi() {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => inject(ThemeService))]);
}
function drawing(name, node) {
	return {
		name,
		node
	};
}
function filled(name, node) {
	return drawing(name, node.map(([tag, attrs]) => [tag, {
		...attrs,
		fill: "currentColor"
	}]));
}
const NEAT_ICONS = {
	media: drawing("media", FolderOpen),
	streaming: drawing("streaming", RadioTower),
	viewer: drawing("viewer", LayoutGrid),
	peripherals: drawing("peripherals", Cable),
	camera: drawing("camera", Camera),
	microphone: drawing("microphone", Mic),
	lidar: drawing("lidar", Radar),
	device: drawing("device", CircuitBoard),
	stats: drawing("stats", Activity),
	board: drawing("board", Cpu),
	info: drawing("info", Info),
	sun: drawing("sun", Sun),
	moon: drawing("moon", Moon),
	"kiosk-enter": drawing("kiosk-enter", Maximize),
	"kiosk-exit": drawing("kiosk-exit", Minimize),
	"rail-expand": drawing("rail-expand", PanelLeftOpen),
	"rail-collapse": drawing("rail-collapse", PanelLeftClose),
	"side-panel": drawing("side-panel", PanelRight),
	palette: drawing("palette", Palette),
	shapes: drawing("shapes", Shapes),
	blocks: drawing("blocks", Blocks),
	document: drawing("document", FileText),
	previous: drawing("previous", ChevronLeft),
	next: drawing("next", ChevronRight),
	close: drawing("close", X),
	check: drawing("check", Check),
	expand: drawing("expand", ChevronDown),
	collapse: drawing("collapse", ChevronUp),
	"aspect-wide": drawing("aspect-wide", RectangleHorizontal),
	"aspect-square": drawing("aspect-square", Square),
	search: drawing("search", Search),
	more: drawing("more", Ellipsis),
	"fit-all": drawing("fit-all", Maximize2),
	upload: drawing("upload", Upload),
	folder: drawing("folder", Folder),
	file: drawing("file", File),
	error: drawing("error", CircleAlert),
	warning: drawing("warning", TriangleAlert),
	refresh: drawing("refresh", RefreshCw),
	spinner: drawing("spinner", LoaderCircle),
	terminal: drawing("terminal", SquareTerminal),
	pause: filled("pause", Pause),
	play: filled("play", Play),
	stop: filled("stop", Square)
};
const NEAT_ICON_NAMES = Object.keys(NEAT_ICONS);
var NeatIcon = class NeatIcon {
	name = input.required(...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	size = input(20, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	glyph = computed(() => NEAT_ICONS[this.name()], ...ngDevMode ? [{ debugName: "glyph" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatIcon,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatIcon,
		isStandalone: true,
		selector: "neat-icon",
		inputs: {
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "attr.data-icon": "name()" } },
		ngImport: i0,
		template: `
    <svg
      [lucideIcon]="glyph()"
      [size]="size()"
      [title]="label()"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() ?? null"
    ></svg>
  `,
		isInline: true,
		styles: [":host{display:inline-flex}@media(prefers-reduced-motion:no-preference){:host([data-icon=\"spinner\"]) svg{animation:neat-icon-spin 1s linear infinite}}@keyframes neat-icon-spin{to{transform:rotate(360deg)}}\n"],
		dependencies: [{
			kind: "component",
			type: LucideDynamicIcon,
			selector: "svg[lucideIcon]",
			inputs: ["lucideIcon"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatIcon,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-icon",
			imports: [LucideDynamicIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[attr.data-icon]": "name()" },
			template: `
    <svg
      [lucideIcon]="glyph()"
      [size]="size()"
      [title]="label()"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() ?? null"
    ></svg>
  `,
			styles: [":host{display:inline-flex}@media(prefers-reduced-motion:no-preference){:host([data-icon=\"spinner\"]) svg{animation:neat-icon-spin 1s linear infinite}}@keyframes neat-icon-spin{to{transform:rotate(360deg)}}\n"]
		}]
	}],
	propDecorators: {
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
function hlm(...inputs) {
	return twMerge(clsx(inputs));
}
const elementClassManagers = /* @__PURE__ */ new WeakMap();
let globalObserver = null;
const observedElements = /* @__PURE__ */ new Set();
let sourceCounter = 0;
function classes(computed, options = {}) {
	runInInjectionContext(options.injector ?? inject(Injector), () => {
		const elementRef = options.elementRef ?? inject(ElementRef);
		const platformId = inject(PLATFORM_ID);
		const destroyRef = inject(DestroyRef);
		const baseClasses = inject(new HostAttributeToken("class"), { optional: true });
		const element = elementRef.nativeElement;
		const sourceId = sourceCounter++;
		let manager = elementClassManagers.get(element);
		if (!manager) {
			const initialBaseClasses = /* @__PURE__ */ new Set();
			if (baseClasses) toClassList(baseClasses).forEach((cls) => initialBaseClasses.add(cls));
			manager = {
				element,
				sources: /* @__PURE__ */ new Map(),
				baseClasses: initialBaseClasses,
				isUpdating: false,
				nextOrder: 0,
				hasInitialized: false,
				restoreRafId: null,
				transitionsSuppressed: false,
				previousTransition: "",
				previousTransitionPriority: ""
			};
			elementClassManagers.set(element, manager);
			setupGlobalObserver(platformId);
			observedElements.add(element);
			if (isPlatformBrowser(platformId)) {
				manager.previousTransition = element.style.getPropertyValue("transition");
				manager.previousTransitionPriority = element.style.getPropertyPriority("transition");
				element.style.setProperty("transition", "none", "important");
				manager.transitionsSuppressed = true;
			}
		}
		const sourceOrder = manager.nextOrder++;
		function updateClasses() {
			const newClasses = toClassList(computed());
			manager.sources.set(sourceId, {
				classes: new Set(newClasses),
				order: sourceOrder
			});
			updateElement(manager);
			if (manager.transitionsSuppressed) {
				manager.transitionsSuppressed = false;
				manager.restoreRafId = requestAnimationFrame(() => {
					manager.restoreRafId = null;
					restoreTransitionSuppression(manager);
				});
			}
		}
		destroyRef.onDestroy(() => {
			if (manager.restoreRafId !== null) {
				cancelAnimationFrame(manager.restoreRafId);
				manager.restoreRafId = null;
			}
			if (manager.transitionsSuppressed) {
				manager.transitionsSuppressed = false;
				restoreTransitionSuppression(manager);
			}
			manager.sources.delete(sourceId);
			if (manager.sources.size === 0) cleanupManager(element);
			else updateElement(manager);
		});
		effect(updateClasses);
	});
}
function restoreTransitionSuppression(manager) {
	const prev = manager.previousTransition;
	if (prev) manager.element.style.setProperty("transition", prev, manager.previousTransitionPriority || void 0);
	else manager.element.style.removeProperty("transition");
}
function setupGlobalObserver(platformId) {
	if (isPlatformBrowser(platformId) && !globalObserver) {
		globalObserver = new MutationObserver((mutations) => {
			for (const mutation of mutations) if (mutation.type === "attributes" && mutation.attributeName === "class") {
				const element = mutation.target;
				const manager = elementClassManagers.get(element);
				if (manager && observedElements.has(element)) {
					if (manager.isUpdating) continue;
					const currentClasses = toClassList(element.className);
					const allSourceClasses = /* @__PURE__ */ new Set();
					for (const source of manager.sources.values()) for (const className of source.classes) allSourceClasses.add(className);
					manager.baseClasses.clear();
					for (const className of currentClasses) if (!allSourceClasses.has(className)) manager.baseClasses.add(className);
					updateElement(manager);
				}
			}
		});
		globalObserver.observe(document, {
			attributes: true,
			attributeFilter: ["class"],
			subtree: true
		});
	}
}
function updateElement(manager) {
	if (manager.isUpdating) return;
	manager.isUpdating = true;
	if (!manager.hasInitialized && manager.sources.size > 0) {
		const currentClasses = toClassList(manager.element.className);
		const allSourceClasses = /* @__PURE__ */ new Set();
		for (const source of manager.sources.values()) source.classes.forEach((className) => allSourceClasses.add(className));
		currentClasses.forEach((className) => {
			if (!allSourceClasses.has(className)) manager.baseClasses.add(className);
		});
		manager.hasInitialized = true;
	}
	const sortedSources = Array.from(manager.sources.entries()).sort(([, a], [, b]) => a.order - b.order);
	const allSourceClasses = [];
	for (const [, source] of sortedSources) allSourceClasses.push(...source.classes);
	const classesToApply = allSourceClasses.length > 0 || manager.baseClasses.size > 0 ? hlm([...allSourceClasses, ...manager.baseClasses]) : "";
	if (manager.element.className !== classesToApply) manager.element.className = classesToApply;
	manager.isUpdating = false;
}
function cleanupManager(element) {
	observedElements.delete(element);
	elementClassManagers.delete(element);
	if (observedElements.size === 0 && globalObserver) {
		globalObserver.disconnect();
		globalObserver = null;
	}
}
const classListCache = /* @__PURE__ */ new Map();
function toClassList(className) {
	if (typeof className === "string" && classListCache.has(className)) return classListCache.get(className);
	const result = clsx(className).split(" ").filter((c) => c.length > 0);
	if (typeof className === "string" && classListCache.size < 1e3) classListCache.set(className, result);
	return result;
}
const defaultConfig = {
	variant: "default",
	size: "default"
};
const BrnButtonConfigToken = new InjectionToken("BrnButtonConfig");
function injectBrnButtonConfig() {
	return inject(BrnButtonConfigToken, { optional: true }) ?? defaultConfig;
}
const buttonVariants = cva("focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 rounded-md border border-transparent bg-clip-padding text-sm font-medium focus-visible:ring-3 active:not-aria-[haspopup]:translate-y-px data-[matches-spartan-invalid=true]:ring-3 [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] group/button inline-flex shrink-0 items-center justify-center whitespace-nowrap transition-all outline-none select-none data-disabled:pointer-events-none data-disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/80",
			outline: "border-border bg-background hover:bg-muted hover:text-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50 aria-expanded:bg-muted aria-expanded:text-foreground shadow-xs",
			secondary: "bg-secondary text-secondary-foreground aria-expanded:bg-secondary aria-expanded:text-secondary-foreground hover:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)]",
			ghost: "hover:bg-muted hover:text-foreground dark:hover:bg-muted/50 aria-expanded:bg-muted aria-expanded:text-foreground",
			destructive: "bg-destructive/10 hover:bg-destructive/20 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/20 text-destructive focus-visible:border-destructive/40 dark:hover:bg-destructive/30",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 gap-1.5 px-2.5 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			xs: "h-6 gap-1 rounded-[min(var(--radius-md),8px)] px-2 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(3)]",
			sm: "h-8 gap-1 rounded-[min(var(--radius-md),10px)] px-2.5 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5",
			lg: "h-10 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			icon: "size-9",
			"icon-xs": "size-6 rounded-[min(var(--radius-md),8px)] in-data-[slot=button-group]:rounded-md [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(3)]",
			"icon-sm": "size-8 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-md",
			"icon-lg": "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var HlmButton = class HlmButton {
	_config = injectBrnButtonConfig();
	_additionalClasses = signal("", ...ngDevMode ? [{ debugName: "_additionalClasses" }] : /* istanbul ignore next */ []);
	variant = input(this._config.variant, ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(this._config.size, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => [buttonVariants({
			variant: this.variant(),
			size: this.size()
		}), this._additionalClasses()]);
	}
	setClass(classes) {
		this._additionalClasses.set(classes);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmButton,
		isStandalone: true,
		selector: "button[hlmBtn], a[hlmBtn]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "button" } },
		exportAs: ["hlmBtn"],
		hostDirectives: [{
			directive: i1$2.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[hlmBtn], a[hlmBtn]",
			exportAs: "hlmBtn",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: { "data-slot": "button" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
const TEXT_HOVER = "hover:bg-accent dark:hover:bg-accent";
const DANGER_FOCUS = "focus-visible:ring-destructive dark:focus-visible:ring-destructive";
const VARIANTS = {
	primary: {
		spartan: "default",
		hover: "hover:bg-primary-hover",
		focus: "focus-visible:ring-ring"
	},
	secondary: {
		spartan: "secondary",
		hover: "",
		focus: "focus-visible:ring-ring"
	},
	outlined: {
		spartan: "outline",
		hover: "hover:bg-accent",
		focus: "focus-visible:ring-ring"
	},
	text: {
		spartan: "ghost",
		hover: TEXT_HOVER,
		focus: "focus-visible:ring-ring"
	},
	danger: {
		spartan: "destructive",
		rest: "bg-destructive text-destructive-foreground dark:bg-destructive",
		hover: "hover:bg-destructive/90 dark:hover:bg-destructive/90",
		focus: DANGER_FOCUS
	},
	"danger-text": {
		spartan: "ghost",
		rest: "text-destructive",
		hover: `${TEXT_HOVER} hover:text-destructive`,
		focus: DANGER_FOCUS
	},
	success: {
		spartan: "default",
		rest: "bg-success text-success-foreground",
		hover: "hover:bg-success/90",
		focus: "focus-visible:ring-ring"
	}
};
const SIZES = {
	small: {
		spartan: "sm",
		spartanIconOnly: "icon-sm"
	},
	medium: {
		spartan: "default",
		spartanIconOnly: "icon"
	},
	large: {
		spartan: "lg",
		spartanIconOnly: "icon-lg"
	},
	touch: {
		spartan: "lg",
		spartanIconOnly: "icon-lg",
		extra: "h-auto min-h-12 min-w-12",
		extraIconOnly: "size-12"
	}
};
const PRESSED = "bg-foreground text-background hover:bg-foreground hover:text-background dark:bg-foreground dark:text-background dark:hover:bg-foreground dark:hover:text-background";
const HELD = "aria-disabled:cursor-not-allowed aria-disabled:opacity-50";
var NeatButton = class NeatButton {
	variant = input("primary", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	iconOnly = input(false, {
		...ngDevMode ? { debugName: "iconOnly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rounded = input(false, {
		...ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	pressed = input(void 0, ...ngDevMode ? [{ debugName: "pressed" }] : /* istanbul ignore next */ []);
	classes = computed(() => {
		const variant = VARIANTS[this.variant()];
		const size = SIZES[this.size()];
		const iconOnly = this.iconOnly();
		return hlm(buttonVariants({
			variant: variant.spartan,
			size: iconOnly ? size.spartanIconOnly : size.spartan
		}), variant.rest, variant.hover, variant.focus, HELD, iconOnly ? size.extraIconOnly : size.extra, this.rounded() && "rounded-full", this.pressed() && PRESSED);
	}, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatButton,
		isStandalone: true,
		selector: "button[neatButton], a[neatButton]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconOnly: {
				classPropertyName: "iconOnly",
				publicName: "iconOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rounded: {
				classPropertyName: "rounded",
				publicName: "rounded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pressed: {
				classPropertyName: "pressed",
				publicName: "pressed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "button" },
			properties: {
				"class": "classes()",
				"attr.aria-pressed": "pressed()"
			}
		},
		hostDirectives: [{
			directive: i1$2.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatButton], a[neatButton]",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: {
				"data-slot": "button",
				"[class]": "classes()",
				"[attr.aria-pressed]": "pressed()"
			}
		}]
	}],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		iconOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconOnly",
				required: false
			}]
		}],
		rounded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		pressed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pressed",
				required: false
			}]
		}]
	}
});
const KIOSK_POINTER_IDLE_MS = 2500;
const ACTIVITY_EVENTS = [
	"pointermove",
	"pointerdown",
	"touchstart"
];
function kioskRequested(search) {
	const value = new URLSearchParams(search).get("kiosk");
	return value !== null && value !== "0" && value !== "false";
}
var KioskService = class KioskService {
	document = inject(DOCUMENT);
	isActive = signal(kioskRequested(this.document.location?.search ?? ""), ...ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ []);
	isPointerIdle = signal(false, ...ngDevMode ? [{ debugName: "isPointerIdle" }] : /* istanbul ignore next */ []);
	ownsFullscreen = false;
	holds = 0;
	idleTimer;
	active = this.isActive.asReadonly();
	pointerIdle = this.isPointerIdle.asReadonly();
	constructor() {
		const onActivity = () => this.onActivity();
		const onFullscreenChange = () => this.onFullscreenChange();
		const passive = { passive: true };
		this.document.addEventListener("fullscreenchange", onFullscreenChange);
		for (const type of ACTIVITY_EVENTS) this.document.addEventListener(type, onActivity, passive);
		this.restartIdleTimer();
		inject(DestroyRef).onDestroy(() => {
			this.document.removeEventListener("fullscreenchange", onFullscreenChange);
			for (const type of ACTIVITY_EVENTS) this.document.removeEventListener(type, onActivity, passive);
			clearTimeout(this.idleTimer);
		});
	}
	async enter() {
		this.isActive.set(true);
		const root = this.document.documentElement;
		if (typeof root.requestFullscreen !== "function" || this.document.fullscreenElement) return;
		try {
			await root.requestFullscreen();
			this.ownsFullscreen = this.document.fullscreenElement === root;
		} catch {}
	}
	async exit() {
		this.isActive.set(false);
		if (!this.ownsFullscreen) return;
		this.ownsFullscreen = false;
		if (!this.document.fullscreenElement || typeof this.document.exitFullscreen !== "function") return;
		try {
			await this.document.exitFullscreen();
		} catch {}
	}
	toggle() {
		return this.isActive() ? this.exit() : this.enter();
	}
	holdToolbar() {
		this.holds++;
		this.isPointerIdle.set(false);
		this.restartIdleTimer();
		let released = false;
		return () => {
			if (released) return;
			released = true;
			this.holds--;
			this.restartIdleTimer();
		};
	}
	onFullscreenChange() {
		if (this.ownsFullscreen && !this.document.fullscreenElement) {
			this.ownsFullscreen = false;
			this.isActive.set(false);
		}
	}
	onActivity() {
		if (this.isPointerIdle()) this.isPointerIdle.set(false);
		this.restartIdleTimer();
	}
	restartIdleTimer() {
		clearTimeout(this.idleTimer);
		if (this.holds === 0) this.idleTimer = setTimeout(() => this.isPointerIdle.set(true), KIOSK_POINTER_IDLE_MS);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KioskService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KioskService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: KioskService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatKioskExit = class NeatKioskExit {
	kiosk = inject(KioskService);
	control = viewChild.required(NeatButton, {
		...ngDevMode ? { debugName: "control" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	exited = output();
	focus() {
		this.control().nativeElement.focus();
	}
	exit() {
		this.kiosk.exit();
		this.exited.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatKioskExit,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatKioskExit,
		isStandalone: true,
		selector: "neat-kiosk-exit",
		outputs: { exited: "exited" },
		viewQueries: [{
			propertyName: "control",
			first: true,
			predicate: NeatButton,
			descendants: true,
			read: ElementRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <button
      neatButton
      type="button"
      class="shadow-md"
      variant="secondary"
      size="touch"
      rounded
      iconOnly
      aria-label="Exit kiosk mode"
      (click)="exit()"
    >
      <neat-icon name="kiosk-exit" />
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NeatButton,
			selector: "button[neatButton], a[neatButton]",
			inputs: [
				"variant",
				"size",
				"iconOnly",
				"rounded",
				"pressed"
			]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatKioskExit,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-kiosk-exit",
			imports: [NeatButton, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      neatButton
      type="button"
      class="shadow-md"
      variant="secondary"
      size="touch"
      rounded
      iconOnly
      aria-label="Exit kiosk mode"
      (click)="exit()"
    >
      <neat-icon name="kiosk-exit" />
    </button>
  `
		}]
	}],
	propDecorators: {
		control: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatButton), {
				read: ElementRef,
				isSignal: true
			}]
		}],
		exited: [{
			type: i0.Output,
			args: ["exited"]
		}]
	}
});
var ShellSlot = class {
	secondError;
	current = signal(null, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	portal = this.current.asReadonly();
	constructor(secondError) {
		this.secondError = secondError;
	}
	register(portal) {
		if (isDevMode() && this.current() !== null) throw new Error(this.secondError);
		this.current.set(portal);
	}
	unregister(portal) {
		if (portal.isAttached) portal.detach();
		if (this.current() === portal) this.current.set(null);
	}
};
const IN_PAGE_TOOLBAR = new InjectionToken("neat-ui: in the page toolbar", {
	providedIn: "root",
	factory: () => false
});
var PageToolbarSlot = class PageToolbarSlot extends ShellSlot {
	constructor() {
		super("neat-ui: only one page toolbar at a time; remove the other *neatPageToolbar first.");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageToolbarSlot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageToolbarSlot,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PageToolbarSlot,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatPageToolbar = class NeatPageToolbar {
	constructor() {
		const slot = inject(PageToolbarSlot);
		const injector = Injector.create({
			providers: [{
				provide: IN_PAGE_TOOLBAR,
				useValue: true
			}],
			parent: inject(Injector)
		});
		const portal = new TemplatePortal(inject(TemplateRef), inject(ViewContainerRef), void 0, injector);
		slot.register(portal);
		inject(DestroyRef).onDestroy(() => slot.unregister(portal));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPageToolbar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPageToolbar,
		isStandalone: true,
		selector: "[neatPageToolbar]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPageToolbar,
	decorators: [{
		type: Directive,
		args: [{ selector: "[neatPageToolbar]" }]
	}],
	ctorParameters: () => []
});
const DEFAULT_TOOLTIP_SVG_CLASS = "bg-foreground fill-foreground z-50 block size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px]";
const DEFAULT_TOOLTIP_CONTENT_CLASSES = hlm("data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 rounded-md px-3 py-1.5 text-xs bg-foreground text-background data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) text-balance");
const tooltipPositionVariants = cva("absolute", { variants: { position: {
	top: "bottom-0 left-[calc(50%-5px)] translate-y-full",
	bottom: "-top-2.5 left-[calc(50%-5px)] translate-y-0 rotate-180",
	left: "-end-2.5 top-[calc(50%-5px)] translate-y-0 rotate-270 rtl:-rotate-270",
	right: "-start-2.5 top-[calc(50%-5px)] translate-y-0 rotate-90 rtl:-rotate-90"
} } });
var HlmTooltip = class HlmTooltip {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HlmTooltip,
		isStandalone: true,
		selector: "[hlmTooltip]",
		providers: [provideBrnTooltipDefaultOptions({
			svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
			tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
			arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
		})],
		exportAs: ["hlmTooltip"],
		hostDirectives: [{
			directive: i1$1.BrnTooltip,
			inputs: [
				"brnTooltip",
				"hlmTooltip",
				"position",
				"position",
				"hideDelay",
				"hideDelay",
				"showDelay",
				"showDelay",
				"tooltipDisabled",
				"tooltipDisabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTooltip]",
			exportAs: "hlmTooltip",
			providers: [provideBrnTooltipDefaultOptions({
				svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
				tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
				arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
			})],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: [
					"brnTooltip: hlmTooltip",
					"position",
					"hideDelay",
					"showDelay",
					"tooltipDisabled"
				]
			}]
		}]
	}]
});
function provideNeatTooltipOptions(position) {
	return provideBrnTooltipDefaultOptions({
		svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
		tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
		arrowClasses: (side) => hlm(tooltipPositionVariants({ position: side })),
		...position ? { position } : {}
	});
}
var NeatTooltip = class NeatTooltip {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatTooltip,
		isStandalone: true,
		selector: "[neatTooltip]",
		providers: [provideNeatTooltipOptions()],
		hostDirectives: [{
			directive: i1$1.BrnTooltip,
			inputs: [
				"brnTooltip",
				"neatTooltip",
				"position",
				"neatTooltipPosition",
				"tooltipDisabled",
				"neatTooltipDisabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatTooltip]",
			providers: [provideNeatTooltipOptions()],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: [
					"brnTooltip: neatTooltip",
					"position: neatTooltipPosition",
					"tooltipDisabled: neatTooltipDisabled"
				]
			}]
		}]
	}]
});
var AsideToggleSlot = class AsideToggleSlot extends ShellSlot {
	constructor() {
		super("neat-ui: only one side-panel toggle at a time; remove the other neat-aside-toggle first.");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AsideToggleSlot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AsideToggleSlot,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AsideToggleSlot,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatAsideToggle = class NeatAsideToggle {
	label = input("Side panel", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	slot = inject(AsideToggleSlot);
	viewContainer = inject(ViewContainerRef);
	destroyRef = inject(DestroyRef);
	template = viewChild.required("toggle", {
		...ngDevMode ? { debugName: "template" } : /* istanbul ignore next */ {},
		read: TemplateRef
	});
	button = viewChild("button", ...ngDevMode ? [{ debugName: "button" }] : /* istanbul ignore next */ []);
	constructor() {
		if (isDevMode() && inject(IN_PAGE_TOOLBAR)) throw new Error("neat-ui: declare neat-aside-toggle outside *neatPageToolbar; the shell draws it at the top bar's right edge.");
	}
	ngOnInit() {
		const portal = new TemplatePortal(this.template(), this.viewContainer);
		this.slot.register(portal);
		this.destroyRef.onDestroy(() => this.slot.unregister(portal));
	}
	focus() {
		this.button()?.nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideToggle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatAsideToggle,
		isStandalone: true,
		selector: "neat-aside-toggle",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: { attributes: { "hidden": "" } },
		viewQueries: [{
			propertyName: "template",
			first: true,
			predicate: ["toggle"],
			descendants: true,
			read: TemplateRef,
			isSignal: true
		}, {
			propertyName: "button",
			first: true,
			predicate: ["button"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #toggle>
      <button
        #button
        neatButton
        type="button"
        variant="text"
        size="large"
        rounded
        iconOnly
        neatTooltipPosition="bottom"
        [attr.aria-label]="label()"
        [neatTooltip]="label()"
        [pressed]="open()"
        (click)="open.set(!open())"
      >
        <neat-icon name="side-panel" />
      </button>
    </ng-template>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideToggle,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-aside-toggle",
			imports: [
				NeatButton,
				NeatIcon,
				NeatTooltip
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { hidden: "" },
			template: `
    <ng-template #toggle>
      <button
        #button
        neatButton
        type="button"
        variant="text"
        size="large"
        rounded
        iconOnly
        neatTooltipPosition="bottom"
        [attr.aria-label]="label()"
        [neatTooltip]="label()"
        [pressed]="open()"
        (click)="open.set(!open())"
      >
        <neat-icon name="side-panel" />
      </button>
    </ng-template>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		template: [{
			type: i0.ViewChild,
			args: ["toggle", {
				read: TemplateRef,
				isSignal: true
			}]
		}],
		button: [{
			type: i0.ViewChild,
			args: ["button", { isSignal: true }]
		}]
	}
});
var NeatAsidePanel = class NeatAsidePanel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsidePanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsidePanel,
		isStandalone: true,
		selector: "[neatAsidePanel]",
		host: { classAttribute: "flex flex-col gap-(--neat-space-3)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsidePanel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsidePanel]",
			host: { class: "flex flex-col gap-(--neat-space-3)" }
		}]
	}]
});
var NeatAsideTitle = class NeatAsideTitle {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideTitle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsideTitle,
		isStandalone: true,
		selector: "[neatAsideTitle]",
		host: { classAttribute: "m-0 text-base font-medium" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideTitle,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsideTitle]",
			host: { class: "m-0 text-base font-medium" }
		}]
	}]
});
var NeatAsideHeading = class NeatAsideHeading {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideHeading,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsideHeading,
		isStandalone: true,
		selector: "[neatAsideHeading]",
		host: { classAttribute: "mb-0 mt-(--neat-space-3) first:mt-0 text-(length:--neat-text-sm) font-semibold" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideHeading,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsideHeading]",
			host: { class: "mb-0 mt-(--neat-space-3) first:mt-0 text-(length:--neat-text-sm) font-semibold" }
		}]
	}]
});
var NeatAsideActions = class NeatAsideActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatAsideActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatAsideActions,
		isStandalone: true,
		selector: "[neatAsideActions]",
		host: { classAttribute: "flex flex-wrap items-center gap-(--neat-space-2)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatAsideActions,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatAsideActions]",
			host: { class: "flex flex-wrap items-center gap-(--neat-space-2)" }
		}]
	}]
});
var NeatCode = class NeatCode {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCode,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatCode,
		isStandalone: true,
		selector: "code[neatCode]",
		host: { classAttribute: "text-(length:--neat-text-xs) wrap-anywhere" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCode,
	decorators: [{
		type: Directive,
		args: [{
			selector: "code[neatCode]",
			host: { class: "text-(length:--neat-text-xs) wrap-anywhere" }
		}]
	}]
});
const NARROW_QUERY = "(width < 48rem)";
var NeatViewport = class NeatViewport {
	state = signal(false, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	narrow = this.state.asReadonly();
	constructor() {
		if (typeof matchMedia !== "function") return;
		const query = matchMedia(NARROW_QUERY);
		this.state.set(query.matches);
		const follow = (event) => this.state.set(event.matches);
		query.addEventListener("change", follow);
		inject(DestroyRef).onDestroy(() => query.removeEventListener("change", follow));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatViewport,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatViewport,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatViewport,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatLogo = class NeatLogo {
	theme = inject(ThemeService);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLogo,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatLogo,
		isStandalone: true,
		selector: "neat-logo",
		ngImport: i0,
		template: `
    @if (theme.scheme() === 'dark') {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#fff" d="M100,69.23V100H69.23l0-.15a77,77,0,0,0-15.24-46Z" />
        <rect fill="#fff" x="69.24" width="30.76" height="30.77" />
        <rect fill="#fff" y="69.23" width="30.77" height="30.77" />
        <path fill="#fff" d="M46.06,46.13,0,30.77V0H30.77l.05.15A77.1,77.1,0,0,0,46.06,46.13Z" />
        <path
          fill="#fff"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    } @else {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#a4cc2d" d="M86.08,83.06,100,69.23V100S94.4,92.45,86.08,83.06Z" />
        <path
          fill="#d1cee6"
          d="M53.94,53.87,100,69.23,86.08,83.06C77.28,73.12,65.44,61.14,53.94,53.87Z"
        />
        <path
          fill="#5998dd"
          d="M53.94,53.87c11.5,7.27,23.34,19.25,32.14,29.19L69.18,99.85A77,77,0,0,0,53.94,53.87Z"
        />
        <path fill="#010f0e" d="M69.18,99.85l16.9-16.79C94.4,92.45,100,100,100,100H69.23Z" />
        <polygon fill="#2a9c4f" points="100 0 100 30.77 84.62 15.39 100 0" />
        <polygon fill="#010f0e" points="100 30.77 69.24 30.77 84.62 15.39 100 30.77" />
        <polygon fill="#a4cc2d" points="84.62 15.39 69.24 30.77 69.24 0 84.62 15.39" />
        <polygon fill="#c0e8db" points="30.77 69.23 15.39 84.62 0 69.23 30.77 69.23" />
        <polygon fill="#d26728" points="30.77 69.23 30.77 100 15.39 84.62 30.77 69.23" />
        <polygon fill="#010f0e" points="30.77 100 0 100 15.39 84.62 30.77 100" />
        <polygon fill="#2a9c4f" points="15.39 84.62 0 100 0 69.23 15.39 84.62" />
        <path fill="#d26728" d="M13.92,16.94,0,30.77V0S5.6,7.55,13.92,16.94Z" />
        <path
          fill="#010f0e"
          d="M46.06,46.13,0,30.77,13.92,16.94C22.72,26.88,34.56,38.86,46.06,46.13Z"
        />
        <path
          fill="#5998dd"
          d="M46.06,46.13c-11.5-7.27-23.34-19.25-32.14-29.19L30.82.15A77,77,0,0,0,46.06,46.13Z"
        />
        <polygon fill="#c0e8db" points="100 0 84.62 15.39 69.24 0 100 0" />
        <path fill="#d1cee6" d="M30.82.15,13.92,16.94C5.6,7.55,0,0,0,0H30.77Z" />
        <path
          fill="#010f0e"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    }
  `,
		isInline: true,
		styles: [":host{display:inline-flex}svg{height:1.75rem;width:auto}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLogo,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-logo",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    @if (theme.scheme() === 'dark') {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#fff" d="M100,69.23V100H69.23l0-.15a77,77,0,0,0-15.24-46Z" />
        <rect fill="#fff" x="69.24" width="30.76" height="30.77" />
        <rect fill="#fff" y="69.23" width="30.77" height="30.77" />
        <path fill="#fff" d="M46.06,46.13,0,30.77V0H30.77l.05.15A77.1,77.1,0,0,0,46.06,46.13Z" />
        <path
          fill="#fff"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    } @else {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#a4cc2d" d="M86.08,83.06,100,69.23V100S94.4,92.45,86.08,83.06Z" />
        <path
          fill="#d1cee6"
          d="M53.94,53.87,100,69.23,86.08,83.06C77.28,73.12,65.44,61.14,53.94,53.87Z"
        />
        <path
          fill="#5998dd"
          d="M53.94,53.87c11.5,7.27,23.34,19.25,32.14,29.19L69.18,99.85A77,77,0,0,0,53.94,53.87Z"
        />
        <path fill="#010f0e" d="M69.18,99.85l16.9-16.79C94.4,92.45,100,100,100,100H69.23Z" />
        <polygon fill="#2a9c4f" points="100 0 100 30.77 84.62 15.39 100 0" />
        <polygon fill="#010f0e" points="100 30.77 69.24 30.77 84.62 15.39 100 30.77" />
        <polygon fill="#a4cc2d" points="84.62 15.39 69.24 30.77 69.24 0 84.62 15.39" />
        <polygon fill="#c0e8db" points="30.77 69.23 15.39 84.62 0 69.23 30.77 69.23" />
        <polygon fill="#d26728" points="30.77 69.23 30.77 100 15.39 84.62 30.77 69.23" />
        <polygon fill="#010f0e" points="30.77 100 0 100 15.39 84.62 30.77 100" />
        <polygon fill="#2a9c4f" points="15.39 84.62 0 100 0 69.23 15.39 84.62" />
        <path fill="#d26728" d="M13.92,16.94,0,30.77V0S5.6,7.55,13.92,16.94Z" />
        <path
          fill="#010f0e"
          d="M46.06,46.13,0,30.77,13.92,16.94C22.72,26.88,34.56,38.86,46.06,46.13Z"
        />
        <path
          fill="#5998dd"
          d="M46.06,46.13c-11.5-7.27-23.34-19.25-32.14-29.19L30.82.15A77,77,0,0,0,46.06,46.13Z"
        />
        <polygon fill="#c0e8db" points="100 0 84.62 15.39 69.24 0 100 0" />
        <path fill="#d1cee6" d="M30.82.15,13.92,16.94C5.6,7.55,0,0,0,0H30.77Z" />
        <path
          fill="#010f0e"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    }
  `,
			styles: [":host{display:inline-flex}svg{height:1.75rem;width:auto}\n"]
		}]
	}]
});
function neatAsideOpen(remembered, remember) {
	const narrow = inject(NeatViewport).narrow;
	const transient = linkedSignal({
		...ngDevMode ? { debugName: "transient" } : /* istanbul ignore next */ {},
		source: narrow,
		computation: () => false
	});
	return {
		open: computed(() => narrow() ? transient() : remembered()),
		set: (open) => narrow() ? transient.set(open) : remember(open)
	};
}
const RAIL_EXPANDED_KEY = "neat-ui:rail-expanded";
var RailState = class RailState {
	viewport = inject(NeatViewport);
	remembered = signal(safeStorage.get(RAIL_EXPANDED_KEY) === "true", ...ngDevMode ? [{ debugName: "remembered" }] : /* istanbul ignore next */ []);
	state = neatAsideOpen(this.remembered, (expanded) => {
		this.remembered.set(expanded);
		safeStorage.set(RAIL_EXPANDED_KEY, String(expanded));
	});
	expanded = this.state.open;
	set(expanded) {
		this.state.set(expanded);
	}
	collapseWhenNarrow() {
		if (this.viewport.narrow()) this.state.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RailState,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RailState
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RailState,
	decorators: [{ type: Injectable }]
});
var NeatRailItem = class NeatRailItem {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	rail = inject(RailState, { optional: true });
	isLink = inject(ElementRef).nativeElement instanceof HTMLAnchorElement;
	constructor() {
		if (this.rail === null) throw new Error("neat-ui: a neatRailItem belongs in neat-shell (its [neatRailEnd] slot).");
		const tooltip = inject(BrnTooltip);
		effect(() => tooltip.mutableTooltipDisabled.set(this.expanded()));
	}
	expanded() {
		return this.rail?.expanded() ?? true;
	}
	followed() {
		if (this.isLink) this.rail?.collapseWhenNarrow();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRailItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatRailItem,
		isStandalone: true,
		selector: "button[neatRailItem], a[neatRailItem]",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "click": "followed()" } },
		providers: [provideNeatTooltipOptions("right")],
		hostDirectives: [{
			directive: i1$1.BrnTooltip,
			inputs: ["brnTooltip", "label"]
		}],
		ngImport: i0,
		template: `
    <span class="icon"><ng-content /></span>
    <span class="label" [class.sr-only]="!expanded()">
      <ng-content select="[neatRailItemLabel]">{{ label() }}</ng-content>
    </span>
  `,
		isInline: true,
		styles: [":host{position:relative;display:flex;flex:none;align-items:center;gap:.75rem;box-sizing:border-box;width:100%;min-height:2.5rem;padding:0 .625rem;border:0;border-radius:var(--radius);background:transparent;color:var(--muted-foreground);font:inherit;text-align:start;text-decoration:none;cursor:pointer}:host(:hover),:host([aria-current=\"page\"]){background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}:host([aria-current=\"page\"]){font-weight:500}:host(:focus-visible){outline:var(--neat-focus-ring-width) solid var(--sidebar-ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}.icon{display:inline-flex;flex:none}.label{min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRailItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[neatRailItem], a[neatRailItem]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideNeatTooltipOptions("right")],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: ["brnTooltip: label"]
			}],
			host: { "(click)": "followed()" },
			template: `
    <span class="icon"><ng-content /></span>
    <span class="label" [class.sr-only]="!expanded()">
      <ng-content select="[neatRailItemLabel]">{{ label() }}</ng-content>
    </span>
  `,
			styles: [":host{position:relative;display:flex;flex:none;align-items:center;gap:.75rem;box-sizing:border-box;width:100%;min-height:2.5rem;padding:0 .625rem;border:0;border-radius:var(--radius);background:transparent;color:var(--muted-foreground);font:inherit;text-align:start;text-decoration:none;cursor:pointer}:host(:hover),:host([aria-current=\"page\"]){background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}:host([aria-current=\"page\"]){font-weight:500}:host(:focus-visible){outline:var(--neat-focus-ring-width) solid var(--sidebar-ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}.icon{display:inline-flex;flex:none}.label{min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: true
		}]
	}] }
});
var NeatRailDivider = class NeatRailDivider {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatRailDivider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatRailDivider,
		isStandalone: true,
		selector: "hr[neatRailDivider]",
		host: {
			attributes: { "aria-hidden": "true" },
			classAttribute: "mx-0 my-1 h-0 shrink-0 border-t border-sidebar-border"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatRailDivider,
	decorators: [{
		type: Directive,
		args: [{
			selector: "hr[neatRailDivider]",
			host: {
				"aria-hidden": "true",
				class: "mx-0 my-1 h-0 shrink-0 border-t border-sidebar-border"
			}
		}]
	}]
});
const PAGE_TOOLBAR_LABEL = "Page tools";
const ACTIVE_MATCH = {
	paths: "subset",
	queryParams: "ignored",
	matrixParams: "ignored",
	fragment: "ignored"
};
var NeatShell = class NeatShell {
	appName = input.required(...ngDevMode ? [{ debugName: "appName" }] : /* istanbul ignore next */ []);
	navItems = input.required(...ngDevMode ? [{ debugName: "navItems" }] : /* istanbul ignore next */ []);
	theme = inject(ThemeService);
	kiosk = inject(KioskService);
	viewport = inject(NeatViewport);
	pageToolbar = inject(PageToolbarSlot).portal;
	asideToggle = inject(AsideToggleSlot).portal;
	toolbarLabel = PAGE_TOOLBAR_LABEL;
	router = inject(Router);
	injector = inject(Injector);
	activeMatch = ACTIVE_MATCH;
	rail = inject(RailState);
	railExpanded = this.rail.expanded;
	kioskExit = viewChild(NeatKioskExit, ...ngDevMode ? [{ debugName: "kioskExit" }] : /* istanbul ignore next */ []);
	kioskButton = viewChild("kioskButton", ...ngDevMode ? [{ debugName: "kioskButton" }] : /* istanbul ignore next */ []);
	pageTitle = computed(() => {
		const url = this.router.lastSuccessfulNavigation()?.finalUrl;
		if (!url) return "";
		return this.navItems().find((item) => containsTree(url, this.router.parseUrl(item.path), ACTIVE_MATCH))?.label ?? "";
	}, ...ngDevMode ? [{ debugName: "pageTitle" }] : /* istanbul ignore next */ []);
	constructor() {
		let wasActive = this.kiosk.active();
		effect(() => {
			const active = this.kiosk.active();
			if (active && !wasActive) afterNextRender(() => this.kioskExit()?.focus(), { injector: this.injector });
			wasActive = active;
		});
	}
	focusKioskButtonAfterExit() {
		afterNextRender(() => this.kioskButton()?.nativeElement.focus(), { injector: this.injector });
	}
	toggleRail() {
		this.rail.set(!this.railExpanded());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatShell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatShell,
		isStandalone: true,
		selector: "neat-shell",
		inputs: {
			appName: {
				classPropertyName: "appName",
				publicName: "appName",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			navItems: {
				classPropertyName: "navItems",
				publicName: "navItems",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { properties: {
			"attr.data-kiosk": "kiosk.active()",
			"attr.data-narrow": "viewport.narrow()"
		} },
		providers: [RailState],
		viewQueries: [{
			propertyName: "kioskExit",
			first: true,
			predicate: NeatKioskExit,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "kioskButton",
			first: true,
			predicate: ["kioskButton"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (kiosk.active()) {\n  <div class=\"kiosk-chrome\" [attr.data-shown]=\"!kiosk.pointerIdle()\">\n    <!-- First in the tab order, so it is reachable from the keyboard; drawn last (right). -->\n    <neat-kiosk-exit (exited)=\"focusKioskButtonAfterExit()\" />\n    @if (pageToolbar() || asideToggle()) {\n      <div class=\"kiosk-toolbar shadow-md\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"pageToolbar()\" />\n        <ng-template [cdkPortalOutlet]=\"asideToggle()\" />\n      </div>\n    }\n  </div>\n} @else {\n  <div\n    class=\"rail data-[floating=true]:shadow-md\"\n    [attr.data-expanded]=\"railExpanded()\"\n    [attr.data-floating]=\"viewport.narrow() && railExpanded()\"\n  >\n    <nav aria-label=\"Main\">\n      <ul class=\"rail-list\">\n        @for (item of navItems(); track item.path) {\n          <li>\n            <a\n              neatRailItem\n              [label]=\"item.label\"\n              [routerLink]=\"item.path\"\n              routerLinkActive=\"active\"\n              [routerLinkActiveOptions]=\"activeMatch\"\n              ariaCurrentWhenActive=\"page\"\n            >\n              <neat-icon [name]=\"item.icon\" />\n            </a>\n          </li>\n        }\n      </ul>\n    </nav>\n\n    <!-- The app's items, then the kit's theme item: after the pages in the tab order. -->\n    <div class=\"rail-end\">\n      <hr neatRailDivider />\n      <ng-content select=\"[neatRailEnd]\" />\n      <button\n        neatRailItem\n        type=\"button\"\n        [label]=\"theme.scheme() === 'dark' ? 'Light theme' : 'Dark theme'\"\n        (click)=\"theme.toggle()\"\n      >\n        <neat-icon [name]=\"theme.scheme() === 'dark' ? 'sun' : 'moon'\" />\n      </button>\n    </div>\n\n    <button\n      neatRailItem\n      type=\"button\"\n      [label]=\"railExpanded() ? 'Collapse' : 'Show labels'\"\n      (click)=\"toggleRail()\"\n    >\n      <neat-icon [name]=\"railExpanded() ? 'rail-collapse' : 'rail-expand'\" />\n    </button>\n  </div>\n\n  <header class=\"topbar\" [attr.data-toolbar]=\"pageToolbar() ? 'true' : 'false'\">\n    <div class=\"brand\">\n      <neat-logo />\n      <span class=\"app-name\" [class.sr-only]=\"viewport.narrow()\">{{ appName() }}</span>\n    </div>\n    @if (pageTitle(); as title) {\n      <h1 class=\"page-title\" [class.sr-only]=\"viewport.narrow()\">{{ title }}</h1>\n    }\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"page-toolbar\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n    <div class=\"topbar-end\">\n      <ng-content select=\"[neatTopbarEnd]\" />\n    </div>\n    <div class=\"topbar-actions\">\n      <button\n        #kioskButton\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Kiosk mode\"\n        neatTooltip=\"Kiosk mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"kiosk.toggle()\"\n      >\n        <neat-icon name=\"kiosk-enter\" />\n      </button>\n    </div>\n    @if (asideToggle(); as toggle) {\n      <!-- The page's side-panel toggle, at the right edge above the panel. -->\n      <div class=\"aside-edge\">\n        <ng-template [cdkPortalOutlet]=\"toggle\" />\n      </div>\n    }\n  </header>\n}\n\n<main class=\"content\">\n  <ng-content />\n</main>\n",
		styles: [":host{--neat-rail-width: 3.5rem;--neat-rail-width-expanded: 13rem;--neat-topbar-height: 3rem;display:grid;height:100dvh;overflow:hidden;background:var(--background);color:var(--foreground)}:host([data-kiosk=\"false\"]){grid-template-areas:\"rail topbar\" \"rail content\"}:host([data-kiosk=\"false\"][data-narrow=\"false\"]){grid-template-columns:auto minmax(0,1fr);grid-template-rows:var(--neat-topbar-height) minmax(0,1fr)}:host([data-kiosk=\"false\"][data-narrow=\"true\"]){position:relative;grid-template-columns:var(--neat-rail-width) minmax(0,1fr);grid-template-rows:auto minmax(0,1fr)}:host([data-kiosk=\"true\"]){grid-template-areas:\"content\";grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr)}.rail{grid-area:rail;display:flex;flex-direction:column;gap:.5rem;box-sizing:border-box;padding:.5rem;overflow:hidden;background:var(--sidebar);color:var(--sidebar-foreground)}.rail[data-floating=false]{box-shadow:inset -1px 0 0 var(--sidebar-border)}.rail[data-expanded=false]{width:var(--neat-rail-width)}.rail[data-expanded=true]{width:var(--neat-rail-width-expanded)}.rail[data-floating=true]{position:absolute;inset-block:0;inset-inline-start:0;z-index:1}@media(prefers-reduced-motion:no-preference){:host([data-narrow=\"false\"]) .rail{transition:width var(--neat-transition-duration)}}nav{flex:1;min-height:0;overflow:hidden auto}.rail-list{display:flex;flex-direction:column;gap:.25rem;margin:0;padding:0;list-style:none}.rail-end{display:flex;flex:none;flex-direction:column;gap:.25rem}.topbar{grid-area:topbar;display:flex;align-items:center;min-width:0;border-block-end:1px solid var(--border)}:host([data-narrow=\"false\"]) .topbar{gap:1rem;padding-inline:1rem var(--neat-space-2)}:host([data-narrow=\"true\"]) .topbar{flex-wrap:wrap;min-height:var(--neat-topbar-height);gap:0 var(--neat-space-2);padding-inline:var(--neat-space-2)}.brand{display:flex;flex:none;align-items:center;gap:.5rem}.app-name{font-weight:700;white-space:nowrap}.page-title{flex:0 1 auto;min-width:0;margin:0;padding-inline-start:1rem;border-inline-start:1px solid var(--border);overflow:hidden;font-size:1rem;font-weight:500;line-height:1.5;white-space:nowrap;text-overflow:ellipsis}.page-toolbar{display:flex;align-items:center;gap:.5rem;min-width:0;padding-inline:.25rem;overflow:auto hidden;scrollbar-width:thin}:host([data-narrow=\"false\"]) .page-toolbar{flex:0 100 auto;align-self:stretch;margin-inline-start:auto}:host([data-narrow=\"true\"]) .page-toolbar{order:1;flex:0 0 100%;box-sizing:border-box;min-height:2.5rem}.topbar-end{display:flex;min-width:0;align-items:center;gap:.5rem}:host([data-narrow=\"false\"]) .topbar-end{flex:0 1 auto}:host([data-narrow=\"true\"]) .topbar-end{flex:1 1 0;justify-content:flex-end}.topbar[data-toolbar=false] .topbar-end{margin-inline-start:auto}.topbar-actions{display:flex;flex:none;align-items:center;gap:.25rem}.aside-edge{display:flex;flex:none;align-self:stretch;align-items:center;justify-content:center;box-sizing:border-box;width:var(--neat-topbar-height);margin-inline-end:calc(-1 * var(--neat-space-2));border-inline-start:1px solid var(--border)}.content{grid-area:content;min-width:0;min-height:0;overflow:hidden;isolation:isolate}.kiosk-chrome{grid-area:content;place-self:start end;z-index:1;display:flex;flex-direction:row-reverse;align-items:center;gap:.5rem;min-width:0;max-width:calc(100% - 2rem);margin:1rem}.kiosk-chrome[data-shown=false]:not(:has(:focus-visible)){opacity:0;pointer-events:none}@media(prefers-reduced-motion:no-preference){.kiosk-chrome{transition:opacity var(--neat-transition-duration)}}neat-kiosk-exit{flex:none}.kiosk-toolbar{display:flex;align-items:center;gap:.5rem;box-sizing:border-box;min-width:0;min-height:3rem;padding-inline:.75rem;overflow:auto hidden;scrollbar-width:thin;border:1px solid var(--border);border-radius:1.5rem;background:var(--background)}\n"],
		dependencies: [
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatKioskExit,
				selector: "neat-kiosk-exit",
				outputs: ["exited"]
			},
			{
				kind: "component",
				type: NeatLogo,
				selector: "neat-logo"
			},
			{
				kind: "directive",
				type: NeatRailDivider,
				selector: "hr[neatRailDivider]"
			},
			{
				kind: "component",
				type: NeatRailItem,
				selector: "button[neatRailItem], a[neatRailItem]",
				inputs: ["label"]
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatShell,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-shell",
			imports: [
				CdkPortalOutlet,
				NeatButton,
				NeatIcon,
				NeatKioskExit,
				NeatLogo,
				NeatRailDivider,
				NeatRailItem,
				NeatTooltip,
				RouterLink,
				RouterLinkActive
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [RailState],
			host: {
				"[attr.data-kiosk]": "kiosk.active()",
				"[attr.data-narrow]": "viewport.narrow()"
			},
			template: "@if (kiosk.active()) {\n  <div class=\"kiosk-chrome\" [attr.data-shown]=\"!kiosk.pointerIdle()\">\n    <!-- First in the tab order, so it is reachable from the keyboard; drawn last (right). -->\n    <neat-kiosk-exit (exited)=\"focusKioskButtonAfterExit()\" />\n    @if (pageToolbar() || asideToggle()) {\n      <div class=\"kiosk-toolbar shadow-md\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"pageToolbar()\" />\n        <ng-template [cdkPortalOutlet]=\"asideToggle()\" />\n      </div>\n    }\n  </div>\n} @else {\n  <div\n    class=\"rail data-[floating=true]:shadow-md\"\n    [attr.data-expanded]=\"railExpanded()\"\n    [attr.data-floating]=\"viewport.narrow() && railExpanded()\"\n  >\n    <nav aria-label=\"Main\">\n      <ul class=\"rail-list\">\n        @for (item of navItems(); track item.path) {\n          <li>\n            <a\n              neatRailItem\n              [label]=\"item.label\"\n              [routerLink]=\"item.path\"\n              routerLinkActive=\"active\"\n              [routerLinkActiveOptions]=\"activeMatch\"\n              ariaCurrentWhenActive=\"page\"\n            >\n              <neat-icon [name]=\"item.icon\" />\n            </a>\n          </li>\n        }\n      </ul>\n    </nav>\n\n    <!-- The app's items, then the kit's theme item: after the pages in the tab order. -->\n    <div class=\"rail-end\">\n      <hr neatRailDivider />\n      <ng-content select=\"[neatRailEnd]\" />\n      <button\n        neatRailItem\n        type=\"button\"\n        [label]=\"theme.scheme() === 'dark' ? 'Light theme' : 'Dark theme'\"\n        (click)=\"theme.toggle()\"\n      >\n        <neat-icon [name]=\"theme.scheme() === 'dark' ? 'sun' : 'moon'\" />\n      </button>\n    </div>\n\n    <button\n      neatRailItem\n      type=\"button\"\n      [label]=\"railExpanded() ? 'Collapse' : 'Show labels'\"\n      (click)=\"toggleRail()\"\n    >\n      <neat-icon [name]=\"railExpanded() ? 'rail-collapse' : 'rail-expand'\" />\n    </button>\n  </div>\n\n  <header class=\"topbar\" [attr.data-toolbar]=\"pageToolbar() ? 'true' : 'false'\">\n    <div class=\"brand\">\n      <neat-logo />\n      <span class=\"app-name\" [class.sr-only]=\"viewport.narrow()\">{{ appName() }}</span>\n    </div>\n    @if (pageTitle(); as title) {\n      <h1 class=\"page-title\" [class.sr-only]=\"viewport.narrow()\">{{ title }}</h1>\n    }\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"page-toolbar\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n    <div class=\"topbar-end\">\n      <ng-content select=\"[neatTopbarEnd]\" />\n    </div>\n    <div class=\"topbar-actions\">\n      <button\n        #kioskButton\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Kiosk mode\"\n        neatTooltip=\"Kiosk mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"kiosk.toggle()\"\n      >\n        <neat-icon name=\"kiosk-enter\" />\n      </button>\n    </div>\n    @if (asideToggle(); as toggle) {\n      <!-- The page's side-panel toggle, at the right edge above the panel. -->\n      <div class=\"aside-edge\">\n        <ng-template [cdkPortalOutlet]=\"toggle\" />\n      </div>\n    }\n  </header>\n}\n\n<main class=\"content\">\n  <ng-content />\n</main>\n",
			styles: [":host{--neat-rail-width: 3.5rem;--neat-rail-width-expanded: 13rem;--neat-topbar-height: 3rem;display:grid;height:100dvh;overflow:hidden;background:var(--background);color:var(--foreground)}:host([data-kiosk=\"false\"]){grid-template-areas:\"rail topbar\" \"rail content\"}:host([data-kiosk=\"false\"][data-narrow=\"false\"]){grid-template-columns:auto minmax(0,1fr);grid-template-rows:var(--neat-topbar-height) minmax(0,1fr)}:host([data-kiosk=\"false\"][data-narrow=\"true\"]){position:relative;grid-template-columns:var(--neat-rail-width) minmax(0,1fr);grid-template-rows:auto minmax(0,1fr)}:host([data-kiosk=\"true\"]){grid-template-areas:\"content\";grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr)}.rail{grid-area:rail;display:flex;flex-direction:column;gap:.5rem;box-sizing:border-box;padding:.5rem;overflow:hidden;background:var(--sidebar);color:var(--sidebar-foreground)}.rail[data-floating=false]{box-shadow:inset -1px 0 0 var(--sidebar-border)}.rail[data-expanded=false]{width:var(--neat-rail-width)}.rail[data-expanded=true]{width:var(--neat-rail-width-expanded)}.rail[data-floating=true]{position:absolute;inset-block:0;inset-inline-start:0;z-index:1}@media(prefers-reduced-motion:no-preference){:host([data-narrow=\"false\"]) .rail{transition:width var(--neat-transition-duration)}}nav{flex:1;min-height:0;overflow:hidden auto}.rail-list{display:flex;flex-direction:column;gap:.25rem;margin:0;padding:0;list-style:none}.rail-end{display:flex;flex:none;flex-direction:column;gap:.25rem}.topbar{grid-area:topbar;display:flex;align-items:center;min-width:0;border-block-end:1px solid var(--border)}:host([data-narrow=\"false\"]) .topbar{gap:1rem;padding-inline:1rem var(--neat-space-2)}:host([data-narrow=\"true\"]) .topbar{flex-wrap:wrap;min-height:var(--neat-topbar-height);gap:0 var(--neat-space-2);padding-inline:var(--neat-space-2)}.brand{display:flex;flex:none;align-items:center;gap:.5rem}.app-name{font-weight:700;white-space:nowrap}.page-title{flex:0 1 auto;min-width:0;margin:0;padding-inline-start:1rem;border-inline-start:1px solid var(--border);overflow:hidden;font-size:1rem;font-weight:500;line-height:1.5;white-space:nowrap;text-overflow:ellipsis}.page-toolbar{display:flex;align-items:center;gap:.5rem;min-width:0;padding-inline:.25rem;overflow:auto hidden;scrollbar-width:thin}:host([data-narrow=\"false\"]) .page-toolbar{flex:0 100 auto;align-self:stretch;margin-inline-start:auto}:host([data-narrow=\"true\"]) .page-toolbar{order:1;flex:0 0 100%;box-sizing:border-box;min-height:2.5rem}.topbar-end{display:flex;min-width:0;align-items:center;gap:.5rem}:host([data-narrow=\"false\"]) .topbar-end{flex:0 1 auto}:host([data-narrow=\"true\"]) .topbar-end{flex:1 1 0;justify-content:flex-end}.topbar[data-toolbar=false] .topbar-end{margin-inline-start:auto}.topbar-actions{display:flex;flex:none;align-items:center;gap:.25rem}.aside-edge{display:flex;flex:none;align-self:stretch;align-items:center;justify-content:center;box-sizing:border-box;width:var(--neat-topbar-height);margin-inline-end:calc(-1 * var(--neat-space-2));border-inline-start:1px solid var(--border)}.content{grid-area:content;min-width:0;min-height:0;overflow:hidden;isolation:isolate}.kiosk-chrome{grid-area:content;place-self:start end;z-index:1;display:flex;flex-direction:row-reverse;align-items:center;gap:.5rem;min-width:0;max-width:calc(100% - 2rem);margin:1rem}.kiosk-chrome[data-shown=false]:not(:has(:focus-visible)){opacity:0;pointer-events:none}@media(prefers-reduced-motion:no-preference){.kiosk-chrome{transition:opacity var(--neat-transition-duration)}}neat-kiosk-exit{flex:none}.kiosk-toolbar{display:flex;align-items:center;gap:.5rem;box-sizing:border-box;min-width:0;min-height:3rem;padding-inline:.75rem;overflow:auto hidden;scrollbar-width:thin;border:1px solid var(--border);border-radius:1.5rem;background:var(--background)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		appName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appName",
				required: true
			}]
		}],
		navItems: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navItems",
				required: true
			}]
		}],
		kioskExit: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatKioskExit), { isSignal: true }]
		}],
		kioskButton: [{
			type: i0.ViewChild,
			args: ["kioskButton", { isSignal: true }]
		}]
	}
});
const MIN_REM = 18;
const BODY_MIN_REM = 20;
const KEY_STEP = 16;
var NeatPage = class NeatPage {
	viewport = inject(NeatViewport);
	scroll = input("body", ...ngDevMode ? [{ debugName: "scroll" }] : /* istanbul ignore next */ []);
	padding = input("page", ...ngDevMode ? [{ debugName: "padding" }] : /* istanbul ignore next */ []);
	aside = input("closed", ...ngDevMode ? [{ debugName: "aside" }] : /* istanbul ignore next */ []);
	asideWidth = model(null, ...ngDevMode ? [{ debugName: "asideWidth" }] : /* istanbul ignore next */ []);
	page = inject(ElementRef).nativeElement;
	panel = viewChild("aside", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	pageWidth = signal(0, ...ngDevMode ? [{ debugName: "pageWidth" }] : /* istanbul ignore next */ []);
	panelWidth = signal(0, ...ngDevMode ? [{ debugName: "panelWidth" }] : /* istanbul ignore next */ []);
	rem = signal(16, ...ngDevMode ? [{ debugName: "rem" }] : /* istanbul ignore next */ []);
	dragWidth = signal(null, ...ngDevMode ? [{ debugName: "dragWidth" }] : /* istanbul ignore next */ []);
	dragStart = null;
	bounds = computed(() => {
		const rem = this.rem();
		const min = Math.round(MIN_REM * rem);
		const page = this.pageWidth();
		return {
			min,
			max: page > 0 ? Math.max(min, Math.floor(page - BODY_MIN_REM * rem)) : null
		};
	}, ...ngDevMode ? [{ debugName: "bounds" }] : /* istanbul ignore next */ []);
	requested = computed(() => this.viewport.narrow() ? null : this.dragWidth() ?? this.asideWidth(), ...ngDevMode ? [{ debugName: "requested" }] : /* istanbul ignore next */ []);
	width = computed(() => {
		const wanted = this.requested() ?? (this.panelWidth() > 0 ? this.panelWidth() : null);
		return wanted === null ? null : this.clamp(wanted);
	}, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	constructor() {
		effect((onCleanup) => {
			const panel = this.panel()?.nativeElement;
			const narrow = this.viewport.narrow();
			onCleanup(() => this.cancelDrag());
			if (!panel || narrow || typeof ResizeObserver !== "function") return;
			const observer = new ResizeObserver(() => this.measure(panel));
			observer.observe(this.page);
			observer.observe(panel);
			onCleanup(() => observer.disconnect());
		});
	}
	step(event) {
		const { min, max } = this.bounds();
		const current = this.current();
		const next = {
			ArrowLeft: current + KEY_STEP,
			ArrowRight: current - KEY_STEP,
			Home: min,
			End: max ?? current
		}[event.key];
		if (next === void 0) return;
		event.preventDefault();
		const width = this.clamp(next);
		if (width !== current) this.asideWidth.set(width);
	}
	startDrag(event) {
		if (event.button !== 0) return;
		event.currentTarget.setPointerCapture(event.pointerId);
		const width = this.current();
		this.dragStart = {
			x: event.clientX,
			width,
			moved: false
		};
		this.dragWidth.set(width);
	}
	drag(event) {
		if (!this.dragStart) return;
		this.dragStart.moved = true;
		this.dragWidth.set(this.clamp(this.dragStart.width + this.dragStart.x - event.clientX));
	}
	endDrag() {
		const width = this.dragWidth();
		const moved = this.dragStart?.moved;
		this.cancelDrag();
		if (moved && width !== null) this.asideWidth.set(width);
	}
	cancelDrag() {
		this.dragStart = null;
		this.dragWidth.set(null);
	}
	current() {
		return this.width() ?? this.clamp(this.panel()?.nativeElement.offsetWidth || this.bounds().min);
	}
	clamp(width) {
		const { min, max } = this.bounds();
		return Math.round(Math.min(max ?? Infinity, Math.max(min, width)));
	}
	measure(panel) {
		this.pageWidth.set(this.page.clientWidth);
		this.panelWidth.set(panel.offsetWidth);
		const fontSize = getComputedStyle(this.page.ownerDocument.documentElement).fontSize;
		this.rem.set(parseFloat(fontSize) || 16);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatPage,
		isStandalone: true,
		selector: "neat-page",
		inputs: {
			scroll: {
				classPropertyName: "scroll",
				publicName: "scroll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			padding: {
				classPropertyName: "padding",
				publicName: "padding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			aside: {
				classPropertyName: "aside",
				publicName: "aside",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			asideWidth: {
				classPropertyName: "asideWidth",
				publicName: "asideWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { asideWidth: "asideWidthChange" },
		host: { properties: {
			"attr.data-aside": "viewport.narrow() ? 'overlay' : 'beside'",
			"attr.data-resizing": "dragWidth() === null ? null : ''"
		} },
		viewQueries: [{
			propertyName: "panel",
			first: true,
			predicate: ["aside"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-content select="[neatPageTabs]" />
    <div class="content">
      <div class="body" [attr.data-scroll]="scroll()" [attr.data-padding]="padding()">
        <ng-content />
      </div>
      @if (aside() === 'open') {
        @if (!viewport.narrow()) {
          <div
            class="separator"
            role="separator"
            tabindex="0"
            aria-orientation="vertical"
            aria-label="Resize side panel"
            [attr.aria-valuemin]="bounds().min"
            [attr.aria-valuemax]="bounds().max"
            [attr.aria-valuenow]="width()"
            [attr.aria-valuetext]="width() === null ? null : width() + ' px'"
            (keydown)="step($event)"
            (pointerdown)="startDrag($event)"
            (pointermove)="drag($event)"
            (pointerup)="endDrag()"
            (pointercancel)="cancelDrag()"
            (lostpointercapture)="cancelDrag()"
            (dblclick)="asideWidth.set(null)"
          ></div>
        }
        <aside
          #aside
          class="in-data-[aside=overlay]:shadow-md"
          [style.--neat-aside-width]="requested() === null ? null : requested() + 'px'"
          [style.--neat-page-aside-min]="viewport.narrow() ? null : bounds().min + 'px'"
          [style.--neat-page-aside-max]="
            viewport.narrow() || bounds().max === null ? null : bounds().max + 'px'
          "
        >
          <ng-content select="[neatPageAside]" />
        </aside>
      }
    </div>
  `,
		isInline: true,
		styles: [":host{display:flex;flex-direction:column;height:100%;overflow:hidden}.content{position:relative;display:flex;flex:1 1 0;min-height:0}.body{flex:1 1 0;min-width:0;box-sizing:border-box;height:100%}.body[data-scroll=body]{overflow:auto}.body[data-scroll=none]{overflow:hidden}.body[data-padding=page]{padding:var(--neat-space-6)}.body[data-padding=none]{padding:0}.separator{position:relative;z-index:1;flex:none;width:var(--neat-space-2);margin-inline:calc(var(--neat-space-2) / -2);cursor:col-resize;touch-action:none;-webkit-user-select:none;user-select:none}.separator:focus-visible{outline:var(--neat-focus-ring-width) solid transparent}.separator:after{content:\"\";position:absolute;inset-block:0;inset-inline-start:calc(50% - var(--neat-focus-ring-width) / 2);width:var(--neat-focus-ring-width);background:var(--ring);opacity:0}.separator:hover:after,.separator:focus-visible:after,:host([data-resizing]) .separator:after{opacity:1}@media(prefers-reduced-motion:no-preference){.separator:after{transition:opacity var(--neat-transition-duration)}}aside{box-sizing:border-box;height:100%;padding:var(--neat-space-4);overflow:auto;border-inline-start:1px solid var(--border)}:host([data-aside=\"beside\"]) aside{flex:none;width:clamp(var(--neat-page-aside-min),var(--neat-aside-width),var(--neat-page-aside-max, 100%))}:host([data-aside=\"overlay\"]) aside{position:absolute;inset-block:0;inset-inline-end:0;z-index:1;width:min(var(--neat-aside-width),100%);background:var(--background)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPage,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-aside]": "viewport.narrow() ? 'overlay' : 'beside'",
				"[attr.data-resizing]": "dragWidth() === null ? null : ''"
			},
			template: `
    <ng-content select="[neatPageTabs]" />
    <div class="content">
      <div class="body" [attr.data-scroll]="scroll()" [attr.data-padding]="padding()">
        <ng-content />
      </div>
      @if (aside() === 'open') {
        @if (!viewport.narrow()) {
          <div
            class="separator"
            role="separator"
            tabindex="0"
            aria-orientation="vertical"
            aria-label="Resize side panel"
            [attr.aria-valuemin]="bounds().min"
            [attr.aria-valuemax]="bounds().max"
            [attr.aria-valuenow]="width()"
            [attr.aria-valuetext]="width() === null ? null : width() + ' px'"
            (keydown)="step($event)"
            (pointerdown)="startDrag($event)"
            (pointermove)="drag($event)"
            (pointerup)="endDrag()"
            (pointercancel)="cancelDrag()"
            (lostpointercapture)="cancelDrag()"
            (dblclick)="asideWidth.set(null)"
          ></div>
        }
        <aside
          #aside
          class="in-data-[aside=overlay]:shadow-md"
          [style.--neat-aside-width]="requested() === null ? null : requested() + 'px'"
          [style.--neat-page-aside-min]="viewport.narrow() ? null : bounds().min + 'px'"
          [style.--neat-page-aside-max]="
            viewport.narrow() || bounds().max === null ? null : bounds().max + 'px'
          "
        >
          <ng-content select="[neatPageAside]" />
        </aside>
      }
    </div>
  `,
			styles: [":host{display:flex;flex-direction:column;height:100%;overflow:hidden}.content{position:relative;display:flex;flex:1 1 0;min-height:0}.body{flex:1 1 0;min-width:0;box-sizing:border-box;height:100%}.body[data-scroll=body]{overflow:auto}.body[data-scroll=none]{overflow:hidden}.body[data-padding=page]{padding:var(--neat-space-6)}.body[data-padding=none]{padding:0}.separator{position:relative;z-index:1;flex:none;width:var(--neat-space-2);margin-inline:calc(var(--neat-space-2) / -2);cursor:col-resize;touch-action:none;-webkit-user-select:none;user-select:none}.separator:focus-visible{outline:var(--neat-focus-ring-width) solid transparent}.separator:after{content:\"\";position:absolute;inset-block:0;inset-inline-start:calc(50% - var(--neat-focus-ring-width) / 2);width:var(--neat-focus-ring-width);background:var(--ring);opacity:0}.separator:hover:after,.separator:focus-visible:after,:host([data-resizing]) .separator:after{opacity:1}@media(prefers-reduced-motion:no-preference){.separator:after{transition:opacity var(--neat-transition-duration)}}aside{box-sizing:border-box;height:100%;padding:var(--neat-space-4);overflow:auto;border-inline-start:1px solid var(--border)}:host([data-aside=\"beside\"]) aside{flex:none;width:clamp(var(--neat-page-aside-min),var(--neat-aside-width),var(--neat-page-aside-max, 100%))}:host([data-aside=\"overlay\"]) aside{position:absolute;inset-block:0;inset-inline-end:0;z-index:1;width:min(var(--neat-aside-width),100%);background:var(--background)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		scroll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scroll",
				required: false
			}]
		}],
		padding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "padding",
				required: false
			}]
		}],
		aside: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "aside",
				required: false
			}]
		}],
		asideWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "asideWidth",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["asideWidthChange"]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["aside", { isSignal: true }]
		}]
	}
});
const MATCH = {
	exact: {
		paths: "exact",
		queryParams: "ignored",
		matrixParams: "ignored",
		fragment: "ignored"
	},
	subset: {
		paths: "subset",
		queryParams: "ignored",
		matrixParams: "ignored",
		fragment: "ignored"
	}
};
var NeatPageTabs = class NeatPageTabs {
	host = inject(ElementRef).nativeElement;
	ngAfterViewInit() {
		if (isDevMode() && !this.host.hasAttribute("aria-label") && !this.host.hasAttribute("aria-labelledby")) throw new Error("nav[neatPageTabs] needs an aria-label (or aria-labelledby) naming the views.");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPageTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPageTabs,
		isStandalone: true,
		selector: "nav[neatPageTabs]",
		host: { classAttribute: "flex flex-none items-stretch gap-(--neat-space-4) overflow-x-auto border-b border-border px-(--neat-space-6)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPageTabs,
	decorators: [{
		type: Directive,
		args: [{
			selector: "nav[neatPageTabs]",
			host: { class: "flex flex-none items-stretch gap-(--neat-space-4) overflow-x-auto border-b border-border px-(--neat-space-6)" }
		}]
	}]
});
var NeatPageTab = class NeatPageTab {
	activeMatch = input("exact", ...ngDevMode ? [{ debugName: "activeMatch" }] : /* istanbul ignore next */ []);
	router = inject(Router);
	link = inject(RouterLink, { self: true });
	active() {
		this.router.lastSuccessfulNavigation();
		const tree = this.link.urlTree;
		return tree !== null && this.router.isActive(tree, MATCH[this.activeMatch()]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPageTab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatPageTab,
		isStandalone: true,
		selector: "a[neatPageTab]",
		inputs: { activeMatch: {
			classPropertyName: "activeMatch",
			publicName: "activeMatch",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: {
				"attr.aria-current": "active() ? 'page' : null",
				"attr.data-active": "active() ? '' : null"
			},
			classAttribute: "shrink-0 whitespace-nowrap border-b-2 border-transparent py-2 leading-5 text-(length:--neat-text-sm) font-medium text-muted-foreground no-underline hover:text-foreground focus-visible:outline-(length:--neat-focus-ring-width) focus-visible:outline-offset-[calc(-1*var(--neat-focus-ring-width))] data-active:border-primary data-active:font-semibold data-active:text-foreground"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPageTab,
	decorators: [{
		type: Directive,
		args: [{
			selector: "a[neatPageTab]",
			host: {
				class: "shrink-0 whitespace-nowrap border-b-2 border-transparent py-2 leading-5 text-(length:--neat-text-sm) font-medium text-muted-foreground no-underline hover:text-foreground focus-visible:outline-(length:--neat-focus-ring-width) focus-visible:outline-offset-[calc(-1*var(--neat-focus-ring-width))] data-active:border-primary data-active:font-semibold data-active:text-foreground",
				"[attr.aria-current]": "active() ? 'page' : null",
				"[attr.data-active]": "active() ? '' : null"
			}
		}]
	}],
	propDecorators: { activeMatch: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "activeMatch",
			required: false
		}]
	}] }
});
const CLASSES = hlm(buttonVariants({ variant: "link" }), "h-auto border-0 p-0 has-data-[icon=inline-end]:pr-0 has-data-[icon=inline-start]:pl-0 text-[length:inherit] text-inherit focus-visible:ring-ring");
var NeatInlineButton = class NeatInlineButton {
	classes = CLASSES;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatInlineButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatInlineButton,
		isStandalone: true,
		selector: "button[neatInlineButton], a[neatInlineButton]",
		host: {
			attributes: { "data-slot": "button" },
			properties: { "class": "classes" }
		},
		hostDirectives: [{
			directive: i1$2.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatInlineButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatInlineButton], a[neatInlineButton]",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: {
				"data-slot": "button",
				"[class]": "classes"
			}
		}]
	}]
});
var NeatLiveDot = class NeatLiveDot {
	pulse = input(false, {
		...ngDevMode ? { debugName: "pulse" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLiveDot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatLiveDot,
		isStandalone: true,
		selector: "neat-live-dot",
		inputs: { pulse: {
			classPropertyName: "pulse",
			publicName: "pulse",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { attributes: { "aria-hidden": "true" } },
		ngImport: i0,
		template: `
    <span class="dot" [class.beat]="pulse()"></span>
    @if (pulse()) {
      <span class="ring"></span>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:inline-block;flex:none;width:.625rem;height:.625rem}.dot,.ring{position:absolute;inset:0;border-radius:50%;background:var(--neat-live)}.ring{display:none;pointer-events:none}@media(prefers-reduced-motion:no-preference){.beat{animation:live-dot-beat 1.6s ease-in-out infinite}.ring{display:block;animation:live-dot-ring 1.6s cubic-bezier(.2,.6,.3,1) infinite}}@keyframes live-dot-beat{0%,to{opacity:1}50%{opacity:.7}}@keyframes live-dot-ring{0%{transform:scale(1);opacity:.45}to{transform:scale(2.6);opacity:0}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLiveDot,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-live-dot",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "aria-hidden": "true" },
			template: `
    <span class="dot" [class.beat]="pulse()"></span>
    @if (pulse()) {
      <span class="ring"></span>
    }
  `,
			styles: [":host{position:relative;display:inline-block;flex:none;width:.625rem;height:.625rem}.dot,.ring{position:absolute;inset:0;border-radius:50%;background:var(--neat-live)}.ring{display:none;pointer-events:none}@media(prefers-reduced-motion:no-preference){.beat{animation:live-dot-beat 1.6s ease-in-out infinite}.ring{display:block;animation:live-dot-ring 1.6s cubic-bezier(.2,.6,.3,1) infinite}}@keyframes live-dot-beat{0%,to{opacity:1}50%{opacity:.7}}@keyframes live-dot-ring{0%{transform:scale(1);opacity:.45}to{transform:scale(2.6);opacity:0}}\n"]
		}]
	}],
	propDecorators: { pulse: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "pulse",
			required: false
		}]
	}] }
});
const NOTE_CLASSES = "m-0 text-muted-foreground text-(length:--neat-text-xs)";
var NeatNote = class NeatNote {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatNote,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatNote,
		isStandalone: true,
		selector: "[neatNote]",
		host: { classAttribute: "m-0 text-muted-foreground text-(length:--neat-text-xs)" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatNote,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatNote]",
			host: { class: NOTE_CLASSES }
		}]
	}]
});
function neatSecondsAgo(seconds) {
	const whole = Math.round(seconds);
	if (whole < 10) return "just now";
	if (whole < 60) return `${whole} s ago`;
	if (whole < 3600) return `${Math.floor(whole / 60)} min ago`;
	if (whole < 86400) return `${Math.floor(whole / 3600)} h ago`;
	return `${Math.floor(whole / 86400)} d ago`;
}
const FIELD_LABEL_CLASSES = {
	stack: "flex flex-col gap-2",
	label: "text-sm font-medium"
};
var HlmTabs = class HlmTabs {
	tab = input.required(...ngDevMode ? [{ debugName: "tab" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabs,
		isStandalone: true,
		selector: "[hlmTabs],hlm-tabs",
		inputs: { tab: {
			classPropertyName: "tab",
			publicName: "tab",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs" } },
		exportAs: ["hlmTabs"],
		hostDirectives: [{
			directive: i1.BrnTabs,
			inputs: [
				"orientation",
				"orientation",
				"activationMode",
				"activationMode",
				"brnTabs",
				"tab"
			],
			outputs: ["tabActivated", "tabActivated"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabs,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabs],hlm-tabs",
			exportAs: "hlmTabs",
			hostDirectives: [{
				directive: BrnTabs,
				inputs: [
					"orientation",
					"activationMode",
					"brnTabs: tab"
				],
				outputs: ["tabActivated"]
			}],
			host: { "data-slot": "tabs" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { tab: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "tab",
			required: true
		}]
	}] }
});
var HlmTabsContent = class HlmTabsContent {
	contentFor = input.required({
		...ngDevMode ? { debugName: "contentFor" } : /* istanbul ignore next */ {},
		alias: "hlmTabsContent"
	});
	constructor() {
		classes(() => "flex-1 text-sm outline-none");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsContent,
		isStandalone: true,
		selector: "[hlmTabsContent]",
		inputs: { contentFor: {
			classPropertyName: "contentFor",
			publicName: "hlmTabsContent",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs-content" } },
		exportAs: ["hlmTabsContent"],
		hostDirectives: [{
			directive: i1.BrnTabsContent,
			inputs: ["brnTabsContent", "hlmTabsContent"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsContent]",
			exportAs: "hlmTabsContent",
			hostDirectives: [{
				directive: BrnTabsContent,
				inputs: ["brnTabsContent: hlmTabsContent"]
			}],
			host: { "data-slot": "tabs-content" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { contentFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hlmTabsContent",
			required: true
		}]
	}] }
});
var HlmTabsContentLazy = class HlmTabsContentLazy {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsContentLazy,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HlmTabsContentLazy,
		isStandalone: true,
		selector: "ng-template[hlmTabsContentLazy]",
		exportAs: ["hlmTabsContentLazy"],
		hostDirectives: [{ directive: i1.BrnTabsContentLazy }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsContentLazy,
	decorators: [{
		type: Directive,
		args: [{
			selector: "ng-template[hlmTabsContentLazy]",
			exportAs: "hlmTabsContentLazy",
			hostDirectives: [BrnTabsContentLazy]
		}]
	}]
});
const listVariants = cva("rounded-lg p-[3px] group-data-horizontal/tabs:h-9 data-[variant=line]:rounded-none group/tabs-list text-muted-foreground inline-flex w-fit items-center justify-center group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col", {
	variants: { variant: {
		default: "bg-muted",
		line: "gap-1 bg-transparent"
	} },
	defaultVariants: { variant: "default" }
});
var HlmTabsList = class HlmTabsList {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => listVariants({ variant: this.variant() }));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsList,
		isStandalone: true,
		selector: "[hlmTabsList],hlm-tabs-list",
		inputs: { variant: {
			classPropertyName: "variant",
			publicName: "variant",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "tabs-list" },
			properties: { "attr.data-variant": "variant()" }
		},
		exportAs: ["hlmTabsList"],
		hostDirectives: [{ directive: i1.BrnTabsList }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsList,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsList],hlm-tabs-list",
			exportAs: "hlmTabsList",
			hostDirectives: [BrnTabsList],
			host: {
				"data-slot": "tabs-list",
				"[attr.data-variant]": "variant()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { variant: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "variant",
			required: false
		}]
	}] }
});
var HlmTabsPaginatedList = class HlmTabsPaginatedList extends BrnTabsPaginatedList {
	constructor() {
		super();
		classes(() => "relative flex flex-shrink-0 items-center gap-1 overflow-hidden");
	}
	items = contentChildren(BrnTabsTrigger, {
		...ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemsChanges = toObservable(this.items);
	tabListContainer = viewChild.required("tabListContainer", ...ngDevMode ? [{ debugName: "tabListContainer" }] : /* istanbul ignore next */ []);
	tabList = viewChild.required("tabList", ...ngDevMode ? [{ debugName: "tabList" }] : /* istanbul ignore next */ []);
	tabListInner = viewChild.required("tabListInner", ...ngDevMode ? [{ debugName: "tabListInner" }] : /* istanbul ignore next */ []);
	nextPaginator = viewChild.required("nextPaginator", ...ngDevMode ? [{ debugName: "nextPaginator" }] : /* istanbul ignore next */ []);
	previousPaginator = viewChild.required("previousPaginator", ...ngDevMode ? [{ debugName: "previousPaginator" }] : /* istanbul ignore next */ []);
	tabListClass = input("", {
		...ngDevMode ? { debugName: "tabListClass" } : /* istanbul ignore next */ {},
		alias: "tabListClass"
	});
	_tabListClass = computed(() => hlm(listVariants(), this.tabListClass()), ...ngDevMode ? [{ debugName: "_tabListClass" }] : /* istanbul ignore next */ []);
	paginationButtonClass = input("", ...ngDevMode ? [{ debugName: "paginationButtonClass" }] : /* istanbul ignore next */ []);
	_paginationButtonClass = computed(() => hlm("relative z-[2] select-none disabled:cursor-default", buttonVariants({
		variant: "ghost",
		size: "icon-sm"
	}), this.paginationButtonClass(), this.showPaginationControls() ? "inline-flex" : "hidden"), ...ngDevMode ? [{ debugName: "_paginationButtonClass" }] : /* istanbul ignore next */ []);
	_itemSelected(event) {
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsPaginatedList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: HlmTabsPaginatedList,
		isStandalone: true,
		selector: "hlm-paginated-tabs-list",
		inputs: {
			tabListClass: {
				classPropertyName: "tabListClass",
				publicName: "tabListClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			paginationButtonClass: {
				classPropertyName: "paginationButtonClass",
				publicName: "paginationButtonClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "tabs-paginated-list" } },
		queries: [{
			propertyName: "items",
			predicate: BrnTabsTrigger,
			isSignal: true
		}],
		viewQueries: [
			{
				propertyName: "tabListContainer",
				first: true,
				predicate: ["tabListContainer"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tabList",
				first: true,
				predicate: ["tabList"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tabListInner",
				first: true,
				predicate: ["tabListInner"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "nextPaginator",
				first: true,
				predicate: ["nextPaginator"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "previousPaginator",
				first: true,
				predicate: ["previousPaginator"],
				descendants: true,
				isSignal: true
			}
		],
		exportAs: ["hlmTabsPaginatedList"],
		usesInheritance: true,
		ngImport: i0,
		template: `
    <button
      #previousPaginator
      data-pagination="previous"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollBefore || null"
      (click)="_handlePaginatorClick('before')"
      (mousedown)="_handlePaginatorPress('before', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="previous" [size]="16" />
    </button>

    <div
      #tabListContainer
      class="z-[1] flex grow overflow-hidden"
      (keydown)="_handleKeydown($event)"
    >
      <div
        class="relative grow transition-transform"
        #tabList
        role="tablist"
        (cdkObserveContent)="_onContentChanges()"
      >
        <div #tabListInner [class]="_tabListClass()">
          <ng-content />
        </div>
      </div>
    </div>

    <button
      #nextPaginator
      data-pagination="next"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollAfter || null"
      (click)="_handlePaginatorClick('after')"
      (mousedown)="_handlePaginatorPress('after', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="next" [size]="16" />
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: CdkObserveContent,
			selector: "[cdkObserveContent]",
			inputs: ["cdkObserveContentDisabled", "debounce"],
			outputs: ["cdkObserveContent"],
			exportAs: ["cdkObserveContent"]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsPaginatedList,
	decorators: [{
		type: Component,
		args: [{
			selector: "hlm-paginated-tabs-list",
			exportAs: "hlmTabsPaginatedList",
			imports: [CdkObserveContent, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "data-slot": "tabs-paginated-list" },
			template: `
    <button
      #previousPaginator
      data-pagination="previous"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollBefore || null"
      (click)="_handlePaginatorClick('before')"
      (mousedown)="_handlePaginatorPress('before', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="previous" [size]="16" />
    </button>

    <div
      #tabListContainer
      class="z-[1] flex grow overflow-hidden"
      (keydown)="_handleKeydown($event)"
    >
      <div
        class="relative grow transition-transform"
        #tabList
        role="tablist"
        (cdkObserveContent)="_onContentChanges()"
      >
        <div #tabListInner [class]="_tabListClass()">
          <ng-content />
        </div>
      </div>
    </div>

    <button
      #nextPaginator
      data-pagination="next"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollAfter || null"
      (click)="_handlePaginatorClick('after')"
      (mousedown)="_handlePaginatorPress('after', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="next" [size]="16" />
    </button>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		items: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => BrnTabsTrigger), {
				descendants: false,
				isSignal: true
			}]
		}],
		tabListContainer: [{
			type: i0.ViewChild,
			args: ["tabListContainer", { isSignal: true }]
		}],
		tabList: [{
			type: i0.ViewChild,
			args: ["tabList", { isSignal: true }]
		}],
		tabListInner: [{
			type: i0.ViewChild,
			args: ["tabListInner", { isSignal: true }]
		}],
		nextPaginator: [{
			type: i0.ViewChild,
			args: ["nextPaginator", { isSignal: true }]
		}],
		previousPaginator: [{
			type: i0.ViewChild,
			args: ["previousPaginator", { isSignal: true }]
		}],
		tabListClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tabListClass",
				required: false
			}]
		}],
		paginationButtonClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "paginationButtonClass",
				required: false
			}]
		}]
	}
});
var HlmTabsTrigger = class HlmTabsTrigger {
	triggerFor = input.required({
		...ngDevMode ? { debugName: "triggerFor" } : /* istanbul ignore next */ {},
		alias: "hlmTabsTrigger"
	});
	constructor() {
		classes(() => [
			`gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0`,
			"group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
			"data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground",
			"after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100"
		]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsTrigger,
		isStandalone: true,
		selector: "[hlmTabsTrigger]",
		inputs: { triggerFor: {
			classPropertyName: "triggerFor",
			publicName: "hlmTabsTrigger",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs-trigger" } },
		exportAs: ["hlmTabsTrigger"],
		hostDirectives: [{
			directive: i1.BrnTabsTrigger,
			inputs: [
				"brnTabsTrigger",
				"hlmTabsTrigger",
				"disabled",
				"disabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsTrigger]",
			exportAs: "hlmTabsTrigger",
			hostDirectives: [{
				directive: BrnTabsTrigger,
				inputs: ["brnTabsTrigger: hlmTabsTrigger", "disabled"]
			}],
			host: { "data-slot": "tabs-trigger" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { triggerFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hlmTabsTrigger",
			required: true
		}]
	}] }
});
export { KIOSK_POINTER_IDLE_MS, KioskService, NEAT_DANGER_BASE, NEAT_HIGHLIGHT_BASE, NEAT_ICON_NAMES, NEAT_NEAR_BLACK, NEAT_PRIMARY_BASE, NEAT_SERIES_TEAL_BASE, NEAT_WARN_BASE, NeatAsideActions, NeatAsideHeading, NeatAsidePanel, NeatAsideTitle, NeatAsideToggle, NeatButton, NeatCode, NeatIcon, NeatInlineButton, NeatLiveDot, NeatNote, NeatPage, NeatPageTab, NeatPageTabs, NeatPageToolbar, NeatRailDivider, NeatRailItem, NeatShell, NeatTooltip, NeatViewport, SIMA_PALETTE, ThemeService, buildColorScale, buildNeutralSurfaceScale, buildSurfaceScale, contrastRatio, neatAsideOpen, neatSecondsAgo, provideNeatUi, FIELD_LABEL_CLASSES as ɵFIELD_LABEL_CLASSES, IN_PAGE_TOOLBAR as ɵIN_PAGE_TOOLBAR, hlm as ɵhlm, listVariants as ɵlistVariants };

//# sourceMappingURL=sima-neat-ui.mjs.map