import * as i0 from "@angular/core";
import { Directive, computed, input } from "@angular/core";
import * as i1 from "@spartan-ng/brain/input";
import { BrnInput } from "@spartan-ng/brain/input";
import { ɵhlm } from "@sima/neat-ui";
const INPUT_HELM_CLASSES = "dark:bg-input/30 border-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 h-9 rounded-md border bg-transparent px-2.5 py-1 text-base shadow-xs transition-[color,box-shadow] file:h-7 file:text-sm file:font-medium focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 md:text-sm file:text-foreground placeholder:text-muted-foreground w-full min-w-0 outline-none file:inline-flex file:border-0 file:bg-transparent disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50";
const OVERRIDES = "focus-visible:ring-ring dark:bg-transparent";
const SIZES = {
	small: "h-8",
	medium: ""
};
var NeatInput = class NeatInput {
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	classes = computed(() => ɵhlm(INPUT_HELM_CLASSES, OVERRIDES, SIZES[this.size()]), ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatInput,
		isStandalone: true,
		selector: "input[neatInput]",
		inputs: { size: {
			classPropertyName: "size",
			publicName: "size",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "input" },
			properties: { "class": "classes()" }
		},
		hostDirectives: [{
			directive: i1.BrnInput,
			inputs: ["id", "id"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatInput,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[neatInput]",
			hostDirectives: [{
				directive: BrnInput,
				inputs: ["id"]
			}],
			host: {
				"data-slot": "input",
				"[class]": "classes()"
			}
		}]
	}],
	propDecorators: { size: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "size",
			required: false
		}]
	}] }
});
export { NeatInput };

//# sourceMappingURL=sima-neat-ui-input.mjs.map