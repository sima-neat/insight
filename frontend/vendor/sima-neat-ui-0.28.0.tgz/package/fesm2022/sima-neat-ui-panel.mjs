import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, input } from "@angular/core";
let nextPanelId = 0;
var NeatPanel = class NeatPanel {
	heading = input.required(...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	headingId = `neat-panel-${++nextPanelId}-heading`;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatPanel,
		isStandalone: true,
		selector: "neat-panel",
		inputs: { heading: {
			classPropertyName: "heading",
			publicName: "heading",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "role": "region" },
			properties: { "attr.aria-labelledby": "headingId" }
		},
		ngImport: i0,
		template: `
    <div class="header" data-slot="panel-header">
      <h2 class="heading" data-slot="panel-heading" [id]="headingId">{{ heading() }}</h2>
      <div class="actions" data-slot="panel-actions">
        <ng-content select="[neatPanelActions]" />
      </div>
    </div>
    <div data-slot="panel-body"><ng-content /></div>
  `,
		isInline: true,
		styles: [":host{--neat-surface: var(--card);display:block;min-width:0;background:var(--card);color:var(--card-foreground);border:1px solid var(--border);border-radius:var(--radius);padding:var(--neat-space-3)}.header{display:flex;align-items:center;justify-content:space-between;gap:var(--neat-space-2);min-height:2rem;margin-block-end:var(--neat-space-2)}.heading{margin:0;font-size:var(--neat-text-sm);font-weight:500;color:var(--muted-foreground)}.actions{display:flex;align-items:center;gap:var(--neat-space-2)}.actions:empty{display:none}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				role: "region",
				"[attr.aria-labelledby]": "headingId"
			},
			template: `
    <div class="header" data-slot="panel-header">
      <h2 class="heading" data-slot="panel-heading" [id]="headingId">{{ heading() }}</h2>
      <div class="actions" data-slot="panel-actions">
        <ng-content select="[neatPanelActions]" />
      </div>
    </div>
    <div data-slot="panel-body"><ng-content /></div>
  `,
			styles: [":host{--neat-surface: var(--card);display:block;min-width:0;background:var(--card);color:var(--card-foreground);border:1px solid var(--border);border-radius:var(--radius);padding:var(--neat-space-3)}.header{display:flex;align-items:center;justify-content:space-between;gap:var(--neat-space-2);min-height:2rem;margin-block-end:var(--neat-space-2)}.heading{margin:0;font-size:var(--neat-text-sm);font-weight:500;color:var(--muted-foreground)}.actions{display:flex;align-items:center;gap:var(--neat-space-2)}.actions:empty{display:none}\n"]
		}]
	}],
	propDecorators: { heading: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "heading",
			required: true
		}]
	}] }
});
export { NeatPanel };

//# sourceMappingURL=sima-neat-ui-panel.mjs.map