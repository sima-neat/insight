import * as i0 from "@angular/core";
/**
 * A titled panel in the kit's card look:
 *
 * ```html
 * <neat-panel heading="Detections">
 *   <button neatButton neatPanelActions type="button" size="small">Clear</button>
 *   <p>Nothing yet.</p>
 * </neat-panel>
 * ```
 *
 * The heading stands at the start of the header, small and muted; elements with the attribute
 * `neatPanelActions` go to the header's end, and everything else is the body. The attribute is a
 * selector of the panel, not a directive, so it needs no import and cannot be forgotten into
 * silence. The actions area is always in the template and hidden while empty, so a panel without
 * actions shows no area and its header keeps no gap for one. The header is as tall with actions as
 * without, so panels side by side keep their bodies in line.
 *
 * The host is a named region (`role="region"`, labelled by the heading), the landmark a `section`
 * with a name maps to; a custom element is not a `section` of its own. The heading is an `h2`:
 * the panels are a page's sections.
 */
export declare class NeatPanel {
  /** The panel's title, which also names it as a region. */
  readonly heading: import("@angular/core").InputSignal<string>;
  protected readonly headingId: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPanel, "neat-panel", never, {
    "heading": {
      "alias": "heading";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["[neatPanelActions]", "*"], true, never>;
}