import { NeatColumn } from "@sima/neat-ui/select-list";
import * as i0 from "@angular/core";
/** One entry of the tree a `neat-file-browser` shows: a folder with its children, or a file. */
interface NeatFileNode {
  /** What the row shows. */
  readonly name: string;
  /** Unique in the tree: relative, with `/` between segments, so a folder's path leads to it. */
  readonly path: string;
  readonly type: 'folder' | 'file';
  /** A folder's entries. */
  readonly children?: readonly NeatFileNode[];
  /**
   * Greys the row without hiding it: a file the app cannot use for its main purpose (one the
   * streamer does not accept), shown so the user knows it is there. It does not stop the row from
   * being selected, opened or checked, so it is not `disabled`; an unavailable file does not count
   * towards a folder's count. An app that must not offer a file leaves it out of the tree.
   */
  readonly unavailable?: boolean;
  /** A short text after the name, such as the reason the row is greyed. */
  readonly tag?: string;
}
/** A folder of a listing, with the number of available files in it and below. */
interface FolderEntry {
  readonly node: NeatFileNode;
  readonly name: string;
  readonly path: string;
  readonly count: number;
}
/** A file that matched a search: `relative` is its path below the folder searched. */
interface FileMatch {
  readonly node: NeatFileNode;
  readonly relative: string;
}
declare const ROOT = "";
/** The children of `folderPath`, or null when that folder is not in `tree`. */
declare function childrenAt(tree: readonly NeatFileNode[] | undefined, folderPath: string): readonly NeatFileNode[] | null;
declare function folderExists(tree: readonly NeatFileNode[], folderPath: string): boolean;
/** Folders first, then files, each by name; an unknown folder lists as empty. */
declare function listFolder(tree: readonly NeatFileNode[], folderPath: string): {
  folders: FolderEntry[];
  files: NeatFileNode[];
};
/** Available files in `folderPath` and all its subfolders: what a folder's badge shows for it. */
declare function playableCount(tree: readonly NeatFileNode[], folderPath: string): number;
declare function parentPath(folderPath: string): string;
/** `[{ name: rootLabel, path: '' }, { name: '30FPS', path: '30FPS' }, ...]` */
declare function breadcrumbs(folderPath: string, rootLabel: string): {
  name: string;
  path: string;
}[];
/**
 * Every file anywhere below `folderPath`, available or not, whose path relative to that folder
 * contains `query` without regard to case, sorted by relative path (the tree's own order, which
 * the listing sorts too, would put a subfolder's files among the folder's). `relative` is what the
 * list shows; the node's `path` is the one to act on.
 */
declare function searchFolder(tree: readonly NeatFileNode[], folderPath: string, query: string): FileMatch[];
/** The folder itself when it still exists after a reload, otherwise its nearest existing ancestor. */
declare function nearestExistingFolder(tree: readonly NeatFileNode[], folderPath: string): string;
/**
 * The folder just below `ancestor` on the way to `descendant`, or null when `descendant` is not
 * below `ancestor`: where the user came from when going up.
 */
declare function childTowards(descendant: string, ancestor: string): string | null;
/** Every available file's path in tree order. */
declare function availableFilePaths(tree: readonly NeatFileNode[] | undefined, acc?: string[]): string[];
/** Every file's path in tree order, available or not (a selection is pruned against this). */
declare function allFilePaths(tree: readonly NeatFileNode[] | undefined, acc?: string[]): string[];
/** `pick` chooses one file; `manage` also has a checkbox on each file, for acting on several. */
type NeatFileBrowserMode = 'pick' | 'manage';
/** The words the browser says itself; `labels` replaces any of them. */
interface NeatFileBrowserLabels {
  /** The breadcrumb's accessible name. */
  readonly breadcrumb: string;
  /** The list's accessible name. */
  readonly files: string;
  /** The heading of the name column; shown only when the app adds columns. */
  readonly name: string;
  /** The filter field's accessible name. */
  readonly filter: string;
  /** What a folder with nothing in it says. */
  readonly empty: string;
  /** What a filter with no match says. */
  readonly noMatches: string;
  /** Read before a folder's name, which an icon alone tells apart from a file. */
  readonly folder: string;
  /** What a folder's count means, read after the folder's name and shown as its tooltip. */
  readonly folderCount: (folder: string, count: number) => string;
  /** The count while a filter is active: its matches, below the named folder. */
  readonly matches: (folder: string, count: number) => string;
}
/** A row of the list: a folder, or a file with its path as listed (relative while filtering). */
interface BrowserRow {
  readonly node: NeatFileNode;
  readonly label: string;
  /** A folder's available files, in it and below; null for a file. */
  readonly count: number | null;
  /** What a folder's count means, in words. */
  readonly countLabel: string;
  /** What the app's column templates get for a file. */
  readonly context: {
    readonly $implicit: NeatFileNode;
  };
}
/**
 * A browser for a tree of folders and files:
 *
 * ```html
 * <neat-file-browser rootLabel="Media Root" [root]="tree()" [(folder)]="folder"
 *   [(selected)]="file" mode="manage" [(checked)]="checkedFiles" filterPlaceholder="Filter files…">
 *   <ng-template neatColumn="size" header="Size" width="6rem" let-file>…</ng-template>
 * </neat-file-browser>
 * ```
 *
 * It shows the breadcrumb of the current `folder` (a path; '' is the root, named `rootLabel`), a
 * count, a filter field and the folder's rows in a `neat-select-list`: folders first, then files,
 * each by name ignoring case. A folder row shows the number of available files in it and below.
 *
 * - **Filter.** Typing lists every file below the current folder whose path, relative to it,
 *   contains the text, ignoring case; the rows show those relative paths, and the count says how
 *   many matched. Navigating, by any means, empties the filter. `filter` is a model, so the app can
 *   read it (a note under the list about what the folder leaves out should show only while it is
 *   empty) and set it.
 * - **Navigating.** A click, or Enter on the row the keyboard is on, opens a folder; a click on a
 *   breadcrumb, or Backspace in the list, goes up. When the folder is gone from `root` (after a
 *   reload), `folder` becomes its nearest ancestor that exists. The list takes the focus after any
 *   navigation, and going up highlights the folder just left; every listing starts at the top.
 *   Pass `root` once it is loaded: an empty tree has no folders, so the browser goes back to the
 *   root.
 * - **Selecting.** `selected` is a file's path. Moving the list's selection with the arrow keys
 *   onto a file selects it, as a click does; onto a folder leaves `selected` as it is (the
 *   preview of a file stays while the keyboard passes folders) and highlights the folder. A
 *   selected file in another folder stays selected. The list's keys are `neat-select-list`'s.
 * - **`manage` mode** is the list's checked mode: a box on each file (not on folders), for the
 *   paths in `checked`, which hold files of other folders too. A click on the box toggles it and
 *   nothing else. From the keyboard, Space toggles the file the list is on; the boxes are not tab
 *   stops, so the arrow keys keep moving the selection. The listbox is multi-selectable and a file
 *   `aria-selected` while checked, which says what checking is; the browser adds no hint of its
 *   own. Paths that are no longer in `root` leave `checked`; `selected` is not pruned, since an
 *   app may select a file before the tree that holds it has loaded.
 * - **Unavailable and tagged nodes**: an `unavailable` node is greyed, and a `tag` shows after
 *   the name as a neutral `neat-status-chip`; such nodes can still be selected, opened and
 *   checked.
 * - **Columns.** `neatColumn` templates (from `@sima/neat-ui/select-list`) add columns after the
 *   name, filled for files only; the template gets the `NeatFileNode`, and `align` and
 *   `hideBelow` work as on the list. Setting any adds a header row, the name's heading being
 *   `labels.name`, and moves a folder's count from the end of the name cell to just after the
 *   name, so that it reads as the folder's rather than as a value in the next column.
 *
 * Everything the browser says is a default in `labels` (a partial, merged over them) except
 * `rootLabel`, which is required, and `filterPlaceholder`. `countLabel` words the count under the
 * breadcrumb from the name of the current folder (`rootLabel` at the root) and the number of
 * available files in it and below.
 *
 * It fills its container, whose height it needs, and scrolls its rows inside. A folder of a
 * thousand files is one pass over the folder's nodes when the folder, filter or tree changes; a
 * selection or a check changes only the rows concerned.
 */
export declare class NeatFileBrowser {
  /** The tree. Pass it once loaded. */
  readonly root: import("@angular/core").InputSignal<readonly NeatFileNode[]>;
  /** The name of the root folder, at the start of the breadcrumb. */
  readonly rootLabel: import("@angular/core").InputSignal<string>;
  /** The current folder's path; '' is the root. */
  readonly folder: import("@angular/core").ModelSignal<string>;
  /** The selected file's path. */
  readonly selected: import("@angular/core").ModelSignal<string | null>;
  readonly mode: import("@angular/core").InputSignal<NeatFileBrowserMode>;
  /** The checked files' paths, in `manage` mode. */
  readonly checked: import("@angular/core").ModelSignal<readonly string[]>;
  readonly filterPlaceholder: import("@angular/core").InputSignal<string>;
  /** Words the count under the breadcrumb: the current folder's name, and its available files. */
  readonly countLabel: import("@angular/core").InputSignal<(folder: string, count: number) => string>;
  readonly labels: import("@angular/core").InputSignal<Partial<NeatFileBrowserLabels>>;
  /**
   * The filter field's text. Two-way, so an app can tell whether a filter is active (a note about
   * the current folder, such as how many files it left out, belongs to the unfiltered listing) or
   * clear it. It is emptied whenever the folder changes; matching ignores surrounding spaces.
   */
  readonly filter: import("@angular/core").ModelSignal<string>;
  protected readonly rowPath: (row: BrowserRow) => string;
  protected readonly isFile: (row: BrowserRow) => boolean;
  protected readonly text: import("@angular/core").Signal<NeatFileBrowserLabels>;
  /** The folder shown: `folder`, or its nearest ancestor that exists. */
  private readonly current;
  protected readonly crumbs: import("@angular/core").Signal<{
    name: string;
    path: string;
  }[]>;
  protected readonly crumbItems: import("@angular/core").Signal<{
    label: string;
  }[]>;
  private readonly folderName;
  protected readonly query: import("@angular/core").Signal<string>;
  protected readonly columns: import("@angular/core").Signal<readonly NeatColumn[]>;
  private readonly list;
  private readonly matches;
  /**
   * The list's rows, worked out when the folder, filter or tree changes: the sort, the folders'
   * counts, the label texts. Nothing in the template computes per row.
   */
  protected readonly rows: import("@angular/core").Signal<readonly BrowserRow[]>;
  protected readonly countText: import("@angular/core").Signal<string>;
  /**
   * The folder the list's selection is on, if it is on one. Folders are not `selected` (that is a
   * file's path), so the list's highlight moves to the folder and `selected` stays. It is
   * forgotten when the folder or filter changes and when `selected` does.
   */
  private readonly cursorFolder;
  /** The row the list highlights: the folder under the keyboard, else the selected file. */
  protected readonly highlighted: import("@angular/core").Signal<BrowserRow | null>;
  constructor();
  protected onFilter(event: Event): void;
  /**
   * Opens a folder. The list takes the focus: a pressed breadcrumb is gone from the page once its
   * folder is the current one (the last crumb is text), and the focus must not fall to the body.
   * Going up lands the highlight on the folder just left, as file managers do.
   */
  protected navigate(path: string): void;
  /** The list's selection moved, by key or click: a file is selected, a folder is highlighted. */
  protected moveCursor(row: BrowserRow | null): void;
  /** Enter, or a click, on a row: a folder opens. */
  protected open(row: BrowserRow): void;
  /**
   * The key that is the browser's rather than the list's, pressed on the list itself (not on the
   * filter field or a control in a cell): Backspace goes up a folder.
   */
  protected onKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatFileBrowser, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatFileBrowser, "neat-file-browser", never, {
    "root": {
      "alias": "root";
      "required": true;
      "isSignal": true;
    };
    "rootLabel": {
      "alias": "rootLabel";
      "required": true;
      "isSignal": true;
    };
    "folder": {
      "alias": "folder";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "filterPlaceholder": {
      "alias": "filterPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "countLabel": {
      "alias": "countLabel";
      "required": false;
      "isSignal": true;
    };
    "labels": {
      "alias": "labels";
      "required": false;
      "isSignal": true;
    };
    "filter": {
      "alias": "filter";
      "required": false;
      "isSignal": true;
    };
  }, {
    "folder": "folderChange";
    "selected": "selectedChange";
    "checked": "checkedChange";
    "filter": "filterChange";
  }, ["columns"], never, true, never>;
}
export type { NeatFileBrowserLabels, NeatFileBrowserMode, NeatFileNode };