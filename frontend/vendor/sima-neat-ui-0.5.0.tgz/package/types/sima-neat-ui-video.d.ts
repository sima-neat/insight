import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
/**
 * One metadata message from the stream's data channel. `_insight.rtp_timestamp` identifies the
 * video frame the message describes; messages without it can only be matched by arrival order.
 */
interface NeatMetadataMessage {
  type: string;
  timestamp?: number;
  frame_id?: unknown;
  data?: unknown;
  _insight?: {
    rtp_timestamp?: number;
  };
}
/**
 * Parses a data-channel text message. Returns null for anything that is not a JSON object with a
 * string `type`, so a caller can drop it without reasoning about the payload. Everything else,
 * `data` and `_insight` included, is kept exactly as received.
 */
declare function parseMetadataMessage(text: string): NeatMetadataMessage | null;
/** A message with the time it arrived, as the queue stores and returns it. */
interface NeatMetadataItem {
  receivedAt: number;
  data: NeatMetadataMessage;
}
/** An item as returned for drawing; `held` marks one redrawn from an earlier frame. */
type NeatDrawableMetadataItem = NeatMetadataItem & {
  held?: true;
};
/** The last item of each metadata type, kept by `holdOverlays` between frames. */
type NeatHeldOverlays = Map<string, {
  item: NeatMetadataItem;
  matchedAt: number;
}>;
/** Cumulative counters; they survive `resetLatenessWindow`. */
interface NeatMetadataQueueStats {
  timestampMatches: number;
  arrivalFallbacks: number;
  frameMisses: number;
  expired: number;
  evicted: number;
  untimestampedReceived: number;
  late: number;
}
interface NeatMetadataSnapshot extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  /** Null until the window holds enough messages for a share to mean anything. */
  recentLateShare: number | null;
  /** Null while the window holds no late message whose frame is still remembered. */
  recentLatenessMedianMs: number | null;
  recentLatenessP90Ms: number | null;
  recentLatenessMaxMs: number | null;
}
/**
 * The per-stream queue. Create it with `createMetadataQueue` and pass it to this module's
 * functions; `metadataQueueSnapshot` reports what it holds. Its contents are not accessible.
 */
interface NeatMetadataQueue {
  readonly __neatMetadataQueue: never;
}
declare function createMetadataQueue(): NeatMetadataQueue;
declare function enqueueMetadata(handle: NeatMetadataQueue, message: NeatMetadataMessage, receivedAt: number): void;
/**
 * The metadata to draw on a frame the browser is presenting. `rtpTimestamp` is the frame's RTP
 * timestamp, or null when the browser does not report one. A retention of 0 never expires.
 */
declare function takeMetadataForFrame(handle: NeatMetadataQueue, rtpTimestamp: number | null, metadataRetentionMs: number, now: number): NeatMetadataItem[];
declare const OVERLAY_HOLD_MS = 200;
declare function holdOverlays(held: NeatHeldOverlays, overlays: NeatMetadataItem[], now: number): NeatDrawableMetadataItem[];
declare function metadataQueueSnapshot(handle: NeatMetadataQueue): NeatMetadataSnapshot;
declare function resetLatenessWindow(handle: NeatMetadataQueue): void;
/** The part of a queue snapshot that the late notice reads. */
type NeatLatenessSnapshot = Pick<NeatMetadataSnapshot, 'recentLateShare' | 'recentLatenessMedianMs' | 'recentLatenessP90Ms'>;
/**
 * Why no buffer is suggested: the browser cannot set one, the window has no lateness sample, or
 * the suggestion would pass the maximum.
 */
type NeatLateNoticeBlocker = 'unsupported' | 'unmeasured' | 'maximum';
/**
 * The notice's second button: `raise` lifts the value the channels follow to the suggestion;
 * `follow` only lets this channel adopt the followed value, which already covers it.
 */
interface NeatGlobalBufferAction {
  kind: 'raise' | 'follow';
  valueMs: number;
}
interface NeatLateNoticeDetails {
  latenessMs: number | null;
  latePercent: number | null;
  bufferMs: number;
  suggestedBufferMs: number | null;
  blockedBy: NeatLateNoticeBlocker | null;
  globalAction: NeatGlobalBufferAction | null;
}
export declare function nextWarningActive(active: boolean, recentLateShare: number | null): boolean;
declare function suggestedBufferMs(currentBufferMs: number, p90LatenessMs: number | null): number | null;
export declare function bufferSettleMs(previousBufferMs: number, nextBufferMs: number): number;
export declare function lateNoticeDetails(snapshot: NeatLatenessSnapshot, currentBufferMs: number, bufferSupported: boolean, followedBufferMs?: number | null): NeatLateNoticeDetails;
/**
 * Identity colours, handed out by the overlay colour allocator in slot order. The first 20 are
 * hand-picked to stay apart on dark and bright video; the last 20 are overflow. Keep 40 entries;
 * overlay-palette.spec.ts checks their separation. Five per row keeps the slot numbers countable.
 */
declare const OVERLAY_PALETTE: readonly string[];
/** The colour of an overlay with no identity: a track or pose without an id, a label-less class. */
declare const OVERLAY_NEUTRAL_COLOR = "#f8fafc";
/** The dark plate behind track and pose labels, so the label reads in its identity colour. */
declare const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
/** ROI polygons: a faint fill so the video stays visible, and a full-strength outline. */
declare const OVERLAY_ROI_COLORS: {
  readonly inclusion: {
    readonly fill: "rgba(0,255,0,0.1)";
    readonly stroke: "green";
  };
  readonly exclusion: {
    readonly fill: "rgba(255,0,0,0.1)";
    readonly stroke: "red";
  };
};
/** The colour a class style row resolves to when its stored colour is missing or not a string. */
export declare const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
/** How a class's boxes and outlines are stroked. */
type NeatOverlayLineStyle = 'solid' | 'dashed' | 'dotted';
/**
 * A class style row: overlays whose label equals `label` draw in `color` with this line. The row
 * labelled `default` applies to every label without a row of its own.
 */
interface NeatOverlayClassStyle {
  readonly label: string;
  readonly color: string;
  readonly style: NeatOverlayLineStyle;
  /** Line width in CSS pixels: thin (1) or thick (3). It overrides `general.lineWidth`. */
  readonly width: 1 | 3;
}
/**
 * A region of interest. Coordinates are normalized to 0..1 of the video frame, so a polygon fits
 * any resolution the stream is sent at.
 */
interface NeatRoiPolygon {
  readonly type: 'inclusion' | 'exclusion';
  readonly points: readonly {
    readonly x: number;
    readonly y: number;
  }[];
}
/**
 * The resolved overlay settings for one channel. The app resolves them once per change (defaults,
 * global values, the channel's own values); drawing reads them every frame and never parses or
 * validates them.
 */
interface NeatOverlaySettings {
  readonly general: {
    /** Line width in CSS pixels for every overlay line a class row does not override. */
    readonly lineWidth: number;
    /** Draw the ROI polygons under the detection, segmentation and tracking overlays. */
    readonly showRoi: boolean;
    /** Hide detections, segments and tracks whose box centre falls outside the ROI. */
    readonly applyRoiFiltering: boolean;
  };
  readonly types: {
    readonly 'object-detection': {
      readonly visible: boolean;
      /** 0..1; an object without a confidence always passes. */
      readonly confidenceThreshold: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly segmentation: {
      readonly visible: boolean;
      /** 0..1; a segment without a confidence counts as fully confident. */
      readonly confidenceThreshold: number;
      /** 0..1, the alpha of mask fills. */
      readonly maskOpacity: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly tracking: {
      readonly visible: boolean;
      readonly confidenceThreshold: number;
      readonly history: {
        /** Draw each track's recent centre positions as a trail. */
        readonly enabled: boolean;
        /** Positions kept per track. */
        readonly trailLength: number;
        /** How long the trail of a track that left the frame stays, in milliseconds. */
        readonly lostTrackTtlMs: number;
      };
    };
    readonly 'pose-estimation': {
      readonly visible: boolean;
      /** Dots on the joints. */
      readonly showKeypoints: boolean;
      /** Joint names next to the dots. */
      readonly showKeypointLabels: boolean;
    };
    readonly classification: {
      readonly visible: boolean;
    };
  };
  readonly roi: readonly NeatRoiPolygon[];
}
/** The settings a channel draws with when nothing is stored. */
export declare const NEAT_OVERLAY_DEFAULTS: NeatOverlaySettings;
interface NeatTileArea {
  readonly width: number;
  readonly height: number;
}
interface NeatTilePack {
  readonly columns: number;
  readonly rows: number;
  /** How many tiles fit at once: `columns * rows`. */
  readonly perPage: number;
  /** The tile size actually used; below the requested width only when one tile did not fit. */
  readonly tileWidth: number;
  readonly tileHeight: number;
}
/**
 * The narrowest tile the kit lays out, in CSS pixels. Below this a tile is a postage stamp, so with
 * very many items in a small area the page pages instead of shrinking tiles further. Only an area
 * smaller than this makes a tile narrower (it then shrinks to the area).
 */
export declare const NEAT_MIN_TILE_WIDTH = 64;
/**
 * How many tiles of `tileWidth` fit into `area` with `gap` between them (and none around the
 * outside), in columns and rows. The gap counts only between tiles, which is why the area is
 * widened by one gap before dividing: `n` tiles take `n * tile + (n - 1) * gap`.
 *
 * `tileWidth` is raised to `NEAT_MIN_TILE_WIDTH` (a NaN, zero or negative one too). If even one
 * tile does not fit, it shrinks to the area while keeping 16:9, to whole CSS pixels so it
 * never rounds past the edge; that rule wins over the minimum. A tile is at least 1 px, so an
 * empty area (before the first measurement) still yields one tile.
 */
declare function packTiles(area: NeatTileArea, tileWidth: number, gap: number): NeatTilePack;
/**
 * The widest tile, in whole CSS pixels, at which `count` tiles fit into `area` on one page. For
 * each column count from 1 to `count` the rows follow (`ceil(count / columns)`), and the tile is
 * bounded by both the width and the height of the area; the column count with the widest tile
 * wins. Whole pixels, rounded down, so a floating-point edge can never make `packTiles` drop a
 * row that this function counted on.
 *
 * Never below `NEAT_MIN_TILE_WIDTH`: when `count` tiles would need narrower ones, the result is
 * the minimum and the caller pages. A count that is not a finite number of at least 1 is one tile;
 * a fractional count is rounded down.
 */
export declare function fitAllTileWidth(area: NeatTileArea, count: number, gap: number): number;
/**
 * What the grid reports: the packing, the gap it used between tiles and the content box it was
 * packed into. A page that sizes tiles itself (to fit a count, say) needs the gap the grid used,
 * which may be the kit's token rather than a number the page chose.
 */
interface NeatTileLayout extends NeatTilePack {
  /** Space between tiles in CSS pixels. */
  readonly gap: number;
  readonly areaWidth: number;
  readonly areaHeight: number;
}
/**
 * Lays its items out as 16:9 tiles of a fixed width in a centred grid, as many as fit into its own box
 * without scrolling or overflowing. The tile width comes from the page (a slider, say); the grid
 * works out the columns, rows and tiles per page and reports them through `layout`, so the page
 * can slice its items to `perPage`. The grid never pages itself.
 *
 * It fills its parent and measures its own box, never the shell's, so it repacks when the parent
 * changes size for any reason. `layout` is emitted when a value of it changes, not on every
 * resize notification.
 *
 * `count` is the number of projected items. When fewer than a row's worth are shown, they form a
 * centred block of their own width instead of hugging the left edge of a full-width row.
 *
 * The gap defaults to the kit's `--neat-space-2` token, read once when the grid initialises; an
 * explicit `gap` (in CSS pixels) overrides it.
 */
export declare class NeatTileGrid {
  /** Tile width in CSS pixels; a tile wider than the area shrinks to it. */
  readonly tileWidth: import("@angular/core").InputSignal<number>;
  /** Space between tiles in CSS pixels; the kit's `--neat-space-2` when unset. */
  readonly gap: import("@angular/core").InputSignal<number | undefined>;
  /** The number of projected items. */
  readonly count: import("@angular/core").InputSignal<number>;
  readonly layout: import("@angular/core").OutputEmitterRef<NeatTileLayout>;
  private readonly gridElement;
  private readonly area;
  /** The token's gap, known once the grid has rendered and its stylesheet can be read. */
  private readonly tokenGap;
  /**
   * The gap in use. It waits for the token to be read even when `gap` is set, so the read never
   * sees a gap this component applied itself.
   */
  protected readonly gapPx: import("@angular/core").Signal<number | null>;
  private readonly packed;
  /** What the template draws: the packed tiles, in as many columns as there are items to show. */
  protected readonly view: import("@angular/core").Signal<{
    columns: number;
    gap: number;
    areaWidth: number;
    areaHeight: number;
    rows: number;
    perPage: number;
    tileWidth: number;
    tileHeight: number;
  } | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTileGrid, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTileGrid, "neat-tile-grid", never, {
    "tileWidth": {
      "alias": "tileWidth";
      "required": true;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": true;
      "isSignal": true;
    };
  }, {
    "layout": "layout";
  }, never, ["*"], true, never>;
}
/**
 * Where a `neat-video-tile` gets its video and metadata. The tile knows nothing about how they
 * arrive (WebRTC, a file, a canvas); the app implements this for its transport.
 */
interface NeatTileSource {
  /** The channel's video, or null while connecting or when it has none. */
  readonly stream: Signal<MediaStream | null>;
  /**
   * Registers a listener for raw metadata text; returns the unsubscribe function. `receivedAt` is
   * on the `performance.now()` clock, the one presented frames are timed with.
   */
  onMetadata(listener: (text: string, receivedAt: number) => void): () => void;
}
/** A tile whose stream presents no frame for this long has stopped. */
declare const NEAT_STREAM_STALE_MS = 1800;
/**
 * `empty` until the stream presents its first frame, `playing` while frames arrive, `stopped`
 * once none has arrived for the stale timeout (about 1.8 s); it plays again when frames return.
 */
type NeatTileState = 'empty' | 'playing' | 'stopped';
/**
 * Where the shown image sits inside the tile, in CSS pixels from the tile's top-left corner: the
 * video without the bars `object-fit: contain` leaves around it.
 */
interface NeatVideoBox {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}
/**
 * The tile's frame-sync counters and video state, as the app reports them (the `synchronization`
 * and `video` groups of vf's browser egress report). Counters are cumulative for the current
 * stream. Every count and pixel size is a whole number: vf parses them as integers and drops a
 * report with a fraction in one.
 */
interface NeatFrameStats extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  recentLatenessMedianMs: number | null;
  recentLatenessMaxMs: number | null;
  /** Valid metadata messages received in the last second. */
  metadataMessagesPerSecond: number;
  /** The video element when the stats were taken. */
  video: {
    /** `HTMLMediaElement.readyState`, 0 to 4. */
    readyState: number;
    paused: boolean;
    /** Seconds, fractional. */
    currentTime: number;
    videoWidth: number;
    videoHeight: number;
    /** Whole milliseconds since the stream's last presented frame; null before its first. */
    lastFrameAgeMs: number | null;
    /** Whether the tile is `playing`. */
    active: boolean;
  };
}
/**
 * Plays a source's video with its metadata drawn as overlays, each frame with the metadata that
 * describes it. It fills the box it is given.
 *
 * The frame loop runs outside Angular and touches no signal: per frame it matches the queued
 * metadata to the presented frame, holds a type that is missing for a moment, and draws. The
 * component sees a state change and, at most once a second, `frameStats`. Inputs the loop needs
 * are copied into fields when they change, so a frame never reads an input or resolves settings.
 *
 * With `bars` on, a bar along the bottom shows `label`, `status` and the chips projected with
 * `neatTileChip`, and a tile without video says so. With `bars` off it is only video and overlay.
 *
 * Content projected with `neatTileOverlay` fills a layer over the tile, above the overlay canvas
 * and below the bar; `videoBox` says where the image is inside it. The layer takes pointer events
 * only where its content does.
 */
export declare class NeatVideoTile {
  readonly source: import("@angular/core").InputSignal<NeatTileSource | null>;
  /** The channel's resolved overlay settings; a new object for each change. */
  readonly settings: import("@angular/core").InputSignal<NeatOverlaySettings>;
  /** How long metadata waits for its frame, in milliseconds; 0 waits indefinitely. */
  readonly retentionMs: import("@angular/core").InputSignal<number>;
  /** The number overlay warnings name the tile by, such as the app's channel. */
  readonly channel: import("@angular/core").InputSignal<number>;
  /** The bar's left text, such as the channel number. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The bar's status text. */
  readonly status: import("@angular/core").InputSignal<string | null>;
  readonly bars: import("@angular/core").InputSignal<boolean>;
  readonly selected: import("@angular/core").InputSignal<boolean>;
  readonly stateChange: import("@angular/core").OutputEmitterRef<NeatTileState>;
  /** The frame-sync counters, once a second while there is a stream. */
  readonly frameStats: import("@angular/core").OutputEmitterRef<NeatFrameStats>;
  protected readonly state: import("@angular/core").WritableSignal<NeatTileState>;
  private readonly box;
  /**
   * Where the shown image sits in the tile. Non-null only while the tile is `playing` and the
   * video and the tile have a size: before the first frame the surface covers the video, and once
   * the stream is `stopped` the frozen frame is blurred and scaled up, so no box describes it.
   * Unlike the frame loop's fields it is a signal, for overlays that follow the image: it is
   * written only when the tile's state or the tile's or the video's size changes, never per frame,
   * and an unchanged box does not notify.
   */
  readonly videoBox: Signal<NeatVideoBox | null>;
  private readonly videoElement;
  private readonly canvasElement;
  private readonly colors;
  private readonly zone;
  private readonly document;
  private frameSettings;
  private frameRetentionMs;
  private overlayState;
  private currentState;
  private canvas;
  private context;
  /** The canvas's CSS size and pixel ratio; the video size is filled in per frame. */
  private readonly view;
  private playing;
  private queue;
  private readonly held;
  /** When the current stream last presented a frame; null until its first. */
  private lastFrameAt;
  private staleTimer;
  /** The last stale check found the tab hidden, so the frame time it would judge is from before. */
  private staleCheckSawHidden;
  private messagesThisSecond;
  private warnedUnreadable;
  private warnedPlayback;
  private destroyed;
  constructor();
  /** The metadata queue's counters and lateness window, for the app's lateness notice. */
  snapshot(): NeatMetadataSnapshot;
  /**
   * Forgets the lateness measured so far, as after the app changes the video sync buffer: what was
   * measured belongs to the old buffer. The cumulative counters stay.
   */
  resetLatenessWindow(): void;
  private play;
  /**
   * Muted autoplay is allowed everywhere, so a rejection is either an AbortError (a newer stream or
   * a pause interrupted it, which is expected) or a real refusal that would leave the tile empty for
   * good, such as NotAllowedError or NotSupportedError. Those are logged, once per tile.
   */
  private startPlayback;
  private stop;
  private receive;
  private present;
  /**
   * One timer at a time, re-armed for the remainder instead of on every frame, so a stream that
   * plays costs one timeout per stale period. A hidden tab presents no frames, so the check waits
   * there instead of stopping a stream that is still running. The first check after the tab
   * returns waits a full period too: the last frame time is from before the tab was hidden, and a
   * check right after the return, before the first new frame, would stop a live stream. A dead one
   * stops a period later.
   */
  private checkStale;
  /** Forgets what was drawn: the canvas, held overlays, track trails and track colours. */
  private clearOverlays;
  private setState;
  private reportFrameStats;
  /** Called when the tile or the video changes size or the tile's state changes, never per frame. */
  private updateVideoBox;
  private sizeCanvas;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatVideoTile, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatVideoTile, "neat-video-tile", never, {
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
    "retentionMs": {
      "alias": "retentionMs";
      "required": false;
      "isSignal": true;
    };
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "bars": {
      "alias": "bars";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
  }, {
    "stateChange": "stateChange";
    "frameStats": "frameStats";
  }, never, ["[neatTileOverlay]", "[neatTileChip]"], true, never>;
}
/** What a click does: nothing, or places points of an inclusion or an exclusion polygon. */
type NeatRoiDrawMode = 'off' | 'inclusion' | 'exclusion';
/**
 * Draws regions of interest on the image of the `neat-video-tile` it is placed in, and lets the
 * user add polygons by clicking points on it. Project it into the tile with `neatTileOverlay`:
 *
 * ```html
 * <neat-video-tile>
 *   <neat-roi-editor neatTileOverlay [regions]="regions" [mode]="mode" (regionsChange)="…" />
 * </neat-video-tile>
 * ```
 *
 * It sits on the tile's video box, so a point is a position on the image, not on the letterbox,
 * and it stays there when the tile resizes. Without a video box it draws nothing and takes no input.
 *
 * With a `mode` of `inclusion` or `exclusion`, each click adds a point. A click within 10 px of
 * the first point closes the polygon once it has three; so does a double-click. The second click
 * of a double-click (`detail` 2 or more) is ignored, so a double-click is its first click plus a
 * close. `regionsChange` emits when a polygon closes, with it appended to `regions`; the editor
 * never changes `regions` itself.
 * Escape cancels the open polygon, and so does a new `mode` or `regions` from outside, or the
 * image going away. Drawing is pointer-only: the polygon is open on the host, which takes focus
 * on the first point so Escape reaches it. An app offers the keyboard its own way to remove
 * regions.
 *
 * The open polygon lives in component signals: it changes per click, and the polyline follows the
 * pointer only while a polygon is open, so a pointer that moves over an idle editor costs no
 * change detection.
 */
export declare class NeatRoiEditor {
  /** The polygons to draw. Open polygons are not part of it until `regionsChange` brings them. */
  readonly regions: import("@angular/core").InputSignal<readonly NeatRoiPolygon[]>;
  /** What a click does; `off` leaves the tile to what is under the editor. */
  readonly mode: import("@angular/core").InputSignal<NeatRoiDrawMode>;
  /** The polygon a click just closed, appended to `regions` in a new array. */
  readonly regionsChange: import("@angular/core").OutputEmitterRef<readonly NeatRoiPolygon[]>;
  private readonly host;
  private readonly injector;
  protected readonly tileBox: import("@angular/core").Signal<NeatVideoBox | null>;
  /** Whether there is an image to draw on; the open polygon does not survive losing it. */
  private readonly hasBox;
  /**
   * The open polygon's points, normalized to the image. A box that only changes size leaves it
   * alone (that is why it is normalized); anything that changes what a click would mean, or what
   * the polygon is drawn among, starts over.
   */
  private readonly open;
  /** The last place the pointer was, normalized; the open polyline runs to it. */
  private readonly pointer;
  protected readonly drawing: import("@angular/core").Signal<boolean>;
  protected readonly placed: import("@angular/core").Signal<{
    points: string;
    fill: "rgba(0,255,0,0.1)" | "rgba(255,0,0,0.1)";
    stroke: "green" | "red";
  }[]>;
  protected readonly draft: import("@angular/core").Signal<{
    line: string;
    stroke: "green" | "red";
    startX: number;
    startY: number;
  } | null>;
  constructor();
  protected onClick(event: MouseEvent): void;
  protected onDoubleClick(event: MouseEvent): void;
  protected cancelOnEscape(event: Event): void;
  private close;
  /**
   * Where the pointer is on the image, 0..1 on each axis and clamped, with the box it was
   * measured against; null without a box to measure. The host fills the tile's overlay layer, so
   * its corner is the tile's.
   */
  private locate;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRoiEditor, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatRoiEditor, "neat-roi-editor", never, {
    "regions": {
      "alias": "regions";
      "required": true;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
  }, {
    "regionsChange": "regionsChange";
  }, never, never, true, never>;
}
export type { NeatFrameStats, NeatGlobalBufferAction, NeatLateNoticeBlocker, NeatLateNoticeDetails, NeatLatenessSnapshot, NeatMetadataMessage, NeatMetadataQueueStats, NeatMetadataSnapshot, NeatOverlayClassStyle, NeatOverlayLineStyle, NeatOverlaySettings, NeatRoiDrawMode, NeatRoiPolygon, NeatTileArea, NeatTileLayout, NeatTilePack, NeatTileSource, NeatTileState, NeatVideoBox };