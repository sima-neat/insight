import * as i0 from "@angular/core";
import { EnvironmentProviders, Signal } from "@angular/core";
import { LucideActivity, LucideBlocks, LucideCable, LucideCpu, LucideFileText, LucideFolderOpen, LucideInfo, LucideLayoutGrid, LucideMaximize, LucideMinimize, LucideMoon, LucidePalette, LucidePanelLeftClose, LucidePanelLeftOpen, LucideRadioTower, LucideShapes, LucideSun } from "@lucide/angular";
import { IsActiveMatchOptions } from "@angular/router";
import * as i1$1 from "@spartan-ng/brain/button";
import * as i1 from "@spartan-ng/brain/tooltip";
type ColorStep = 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950;
type ColorScale = Record<Exclude<ColorStep, 0>, string>;
type SurfaceScale = Record<ColorStep, string>;
/** Builds a 50-950 ramp in OKLCH around `base`, which becomes step 500 unchanged. */
export declare function buildColorScale(base: string): ColorScale;
/**
 * Builds the neutral surface ramp: white, the two palette backgrounds and the palette text as
 * anchors, with 200-900 interpolated in OKLab between the alternate background and the text.
 */
export declare function buildSurfaceScale(): SurfaceScale;
/**
 * Colour maths for the theme: hex <-> linear sRGB <-> OKLab/OKLCH, and WCAG 2.x contrast.
 * OKLab matrices from Björn Ottosson, "A perceptual color space for image processing" (2020).
 */
/** OKLCH: lightness 0..1, chroma >= 0, hue in degrees. */
interface Oklch {
  l: number;
  c: number;
  h: number;
}
/** Three channels: gamma-encoded or linear sRGB, or OKLab `[L, a, b]`. */
type Vec3 = readonly [number, number, number];
/** Validates `#RRGGBB` in either case and returns it in upper case. */
declare function normalizeHex(hex: string): string;
/** Converts `#RRGGBB` (either case) to OKLab `[L, a, b]`. */
declare function hexToOklab(hex: string): Vec3;
/** Converts OKLab `[L, a, b]` to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklabToHex(lab: Vec3): string;
/** Converts `#RRGGBB` (either case) to OKLCH. */
declare function hexToOklch(hex: string): Oklch;
/** Converts OKLCH to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklchToHex(color: Oklch): string;
/** Whether an OKLCH colour can be shown in sRGB without clamping. */
declare function isInSrgbGamut(color: Oklch): boolean;
/**
 * `foreground` at `alpha` (0 to 1) over an opaque `background`, blended per channel in
 * gamma-encoded sRGB as browsers composite a translucent fill such as Tailwind's `bg-x/10`.
 */
declare function composite(foreground: string, alpha: number, background: string): string;
/** WCAG 2.x relative luminance of `#RRGGBB`. */
declare function relativeLuminance(hex: string): number;
/** WCAG 2.x contrast ratio (1 to 21) between two `#RRGGBB` colours, in either order. */
export declare function contrastRatio(a: string, b: string): number;
/** The fixed SiMa.ai brand palette (identical to the Slides/PowerPoint theme). */
export declare const SIMA_PALETTE: {
  readonly text: "#010F0E";
  readonly background: "#F3F4F5";
  readonly backgroundAlt: "#E8E9EB";
  readonly white: "#FFFFFF";
  readonly orange: "#D26728";
  readonly purple: "#D1CEE6";
  readonly blue: "#5998DD";
  readonly mint: "#C0E8DB";
  readonly green: "#2A9C4F";
  readonly lime: "#A4CC2D";
};
/** Base of the primary scale. Swapping it (for example to the palette blue) re-derives the whole primary ramp. */
export declare const NEAT_PRIMARY_BASE: string;
/** Functional colours outside the palette, which has no red or amber but errors and warnings need them. */
export declare const NEAT_DANGER_BASE = "#C8372D";
export declare const NEAT_WARN_BASE = "#B7791F";
/**
 * The kit's start-up in one call: it applies the stored colour scheme before the first render.
 * The colours themselves come from the kit stylesheet (`@sima/neat-ui/styles/neat-ui.css`).
 */
export declare function provideNeatUi(): EnvironmentProviders;
type NeatColorScheme = 'light' | 'dark';
/** The dark theme's selector: tokens.generated.css and the `dark` variant in neat-ui.tailwind.css. */
declare const NEAT_DARK_CLASS = "neat-dark";
/**
 * Light/dark switch for the kit. Light is the default regardless of the OS preference (which is
 * deliberately never read); dark is opt-in and persisted.
 */
export declare class ThemeService {
  private readonly root;
  private readonly current;
  readonly scheme: Signal<NeatColorScheme>;
  constructor();
  setScheme(scheme: NeatColorScheme): void;
  toggle(): void;
  private apply;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * An icon from the kit's curated set. Decorative by default (hidden from assistive technology);
 * give it a `label` when it carries meaning on its own. It takes its colour from the surrounding
 * text.
 */
export declare class NeatIcon {
  readonly name: import("@angular/core").InputSignal<"media" | "streaming" | "viewer" | "peripherals" | "stats" | "board" | "info" | "sun" | "moon" | "kiosk-enter" | "kiosk-exit" | "rail-expand" | "rail-collapse" | "palette" | "shapes" | "blocks" | "document">;
  /** Edge length in pixels. */
  readonly size: import("@angular/core").InputSignal<number>;
  /** Accessible name; leave unset for a decorative icon. */
  readonly label: import("@angular/core").InputSignal<string | undefined>;
  protected readonly glyph: import("@angular/core").Signal<typeof import("@lucide/angular").LucideFolderOpen | typeof import("@lucide/angular").LucideRadioTower | typeof import("@lucide/angular").LucideLayoutGrid | typeof import("@lucide/angular").LucideCable | typeof import("@lucide/angular").LucideActivity | typeof import("@lucide/angular").LucideCpu | typeof import("@lucide/angular").LucideInfo | typeof import("@lucide/angular").LucideSun | typeof import("@lucide/angular").LucideMoon | typeof import("@lucide/angular").LucideMaximize | typeof import("@lucide/angular").LucideMinimize | typeof import("@lucide/angular").LucidePanelLeftOpen | typeof import("@lucide/angular").LucidePanelLeftClose | typeof import("@lucide/angular").LucidePalette | typeof import("@lucide/angular").LucideShapes | typeof import("@lucide/angular").LucideBlocks | typeof import("@lucide/angular").LucideFileText>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatIcon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatIcon, "neat-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The kit's icon vocabulary: names say what an icon means in the app, the value is the Lucide
 * glyph that draws it. This is the only file that references Lucide glyphs, so a glyph is swapped
 * in one place and only the glyphs listed here end up in an app's bundle.
 */
declare const NEAT_ICONS: {
  media: typeof LucideFolderOpen;
  streaming: typeof LucideRadioTower;
  viewer: typeof LucideLayoutGrid;
  peripherals: typeof LucideCable;
  stats: typeof LucideActivity;
  board: typeof LucideCpu;
  info: typeof LucideInfo;
  sun: typeof LucideSun;
  moon: typeof LucideMoon;
  'kiosk-enter': typeof LucideMaximize;
  'kiosk-exit': typeof LucideMinimize;
  'rail-expand': typeof LucidePanelLeftOpen;
  'rail-collapse': typeof LucidePanelLeftClose;
  palette: typeof LucidePalette;
  shapes: typeof LucideShapes;
  blocks: typeof LucideBlocks;
  document: typeof LucideFileText;
};
type NeatIconName = keyof typeof NEAT_ICONS;
/** Every name in the registry, in registry order, for galleries and pickers. */
export declare const NEAT_ICON_NAMES: readonly NeatIconName[];
/** One page in the shell's rail. */
interface NeatNavItem {
  /** Shown as the link's name, its tooltip and, while the page is active, the page title. */
  label: string;
  icon: NeatIconName;
  /** Absolute app path, for example `/media`; the item stays active on routes nested under it. */
  path: string;
}
/** How long the pointer must rest before `KioskService.pointerIdle` turns true. */
export declare const KIOSK_POINTER_IDLE_MS = 2500;
/**
 * Kiosk mode for expos: the shell hides its rail and top bar, and pages can hide their own chrome
 * while the pointer rests (`pointerIdle`). Kiosk keeps the current colour scheme and is not
 * persisted; it comes from the button or from a `?kiosk` URL parameter read once at start.
 *
 * `enter()` also asks for browser fullscreen. The URL parameter does not, because browsers refuse
 * fullscreen without a user gesture; booth machines use the browser's own kiosk flag instead.
 * If fullscreen was obtained by `enter()`, leaving it (Esc) leaves kiosk mode too.
 *
 * The document listeners are plain DOM listeners outside change detection; signals change only
 * when the state does, so pointer movement does not cause renders.
 */
export declare class KioskService {
  private readonly document;
  private readonly isActive;
  private readonly isPointerIdle;
  /** Whether the current fullscreen is the one `enter()` asked for. */
  private ownsFullscreen;
  private idleTimer;
  readonly active: Signal<boolean>;
  /** True once the pointer has rested for `KIOSK_POINTER_IDLE_MS`; false again on pointer or touch input. */
  readonly pointerIdle: Signal<boolean>;
  constructor();
  /** Turns kiosk on and asks for fullscreen; kiosk stays on if fullscreen is refused. */
  enter(): Promise<void>;
  /** Turns kiosk off, leaving fullscreen only if `enter()` obtained it. */
  exit(): Promise<void>;
  toggle(): Promise<void>;
  private onFullscreenChange;
  private onActivity;
  private restartIdleTimer;
  static ɵfac: i0.ɵɵFactoryDeclaration<KioskService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The app frame: an icon rail with the pages on the left (expandable to show labels), a top bar
 * with logo, app name, page title and app-specific items, and the content area for the routed
 * page. It fills the viewport; the content area gives its page the remaining space and never
 * scrolls itself, so pages own their scrolling (see `neat-page`).
 *
 * Content projection: the default slot is the content area (usually a `<router-outlet />`);
 * elements marked `neatTopbarEnd` go to the right side of the top bar.
 *
 * Kiosk mode (`KioskService`, entered from the top bar or with `?kiosk`) drops the rail and the
 * top bar, gives the content area the whole viewport and floats an exit control over its top
 * right corner while the pointer moves.
 */
export declare class NeatShell {
  readonly appName: import("@angular/core").InputSignal<string>;
  readonly navItems: import("@angular/core").InputSignal<NeatNavItem[]>;
  protected readonly theme: ThemeService;
  protected readonly kiosk: KioskService;
  private readonly router;
  protected readonly activeMatch: IsActiveMatchOptions;
  protected readonly railExpanded: import("@angular/core").WritableSignal<boolean>;
  private readonly kioskExit;
  /** Label of the nav item the current route belongs to; the first match wins. */
  protected readonly pageTitle: import("@angular/core").Signal<string>;
  constructor();
  protected toggleRail(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatShell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatShell, "neat-shell", never, {
    "appName": {
      "alias": "appName";
      "required": true;
      "isSignal": true;
    };
    "navItems": {
      "alias": "navItems";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["[neatTopbarEnd]", "*"], true, never>;
}
/**
 * A page in the shell's content area. It fills its parent and owns at most one scroll context:
 * with `scroll="body"` (the default) its body is the single scroll container; with
 * `scroll="none"` nothing scrolls and the content sizes itself to the page (for example a grid
 * that fits the screen).
 */
export declare class NeatPage {
  readonly scroll: import("@angular/core").InputSignal<"none" | "body">;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPage, "neat-page", never, {
    "scroll": {
      "alias": "scroll";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
type NeatButtonVariant = 'primary' | 'secondary' | 'outlined' | 'text' | 'danger';
/** `touch` is a 3rem (48px) target, above the 44px minimum, for kiosk and touch screens. */
type NeatButtonSize = 'small' | 'medium' | 'large' | 'touch';
/**
 * A button or link styled as a kit button. Content is the label and/or a `neat-icon`; an
 * icon-only button needs an `aria-label` (and usually a `neatTooltip` with the same text).
 *
 * Built from Spartan's brain primitive and helm's class map rather than on helm's directive:
 * every host directive of a public directive becomes public API, and helm stays internal.
 * The classes go through Angular's `[class]` binding, not helm's `classes()`, which rewrites
 * `className` and can drop a `[class.x]` binding that changes in the same render.
 */
export declare class NeatButton {
  readonly variant: import("@angular/core").InputSignal<NeatButtonVariant>;
  readonly size: import("@angular/core").InputSignal<NeatButtonSize>;
  /** Square (or, with `rounded`, circular) and sized for a single icon. */
  readonly iconOnly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Fully rounded ends: a pill, or a circle when `iconOnly`. */
  readonly rounded: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatButton, "button[neatButton], a[neatButton]", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "iconOnly": {
      "alias": "iconOnly";
      "required": false;
      "isSignal": true;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$1.BrnButton;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
type NeatTooltipPosition = 'top' | 'right' | 'bottom' | 'left';
/**
 * A short text label shown on mouse or pen hover and on keyboard focus, hidden on leave, blur and
 * Escape; the host carries `aria-describedby` while it is shown. It never opens on touch (a tap
 * would trigger the host's action too), so it must not carry anything the host's accessible name
 * does not.
 *
 * `neatTooltip` takes a string only. Its declared type is brain's (`string | TemplateRef | null`)
 * because a host-directive alias keeps the primitive's input type; templates are not supported.
 *
 * Built like helm's tooltip (brain primitive plus helm's classes) rather than on top of it: a host
 * directive cannot re-expose inputs of its own host directives, and every host directive of a
 * public directive becomes public API.
 */
export declare class NeatTooltip {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTooltip, "[neatTooltip]", never, {}, {}, never, never, true, [{
    directive: typeof i1.BrnTooltip;
    inputs: {
      "brnTooltip": "neatTooltip";
      "position": "neatTooltipPosition";
      "tooltipDisabled": "neatTooltipDisabled";
    };
    outputs: {};
  }]>;
}
export type { ColorScale, ColorStep, NeatButtonSize, NeatButtonVariant, NeatColorScheme, NeatIconName, NeatNavItem, NeatTooltipPosition, SurfaceScale };