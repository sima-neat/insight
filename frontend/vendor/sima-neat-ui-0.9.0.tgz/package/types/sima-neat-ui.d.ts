import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, Injector, Signal } from "@angular/core";
import { LucideActivity, LucideBlocks, LucideCable, LucideCheck, LucideChevronDown, LucideChevronLeft, LucideChevronRight, LucideChevronUp, LucideCircleAlert, LucideCpu, LucideEllipsis, LucideFile, LucideFileText, LucideFolder, LucideFolderOpen, LucideInfo, LucideLayoutGrid, LucideMaximize, LucideMaximize2, LucideMinimize, LucideMoon, LucidePalette, LucidePanelLeftClose, LucidePanelLeftOpen, LucideRadioTower, LucideRectangleHorizontal, LucideSearch, LucideShapes, LucideSquare, LucideSun, LucideTriangleAlert, LucideUpload, LucideX } from "@lucide/angular";
import { IsActiveMatchOptions } from "@angular/router";
import { TemplatePortal } from "@angular/cdk/portal";
import * as i1$3 from "@spartan-ng/brain/button";
import * as i1$2 from "@spartan-ng/brain/tooltip";
import * as i1$1 from "@spartan-ng/brain/tabs";
import { BrnPaginatedTabHeaderItem, BrnTabsPaginatedList, BrnTabsTrigger } from "@spartan-ng/brain/tabs";
import { ClassValue } from "clsx";
import { Observable } from "rxjs";
import { VariantProps } from "class-variance-authority";
import * as i1 from "@spartan-ng/brain/toggle";
type ColorStep = 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950;
type ColorScale = Record<Exclude<ColorStep, 0>, string>;
type SurfaceScale = Record<ColorStep, string>;
/** Builds a 50-950 ramp in OKLCH around `base`, which becomes step 500 unchanged. */
export declare function buildColorScale(base: string): ColorScale;
/**
 * Builds the brand surface ramp: white, the two palette backgrounds and the palette text as
 * anchors, with 200-900 interpolated in OKLab between the alternate background and the text. The
 * light scheme's surfaces.
 */
export declare function buildSurfaceScale(): SurfaceScale;
/**
 * Builds the neutral surface ramp: the brand ramp's construction in greys only, from greys as light
 * as the two palette backgrounds down to the near-black (`NEAT_NEAR_BLACK`). The dark scheme's
 * surfaces, which carry no hue of their own.
 */
export declare function buildNeutralSurfaceScale(): SurfaceScale;
/**
 * Colour maths for the theme: hex <-> linear sRGB <-> OKLab/OKLCH, and WCAG 2.x contrast.
 * OKLab matrices from Björn Ottosson, "A perceptual color space for image processing" (2020).
 */
/** OKLCH: lightness 0..1, chroma >= 0, hue in degrees. */
interface Oklch {
  l: number;
  c: number;
  h: number;
}
/** Three channels: gamma-encoded or linear sRGB, or OKLab `[L, a, b]`. */
type Vec3 = readonly [number, number, number];
/** Validates `#RRGGBB` in either case and returns it in upper case. */
declare function normalizeHex(hex: string): string;
/** Converts `#RRGGBB` (either case) to OKLab `[L, a, b]`. */
declare function hexToOklab(hex: string): Vec3;
/** Converts OKLab `[L, a, b]` to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklabToHex(lab: Vec3): string;
/** Converts `#RRGGBB` (either case) to OKLCH. */
declare function hexToOklch(hex: string): Oklch;
/** Converts OKLCH to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklchToHex(color: Oklch): string;
/** Whether an OKLCH colour can be shown in sRGB without clamping. */
declare function isInSrgbGamut(color: Oklch): boolean;
/**
 * `foreground` at `alpha` (0 to 1) over an opaque `background`, blended per channel in
 * gamma-encoded sRGB as browsers composite a translucent fill such as Tailwind's `bg-x/10`.
 */
declare function composite(foreground: string, alpha: number, background: string): string;
/**
 * `color` mixed into an opaque `background` by `share` (0 to 1), in OKLab, as CSS
 * `color-mix(in oklab, color <share>, background)` does: a perceptually even step from the
 * background towards the colour, for an opaque tint.
 */
declare function mixOklab(color: string, share: number, background: string): string;
/**
 * `color` with an alpha channel, as `#RRGGBBAA`, for a translucent token such as a scrim. The alpha
 * is rounded to the nearest of the 256 values the hex byte can hold.
 */
declare function withAlpha(color: string, alpha: number): string;
/** WCAG 2.x relative luminance of `#RRGGBB`. */
declare function relativeLuminance(hex: string): number;
/** WCAG 2.x contrast ratio (1 to 21) between two `#RRGGBB` colours, in either order. */
export declare function contrastRatio(a: string, b: string): number;
/** The fixed SiMa.ai brand palette (identical to the Slides/PowerPoint theme). */
export declare const SIMA_PALETTE: {
  readonly text: "#010F0E";
  readonly background: "#F3F4F5";
  readonly backgroundAlt: "#E8E9EB";
  readonly white: "#FFFFFF";
  readonly orange: "#D26728";
  readonly purple: "#D1CEE6";
  readonly blue: "#5998DD";
  readonly mint: "#C0E8DB";
  readonly green: "#2A9C4F";
  readonly lime: "#A4CC2D";
};
/** Base of the primary scale. Swapping it (for example to the palette blue) re-derives the whole primary ramp. */
export declare const NEAT_PRIMARY_BASE: string;
/** Functional colours outside the palette, which has no red or amber but errors and warnings need them. */
export declare const NEAT_DANGER_BASE = "#C8372D";
/** Used unchanged as the warning fill (step 500 of its scale), with palette text colour on it. */
export declare const NEAT_WARN_BASE = "#E9A23B";
/**
 * The hue of the highlight tone, which marks a distinct state that is none of the statuses: the
 * palette purple's hue (291° in OKLCH) at about three times its chroma. The palette purple itself is
 * too pale to work from: a row tint of 10% of it on white is #FAFAFD, no tint at all, and no step
 * of its scale is a fill that white text reads on and that still looks purple.
 */
export declare const NEAT_HIGHLIGHT_BASE = "#9D93D6";
/**
 * The dark scheme's darkest surface, its page: a neutral near-black. The dark surfaces are greys
 * from here up (`buildNeutralSurfaceScale`) rather than steps towards the palette text, whose teal
 * made a whole dark page read green.
 */
export declare const NEAT_NEAR_BLACK = "#101010";
/**
 * What a status colour says: nothing in particular (`neutral`), it went well, take note, it
 * failed, for information, or a distinct state that is none of these (`highlight`, the brand
 * purple). A status chip's fill and a select-list row's tint both take it, so that a row and its
 * chip, given the same tone, say the same.
 */
type NeatTone = 'neutral' | 'success' | 'warning' | 'danger' | 'info' | 'highlight';
/**
 * The kit's start-up in one call: it applies the stored colour scheme before the first render.
 * The colours themselves come from the kit stylesheet (`@sima/neat-ui/styles/neat-ui.css`).
 */
export declare function provideNeatUi(): EnvironmentProviders;
type NeatColorScheme = 'light' | 'dark';
/** The dark theme's selector: tokens.generated.css and the `dark` variant in neat-ui.tailwind.css. */
declare const NEAT_DARK_CLASS = "neat-dark";
/**
 * Light/dark switch for the kit. Light is the default regardless of the OS preference (which is
 * deliberately never read); dark is opt-in and persisted.
 */
export declare class ThemeService {
  private readonly root;
  private readonly current;
  readonly scheme: Signal<NeatColorScheme>;
  constructor();
  /**
   * Applies `scheme` and, unless `persist` is false, stores it for later page loads. Without
   * storing, the scheme holds for this page load only, as a URL parameter that themes a shared
   * link needs: the user's stored choice stays, and a later toggle stores as usual.
   */
  setScheme(scheme: NeatColorScheme, { persist }?: {
    persist?: boolean;
  }): void;
  toggle(): void;
  private apply;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * An icon from the kit's curated set. Decorative by default (hidden from assistive technology);
 * give it a `label` when it carries meaning on its own. It takes its colour from the surrounding
 * text.
 */
export declare class NeatIcon {
  readonly name: import("@angular/core").InputSignal<"warning" | "info" | "media" | "streaming" | "viewer" | "peripherals" | "stats" | "board" | "sun" | "moon" | "kiosk-enter" | "kiosk-exit" | "rail-expand" | "rail-collapse" | "palette" | "shapes" | "blocks" | "document" | "previous" | "next" | "close" | "check" | "expand" | "collapse" | "aspect-wide" | "aspect-square" | "search" | "more" | "fit-all" | "upload" | "folder" | "file" | "error">;
  /** Edge length in pixels. */
  readonly size: import("@angular/core").InputSignal<number>;
  /** Accessible name; leave unset for a decorative icon. */
  readonly label: import("@angular/core").InputSignal<string | undefined>;
  protected readonly glyph: import("@angular/core").Signal<typeof import("@lucide/angular").LucideFolderOpen | typeof import("@lucide/angular").LucideRadioTower | typeof import("@lucide/angular").LucideLayoutGrid | typeof import("@lucide/angular").LucideCable | typeof import("@lucide/angular").LucideActivity | typeof import("@lucide/angular").LucideCpu | typeof import("@lucide/angular").LucideInfo | typeof import("@lucide/angular").LucideSun | typeof import("@lucide/angular").LucideMoon | typeof import("@lucide/angular").LucideMaximize | typeof import("@lucide/angular").LucideMinimize | typeof import("@lucide/angular").LucidePanelLeftOpen | typeof import("@lucide/angular").LucidePanelLeftClose | typeof import("@lucide/angular").LucidePalette | typeof import("@lucide/angular").LucideShapes | typeof import("@lucide/angular").LucideBlocks | typeof import("@lucide/angular").LucideFileText | typeof import("@lucide/angular").LucideChevronLeft | typeof import("@lucide/angular").LucideChevronRight | typeof import("@lucide/angular").LucideX | typeof import("@lucide/angular").LucideCheck | typeof import("@lucide/angular").LucideChevronDown | typeof import("@lucide/angular").LucideChevronUp | typeof import("@lucide/angular").LucideRectangleHorizontal | typeof import("@lucide/angular").LucideSquare | typeof import("@lucide/angular").LucideSearch | typeof import("@lucide/angular").LucideEllipsis | typeof import("@lucide/angular").LucideMaximize2 | typeof import("@lucide/angular").LucideUpload | typeof import("@lucide/angular").LucideFolder | typeof import("@lucide/angular").LucideFile | typeof import("@lucide/angular").LucideCircleAlert | typeof import("@lucide/angular").LucideTriangleAlert>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatIcon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatIcon, "neat-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The kit's icon vocabulary: names say what an icon means in the app, the value is the Lucide
 * glyph that draws it. This is the only file that references Lucide glyphs, so a glyph is swapped
 * in one place and only the glyphs listed here end up in an app's bundle.
 */
declare const NEAT_ICONS: {
  media: typeof LucideFolderOpen;
  streaming: typeof LucideRadioTower;
  viewer: typeof LucideLayoutGrid;
  peripherals: typeof LucideCable;
  stats: typeof LucideActivity;
  board: typeof LucideCpu;
  info: typeof LucideInfo;
  sun: typeof LucideSun;
  moon: typeof LucideMoon;
  'kiosk-enter': typeof LucideMaximize;
  'kiosk-exit': typeof LucideMinimize;
  'rail-expand': typeof LucidePanelLeftOpen;
  'rail-collapse': typeof LucidePanelLeftClose;
  palette: typeof LucidePalette;
  shapes: typeof LucideShapes;
  blocks: typeof LucideBlocks;
  document: typeof LucideFileText;
  previous: typeof LucideChevronLeft;
  next: typeof LucideChevronRight;
  close: typeof LucideX;
  check: typeof LucideCheck;
  expand: typeof LucideChevronDown;
  collapse: typeof LucideChevronUp;
  'aspect-wide': typeof LucideRectangleHorizontal;
  'aspect-square': typeof LucideSquare;
  search: typeof LucideSearch;
  more: typeof LucideEllipsis;
  'fit-all': typeof LucideMaximize2;
  upload: typeof LucideUpload;
  folder: typeof LucideFolder;
  file: typeof LucideFile;
  error: typeof LucideCircleAlert;
  warning: typeof LucideTriangleAlert;
};
type NeatIconName = keyof typeof NEAT_ICONS;
/** Every name in the registry, in registry order, for galleries and pickers. */
export declare const NEAT_ICON_NAMES: readonly NeatIconName[];
/** One page in the shell's rail. */
interface NeatNavItem {
  /** Shown as the link's name, its tooltip and, while the page is active, the page title. */
  label: string;
  icon: NeatIconName;
  /** Absolute app path, for example `/media`; the item stays active on routes nested under it. */
  path: string;
}
/** How long the pointer must rest before `KioskService.pointerIdle` turns true. */
export declare const KIOSK_POINTER_IDLE_MS = 2500;
/**
 * Kiosk mode for expos: the shell hides its rail and top bar, and pages can hide their own chrome
 * while the pointer rests (`pointerIdle`). Kiosk keeps the current colour scheme and is not
 * persisted; it comes from the button or from a `?kiosk` URL parameter read once at start.
 *
 * `enter()` also asks for browser fullscreen. The URL parameter does not, because browsers refuse
 * fullscreen without a user gesture; booth machines use the browser's own kiosk flag instead.
 * If fullscreen was obtained by `enter()`, leaving it (Esc) leaves kiosk mode too.
 *
 * A component whose UI lives outside the floating chrome but belongs to it (a popover opened from
 * the page toolbar) holds the toolbar with `holdToolbar()`, so the chrome does not fade under it.
 *
 * The document listeners are plain DOM listeners outside change detection; signals change only
 * when the state does, so pointer movement does not cause renders.
 */
export declare class KioskService {
  private readonly document;
  private readonly isActive;
  private readonly isPointerIdle;
  /** Whether the current fullscreen is the one `enter()` asked for. */
  private ownsFullscreen;
  /** Unreleased `holdToolbar()` calls; the pointer never counts as idle while there are any. */
  private holds;
  private idleTimer;
  readonly active: Signal<boolean>;
  /**
   * True once the pointer has rested for `KIOSK_POINTER_IDLE_MS`; false again on pointer or touch
   * input, and false throughout a `holdToolbar()`.
   */
  readonly pointerIdle: Signal<boolean>;
  constructor();
  /** Turns kiosk on and asks for fullscreen; kiosk stays on if fullscreen is refused. */
  enter(): Promise<void>;
  /** Turns kiosk off, leaving fullscreen only if `enter()` obtained it. */
  exit(): Promise<void>;
  toggle(): Promise<void>;
  /**
   * Keeps `pointerIdle` false, so the kiosk chrome stays shown, until the returned function is
   * called. Holds stack: the pointer can go idle again only once every hold is released, and then
   * only after resting a full `KIOSK_POINTER_IDLE_MS`. Releasing twice counts once.
   */
  holdToolbar(): () => void;
  private onFullscreenChange;
  private onActivity;
  /** Starts the countdown to idle over; while the toolbar is held there is nothing to count. */
  private restartIdleTimer;
  static ɵfac: i0.ɵɵFactoryDeclaration<KioskService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The app frame: an icon rail with the pages on the left (expandable to show labels), a top bar
 * with logo, app name, page title and app-specific items, and the content area for the routed
 * page. It fills the viewport; the content area gives its page the remaining space and never
 * scrolls itself, so pages own their scrolling (see `neat-page`).
 *
 * Content projection: the default slot is the content area (usually a `<router-outlet />`);
 * elements marked `neatTopbarEnd` go to the right side of the top bar. The active page's own
 * controls (`*neatPageToolbar`) sit at the right of the top bar, just before that end slot.
 *
 * Kiosk mode (`KioskService`, entered from the top bar or with `?kiosk`) drops the rail and the
 * top bar, gives the content area the whole viewport and floats an exit control over its top
 * right corner while the pointer moves; the page toolbar floats beside it on the same terms. Its
 * view is re-created on entering and leaving kiosk mode, so the page keeps the toolbar's state.
 */
export declare class NeatShell {
  readonly appName: import("@angular/core").InputSignal<string>;
  readonly navItems: import("@angular/core").InputSignal<NeatNavItem[]>;
  protected readonly theme: ThemeService;
  protected readonly kiosk: KioskService;
  protected readonly pageToolbar: import("@angular/core").Signal<import("@angular/cdk/portal").TemplatePortal<any> | null>;
  protected readonly toolbarLabel = "Page tools";
  private readonly router;
  private readonly injector;
  protected readonly activeMatch: IsActiveMatchOptions;
  protected readonly railExpanded: import("@angular/core").WritableSignal<boolean>;
  private readonly kioskExit;
  private readonly kioskButton;
  /** Label of the nav item the current route belongs to; the first match wins. */
  protected readonly pageTitle: import("@angular/core").Signal<string>;
  constructor();
  /**
   * The mirror of entering: leaving kiosk mode with the exit control removes it, which drops focus
   * to <body>; hand focus to the top-bar kiosk button that comes back, where kiosk mode was entered.
   * Not when kiosk mode ends otherwise (Esc leaving fullscreen, for example), when focus may be on
   * the page and must stay there.
   */
  protected focusKioskButtonAfterExit(): void;
  protected toggleRail(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatShell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatShell, "neat-shell", never, {
    "appName": {
      "alias": "appName";
      "required": true;
      "isSignal": true;
    };
    "navItems": {
      "alias": "navItems";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["[neatTopbarEnd]", "*"], true, never>;
}
/**
 * True for content rendered inside the page toolbar, in the top bar or the kiosk bar alike.
 * Internal to the kit: a popover reads it to hold the kiosk bar open while it is open.
 */
declare const IN_PAGE_TOOLBAR: InjectionToken<boolean>;
/**
 * Where the active page's toolbar is handed to the shell. Internal to the kit: pages use
 * `*neatPageToolbar`, the shell renders `portal`.
 */
declare class PageToolbarSlot {
  private readonly current;
  /** The registered page toolbar, or null when the active page has none. */
  readonly portal: Signal<TemplatePortal | null>;
  register(portal: TemplatePortal): void;
  unregister(portal: TemplatePortal): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageToolbarSlot, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The page's toolbar: `<div *neatPageToolbar>…</div>` on a page renders that content in the
 * shell's top bar, at its right end just before the end slot, while the page exists. In kiosk mode,
 * where the top bar is hidden, it renders in a floating bar beside the exit control that shows
 * while the pointer moves. The content stays the page's: its bindings and injection context are
 * those of the page's template.
 *
 * One page toolbar at a time; a second one throws in dev mode.
 */
export declare class NeatPageToolbar {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPageToolbar, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPageToolbar, "[neatPageToolbar]", never, {}, {}, never, never, true, never>;
}
/**
 * A page in the shell's content area. It fills its parent and owns at most one scroll context:
 * with `scroll="body"` (the default) its body is the single scroll container; with
 * `scroll="none"` nothing scrolls and the content sizes itself to the page (for example a grid
 * that fits the screen).
 *
 * With `padding="page"` (the default) the content keeps the kit's page inset from the content
 * area's edges, so every app's pages line up; `padding="none"` lets full-bleed content (a video
 * grid, a map) reach the edges.
 *
 * Elements marked `neatPageAside` form the page's side panel (an inspector, say), shown on the
 * right while `aside="open"`. The panel is `--neat-aside-width` wide and scrolls on its own; the
 * body narrows beside it rather than being covered, keeping its own scroll setting. The aside is
 * the one supported second scroll context of a page. Closed, the panel and its content are out
 * of the DOM, but projected content is still instantiated (content projection always creates
 * it): gate expensive content with an `@if` of your own.
 */
export declare class NeatPage {
  readonly scroll: import("@angular/core").InputSignal<"none" | "body">;
  readonly padding: import("@angular/core").InputSignal<"none" | "page">;
  readonly aside: import("@angular/core").InputSignal<"open" | "closed">;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPage, "neat-page", never, {
    "scroll": {
      "alias": "scroll";
      "required": false;
      "isSignal": true;
    };
    "padding": {
      "alias": "padding";
      "required": false;
      "isSignal": true;
    };
    "aside": {
      "alias": "aside";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[neatPageAside]"], true, never>;
}
/**
 * The toolbar button that opens and closes the page's side panel:
 *
 * ```html
 * <div *neatPageToolbar>
 *   …
 *   <neat-aside-toggle [(open)]="asideOpen" />
 * </div>
 * <neat-page [aside]="asideOpen() ? 'open' : 'closed'">…</neat-page>
 * ```
 *
 * One look on every page: a small, text, icon-only `neatButton` with the `info` icon, whose
 * pressed state is the panel's. `label` names it and is its tooltip ("Side panel" unless the page
 * says otherwise). `open` is a model the page owns, so the page decides where it is remembered;
 * the toggle only flips it. `focus()` puts the focus on the button, for a page whose panel closes
 * from inside (Escape, a close button) and must not leave the focus on nothing.
 *
 * The page's toolbar is a template the shell renders elsewhere, outside `neat-page`, so the toggle
 * and the page meet in the page's own state, not through the kit.
 */
export declare class NeatAsideToggle {
  /** The button's name and tooltip. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Whether the page's side panel is open. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  private readonly button;
  /** Puts the focus on the button. */
  focus(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideToggle, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatAsideToggle, "neat-aside-toggle", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, never, true, never>;
}
/**
 * The column of a side panel's content, on the element the page marks `neatPageAside` (or its
 * root inside): its parts stacked one gap apart (`--neat-space-3`). The aside gives it its width,
 * inset and scrolling.
 */
export declare class NeatAsidePanel {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsidePanel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsidePanel, "[neatAsidePanel]", never, {}, {}, never, never, true, never>;
}
/** What the panel is about, as its first line: `<h2 neatAsideTitle>src3</h2>`. */
export declare class NeatAsideTitle {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideTitle, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsideTitle, "[neatAsideTitle]", never, {}, {}, never, never, true, never>;
}
/**
 * The heading of a section of the panel: `<h3 neatAsideHeading>Source</h3>`. It sits nearer to the
 * section it names than to the one before (a gap above it on top of the panel's), except as the
 * panel's first part.
 */
export declare class NeatAsideHeading {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideHeading, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsideHeading, "[neatAsideHeading]", never, {}, {}, never, never, true, never>;
}
/** A row of the panel's buttons, which wraps when the panel is narrow. */
export declare class NeatAsideActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatAsideActions, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatAsideActions, "[neatAsideActions]", never, {}, {}, never, never, true, never>;
}
/**
 * A URL, a path or a name in running text: `<code neatCode>rtsp://…/src3</code>`. Monospace runs
 * wide, so it is the kit's small size, and it has no spaces to break at, so it wraps anywhere.
 */
export declare class NeatCode {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCode, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatCode, "code[neatCode]", never, {}, {}, never, never, true, never>;
}
type NeatButtonVariant = 'primary' | 'secondary' | 'outlined' | 'text' | 'danger';
/** `touch` is a 3rem (48px) target, above the 44px minimum, for kiosk and touch screens. */
type NeatButtonSize = 'small' | 'medium' | 'large' | 'touch';
/**
 * A button or link styled as a kit button. Content is the label and/or a `neat-icon`; an
 * icon-only button needs an `aria-label` (and usually a `neatTooltip` with the same text).
 *
 * Built from Spartan's brain primitive and helm's class map rather than on helm's directive:
 * every host directive of a public directive becomes public API, and helm stays internal.
 * The classes go through Angular's `[class]` binding, not helm's `classes()`, which rewrites
 * `className` and can drop a `[class.x]` binding that changes in the same render.
 *
 * A toggle button binds `pressed`: it sets `aria-pressed` and the pressed look. Leave it undefined
 * on a button that is not a toggle, since `aria-pressed="false"` would announce one.
 *
 * `[attr.aria-disabled]="true"` dims the button with a not-allowed cursor while it stays focusable
 * and its tooltip still opens on hover, for a button that waits and must not drop the focus. The
 * kit only styles it: a click, Enter and Space all still fire `click`, so the handler ignores
 * presses while it waits.
 */
export declare class NeatButton {
  readonly variant: import("@angular/core").InputSignal<NeatButtonVariant>;
  readonly size: import("@angular/core").InputSignal<NeatButtonSize>;
  /** Square (or, with `rounded`, circular) and sized for a single icon. */
  readonly iconOnly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Fully rounded ends: a pill, or a circle when `iconOnly`. */
  readonly rounded: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * A toggle's state: `aria-pressed` and the pressed look. Undefined for a button that is not a
   * toggle. Only for `button[neatButton]`: `aria-pressed` is not valid on a link. The primary
   * variant is a solid fill already, so its pressed look is the least distinct (2.78:1 against
   * its resting fill in dark); put toggles on the other variants.
   */
  readonly pressed: import("@angular/core").InputSignal<boolean | undefined>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatButton, "button[neatButton], a[neatButton]", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "iconOnly": {
      "alias": "iconOnly";
      "required": false;
      "isSignal": true;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
      "isSignal": true;
    };
    "pressed": {
      "alias": "pressed";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$3.BrnButton;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
/**
 * A text action set into a line of text, such as "Use global" at the end of a list line: medium
 * weight and underlined on hover, as tall as its text, in the font size and colour of its parent.
 * Its label does not wrap, so keep it to a few words. Use `neatButton` for actions that stand on
 * their own; this one is for dense lines where a `neatButton`'s 2rem height would set the line
 * height. Keep lines at least 1.5rem high (`min-block-size`) when several sit in a column, so the
 * targets stay apart (WCAG 2.5.8).
 */
export declare class NeatInlineButton {
  protected readonly classes: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatInlineButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatInlineButton, "button[neatInlineButton], a[neatInlineButton]", never, {}, {}, never, never, true, [{
    directive: typeof i1$3.BrnButton;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
/**
 * A short note under a control or a heading: no margin, in the muted text colour and the small
 * text size, as `<p neatNote>Applies to every channel without its own value.</p>`. It sets the look
 * only; the words, and any role, are the app's. A `neatInlineButton` inside takes the note's size
 * and colour, so an action set into the note ("Show", "Use global") reads like the words around it.
 */
export declare class NeatNote {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatNote, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatNote, "[neatNote]", never, {}, {}, never, never, true, never>;
}
type NeatTooltipPosition = 'top' | 'right' | 'bottom' | 'left';
/**
 * A short text label shown on mouse or pen hover and on keyboard focus, hidden on leave, blur and
 * Escape; the host carries `aria-describedby` while it is shown. It never opens on touch (a tap
 * would trigger the host's action too), so it must not carry anything the host's accessible name
 * does not.
 *
 * `neatTooltip` takes a string only. Its declared type is brain's (`string | TemplateRef | null`)
 * because a host-directive alias keeps the primitive's input type; templates are not supported.
 *
 * Built like helm's tooltip (brain primitive plus helm's classes) rather than on top of it: a host
 * directive cannot re-expose inputs of its own host directives, and every host directive of a
 * public directive becomes public API.
 */
export declare class NeatTooltip {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTooltip, "[neatTooltip]", never, {}, {}, never, never, true, [{
    directive: typeof i1$2.BrnTooltip;
    inputs: {
      "brnTooltip": "neatTooltip";
      "position": "neatTooltipPosition";
      "tooltipDisabled": "neatTooltipDisabled";
    };
    outputs: {};
  }]>;
}
declare const FIELD_LABEL_CLASSES: {
  /** The column that holds the name and, under it, the control. */
  readonly stack: "flex flex-col gap-2";
  /** The name. */
  readonly label: "text-sm font-medium";
};
declare class HlmTabs {
  readonly tab: import("@angular/core").InputSignal<string>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabs, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabs, "[hlmTabs],hlm-tabs", ["hlmTabs"], {
    "tab": {
      "alias": "tab";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$1.BrnTabs;
    inputs: {
      "orientation": "orientation";
      "activationMode": "activationMode";
      "brnTabs": "tab";
    };
    outputs: {
      "tabActivated": "tabActivated";
    };
  }]>;
}
declare class HlmTabsContent {
  readonly contentFor: import("@angular/core").InputSignal<string>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsContent, "[hlmTabsContent]", ["hlmTabsContent"], {
    "contentFor": {
      "alias": "hlmTabsContent";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$1.BrnTabsContent;
    inputs: {
      "brnTabsContent": "hlmTabsContent";
    };
    outputs: {};
  }]>;
}
declare class HlmTabsContentLazy {
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsContentLazy, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsContentLazy, "ng-template[hlmTabsContentLazy]", ["hlmTabsContentLazy"], {}, {}, never, never, true, [{
    directive: typeof i1$1.BrnTabsContentLazy;
    inputs: {};
    outputs: {};
  }]>;
}
declare const listVariants: (props?: ({
  variant?: "default" | "line" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
declare class HlmTabsList {
  readonly variant: import("@angular/core").InputSignal<"default" | "line" | null | undefined>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsList, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsList, "[hlmTabsList],hlm-tabs-list", ["hlmTabsList"], {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$1.BrnTabsList;
    inputs: {};
    outputs: {};
  }]>;
}
declare class HlmTabsPaginatedList extends BrnTabsPaginatedList {
  constructor();
  readonly items: import("@angular/core").Signal<readonly BrnTabsTrigger[]>;
  /** Explicitly annotating type to avoid non-portable inferred type */
  readonly itemsChanges: Observable<ReadonlyArray<BrnPaginatedTabHeaderItem>>;
  readonly tabListContainer: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly tabList: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly tabListInner: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly nextPaginator: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly previousPaginator: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly tabListClass: import("@angular/core").InputSignal<ClassValue>;
  protected readonly _tabListClass: import("@angular/core").Signal<string>;
  readonly paginationButtonClass: import("@angular/core").InputSignal<ClassValue>;
  protected readonly _paginationButtonClass: import("@angular/core").Signal<string>;
  protected _itemSelected(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsPaginatedList, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HlmTabsPaginatedList, "hlm-paginated-tabs-list", ["hlmTabsPaginatedList"], {
    "tabListClass": {
      "alias": "tabListClass";
      "required": false;
      "isSignal": true;
    };
    "paginationButtonClass": {
      "alias": "paginationButtonClass";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["items"], ["*"], true, never>;
}
declare class HlmTabsTrigger {
  readonly triggerFor: import("@angular/core").InputSignal<string>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmTabsTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmTabsTrigger, "[hlmTabsTrigger]", ["hlmTabsTrigger"], {
    "triggerFor": {
      "alias": "hlmTabsTrigger";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$1.BrnTabsTrigger;
    inputs: {
      "brnTabsTrigger": "hlmTabsTrigger";
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
declare const HlmTabsImports: readonly [typeof HlmTabs, typeof HlmTabsList, typeof HlmTabsTrigger, typeof HlmTabsContent, typeof HlmTabsContentLazy, typeof HlmTabsPaginatedList];
declare const toggleVariants: (props?: ({
  variant?: "default" | "outline" | null | undefined;
  size?: "default" | "sm" | "lg" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type ToggleVariants = VariantProps<typeof toggleVariants>;
declare class HlmToggle {
  readonly variant: import("@angular/core").InputSignal<"default" | "outline" | null | undefined>;
  readonly size: import("@angular/core").InputSignal<"default" | "sm" | "lg" | null | undefined>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<HlmToggle, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HlmToggle, "button[hlmToggle]", ["hlmToggle"], {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnToggle;
    inputs: {
      "id": "id";
      "value": "value";
      "disabled": "disabled";
      "state": "state";
      "aria-label": "aria-label";
      "type": "type";
    };
    outputs: {
      "stateChange": "stateChange";
    };
  }]>;
}
declare const HlmToggleImports: readonly [typeof HlmToggle];
declare function hlm(...inputs: ClassValue[]): string;
/**
 * This function dynamically adds and removes classes for a given element without requiring
 * the a class binding (e.g. `[class]="..."`) which may interfere with other class bindings.
 *
 * 1. This will merge the existing classes on the element with the new classes.
 * 2. It will also remove any classes that were previously added by this function but are no longer present in the new classes.
 * 3. Multiple calls to this function on the same element will be merged efficiently.
 */
declare function classes(computed: () => ClassValue[] | string, options?: ClassesOptions): void;
interface ClassesOptions {
  elementRef?: ElementRef<HTMLElement>;
  injector?: Injector;
}
/**
 * Provides default configuration for Spartan Helm components.
 *
 * This utility configures the Angular CDK overlay to disable the `usePopover`
 * behavior introduced in Angular 21, which causes CDK overlay-based components
 * (sheets, dialogs, tooltips, etc.) to render above `position: fixed` elements
 * like `<hlm-toaster>`.
 *
 * @returns {EnvironmentProviders} Environment providers to be added to the application config.
 *
 * @example
 * ```ts
 * // app.config.ts
 * import { provideSpartanHlm } from '@spartan-ng/helm/utils';
 *
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideSpartanHlm(),
 *     // ... other providers
 *   ],
 * };
 * ```
 */
declare function provideSpartanHlm(): EnvironmentProviders;
export { type ColorScale, type ColorStep, type NeatButtonSize, type NeatButtonVariant, type NeatColorScheme, type NeatIconName, type NeatNavItem, type NeatTone, type NeatTooltipPosition, type SurfaceScale, FIELD_LABEL_CLASSES as ɵFIELD_LABEL_CLASSES, IN_PAGE_TOOLBAR as ɵIN_PAGE_TOOLBAR, hlm as ɵhlm, listVariants as ɵlistVariants, toggleVariants as ɵtoggleVariants };