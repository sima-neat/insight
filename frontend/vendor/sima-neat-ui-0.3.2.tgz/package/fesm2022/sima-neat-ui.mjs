import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, Directive, ElementRef, HostAttributeToken, Injectable, InjectionToken, Injector, NgZone, PLATFORM_ID, TemplateRef, ViewContainerRef, afterNextRender, afterRenderEffect, booleanAttribute, computed, contentChild, contentChildren, effect, inject, input, isDevMode, makeEnvironmentProviders, model, output, provideEnvironmentInitializer, runInInjectionContext, signal, untracked, viewChild, viewChildren } from "@angular/core";
import { LucideActivity, LucideBlocks, LucideCable, LucideChevronLeft, LucideChevronRight, LucideCpu, LucideDynamicIcon, LucideFileText, LucideFolderOpen, LucideInfo, LucideLayoutGrid, LucideMaximize, LucideMinimize, LucideMoon, LucidePalette, LucidePanelLeftClose, LucidePanelLeftOpen, LucideRadioTower, LucideRectangleHorizontal, LucideShapes, LucideSquare, LucideSun, LucideX } from "@lucide/angular";
import { CdkPortalOutlet, TemplatePortal } from "@angular/cdk/portal";
import { Router, RouterLink, RouterLinkActive, containsTree } from "@angular/router";
import * as i1$5 from "@spartan-ng/brain/button";
import { BrnButton } from "@spartan-ng/brain/button";
import { NgTemplateOutlet, isPlatformBrowser } from "@angular/common";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import "@angular/cdk/overlay";
import { cva } from "class-variance-authority";
import * as i1$4 from "@spartan-ng/brain/tooltip";
import { BrnTooltip, provideBrnTooltipDefaultOptions } from "@spartan-ng/brain/tooltip";
import * as i1$3 from "@spartan-ng/brain/slider";
import { BrnSlider, BrnSliderRange, BrnSliderThumb, BrnSliderTrack } from "@spartan-ng/brain/slider";
import * as i1$2 from "@spartan-ng/brain/toggle";
import { BrnToggle } from "@spartan-ng/brain/toggle";
import * as i1$1 from "@spartan-ng/brain/tabs";
import { BrnTabs, BrnTabsContent, BrnTabsContentLazy, BrnTabsList, BrnTabsPaginatedList, BrnTabsTrigger } from "@spartan-ng/brain/tabs";
import { CdkObserveContent } from "@angular/cdk/observers";
import { toObservable } from "@angular/core/rxjs-interop";
import * as i1 from "@spartan-ng/brain/input";
import { BrnInput } from "@spartan-ng/brain/input";
const HEX_PATTERN = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i;
function parseHex(hex) {
	const match = HEX_PATTERN.exec(hex);
	if (!match) throw new Error(`Expected a #RRGGBB colour, got "${hex}"`);
	return [
		parseInt(match[1], 16) / 255,
		parseInt(match[2], 16) / 255,
		parseInt(match[3], 16) / 255
	];
}
function formatHex(rgb) {
	const channel = (value) => Math.round(Math.min(1, Math.max(0, value)) * 255).toString(16).padStart(2, "0");
	return `#${rgb.map(channel).join("")}`.toUpperCase();
}
function toLinear(channel) {
	return channel <= .04045 ? channel / 12.92 : ((channel + .055) / 1.055) ** 2.4;
}
function fromLinear(channel) {
	return channel <= .0031308 ? channel * 12.92 : 1.055 * channel ** (1 / 2.4) - .055;
}
function linearToOklab([r, g, b]) {
	const l = Math.cbrt(.4122214708 * r + .5363325363 * g + .0514459929 * b);
	const m = Math.cbrt(.2119034982 * r + .6806995451 * g + .1073969566 * b);
	const s = Math.cbrt(.0883024619 * r + .2817188376 * g + .6299787005 * b);
	return [
		.2104542553 * l + .793617785 * m - .0040720468 * s,
		1.9779984951 * l - 2.428592205 * m + .4505937099 * s,
		.0259040371 * l + .7827717662 * m - .808675766 * s
	];
}
function oklabToLinear([lightness, a, b]) {
	const l = (lightness + .3963377774 * a + .2158037573 * b) ** 3;
	const m = (lightness - .1055613458 * a - .0638541728 * b) ** 3;
	const s = (lightness - .0894841775 * a - 1.291485548 * b) ** 3;
	return [
		4.0767416621 * l - 3.3077115913 * m + .2309699292 * s,
		-1.2684380046 * l + 2.6097574011 * m - .3413193965 * s,
		-.0041960863 * l - .7034186147 * m + 1.707614701 * s
	];
}
function normalizeHex(hex) {
	return formatHex(parseHex(hex));
}
function hexToLinear(hex) {
	const [r, g, b] = parseHex(hex);
	return [
		toLinear(r),
		toLinear(g),
		toLinear(b)
	];
}
function linearToHex([r, g, b]) {
	return formatHex([
		fromLinear(r),
		fromLinear(g),
		fromLinear(b)
	]);
}
function hexToOklab(hex) {
	return linearToOklab(hexToLinear(hex));
}
function oklabToHex(lab) {
	return linearToHex(oklabToLinear(lab));
}
function oklchToOklab({ l, c, h }) {
	const radians = h * Math.PI / 180;
	return [
		l,
		c * Math.cos(radians),
		c * Math.sin(radians)
	];
}
function hexToOklch(hex) {
	const [l, a, b] = hexToOklab(hex);
	const h = Math.atan2(b, a) * 180 / Math.PI;
	return {
		l,
		c: Math.hypot(a, b),
		h: h < 0 ? h + 360 : h
	};
}
function oklchToHex(color) {
	return oklabToHex(oklchToOklab(color));
}
function isInSrgbGamut(color) {
	return oklabToLinear(oklchToOklab(color)).every((channel) => channel >= -1e-6 && channel <= 1.000001);
}
function relativeLuminance(hex) {
	const [r, g, b] = hexToLinear(hex);
	return .2126 * r + .7152 * g + .0722 * b;
}
function contrastRatio(a, b) {
	const [lighter, darker] = [relativeLuminance(a), relativeLuminance(b)].sort((x, y) => y - x);
	return (lighter + .05) / (darker + .05);
}
const SIMA_PALETTE = {
	text: "#010F0E",
	background: "#F3F4F5",
	backgroundAlt: "#E8E9EB",
	white: "#FFFFFF",
	orange: "#D26728",
	purple: "#D1CEE6",
	blue: "#5998DD",
	mint: "#C0E8DB",
	green: "#2A9C4F",
	lime: "#A4CC2D"
};
const NEAT_PRIMARY_BASE = SIMA_PALETTE.orange;
const NEAT_DANGER_BASE = "#C8372D";
const NEAT_WARN_BASE = "#B7791F";
const LIGHTEST_L = .985;
const DARKEST_L = .13;
const LIGHTER_FRACTIONS = {
	50: .92,
	100: .8,
	200: .62,
	300: .42,
	400: .2
};
const DARKER_FRACTIONS = {
	600: .15,
	700: .32,
	800: .5,
	900: .66,
	950: .8
};
const CHROMA_FALLOFF = .6;
const GAMUT_SEARCH_ROUNDS = 24;
const SURFACE_FRACTIONS = {
	200: .1,
	300: .22,
	400: .36,
	500: .5,
	600: .62,
	700: .73,
	800: .83,
	900: .92
};
function fitToSrgb(color) {
	if (isInSrgbGamut(color)) return color;
	let inside = 0;
	let outside = color.c;
	for (let round = 0; round < GAMUT_SEARCH_ROUNDS; round++) {
		const c = (inside + outside) / 2;
		if (isInSrgbGamut({
			...color,
			c
		})) inside = c;
		else outside = c;
	}
	return {
		...color,
		c: inside
	};
}
function shade(base, targetL, fraction) {
	return oklchToHex(fitToSrgb({
		l: base.l + (targetL - base.l) * fraction,
		c: base.c * (1 - CHROMA_FALLOFF * fraction),
		h: base.h
	}));
}
function buildColorScale(base) {
	const oklch = hexToOklch(base);
	const lighter = (step) => shade(oklch, LIGHTEST_L, LIGHTER_FRACTIONS[step]);
	const darker = (step) => shade(oklch, DARKEST_L, DARKER_FRACTIONS[step]);
	return {
		50: lighter(50),
		100: lighter(100),
		200: lighter(200),
		300: lighter(300),
		400: lighter(400),
		500: normalizeHex(base),
		600: darker(600),
		700: darker(700),
		800: darker(800),
		900: darker(900),
		950: darker(950)
	};
}
function buildSurfaceScale() {
	const from = hexToOklab(SIMA_PALETTE.backgroundAlt);
	const to = hexToOklab(SIMA_PALETTE.text);
	const between = (step) => {
		const t = SURFACE_FRACTIONS[step];
		const mix = (channel) => from[channel] + (to[channel] - from[channel]) * t;
		return oklabToHex([
			mix(0),
			mix(1),
			mix(2)
		]);
	};
	return {
		0: SIMA_PALETTE.white,
		50: SIMA_PALETTE.background,
		100: SIMA_PALETTE.backgroundAlt,
		200: between(200),
		300: between(300),
		400: between(400),
		500: between(500),
		600: between(600),
		700: between(700),
		800: between(800),
		900: between(900),
		950: SIMA_PALETTE.text
	};
}
const safeStorage = {
	get(key) {
		try {
			return localStorage.getItem(key);
		} catch {
			return null;
		}
	},
	set(key, value) {
		try {
			localStorage.setItem(key, value);
		} catch {}
	}
};
const STORAGE_KEY = "neat-ui:color-scheme";
const NEAT_DARK_CLASS = "neat-dark";
var ThemeService = class ThemeService {
	root = inject(DOCUMENT).documentElement;
	current = signal(safeStorage.get(STORAGE_KEY) === "dark" ? "dark" : "light", ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	scheme = this.current.asReadonly();
	constructor() {
		this.apply(this.current());
	}
	setScheme(scheme, { persist = true } = {}) {
		this.current.set(scheme);
		this.apply(scheme);
		if (persist) safeStorage.set(STORAGE_KEY, scheme);
	}
	toggle() {
		this.setScheme(this.current() === "dark" ? "light" : "dark");
	}
	apply(scheme) {
		this.root.classList.toggle(NEAT_DARK_CLASS, scheme === "dark");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ThemeService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function provideNeatUi() {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => inject(ThemeService))]);
}
const NEAT_ICONS = {
	media: LucideFolderOpen,
	streaming: LucideRadioTower,
	viewer: LucideLayoutGrid,
	peripherals: LucideCable,
	stats: LucideActivity,
	board: LucideCpu,
	info: LucideInfo,
	sun: LucideSun,
	moon: LucideMoon,
	"kiosk-enter": LucideMaximize,
	"kiosk-exit": LucideMinimize,
	"rail-expand": LucidePanelLeftOpen,
	"rail-collapse": LucidePanelLeftClose,
	palette: LucidePalette,
	shapes: LucideShapes,
	blocks: LucideBlocks,
	document: LucideFileText,
	previous: LucideChevronLeft,
	next: LucideChevronRight,
	close: LucideX,
	"aspect-wide": LucideRectangleHorizontal,
	"aspect-square": LucideSquare
};
const NEAT_ICON_NAMES = Object.keys(NEAT_ICONS);
var NeatIcon = class NeatIcon {
	name = input.required(...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	size = input(20, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	glyph = computed(() => NEAT_ICONS[this.name()], ...ngDevMode ? [{ debugName: "glyph" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatIcon,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatIcon,
		isStandalone: true,
		selector: "neat-icon",
		inputs: {
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <svg
      [lucideIcon]="glyph()"
      [size]="size()"
      [title]="label()"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() ?? null"
    ></svg>
  `,
		isInline: true,
		styles: [":host{display:inline-flex}\n"],
		dependencies: [{
			kind: "component",
			type: LucideDynamicIcon,
			selector: "svg[lucideIcon]",
			inputs: ["lucideIcon"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatIcon,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-icon",
			imports: [LucideDynamicIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <svg
      [lucideIcon]="glyph()"
      [size]="size()"
      [title]="label()"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() ?? null"
    ></svg>
  `,
			styles: [":host{display:inline-flex}\n"]
		}]
	}],
	propDecorators: {
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
function hlm(...inputs) {
	return twMerge(clsx(inputs));
}
const elementClassManagers = /* @__PURE__ */ new WeakMap();
let globalObserver = null;
const observedElements = /* @__PURE__ */ new Set();
let sourceCounter = 0;
function classes(computed, options = {}) {
	runInInjectionContext(options.injector ?? inject(Injector), () => {
		const elementRef = options.elementRef ?? inject(ElementRef);
		const platformId = inject(PLATFORM_ID);
		const destroyRef = inject(DestroyRef);
		const baseClasses = inject(new HostAttributeToken("class"), { optional: true });
		const element = elementRef.nativeElement;
		const sourceId = sourceCounter++;
		let manager = elementClassManagers.get(element);
		if (!manager) {
			const initialBaseClasses = /* @__PURE__ */ new Set();
			if (baseClasses) toClassList(baseClasses).forEach((cls) => initialBaseClasses.add(cls));
			manager = {
				element,
				sources: /* @__PURE__ */ new Map(),
				baseClasses: initialBaseClasses,
				isUpdating: false,
				nextOrder: 0,
				hasInitialized: false,
				restoreRafId: null,
				transitionsSuppressed: false,
				previousTransition: "",
				previousTransitionPriority: ""
			};
			elementClassManagers.set(element, manager);
			setupGlobalObserver(platformId);
			observedElements.add(element);
			if (isPlatformBrowser(platformId)) {
				manager.previousTransition = element.style.getPropertyValue("transition");
				manager.previousTransitionPriority = element.style.getPropertyPriority("transition");
				element.style.setProperty("transition", "none", "important");
				manager.transitionsSuppressed = true;
			}
		}
		const sourceOrder = manager.nextOrder++;
		function updateClasses() {
			const newClasses = toClassList(computed());
			manager.sources.set(sourceId, {
				classes: new Set(newClasses),
				order: sourceOrder
			});
			updateElement(manager);
			if (manager.transitionsSuppressed) {
				manager.transitionsSuppressed = false;
				manager.restoreRafId = requestAnimationFrame(() => {
					manager.restoreRafId = null;
					restoreTransitionSuppression(manager);
				});
			}
		}
		destroyRef.onDestroy(() => {
			if (manager.restoreRafId !== null) {
				cancelAnimationFrame(manager.restoreRafId);
				manager.restoreRafId = null;
			}
			if (manager.transitionsSuppressed) {
				manager.transitionsSuppressed = false;
				restoreTransitionSuppression(manager);
			}
			manager.sources.delete(sourceId);
			if (manager.sources.size === 0) cleanupManager(element);
			else updateElement(manager);
		});
		effect(updateClasses);
	});
}
function restoreTransitionSuppression(manager) {
	const prev = manager.previousTransition;
	if (prev) manager.element.style.setProperty("transition", prev, manager.previousTransitionPriority || void 0);
	else manager.element.style.removeProperty("transition");
}
function setupGlobalObserver(platformId) {
	if (isPlatformBrowser(platformId) && !globalObserver) {
		globalObserver = new MutationObserver((mutations) => {
			for (const mutation of mutations) if (mutation.type === "attributes" && mutation.attributeName === "class") {
				const element = mutation.target;
				const manager = elementClassManagers.get(element);
				if (manager && observedElements.has(element)) {
					if (manager.isUpdating) continue;
					const currentClasses = toClassList(element.className);
					const allSourceClasses = /* @__PURE__ */ new Set();
					for (const source of manager.sources.values()) for (const className of source.classes) allSourceClasses.add(className);
					manager.baseClasses.clear();
					for (const className of currentClasses) if (!allSourceClasses.has(className)) manager.baseClasses.add(className);
					updateElement(manager);
				}
			}
		});
		globalObserver.observe(document, {
			attributes: true,
			attributeFilter: ["class"],
			subtree: true
		});
	}
}
function updateElement(manager) {
	if (manager.isUpdating) return;
	manager.isUpdating = true;
	if (!manager.hasInitialized && manager.sources.size > 0) {
		const currentClasses = toClassList(manager.element.className);
		const allSourceClasses = /* @__PURE__ */ new Set();
		for (const source of manager.sources.values()) source.classes.forEach((className) => allSourceClasses.add(className));
		currentClasses.forEach((className) => {
			if (!allSourceClasses.has(className)) manager.baseClasses.add(className);
		});
		manager.hasInitialized = true;
	}
	const sortedSources = Array.from(manager.sources.entries()).sort(([, a], [, b]) => a.order - b.order);
	const allSourceClasses = [];
	for (const [, source] of sortedSources) allSourceClasses.push(...source.classes);
	const classesToApply = allSourceClasses.length > 0 || manager.baseClasses.size > 0 ? hlm([...allSourceClasses, ...manager.baseClasses]) : "";
	if (manager.element.className !== classesToApply) manager.element.className = classesToApply;
	manager.isUpdating = false;
}
function cleanupManager(element) {
	observedElements.delete(element);
	elementClassManagers.delete(element);
	if (observedElements.size === 0 && globalObserver) {
		globalObserver.disconnect();
		globalObserver = null;
	}
}
const classListCache = /* @__PURE__ */ new Map();
function toClassList(className) {
	if (typeof className === "string" && classListCache.has(className)) return classListCache.get(className);
	const result = clsx(className).split(" ").filter((c) => c.length > 0);
	if (typeof className === "string" && classListCache.size < 1e3) classListCache.set(className, result);
	return result;
}
const defaultConfig = {
	variant: "default",
	size: "default"
};
const BrnButtonConfigToken = new InjectionToken("BrnButtonConfig");
function injectBrnButtonConfig() {
	return inject(BrnButtonConfigToken, { optional: true }) ?? defaultConfig;
}
const buttonVariants = cva("focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 rounded-md border border-transparent bg-clip-padding text-sm font-medium focus-visible:ring-3 active:not-aria-[haspopup]:translate-y-px data-[matches-spartan-invalid=true]:ring-3 [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] group/button inline-flex shrink-0 items-center justify-center whitespace-nowrap transition-all outline-none select-none data-disabled:pointer-events-none data-disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/80",
			outline: "border-border bg-background hover:bg-muted hover:text-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50 aria-expanded:bg-muted aria-expanded:text-foreground shadow-xs",
			secondary: "bg-secondary text-secondary-foreground aria-expanded:bg-secondary aria-expanded:text-secondary-foreground hover:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)]",
			ghost: "hover:bg-muted hover:text-foreground dark:hover:bg-muted/50 aria-expanded:bg-muted aria-expanded:text-foreground",
			destructive: "bg-destructive/10 hover:bg-destructive/20 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/20 text-destructive focus-visible:border-destructive/40 dark:hover:bg-destructive/30",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 gap-1.5 px-2.5 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			xs: "h-6 gap-1 rounded-[min(var(--radius-md),8px)] px-2 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(3)]",
			sm: "h-8 gap-1 rounded-[min(var(--radius-md),10px)] px-2.5 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5",
			lg: "h-10 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			icon: "size-9",
			"icon-xs": "size-6 rounded-[min(var(--radius-md),8px)] in-data-[slot=button-group]:rounded-md [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(3)]",
			"icon-sm": "size-8 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-md",
			"icon-lg": "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var HlmButton = class HlmButton {
	_config = injectBrnButtonConfig();
	_additionalClasses = signal("", ...ngDevMode ? [{ debugName: "_additionalClasses" }] : /* istanbul ignore next */ []);
	variant = input(this._config.variant, ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(this._config.size, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => [buttonVariants({
			variant: this.variant(),
			size: this.size()
		}), this._additionalClasses()]);
	}
	setClass(classes) {
		this._additionalClasses.set(classes);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmButton,
		isStandalone: true,
		selector: "button[hlmBtn], a[hlmBtn]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "button" } },
		exportAs: ["hlmBtn"],
		hostDirectives: [{
			directive: i1$5.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[hlmBtn], a[hlmBtn]",
			exportAs: "hlmBtn",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: { "data-slot": "button" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
const VARIANTS = {
	primary: {
		spartan: "default",
		hover: "hover:bg-primary-hover",
		focus: "focus-visible:ring-ring"
	},
	secondary: {
		spartan: "secondary",
		hover: "",
		focus: "focus-visible:ring-ring"
	},
	outlined: {
		spartan: "outline",
		hover: "hover:bg-accent",
		focus: "focus-visible:ring-ring"
	},
	text: {
		spartan: "ghost",
		hover: "hover:bg-accent dark:hover:bg-accent",
		focus: "focus-visible:ring-ring"
	},
	danger: {
		spartan: "destructive",
		hover: "hover:bg-destructive hover:text-destructive-foreground dark:hover:bg-destructive",
		focus: "focus-visible:ring-destructive dark:focus-visible:ring-destructive"
	}
};
const SIZES$1 = {
	small: {
		spartan: "sm",
		spartanIconOnly: "icon-sm"
	},
	medium: {
		spartan: "default",
		spartanIconOnly: "icon"
	},
	large: {
		spartan: "lg",
		spartanIconOnly: "icon-lg"
	},
	touch: {
		spartan: "lg",
		spartanIconOnly: "icon-lg",
		extra: "h-auto min-h-12 min-w-12",
		extraIconOnly: "size-12"
	}
};
const PRESSED = "bg-foreground text-background hover:bg-foreground hover:text-background dark:bg-foreground dark:text-background dark:hover:bg-foreground dark:hover:text-background";
var NeatButton = class NeatButton {
	variant = input("primary", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	iconOnly = input(false, {
		...ngDevMode ? { debugName: "iconOnly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rounded = input(false, {
		...ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	pressed = input(void 0, ...ngDevMode ? [{ debugName: "pressed" }] : /* istanbul ignore next */ []);
	classes = computed(() => {
		const variant = VARIANTS[this.variant()];
		const size = SIZES$1[this.size()];
		const iconOnly = this.iconOnly();
		return hlm(buttonVariants({
			variant: variant.spartan,
			size: iconOnly ? size.spartanIconOnly : size.spartan
		}), variant.hover, variant.focus, iconOnly ? size.extraIconOnly : size.extra, this.rounded() && "rounded-full", this.pressed() && PRESSED);
	}, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatButton,
		isStandalone: true,
		selector: "button[neatButton], a[neatButton]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconOnly: {
				classPropertyName: "iconOnly",
				publicName: "iconOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rounded: {
				classPropertyName: "rounded",
				publicName: "rounded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pressed: {
				classPropertyName: "pressed",
				publicName: "pressed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "button" },
			properties: {
				"class": "classes()",
				"attr.aria-pressed": "pressed()"
			}
		},
		hostDirectives: [{
			directive: i1$5.BrnButton,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatButton], a[neatButton]",
			hostDirectives: [{
				directive: BrnButton,
				inputs: ["disabled"]
			}],
			host: {
				"data-slot": "button",
				"[class]": "classes()",
				"[attr.aria-pressed]": "pressed()"
			}
		}]
	}],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		iconOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconOnly",
				required: false
			}]
		}],
		rounded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		pressed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pressed",
				required: false
			}]
		}]
	}
});
const KIOSK_POINTER_IDLE_MS = 2500;
const ACTIVITY_EVENTS = [
	"pointermove",
	"pointerdown",
	"touchstart"
];
function kioskRequested(search) {
	const value = new URLSearchParams(search).get("kiosk");
	return value !== null && value !== "0" && value !== "false";
}
var KioskService = class KioskService {
	document = inject(DOCUMENT);
	isActive = signal(kioskRequested(this.document.location?.search ?? ""), ...ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ []);
	isPointerIdle = signal(false, ...ngDevMode ? [{ debugName: "isPointerIdle" }] : /* istanbul ignore next */ []);
	ownsFullscreen = false;
	idleTimer;
	active = this.isActive.asReadonly();
	pointerIdle = this.isPointerIdle.asReadonly();
	constructor() {
		const onActivity = () => this.onActivity();
		const onFullscreenChange = () => this.onFullscreenChange();
		const passive = { passive: true };
		this.document.addEventListener("fullscreenchange", onFullscreenChange);
		for (const type of ACTIVITY_EVENTS) this.document.addEventListener(type, onActivity, passive);
		this.restartIdleTimer();
		inject(DestroyRef).onDestroy(() => {
			this.document.removeEventListener("fullscreenchange", onFullscreenChange);
			for (const type of ACTIVITY_EVENTS) this.document.removeEventListener(type, onActivity, passive);
			clearTimeout(this.idleTimer);
		});
	}
	async enter() {
		this.isActive.set(true);
		const root = this.document.documentElement;
		if (typeof root.requestFullscreen !== "function" || this.document.fullscreenElement) return;
		try {
			await root.requestFullscreen();
			this.ownsFullscreen = this.document.fullscreenElement === root;
		} catch {}
	}
	async exit() {
		this.isActive.set(false);
		if (!this.ownsFullscreen) return;
		this.ownsFullscreen = false;
		if (!this.document.fullscreenElement || typeof this.document.exitFullscreen !== "function") return;
		try {
			await this.document.exitFullscreen();
		} catch {}
	}
	toggle() {
		return this.isActive() ? this.exit() : this.enter();
	}
	onFullscreenChange() {
		if (this.ownsFullscreen && !this.document.fullscreenElement) {
			this.ownsFullscreen = false;
			this.isActive.set(false);
		}
	}
	onActivity() {
		if (this.isPointerIdle()) this.isPointerIdle.set(false);
		this.restartIdleTimer();
	}
	restartIdleTimer() {
		clearTimeout(this.idleTimer);
		this.idleTimer = setTimeout(() => this.isPointerIdle.set(true), KIOSK_POINTER_IDLE_MS);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KioskService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KioskService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: KioskService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var NeatKioskExit = class NeatKioskExit {
	kiosk = inject(KioskService);
	control = viewChild.required(NeatButton, {
		...ngDevMode ? { debugName: "control" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	exited = output();
	focus() {
		this.control().nativeElement.focus();
	}
	exit() {
		this.kiosk.exit();
		this.exited.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatKioskExit,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatKioskExit,
		isStandalone: true,
		selector: "neat-kiosk-exit",
		outputs: { exited: "exited" },
		viewQueries: [{
			propertyName: "control",
			first: true,
			predicate: NeatButton,
			descendants: true,
			read: ElementRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <button
      neatButton
      type="button"
      class="shadow-md"
      variant="secondary"
      size="touch"
      rounded
      iconOnly
      aria-label="Exit kiosk mode"
      (click)="exit()"
    >
      <neat-icon name="kiosk-exit" />
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NeatButton,
			selector: "button[neatButton], a[neatButton]",
			inputs: [
				"variant",
				"size",
				"iconOnly",
				"rounded",
				"pressed"
			]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatKioskExit,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-kiosk-exit",
			imports: [NeatButton, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      neatButton
      type="button"
      class="shadow-md"
      variant="secondary"
      size="touch"
      rounded
      iconOnly
      aria-label="Exit kiosk mode"
      (click)="exit()"
    >
      <neat-icon name="kiosk-exit" />
    </button>
  `
		}]
	}],
	propDecorators: {
		control: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatButton), {
				read: ElementRef,
				isSignal: true
			}]
		}],
		exited: [{
			type: i0.Output,
			args: ["exited"]
		}]
	}
});
const DEFAULT_TOOLTIP_SVG_CLASS = "bg-foreground fill-foreground z-50 block size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px]";
const DEFAULT_TOOLTIP_CONTENT_CLASSES = hlm("data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 rounded-md px-3 py-1.5 text-xs bg-foreground text-background data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) text-balance");
const tooltipPositionVariants = cva("absolute", { variants: { position: {
	top: "bottom-0 left-[calc(50%-5px)] translate-y-full",
	bottom: "-top-2.5 left-[calc(50%-5px)] translate-y-0 rotate-180",
	left: "-end-2.5 top-[calc(50%-5px)] translate-y-0 rotate-270 rtl:-rotate-270",
	right: "-start-2.5 top-[calc(50%-5px)] translate-y-0 rotate-90 rtl:-rotate-90"
} } });
var HlmTooltip = class HlmTooltip {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HlmTooltip,
		isStandalone: true,
		selector: "[hlmTooltip]",
		providers: [provideBrnTooltipDefaultOptions({
			svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
			tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
			arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
		})],
		exportAs: ["hlmTooltip"],
		hostDirectives: [{
			directive: i1$4.BrnTooltip,
			inputs: [
				"brnTooltip",
				"hlmTooltip",
				"position",
				"position",
				"hideDelay",
				"hideDelay",
				"showDelay",
				"showDelay",
				"tooltipDisabled",
				"tooltipDisabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTooltip]",
			exportAs: "hlmTooltip",
			providers: [provideBrnTooltipDefaultOptions({
				svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
				tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
				arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
			})],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: [
					"brnTooltip: hlmTooltip",
					"position",
					"hideDelay",
					"showDelay",
					"tooltipDisabled"
				]
			}]
		}]
	}]
});
var NeatTooltip = class NeatTooltip {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatTooltip,
		isStandalone: true,
		selector: "[neatTooltip]",
		providers: [provideBrnTooltipDefaultOptions({
			svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
			tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
			arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
		})],
		hostDirectives: [{
			directive: i1$4.BrnTooltip,
			inputs: [
				"brnTooltip",
				"neatTooltip",
				"position",
				"neatTooltipPosition",
				"tooltipDisabled",
				"neatTooltipDisabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[neatTooltip]",
			providers: [provideBrnTooltipDefaultOptions({
				svgClasses: DEFAULT_TOOLTIP_SVG_CLASS,
				tooltipContentClasses: DEFAULT_TOOLTIP_CONTENT_CLASSES,
				arrowClasses: (position) => hlm(tooltipPositionVariants({ position }))
			})],
			hostDirectives: [{
				directive: BrnTooltip,
				inputs: [
					"brnTooltip: neatTooltip",
					"position: neatTooltipPosition",
					"tooltipDisabled: neatTooltipDisabled"
				]
			}]
		}]
	}]
});
var NeatLogo = class NeatLogo {
	theme = inject(ThemeService);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatLogo,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatLogo,
		isStandalone: true,
		selector: "neat-logo",
		ngImport: i0,
		template: `
    @if (theme.scheme() === 'dark') {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#fff" d="M100,69.23V100H69.23l0-.15a77,77,0,0,0-15.24-46Z" />
        <rect fill="#fff" x="69.24" width="30.76" height="30.77" />
        <rect fill="#fff" y="69.23" width="30.77" height="30.77" />
        <path fill="#fff" d="M46.06,46.13,0,30.77V0H30.77l.05.15A77.1,77.1,0,0,0,46.06,46.13Z" />
        <path
          fill="#fff"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    } @else {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#a4cc2d" d="M86.08,83.06,100,69.23V100S94.4,92.45,86.08,83.06Z" />
        <path
          fill="#d1cee6"
          d="M53.94,53.87,100,69.23,86.08,83.06C77.28,73.12,65.44,61.14,53.94,53.87Z"
        />
        <path
          fill="#5998dd"
          d="M53.94,53.87c11.5,7.27,23.34,19.25,32.14,29.19L69.18,99.85A77,77,0,0,0,53.94,53.87Z"
        />
        <path fill="#010f0e" d="M69.18,99.85l16.9-16.79C94.4,92.45,100,100,100,100H69.23Z" />
        <polygon fill="#2a9c4f" points="100 0 100 30.77 84.62 15.39 100 0" />
        <polygon fill="#010f0e" points="100 30.77 69.24 30.77 84.62 15.39 100 30.77" />
        <polygon fill="#a4cc2d" points="84.62 15.39 69.24 30.77 69.24 0 84.62 15.39" />
        <polygon fill="#c0e8db" points="30.77 69.23 15.39 84.62 0 69.23 30.77 69.23" />
        <polygon fill="#d26728" points="30.77 69.23 30.77 100 15.39 84.62 30.77 69.23" />
        <polygon fill="#010f0e" points="30.77 100 0 100 15.39 84.62 30.77 100" />
        <polygon fill="#2a9c4f" points="15.39 84.62 0 100 0 69.23 15.39 84.62" />
        <path fill="#d26728" d="M13.92,16.94,0,30.77V0S5.6,7.55,13.92,16.94Z" />
        <path
          fill="#010f0e"
          d="M46.06,46.13,0,30.77,13.92,16.94C22.72,26.88,34.56,38.86,46.06,46.13Z"
        />
        <path
          fill="#5998dd"
          d="M46.06,46.13c-11.5-7.27-23.34-19.25-32.14-29.19L30.82.15A77,77,0,0,0,46.06,46.13Z"
        />
        <polygon fill="#c0e8db" points="100 0 84.62 15.39 69.24 0 100 0" />
        <path fill="#d1cee6" d="M30.82.15,13.92,16.94C5.6,7.55,0,0,0,0H30.77Z" />
        <path
          fill="#010f0e"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    }
  `,
		isInline: true,
		styles: [":host{display:inline-flex}svg{height:1.75rem;width:auto}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatLogo,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-logo",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    @if (theme.scheme() === 'dark') {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#fff" d="M100,69.23V100H69.23l0-.15a77,77,0,0,0-15.24-46Z" />
        <rect fill="#fff" x="69.24" width="30.76" height="30.77" />
        <rect fill="#fff" y="69.23" width="30.77" height="30.77" />
        <path fill="#fff" d="M46.06,46.13,0,30.77V0H30.77l.05.15A77.1,77.1,0,0,0,46.06,46.13Z" />
        <path
          fill="#fff"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    } @else {
      <svg
        role="img"
        aria-label="SiMa.ai"
        viewBox="0 0 111.34 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path fill="#a4cc2d" d="M86.08,83.06,100,69.23V100S94.4,92.45,86.08,83.06Z" />
        <path
          fill="#d1cee6"
          d="M53.94,53.87,100,69.23,86.08,83.06C77.28,73.12,65.44,61.14,53.94,53.87Z"
        />
        <path
          fill="#5998dd"
          d="M53.94,53.87c11.5,7.27,23.34,19.25,32.14,29.19L69.18,99.85A77,77,0,0,0,53.94,53.87Z"
        />
        <path fill="#010f0e" d="M69.18,99.85l16.9-16.79C94.4,92.45,100,100,100,100H69.23Z" />
        <polygon fill="#2a9c4f" points="100 0 100 30.77 84.62 15.39 100 0" />
        <polygon fill="#010f0e" points="100 30.77 69.24 30.77 84.62 15.39 100 30.77" />
        <polygon fill="#a4cc2d" points="84.62 15.39 69.24 30.77 69.24 0 84.62 15.39" />
        <polygon fill="#c0e8db" points="30.77 69.23 15.39 84.62 0 69.23 30.77 69.23" />
        <polygon fill="#d26728" points="30.77 69.23 30.77 100 15.39 84.62 30.77 69.23" />
        <polygon fill="#010f0e" points="30.77 100 0 100 15.39 84.62 30.77 100" />
        <polygon fill="#2a9c4f" points="15.39 84.62 0 100 0 69.23 15.39 84.62" />
        <path fill="#d26728" d="M13.92,16.94,0,30.77V0S5.6,7.55,13.92,16.94Z" />
        <path
          fill="#010f0e"
          d="M46.06,46.13,0,30.77,13.92,16.94C22.72,26.88,34.56,38.86,46.06,46.13Z"
        />
        <path
          fill="#5998dd"
          d="M46.06,46.13c-11.5-7.27-23.34-19.25-32.14-29.19L30.82.15A77,77,0,0,0,46.06,46.13Z"
        />
        <polygon fill="#c0e8db" points="100 0 84.62 15.39 69.24 0 100 0" />
        <path fill="#d1cee6" d="M30.82.15,13.92,16.94C5.6,7.55,0,0,0,0H30.77Z" />
        <path
          fill="#010f0e"
          d="M103.34,0h3.28V.67h-1.27V4h-.74V.67h-1.27Zm8,0V4h-.76V1.34L109.72,4h-.79l-.85-2.69V4h-.76V0h1l1,3.27,1-3.27Z"
        />
      </svg>
    }
  `,
			styles: [":host{display:inline-flex}svg{height:1.75rem;width:auto}\n"]
		}]
	}]
});
var PageToolbarSlot = class PageToolbarSlot {
	current = signal(null, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	portal = this.current.asReadonly();
	register(portal) {
		if (isDevMode() && this.current() !== null) throw new Error("neat-ui: only one page toolbar at a time; remove the other *neatPageToolbar first.");
		this.current.set(portal);
	}
	unregister(portal) {
		if (portal.isAttached) portal.detach();
		if (this.current() === portal) this.current.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageToolbarSlot,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageToolbarSlot,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PageToolbarSlot,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var NeatPageToolbar = class NeatPageToolbar {
	constructor() {
		const slot = inject(PageToolbarSlot);
		const portal = new TemplatePortal(inject(TemplateRef), inject(ViewContainerRef));
		slot.register(portal);
		inject(DestroyRef).onDestroy(() => slot.unregister(portal));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPageToolbar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPageToolbar,
		isStandalone: true,
		selector: "[neatPageToolbar]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPageToolbar,
	decorators: [{
		type: Directive,
		args: [{ selector: "[neatPageToolbar]" }]
	}],
	ctorParameters: () => []
});
const RAIL_EXPANDED_KEY = "neat-ui:rail-expanded";
const PAGE_TOOLBAR_LABEL = "Page tools";
const ACTIVE_MATCH = {
	paths: "subset",
	queryParams: "ignored",
	matrixParams: "ignored",
	fragment: "ignored"
};
var NeatShell = class NeatShell {
	appName = input.required(...ngDevMode ? [{ debugName: "appName" }] : /* istanbul ignore next */ []);
	navItems = input.required(...ngDevMode ? [{ debugName: "navItems" }] : /* istanbul ignore next */ []);
	theme = inject(ThemeService);
	kiosk = inject(KioskService);
	pageToolbar = inject(PageToolbarSlot).portal;
	toolbarLabel = PAGE_TOOLBAR_LABEL;
	router = inject(Router);
	injector = inject(Injector);
	activeMatch = ACTIVE_MATCH;
	railExpanded = signal(safeStorage.get(RAIL_EXPANDED_KEY) === "true", ...ngDevMode ? [{ debugName: "railExpanded" }] : /* istanbul ignore next */ []);
	kioskExit = viewChild(NeatKioskExit, ...ngDevMode ? [{ debugName: "kioskExit" }] : /* istanbul ignore next */ []);
	kioskButton = viewChild("kioskButton", ...ngDevMode ? [{ debugName: "kioskButton" }] : /* istanbul ignore next */ []);
	pageTitle = computed(() => {
		const url = this.router.lastSuccessfulNavigation()?.finalUrl;
		if (!url) return "";
		return this.navItems().find((item) => containsTree(url, this.router.parseUrl(item.path), ACTIVE_MATCH))?.label ?? "";
	}, ...ngDevMode ? [{ debugName: "pageTitle" }] : /* istanbul ignore next */ []);
	constructor() {
		let wasActive = this.kiosk.active();
		effect(() => {
			const active = this.kiosk.active();
			if (active && !wasActive) afterNextRender(() => this.kioskExit()?.focus(), { injector: this.injector });
			wasActive = active;
		});
	}
	focusKioskButtonAfterExit() {
		afterNextRender(() => this.kioskButton()?.nativeElement.focus(), { injector: this.injector });
	}
	toggleRail() {
		const expanded = !this.railExpanded();
		this.railExpanded.set(expanded);
		safeStorage.set(RAIL_EXPANDED_KEY, String(expanded));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatShell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatShell,
		isStandalone: true,
		selector: "neat-shell",
		inputs: {
			appName: {
				classPropertyName: "appName",
				publicName: "appName",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			navItems: {
				classPropertyName: "navItems",
				publicName: "navItems",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { properties: { "attr.data-kiosk": "kiosk.active()" } },
		viewQueries: [{
			propertyName: "kioskExit",
			first: true,
			predicate: NeatKioskExit,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "kioskButton",
			first: true,
			predicate: ["kioskButton"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (kiosk.active()) {\n  <div class=\"kiosk-chrome\" [attr.data-shown]=\"!kiosk.pointerIdle()\">\n    <!-- First in the tab order, so it is reachable from the keyboard; drawn last (right). -->\n    <neat-kiosk-exit (exited)=\"focusKioskButtonAfterExit()\" />\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"kiosk-toolbar shadow-md\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n  </div>\n} @else {\n  <div class=\"rail\" [attr.data-expanded]=\"railExpanded()\">\n    <nav aria-label=\"Main\">\n      <ul class=\"rail-list\">\n        @for (item of navItems(); track item.path) {\n          <li>\n            <a\n              class=\"rail-item\"\n              [routerLink]=\"item.path\"\n              routerLinkActive=\"active\"\n              [routerLinkActiveOptions]=\"activeMatch\"\n              ariaCurrentWhenActive=\"page\"\n              [neatTooltip]=\"item.label\"\n              neatTooltipPosition=\"right\"\n              [neatTooltipDisabled]=\"railExpanded()\"\n            >\n              <neat-icon [name]=\"item.icon\" />\n              <span class=\"label\" [class.visually-hidden]=\"!railExpanded()\">{{ item.label }}</span>\n            </a>\n          </li>\n        }\n      </ul>\n    </nav>\n\n    <button\n      type=\"button\"\n      class=\"rail-item rail-toggle\"\n      aria-label=\"Show labels\"\n      [attr.aria-pressed]=\"railExpanded()\"\n      neatTooltip=\"Show labels\"\n      neatTooltipPosition=\"right\"\n      [neatTooltipDisabled]=\"railExpanded()\"\n      (click)=\"toggleRail()\"\n    >\n      <neat-icon [name]=\"railExpanded() ? 'rail-collapse' : 'rail-expand'\" />\n    </button>\n  </div>\n\n  <header class=\"topbar\">\n    <div class=\"brand\">\n      <neat-logo />\n      <span class=\"app-name\">{{ appName() }}</span>\n    </div>\n    @if (pageTitle(); as title) {\n      <h1 class=\"page-title\">{{ title }}</h1>\n    }\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"page-toolbar\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n    <div class=\"topbar-end\">\n      <ng-content select=\"[neatTopbarEnd]\" />\n    </div>\n    <div class=\"topbar-actions\">\n      <button\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Dark mode\"\n        [pressed]=\"theme.scheme() === 'dark'\"\n        neatTooltip=\"Dark mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"theme.toggle()\"\n      >\n        <neat-icon [name]=\"theme.scheme() === 'dark' ? 'sun' : 'moon'\" />\n      </button>\n      <button\n        #kioskButton\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Kiosk mode\"\n        neatTooltip=\"Kiosk mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"kiosk.toggle()\"\n      >\n        <neat-icon name=\"kiosk-enter\" />\n      </button>\n    </div>\n  </header>\n}\n\n<main class=\"content\">\n  <ng-content />\n</main>\n",
		styles: [":host{--neat-rail-width: 3.5rem;--neat-rail-width-expanded: 13rem;--neat-topbar-height: 3rem;display:grid;height:100dvh;overflow:hidden;background:var(--background);color:var(--foreground)}:host([data-kiosk=\"false\"]){grid-template-areas:\"rail topbar\" \"rail content\";grid-template-columns:auto minmax(0,1fr);grid-template-rows:var(--neat-topbar-height) minmax(0,1fr)}:host([data-kiosk=\"true\"]){grid-template-areas:\"content\";grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr)}.rail{grid-area:rail;display:flex;flex-direction:column;gap:.5rem;box-sizing:border-box;padding:.5rem;overflow:hidden;background:var(--sidebar);color:var(--sidebar-foreground);box-shadow:inset -1px 0 0 var(--sidebar-border)}.rail[data-expanded=false]{width:var(--neat-rail-width)}.rail[data-expanded=true]{width:var(--neat-rail-width-expanded)}@media(prefers-reduced-motion:no-preference){.rail{transition:width var(--neat-transition-duration)}}nav{flex:1;min-height:0;overflow:hidden auto}.rail-list{display:flex;flex-direction:column;gap:.25rem;margin:0;padding:0;list-style:none}.rail-item{display:flex;align-items:center;gap:.75rem;box-sizing:border-box;width:100%;min-height:2.5rem;padding:0 .625rem;border:0;border-radius:var(--radius);background:transparent;color:var(--muted-foreground);font:inherit;text-decoration:none;cursor:pointer}.rail-item:hover,.rail-item.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}.rail-item.active{font-weight:500}.rail-item:focus-visible{outline:var(--neat-focus-ring-width) solid var(--sidebar-ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}.rail-item neat-icon{flex:none}.label{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.rail-toggle{flex:none}.visually-hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.topbar{grid-area:topbar;display:flex;align-items:center;gap:1rem;min-width:0;padding-inline:1rem .5rem;border-block-end:1px solid var(--border)}.brand{display:flex;flex:none;align-items:center;gap:.5rem}.app-name{font-weight:700;white-space:nowrap}.page-title{flex:0 1 auto;min-width:0;margin:0;padding-inline-start:1rem;border-inline-start:1px solid var(--border);overflow:hidden;font-size:1rem;font-weight:500;line-height:1.5;white-space:nowrap;text-overflow:ellipsis}.page-toolbar{display:flex;flex:0 100 auto;align-self:stretch;align-items:center;gap:.5rem;min-width:0;padding-inline:.25rem;overflow:auto hidden;scrollbar-width:thin}.topbar-end{display:flex;flex:1 1 auto;min-width:0;align-items:center;justify-content:flex-end;gap:.5rem}.topbar-actions{display:flex;flex:none;align-items:center;gap:.25rem}.content{grid-area:content;min-width:0;min-height:0;overflow:hidden;isolation:isolate}.kiosk-chrome{grid-area:content;place-self:start end;z-index:1;display:flex;flex-direction:row-reverse;align-items:center;gap:.5rem;min-width:0;max-width:calc(100% - 2rem);margin:1rem}.kiosk-chrome[data-shown=false]:not(:has(:focus-visible)){opacity:0;pointer-events:none}@media(prefers-reduced-motion:no-preference){.kiosk-chrome{transition:opacity var(--neat-transition-duration)}}neat-kiosk-exit{flex:none}.kiosk-toolbar{display:flex;align-items:center;gap:.5rem;box-sizing:border-box;min-width:0;min-height:3rem;padding-inline:.75rem;overflow:auto hidden;scrollbar-width:thin;border:1px solid var(--border);border-radius:1.5rem;background:var(--background)}\n"],
		dependencies: [
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "component",
				type: NeatKioskExit,
				selector: "neat-kiosk-exit",
				outputs: ["exited"]
			},
			{
				kind: "component",
				type: NeatLogo,
				selector: "neat-logo"
			},
			{
				kind: "directive",
				type: NeatTooltip,
				selector: "[neatTooltip]"
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatShell,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-shell",
			imports: [
				CdkPortalOutlet,
				NeatButton,
				NeatIcon,
				NeatKioskExit,
				NeatLogo,
				NeatTooltip,
				RouterLink,
				RouterLinkActive
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[attr.data-kiosk]": "kiosk.active()" },
			template: "@if (kiosk.active()) {\n  <div class=\"kiosk-chrome\" [attr.data-shown]=\"!kiosk.pointerIdle()\">\n    <!-- First in the tab order, so it is reachable from the keyboard; drawn last (right). -->\n    <neat-kiosk-exit (exited)=\"focusKioskButtonAfterExit()\" />\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"kiosk-toolbar shadow-md\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n  </div>\n} @else {\n  <div class=\"rail\" [attr.data-expanded]=\"railExpanded()\">\n    <nav aria-label=\"Main\">\n      <ul class=\"rail-list\">\n        @for (item of navItems(); track item.path) {\n          <li>\n            <a\n              class=\"rail-item\"\n              [routerLink]=\"item.path\"\n              routerLinkActive=\"active\"\n              [routerLinkActiveOptions]=\"activeMatch\"\n              ariaCurrentWhenActive=\"page\"\n              [neatTooltip]=\"item.label\"\n              neatTooltipPosition=\"right\"\n              [neatTooltipDisabled]=\"railExpanded()\"\n            >\n              <neat-icon [name]=\"item.icon\" />\n              <span class=\"label\" [class.visually-hidden]=\"!railExpanded()\">{{ item.label }}</span>\n            </a>\n          </li>\n        }\n      </ul>\n    </nav>\n\n    <button\n      type=\"button\"\n      class=\"rail-item rail-toggle\"\n      aria-label=\"Show labels\"\n      [attr.aria-pressed]=\"railExpanded()\"\n      neatTooltip=\"Show labels\"\n      neatTooltipPosition=\"right\"\n      [neatTooltipDisabled]=\"railExpanded()\"\n      (click)=\"toggleRail()\"\n    >\n      <neat-icon [name]=\"railExpanded() ? 'rail-collapse' : 'rail-expand'\" />\n    </button>\n  </div>\n\n  <header class=\"topbar\">\n    <div class=\"brand\">\n      <neat-logo />\n      <span class=\"app-name\">{{ appName() }}</span>\n    </div>\n    @if (pageTitle(); as title) {\n      <h1 class=\"page-title\">{{ title }}</h1>\n    }\n    @if (pageToolbar(); as toolbar) {\n      <div class=\"page-toolbar\" role=\"group\" [attr.aria-label]=\"toolbarLabel\">\n        <ng-template [cdkPortalOutlet]=\"toolbar\" />\n      </div>\n    }\n    <div class=\"topbar-end\">\n      <ng-content select=\"[neatTopbarEnd]\" />\n    </div>\n    <div class=\"topbar-actions\">\n      <button\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Dark mode\"\n        [pressed]=\"theme.scheme() === 'dark'\"\n        neatTooltip=\"Dark mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"theme.toggle()\"\n      >\n        <neat-icon [name]=\"theme.scheme() === 'dark' ? 'sun' : 'moon'\" />\n      </button>\n      <button\n        #kioskButton\n        neatButton\n        type=\"button\"\n        variant=\"text\"\n        size=\"large\"\n        rounded\n        iconOnly\n        aria-label=\"Kiosk mode\"\n        neatTooltip=\"Kiosk mode\"\n        neatTooltipPosition=\"bottom\"\n        (click)=\"kiosk.toggle()\"\n      >\n        <neat-icon name=\"kiosk-enter\" />\n      </button>\n    </div>\n  </header>\n}\n\n<main class=\"content\">\n  <ng-content />\n</main>\n",
			styles: [":host{--neat-rail-width: 3.5rem;--neat-rail-width-expanded: 13rem;--neat-topbar-height: 3rem;display:grid;height:100dvh;overflow:hidden;background:var(--background);color:var(--foreground)}:host([data-kiosk=\"false\"]){grid-template-areas:\"rail topbar\" \"rail content\";grid-template-columns:auto minmax(0,1fr);grid-template-rows:var(--neat-topbar-height) minmax(0,1fr)}:host([data-kiosk=\"true\"]){grid-template-areas:\"content\";grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr)}.rail{grid-area:rail;display:flex;flex-direction:column;gap:.5rem;box-sizing:border-box;padding:.5rem;overflow:hidden;background:var(--sidebar);color:var(--sidebar-foreground);box-shadow:inset -1px 0 0 var(--sidebar-border)}.rail[data-expanded=false]{width:var(--neat-rail-width)}.rail[data-expanded=true]{width:var(--neat-rail-width-expanded)}@media(prefers-reduced-motion:no-preference){.rail{transition:width var(--neat-transition-duration)}}nav{flex:1;min-height:0;overflow:hidden auto}.rail-list{display:flex;flex-direction:column;gap:.25rem;margin:0;padding:0;list-style:none}.rail-item{display:flex;align-items:center;gap:.75rem;box-sizing:border-box;width:100%;min-height:2.5rem;padding:0 .625rem;border:0;border-radius:var(--radius);background:transparent;color:var(--muted-foreground);font:inherit;text-decoration:none;cursor:pointer}.rail-item:hover,.rail-item.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}.rail-item.active{font-weight:500}.rail-item:focus-visible{outline:var(--neat-focus-ring-width) solid var(--sidebar-ring);outline-offset:calc(-1 * var(--neat-focus-ring-width))}.rail-item neat-icon{flex:none}.label{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.rail-toggle{flex:none}.visually-hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.topbar{grid-area:topbar;display:flex;align-items:center;gap:1rem;min-width:0;padding-inline:1rem .5rem;border-block-end:1px solid var(--border)}.brand{display:flex;flex:none;align-items:center;gap:.5rem}.app-name{font-weight:700;white-space:nowrap}.page-title{flex:0 1 auto;min-width:0;margin:0;padding-inline-start:1rem;border-inline-start:1px solid var(--border);overflow:hidden;font-size:1rem;font-weight:500;line-height:1.5;white-space:nowrap;text-overflow:ellipsis}.page-toolbar{display:flex;flex:0 100 auto;align-self:stretch;align-items:center;gap:.5rem;min-width:0;padding-inline:.25rem;overflow:auto hidden;scrollbar-width:thin}.topbar-end{display:flex;flex:1 1 auto;min-width:0;align-items:center;justify-content:flex-end;gap:.5rem}.topbar-actions{display:flex;flex:none;align-items:center;gap:.25rem}.content{grid-area:content;min-width:0;min-height:0;overflow:hidden;isolation:isolate}.kiosk-chrome{grid-area:content;place-self:start end;z-index:1;display:flex;flex-direction:row-reverse;align-items:center;gap:.5rem;min-width:0;max-width:calc(100% - 2rem);margin:1rem}.kiosk-chrome[data-shown=false]:not(:has(:focus-visible)){opacity:0;pointer-events:none}@media(prefers-reduced-motion:no-preference){.kiosk-chrome{transition:opacity var(--neat-transition-duration)}}neat-kiosk-exit{flex:none}.kiosk-toolbar{display:flex;align-items:center;gap:.5rem;box-sizing:border-box;min-width:0;min-height:3rem;padding-inline:.75rem;overflow:auto hidden;scrollbar-width:thin;border:1px solid var(--border);border-radius:1.5rem;background:var(--background)}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		appName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appName",
				required: true
			}]
		}],
		navItems: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navItems",
				required: true
			}]
		}],
		kioskExit: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatKioskExit), { isSignal: true }]
		}],
		kioskButton: [{
			type: i0.ViewChild,
			args: ["kioskButton", { isSignal: true }]
		}]
	}
});
var NeatPage = class NeatPage {
	scroll = input("body", ...ngDevMode ? [{ debugName: "scroll" }] : /* istanbul ignore next */ []);
	padding = input("page", ...ngDevMode ? [{ debugName: "padding" }] : /* istanbul ignore next */ []);
	aside = input("closed", ...ngDevMode ? [{ debugName: "aside" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatPage,
		isStandalone: true,
		selector: "neat-page",
		inputs: {
			scroll: {
				classPropertyName: "scroll",
				publicName: "scroll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			padding: {
				classPropertyName: "padding",
				publicName: "padding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			aside: {
				classPropertyName: "aside",
				publicName: "aside",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <div class="body" [attr.data-scroll]="scroll()" [attr.data-padding]="padding()">
      <ng-content />
    </div>
    @if (aside() === 'open') {
      <aside>
        <ng-content select="[neatPageAside]" />
      </aside>
    }
  `,
		isInline: true,
		styles: [":host{display:flex;height:100%;overflow:hidden}.body{flex:1 1 0;min-width:0;box-sizing:border-box;height:100%}.body[data-scroll=body]{overflow:auto}.body[data-scroll=none]{overflow:hidden}.body[data-padding=page]{padding:var(--neat-space-6)}.body[data-padding=none]{padding:0}aside{flex:none;box-sizing:border-box;width:var(--neat-aside-width);height:100%;padding:var(--neat-space-4);overflow:auto;border-inline-start:1px solid var(--border)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPage,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <div class="body" [attr.data-scroll]="scroll()" [attr.data-padding]="padding()">
      <ng-content />
    </div>
    @if (aside() === 'open') {
      <aside>
        <ng-content select="[neatPageAside]" />
      </aside>
    }
  `,
			styles: [":host{display:flex;height:100%;overflow:hidden}.body{flex:1 1 0;min-width:0;box-sizing:border-box;height:100%}.body[data-scroll=body]{overflow:auto}.body[data-scroll=none]{overflow:hidden}.body[data-padding=page]{padding:var(--neat-space-6)}.body[data-padding=none]{padding:0}aside{flex:none;box-sizing:border-box;width:var(--neat-aside-width);height:100%;padding:var(--neat-space-4);overflow:auto;border-inline-start:1px solid var(--border)}\n"]
		}]
	}],
	propDecorators: {
		scroll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scroll",
				required: false
			}]
		}],
		padding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "padding",
				required: false
			}]
		}],
		aside: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "aside",
				required: false
			}]
		}]
	}
});
const SWITCH_HELM_CLASSES = {
	track: "data-checked:bg-primary data-unchecked:bg-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 dark:data-unchecked:bg-input/80 rounded-full border border-transparent shadow-xs focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 data-[size=default]:h-[18.4px] data-[size=default]:w-[32px] data-[size=sm]:h-[14px] data-[size=sm]:w-[24px] group/switch inline-flex shrink-0 items-center transition-all outline-none data-disabled:cursor-not-allowed data-disabled:opacity-50",
	thumb: "bg-background dark:data-unchecked:bg-foreground dark:data-checked:bg-primary-foreground rounded-full group-data-[size=default]/switch:size-4 group-data-[size=sm]/switch:size-3 data-unchecked:translate-x-0 data-checked:ltr:translate-x-[calc(100%-2px)] data-checked:rtl:-translate-x-[calc(100%-2px)] pointer-events-none block ring-0 transition-transform"
};
const HOST_CLASSES = "inline-flex items-center gap-2 rounded-md text-sm font-medium outline-none focus-visible:ring-3 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50";
var NeatSwitch = class NeatSwitch {
	checked = model(false, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	hostClasses = HOST_CLASSES;
	trackClasses = SWITCH_HELM_CLASSES.track;
	thumbClasses = SWITCH_HELM_CLASSES.thumb;
	state = computed(() => this.checked() ? "checked" : "unchecked", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	toggle() {
		this.checked.update((checked) => !checked);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSwitch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatSwitch,
		isStandalone: true,
		selector: "button[neatSwitch]",
		inputs: {
			checked: {
				classPropertyName: "checked",
				publicName: "checked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { checked: "checkedChange" },
		host: {
			attributes: {
				"data-slot": "switch",
				"type": "button",
				"role": "switch"
			},
			listeners: { "click": "toggle()" },
			properties: {
				"attr.aria-checked": "checked()",
				"disabled": "disabled()",
				"class": "hostClasses"
			}
		},
		ngImport: i0,
		template: `
    <span
      data-slot="switch-track"
      data-size="default"
      aria-hidden="true"
      [attr.data-state]="state()"
      [class]="trackClasses"
    >
      <span data-slot="switch-thumb" [attr.data-state]="state()" [class]="thumbClasses"></span>
    </span>
    <ng-content />
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSwitch,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[neatSwitch]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "switch",
				type: "button",
				role: "switch",
				"[attr.aria-checked]": "checked()",
				"[disabled]": "disabled()",
				"[class]": "hostClasses",
				"(click)": "toggle()"
			},
			template: `
    <span
      data-slot="switch-track"
      data-size="default"
      aria-hidden="true"
      [attr.data-state]="state()"
      [class]="trackClasses"
    >
      <span data-slot="switch-thumb" [attr.data-state]="state()" [class]="thumbClasses"></span>
    </span>
    <ng-content />
  `
		}]
	}],
	propDecorators: {
		checked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checked",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
const SLIDER_HELM_CLASSES = {
	root: "group flex w-full touch-none flex-col select-none data-vertical:h-full data-vertical:min-h-40 data-vertical:w-auto data-vertical:flex-row data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
	frame: "relative flex w-full items-center group-data-vertical:w-auto group-data-vertical:flex-col",
	track: "bg-muted rounded-full data-horizontal:h-1.5 data-horizontal:w-full data-vertical:h-full data-vertical:w-1.5 relative grow overflow-hidden",
	range: "bg-primary absolute select-none data-draggable-range:cursor-move data-horizontal:h-full data-vertical:w-full",
	thumb: "border-primary ring-ring/50 size-4 rounded-full border bg-white shadow-sm transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden absolute block shrink-0 select-none after:absolute after:-inset-2"
};
const TRACK_CLASSES = hlm(SLIDER_HELM_CLASSES.track, "bg-input");
const THUMB_CLASSES = hlm(SLIDER_HELM_CLASSES.thumb, "bg-background focus-visible:ring-ring");
var NeatSlider = class NeatSlider {
	value = model(0, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	min = input.required(...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input.required(...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	step = input.required(...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	describedBy = input(...ngDevMode ? [void 0, { debugName: "describedBy" }] : /* istanbul ignore next */ []);
	rootClasses = SLIDER_HELM_CLASSES.root;
	frameClasses = SLIDER_HELM_CLASSES.frame;
	trackClasses = TRACK_CLASSES;
	rangeClasses = SLIDER_HELM_CLASSES.range;
	thumbClasses = THUMB_CLASSES;
	disabledAttr;
	constructor() {
		const slider = inject(BrnSlider);
		this.disabledAttr = computed(() => slider.mutableDisabled() ? "true" : null, ...ngDevMode ? [{ debugName: "disabledAttr" }] : /* istanbul ignore next */ []);
		effect(() => slider.value.set([this.value()]));
		slider.valueChange.subscribe(([value]) => this.value.set(value));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSlider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatSlider,
		isStandalone: true,
		selector: "neat-slider",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { properties: { "class": "rootClasses" } },
		hostDirectives: [{
			directive: i1$3.BrnSlider,
			inputs: [
				"min",
				"min",
				"max",
				"max",
				"step",
				"step",
				"disabled",
				"disabled",
				"aria-label",
				"label"
			]
		}],
		ngImport: i0,
		template: `
    <div [class]="frameClasses">
      <div brnSliderTrack [class]="trackClasses">
        <div brnSliderRange [class]="rangeClasses"></div>
      </div>
      <span
        brnSliderThumb
        [class]="thumbClasses"
        [attr.aria-describedby]="describedBy() ?? null"
        [attr.aria-disabled]="disabledAttr()"
      ></span>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnSliderTrack,
				selector: "[brnSliderTrack]",
				exportAs: ["brnSliderTrack"]
			},
			{
				kind: "directive",
				type: BrnSliderRange,
				selector: "[brnSliderRange]",
				exportAs: ["brnSliderRange"]
			},
			{
				kind: "directive",
				type: BrnSliderThumb,
				selector: "[brnSliderThumb]",
				exportAs: ["brnSliderThumb"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSlider,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-slider",
			imports: [
				BrnSliderTrack,
				BrnSliderRange,
				BrnSliderThumb
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			hostDirectives: [{
				directive: BrnSlider,
				inputs: [
					"min",
					"max",
					"step",
					"disabled",
					"aria-label: label"
				]
			}],
			host: { "[class]": "rootClasses" },
			template: `
    <div [class]="frameClasses">
      <div brnSliderTrack [class]="trackClasses">
        <div brnSliderRange [class]="rangeClasses"></div>
      </div>
      <span
        brnSliderThumb
        [class]="thumbClasses"
        [attr.aria-describedby]="describedBy() ?? null"
        [attr.aria-disabled]="disabledAttr()"
      ></span>
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: true
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: true
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}]
	}
});
const toggleVariants = cva("hover:text-foreground aria-pressed:bg-muted focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 gap-1 rounded-md text-sm font-medium transition-[color,box-shadow] [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] group/toggle hover:bg-muted inline-flex items-center justify-center whitespace-nowrap outline-none focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0", {
	variants: {
		variant: {
			default: "bg-transparent",
			outline: "border-input hover:bg-muted border bg-transparent shadow-xs"
		},
		size: {
			default: "h-9 min-w-9 px-2.5",
			sm: "h-8 min-w-8 px-2.5",
			lg: "h-10 min-w-10 px-2.5"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var HlmToggle = class HlmToggle {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("default", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => toggleVariants({
			variant: this.variant(),
			size: this.size()
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmToggle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmToggle,
		isStandalone: true,
		selector: "button[hlmToggle]",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "toggle" } },
		exportAs: ["hlmToggle"],
		hostDirectives: [{
			directive: i1$2.BrnToggle,
			inputs: [
				"id",
				"id",
				"value",
				"value",
				"disabled",
				"disabled",
				"state",
				"state",
				"aria-label",
				"aria-label",
				"type",
				"type"
			],
			outputs: ["stateChange", "stateChange"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmToggle,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[hlmToggle]",
			exportAs: "hlmToggle",
			hostDirectives: [{
				directive: BrnToggle,
				inputs: [
					"id",
					"value",
					"disabled",
					"state",
					"aria-label",
					"type"
				],
				outputs: ["stateChange"]
			}],
			host: { "data-slot": "toggle" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
const SEGMENTED_HELM_CLASSES = {
	group: "rounded-md data-[spacing=0]:data-[variant=outline]:shadow-xs group/toggle-group flex w-fit flex-row items-center gap-[--spacing(var(--gap))] data-vertical:flex-col data-vertical:items-stretch",
	item: "data-[state=on]:bg-muted group-data-[spacing=0]/toggle-group:rounded-none group-data-[spacing=0]/toggle-group:px-2 group-data-[spacing=0]/toggle-group:shadow-none group-data-horizontal/toggle-group:data-[spacing=0]:first:rounded-s-md group-data-vertical/toggle-group:data-[spacing=0]:first:rounded-t-md group-data-horizontal/toggle-group:data-[spacing=0]:last:rounded-e-md group-data-vertical/toggle-group:data-[spacing=0]:last:rounded-b-md shrink-0 focus:z-10 focus-visible:z-10 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:border-s-0 group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:border-t-0 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-s group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-t"
};
const ITEM_CLASSES = hlm(SEGMENTED_HELM_CLASSES.item, toggleVariants({
	variant: "outline",
	size: "default"
}), "hover:bg-accent focus-visible:ring-ring", "data-[state=on]:bg-primary data-[state=on]:text-primary-foreground", "data-[state=on]:hover:bg-primary-hover data-[state=on]:hover:text-primary-foreground");
const MOVES = {
	ArrowRight: (index, count) => (index + 1) % count,
	ArrowDown: (index, count) => (index + 1) % count,
	ArrowLeft: (index, count) => (index - 1 + count) % count,
	ArrowUp: (index, count) => (index - 1 + count) % count,
	Home: () => 0,
	End: (_, count) => count - 1
};
var NeatSegmented = class NeatSegmented {
	value = model.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	groupClasses = SEGMENTED_HELM_CLASSES.group;
	itemClasses = ITEM_CLASSES;
	tabStop = computed(() => Math.max(0, this.options().findIndex((option) => option.value === this.value())), ...ngDevMode ? [{ debugName: "tabStop" }] : /* istanbul ignore next */ []);
	segments = viewChildren("segment", ...ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []);
	move(event, current) {
		const next = MOVES[event.key];
		if (!next || this.disabled()) return;
		event.preventDefault();
		const options = this.options();
		const index = next(current, options.length);
		this.value.set(options[index].value);
		this.segments()[index]?.nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatSegmented,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatSegmented,
		isStandalone: true,
		selector: "neat-segmented",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { classAttribute: "inline-flex" },
		viewQueries: [{
			propertyName: "segments",
			predicate: ["segment"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      role="radiogroup"
      [attr.aria-label]="label()"
      [attr.aria-disabled]="disabled() || null"
      data-variant="outline"
      data-spacing="0"
      data-orientation="horizontal"
      [class]="groupClasses"
    >
      @for (option of options(); track option.value; let index = $index) {
        <button
          #segment
          type="button"
          role="radio"
          [attr.aria-checked]="option.value === value()"
          [attr.data-state]="option.value === value() ? 'on' : 'off'"
          [tabIndex]="index === tabStop() ? 0 : -1"
          [disabled]="disabled()"
          data-variant="outline"
          data-size="default"
          data-spacing="0"
          [class]="itemClasses"
          (click)="value.set(option.value)"
          (keydown)="move($event, index)"
        >
          @if (option.icon) {
            <neat-icon [name]="option.icon" [size]="16" />
          }
          {{ option.label }}
        </button>
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatSegmented,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-segmented",
			imports: [NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "inline-flex" },
			template: `
    <div
      role="radiogroup"
      [attr.aria-label]="label()"
      [attr.aria-disabled]="disabled() || null"
      data-variant="outline"
      data-spacing="0"
      data-orientation="horizontal"
      [class]="groupClasses"
    >
      @for (option of options(); track option.value; let index = $index) {
        <button
          #segment
          type="button"
          role="radio"
          [attr.aria-checked]="option.value === value()"
          [attr.data-state]="option.value === value() ? 'on' : 'off'"
          [tabIndex]="index === tabStop() ? 0 : -1"
          [disabled]="disabled()"
          data-variant="outline"
          data-size="default"
          data-spacing="0"
          [class]="itemClasses"
          (click)="value.set(option.value)"
          (keydown)="move($event, index)"
        >
          @if (option.icon) {
            <neat-icon [name]="option.icon" [size]="16" />
          }
          {{ option.label }}
        </button>
      }
    </div>
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		segments: [{
			type: i0.ViewChildren,
			args: ["segment", { isSignal: true }]
		}]
	}
});
var HlmTabs = class HlmTabs {
	tab = input.required(...ngDevMode ? [{ debugName: "tab" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabs,
		isStandalone: true,
		selector: "[hlmTabs],hlm-tabs",
		inputs: { tab: {
			classPropertyName: "tab",
			publicName: "tab",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs" } },
		exportAs: ["hlmTabs"],
		hostDirectives: [{
			directive: i1$1.BrnTabs,
			inputs: [
				"orientation",
				"orientation",
				"activationMode",
				"activationMode",
				"brnTabs",
				"tab"
			],
			outputs: ["tabActivated", "tabActivated"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabs,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabs],hlm-tabs",
			exportAs: "hlmTabs",
			hostDirectives: [{
				directive: BrnTabs,
				inputs: [
					"orientation",
					"activationMode",
					"brnTabs: tab"
				],
				outputs: ["tabActivated"]
			}],
			host: { "data-slot": "tabs" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { tab: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "tab",
			required: true
		}]
	}] }
});
var HlmTabsContent = class HlmTabsContent {
	contentFor = input.required({
		...ngDevMode ? { debugName: "contentFor" } : /* istanbul ignore next */ {},
		alias: "hlmTabsContent"
	});
	constructor() {
		classes(() => "flex-1 text-sm outline-none");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsContent,
		isStandalone: true,
		selector: "[hlmTabsContent]",
		inputs: { contentFor: {
			classPropertyName: "contentFor",
			publicName: "hlmTabsContent",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs-content" } },
		exportAs: ["hlmTabsContent"],
		hostDirectives: [{
			directive: i1$1.BrnTabsContent,
			inputs: ["brnTabsContent", "hlmTabsContent"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsContent]",
			exportAs: "hlmTabsContent",
			hostDirectives: [{
				directive: BrnTabsContent,
				inputs: ["brnTabsContent: hlmTabsContent"]
			}],
			host: { "data-slot": "tabs-content" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { contentFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hlmTabsContent",
			required: true
		}]
	}] }
});
var HlmTabsContentLazy = class HlmTabsContentLazy {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsContentLazy,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HlmTabsContentLazy,
		isStandalone: true,
		selector: "ng-template[hlmTabsContentLazy]",
		exportAs: ["hlmTabsContentLazy"],
		hostDirectives: [{ directive: i1$1.BrnTabsContentLazy }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsContentLazy,
	decorators: [{
		type: Directive,
		args: [{
			selector: "ng-template[hlmTabsContentLazy]",
			exportAs: "hlmTabsContentLazy",
			hostDirectives: [BrnTabsContentLazy]
		}]
	}]
});
const listVariants = cva("rounded-lg p-[3px] group-data-horizontal/tabs:h-9 data-[variant=line]:rounded-none group/tabs-list text-muted-foreground inline-flex w-fit items-center justify-center group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col", {
	variants: { variant: {
		default: "bg-muted",
		line: "gap-1 bg-transparent"
	} },
	defaultVariants: { variant: "default" }
});
var HlmTabsList = class HlmTabsList {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	constructor() {
		classes(() => listVariants({ variant: this.variant() }));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsList,
		isStandalone: true,
		selector: "[hlmTabsList],hlm-tabs-list",
		inputs: { variant: {
			classPropertyName: "variant",
			publicName: "variant",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "tabs-list" },
			properties: { "attr.data-variant": "variant()" }
		},
		exportAs: ["hlmTabsList"],
		hostDirectives: [{ directive: i1$1.BrnTabsList }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsList,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsList],hlm-tabs-list",
			exportAs: "hlmTabsList",
			hostDirectives: [BrnTabsList],
			host: {
				"data-slot": "tabs-list",
				"[attr.data-variant]": "variant()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { variant: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "variant",
			required: false
		}]
	}] }
});
var HlmTabsPaginatedList = class HlmTabsPaginatedList extends BrnTabsPaginatedList {
	constructor() {
		super();
		classes(() => "relative flex flex-shrink-0 items-center gap-1 overflow-hidden");
	}
	items = contentChildren(BrnTabsTrigger, {
		...ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemsChanges = toObservable(this.items);
	tabListContainer = viewChild.required("tabListContainer", ...ngDevMode ? [{ debugName: "tabListContainer" }] : /* istanbul ignore next */ []);
	tabList = viewChild.required("tabList", ...ngDevMode ? [{ debugName: "tabList" }] : /* istanbul ignore next */ []);
	tabListInner = viewChild.required("tabListInner", ...ngDevMode ? [{ debugName: "tabListInner" }] : /* istanbul ignore next */ []);
	nextPaginator = viewChild.required("nextPaginator", ...ngDevMode ? [{ debugName: "nextPaginator" }] : /* istanbul ignore next */ []);
	previousPaginator = viewChild.required("previousPaginator", ...ngDevMode ? [{ debugName: "previousPaginator" }] : /* istanbul ignore next */ []);
	tabListClass = input("", {
		...ngDevMode ? { debugName: "tabListClass" } : /* istanbul ignore next */ {},
		alias: "tabListClass"
	});
	_tabListClass = computed(() => hlm(listVariants(), this.tabListClass()), ...ngDevMode ? [{ debugName: "_tabListClass" }] : /* istanbul ignore next */ []);
	paginationButtonClass = input("", ...ngDevMode ? [{ debugName: "paginationButtonClass" }] : /* istanbul ignore next */ []);
	_paginationButtonClass = computed(() => hlm("relative z-[2] select-none disabled:cursor-default", buttonVariants({
		variant: "ghost",
		size: "icon-sm"
	}), this.paginationButtonClass(), this.showPaginationControls() ? "inline-flex" : "hidden"), ...ngDevMode ? [{ debugName: "_paginationButtonClass" }] : /* istanbul ignore next */ []);
	_itemSelected(event) {
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsPaginatedList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: HlmTabsPaginatedList,
		isStandalone: true,
		selector: "hlm-paginated-tabs-list",
		inputs: {
			tabListClass: {
				classPropertyName: "tabListClass",
				publicName: "tabListClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			paginationButtonClass: {
				classPropertyName: "paginationButtonClass",
				publicName: "paginationButtonClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { attributes: { "data-slot": "tabs-paginated-list" } },
		queries: [{
			propertyName: "items",
			predicate: BrnTabsTrigger,
			isSignal: true
		}],
		viewQueries: [
			{
				propertyName: "tabListContainer",
				first: true,
				predicate: ["tabListContainer"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tabList",
				first: true,
				predicate: ["tabList"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "tabListInner",
				first: true,
				predicate: ["tabListInner"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "nextPaginator",
				first: true,
				predicate: ["nextPaginator"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "previousPaginator",
				first: true,
				predicate: ["previousPaginator"],
				descendants: true,
				isSignal: true
			}
		],
		exportAs: ["hlmTabsPaginatedList"],
		usesInheritance: true,
		ngImport: i0,
		template: `
    <button
      #previousPaginator
      data-pagination="previous"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollBefore || null"
      (click)="_handlePaginatorClick('before')"
      (mousedown)="_handlePaginatorPress('before', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="previous" [size]="16" />
    </button>

    <div
      #tabListContainer
      class="z-[1] flex grow overflow-hidden"
      (keydown)="_handleKeydown($event)"
    >
      <div
        class="relative grow transition-transform"
        #tabList
        role="tablist"
        (cdkObserveContent)="_onContentChanges()"
      >
        <div #tabListInner [class]="_tabListClass()">
          <ng-content />
        </div>
      </div>
    </div>

    <button
      #nextPaginator
      data-pagination="next"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollAfter || null"
      (click)="_handlePaginatorClick('after')"
      (mousedown)="_handlePaginatorPress('after', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="next" [size]="16" />
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: CdkObserveContent,
			selector: "[cdkObserveContent]",
			inputs: ["cdkObserveContentDisabled", "debounce"],
			outputs: ["cdkObserveContent"],
			exportAs: ["cdkObserveContent"]
		}, {
			kind: "component",
			type: NeatIcon,
			selector: "neat-icon",
			inputs: [
				"name",
				"size",
				"label"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsPaginatedList,
	decorators: [{
		type: Component,
		args: [{
			selector: "hlm-paginated-tabs-list",
			exportAs: "hlmTabsPaginatedList",
			imports: [CdkObserveContent, NeatIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "data-slot": "tabs-paginated-list" },
			template: `
    <button
      #previousPaginator
      data-pagination="previous"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollBefore || null"
      (click)="_handlePaginatorClick('before')"
      (mousedown)="_handlePaginatorPress('before', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="previous" [size]="16" />
    </button>

    <div
      #tabListContainer
      class="z-[1] flex grow overflow-hidden"
      (keydown)="_handleKeydown($event)"
    >
      <div
        class="relative grow transition-transform"
        #tabList
        role="tablist"
        (cdkObserveContent)="_onContentChanges()"
      >
        <div #tabListInner [class]="_tabListClass()">
          <ng-content />
        </div>
      </div>
    </div>

    <button
      #nextPaginator
      data-pagination="next"
      type="button"
      aria-hidden="true"
      tabindex="-1"
      [class]="_paginationButtonClass()"
      [disabled]="disableScrollAfter || null"
      (click)="_handlePaginatorClick('after')"
      (mousedown)="_handlePaginatorPress('after', $event)"
      (touchend)="_stopInterval()"
    >
      <neat-icon name="next" [size]="16" />
    </button>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		items: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => BrnTabsTrigger), {
				descendants: false,
				isSignal: true
			}]
		}],
		tabListContainer: [{
			type: i0.ViewChild,
			args: ["tabListContainer", { isSignal: true }]
		}],
		tabList: [{
			type: i0.ViewChild,
			args: ["tabList", { isSignal: true }]
		}],
		tabListInner: [{
			type: i0.ViewChild,
			args: ["tabListInner", { isSignal: true }]
		}],
		nextPaginator: [{
			type: i0.ViewChild,
			args: ["nextPaginator", { isSignal: true }]
		}],
		previousPaginator: [{
			type: i0.ViewChild,
			args: ["previousPaginator", { isSignal: true }]
		}],
		tabListClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tabListClass",
				required: false
			}]
		}],
		paginationButtonClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "paginationButtonClass",
				required: false
			}]
		}]
	}
});
var HlmTabsTrigger = class HlmTabsTrigger {
	triggerFor = input.required({
		...ngDevMode ? { debugName: "triggerFor" } : /* istanbul ignore next */ {},
		alias: "hlmTabsTrigger"
	});
	constructor() {
		classes(() => [
			`gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0`,
			"group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
			"data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground",
			"after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100"
		]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HlmTabsTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: HlmTabsTrigger,
		isStandalone: true,
		selector: "[hlmTabsTrigger]",
		inputs: { triggerFor: {
			classPropertyName: "triggerFor",
			publicName: "hlmTabsTrigger",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { attributes: { "data-slot": "tabs-trigger" } },
		exportAs: ["hlmTabsTrigger"],
		hostDirectives: [{
			directive: i1$1.BrnTabsTrigger,
			inputs: [
				"brnTabsTrigger",
				"hlmTabsTrigger",
				"disabled",
				"disabled"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HlmTabsTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[hlmTabsTrigger]",
			exportAs: "hlmTabsTrigger",
			hostDirectives: [{
				directive: BrnTabsTrigger,
				inputs: ["brnTabsTrigger: hlmTabsTrigger", "disabled"]
			}],
			host: { "data-slot": "tabs-trigger" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { triggerFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hlmTabsTrigger",
			required: true
		}]
	}] }
});
const TABS_HELM_CLASSES = {
	root: "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col",
	trigger: "gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0",
	triggerLine: "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
	triggerActive: "data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground",
	triggerIndicator: "after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100",
	content: "flex-1 text-sm outline-none"
};
const LIST_CLASSES = listVariants({ variant: "line" });
const TRIGGER_CLASSES = hlm(TABS_HELM_CLASSES.trigger, TABS_HELM_CLASSES.triggerLine, TABS_HELM_CLASSES.triggerActive, TABS_HELM_CLASSES.triggerIndicator, "focus-visible:ring-ring");
var NeatTab = class NeatTab {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	content = contentChild.required(TemplateRef, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatTab,
		isStandalone: true,
		selector: "neat-tab",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		queries: [{
			propertyName: "content",
			first: true,
			predicate: TemplateRef,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTab,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tab",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: ""
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		content: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => TemplateRef), { isSignal: true }]
		}]
	}
});
let nextTabsId = 0;
var NeatTabs = class NeatTabs {
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	tabs = contentChildren(NeatTab, ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	open = computed(() => {
		const tabs = this.tabs();
		return (tabs.find((tab) => tab.value() === this.value()) ?? tabs.find((tab) => !tab.disabled()))?.value();
	}, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	rootClasses = TABS_HELM_CLASSES.root;
	listClasses = LIST_CLASSES;
	triggerClasses = TRIGGER_CLASSES;
	contentClasses = TABS_HELM_CLASSES.content;
	prefix = `neat-tabs-${++nextTabsId}-`;
	constructor() {
		const tabs = inject(BrnTabs);
		effect(() => {
			const open = this.open();
			tabs.activeTab.set(open === void 0 ? void 0 : this.key(open));
		});
		tabs.tabActivated.subscribe((key) => this.value.set(key.slice(this.prefix.length)));
	}
	key(value) {
		return this.prefix + value;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatTabs,
		isStandalone: true,
		selector: "neat-tabs",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { properties: { "class": "rootClasses" } },
		queries: [{
			propertyName: "tabs",
			predicate: NeatTab,
			isSignal: true
		}],
		hostDirectives: [{ directive: i1$1.BrnTabs }],
		ngImport: i0,
		template: `
    <div brnTabsList data-variant="line" [attr.aria-label]="label()" [class]="listClasses">
      @for (tab of tabs(); track tab.value()) {
        <button
          [brnTabsTrigger]="key(tab.value())"
          [disabled]="tab.disabled()"
          [class]="triggerClasses"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    @for (tab of tabs(); track tab.value()) {
      @if (tab.value() === open()) {
        <div [brnTabsContent]="key(tab.value())" [class]="contentClasses">
          <ng-container [ngTemplateOutlet]="tab.content()" />
        </div>
      }
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: BrnTabsList,
				selector: "[brnTabsList]",
				exportAs: ["brnTabsList"]
			},
			{
				kind: "directive",
				type: BrnTabsTrigger,
				selector: "button[brnTabsTrigger]",
				inputs: ["brnTabsTrigger", "disabled"],
				exportAs: ["brnTabsTrigger"]
			},
			{
				kind: "directive",
				type: BrnTabsContent,
				selector: "[brnTabsContent]",
				inputs: ["brnTabsContent"],
				exportAs: ["brnTabsContent"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTabs,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tabs",
			imports: [
				BrnTabsList,
				BrnTabsTrigger,
				BrnTabsContent,
				NgTemplateOutlet
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			hostDirectives: [BrnTabs],
			host: { "[class]": "rootClasses" },
			template: `
    <div brnTabsList data-variant="line" [attr.aria-label]="label()" [class]="listClasses">
      @for (tab of tabs(); track tab.value()) {
        <button
          [brnTabsTrigger]="key(tab.value())"
          [disabled]="tab.disabled()"
          [class]="triggerClasses"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    @for (tab of tabs(); track tab.value()) {
      @if (tab.value() === open()) {
        <div [brnTabsContent]="key(tab.value())" [class]="contentClasses">
          <ng-container [ngTemplateOutlet]="tab.content()" />
        </div>
      }
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		tabs: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => NeatTab), { isSignal: true }]
		}]
	}
});
const INPUT_HELM_CLASSES = "dark:bg-input/30 border-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 h-9 rounded-md border bg-transparent px-2.5 py-1 text-base shadow-xs transition-[color,box-shadow] file:h-7 file:text-sm file:font-medium focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 md:text-sm file:text-foreground placeholder:text-muted-foreground w-full min-w-0 outline-none file:inline-flex file:border-0 file:bg-transparent disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50";
const OVERRIDES = "focus-visible:ring-ring dark:bg-transparent";
const SIZES = {
	small: "h-8",
	medium: ""
};
var NeatInput = class NeatInput {
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	classes = computed(() => hlm(INPUT_HELM_CLASSES, OVERRIDES, SIZES[this.size()]), ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatInput,
		isStandalone: true,
		selector: "input[neatInput]",
		inputs: { size: {
			classPropertyName: "size",
			publicName: "size",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "input" },
			properties: { "class": "classes()" }
		},
		hostDirectives: [{
			directive: i1.BrnInput,
			inputs: ["id", "id"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatInput,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[neatInput]",
			hostDirectives: [{
				directive: BrnInput,
				inputs: ["id"]
			}],
			host: {
				"data-slot": "input",
				"[class]": "classes()"
			}
		}]
	}],
	propDecorators: { size: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "size",
			required: false
		}]
	}] }
});
function parseMetadataMessage(text) {
	let parsed;
	try {
		parsed = JSON.parse(text);
	} catch {
		return null;
	}
	if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return null;
	if (typeof parsed.type !== "string") return null;
	return parsed;
}
const METADATA_QUEUE_LIMIT = 300;
const LATENESS_WINDOW_MS = 5e3;
const LATENESS_WINDOW_MIN_MESSAGES = 10;
const LATENESS_MEMORY_LIMIT = 1024;
const AUXILIARY_METADATA_TYPE$1 = "auxiliary-visualization";
const AUXILIARY_MAX_ID_LENGTH = 128;
function stateOf$1(queue) {
	return queue;
}
function metadataTypeOf(message) {
	if (message.type !== AUXILIARY_METADATA_TYPE$1) return message.type;
	const data = message.data;
	const id = typeof data?.id === "string" ? data.id.trim() : "";
	return id && id.length <= AUXILIARY_MAX_ID_LENGTH ? `${AUXILIARY_METADATA_TYPE$1}\u0000${id}` : AUXILIARY_METADATA_TYPE$1;
}
function createMetadataQueue() {
	return {
		timestamped: /* @__PURE__ */ new Map(),
		timestampedEntries: 0,
		arrival: [],
		presented: /* @__PURE__ */ new Map(),
		lastPresented: null,
		lastPresentedAt: 0,
		outcomes: [],
		stats: {
			timestampMatches: 0,
			arrivalFallbacks: 0,
			frameMisses: 0,
			expired: 0,
			evicted: 0,
			untimestampedReceived: 0,
			late: 0
		}
	};
}
function enqueueMetadata(handle, message, receivedAt) {
	const queue = stateOf$1(handle);
	const key = message._insight?.rtp_timestamp;
	const item = {
		receivedAt,
		data: message
	};
	if (key !== void 0 && Number.isInteger(key) && key >= 0 && key <= 4294967295) {
		if (isLate(queue, key)) {
			const presentedAt = queue.presented.get(key);
			queue.stats.late += 1;
			recordOutcome(queue, {
				at: queue.lastPresentedAt,
				late: true,
				latenessMs: presentedAt === void 0 ? null : Math.max(0, receivedAt - presentedAt)
			});
			return;
		}
		const byType = queue.timestamped.get(key) ?? /* @__PURE__ */ new Map();
		const type = metadataTypeOf(message);
		if (!byType.has(type)) queue.timestampedEntries += 1;
		queue.timestamped.delete(key);
		byType.delete(type);
		byType.set(type, item);
		queue.timestamped.set(key, byType);
		while (queue.timestampedEntries > METADATA_QUEUE_LIMIT) {
			const [oldest, evictedTypes] = queue.timestamped.entries().next().value;
			queue.timestampedEntries -= evictedTypes.size;
			queue.stats.evicted += evictedTypes.size;
			queue.timestamped.delete(oldest);
		}
		return;
	}
	queue.stats.untimestampedReceived += 1;
	queue.arrival.push(item);
	if (queue.arrival.length > METADATA_QUEUE_LIMIT) {
		const evicted = queue.arrival.length - METADATA_QUEUE_LIMIT;
		queue.arrival.splice(0, evicted);
		queue.stats.evicted += evicted;
	}
}
function takeMetadataForFrame(handle, rtpTimestamp, metadataRetentionMs, now) {
	const queue = stateOf$1(handle);
	pruneMetadataQueue(queue, metadataRetentionMs, now);
	const hasFrameTimestamp = rtpTimestamp !== null && Number.isInteger(rtpTimestamp) && rtpTimestamp >= 0;
	if (hasFrameTimestamp) {
		const key = rtpTimestamp >>> 0;
		recordPresentedFrame(queue, key, now);
		const byType = queue.timestamped.get(key) ?? null;
		if (byType && byType.size > 0) {
			queue.timestamped.delete(key);
			queue.timestampedEntries -= byType.size;
			queue.stats.timestampMatches += 1;
			for (let matched = 0; matched < byType.size; matched += 1) recordOutcome(queue, {
				at: now,
				late: false,
				latenessMs: null
			});
			return [...byType.values()];
		}
	}
	if (!hasFrameTimestamp) {
		let latest = null;
		let latestFrame = null;
		for (const byType of queue.timestamped.values()) for (const item of byType.values()) if (!latest || item.receivedAt >= latest.receivedAt) {
			latest = item;
			latestFrame = byType;
		}
		for (const item of queue.arrival) if (!latest || item.receivedAt >= latest.receivedAt) {
			latest = item;
			latestFrame = null;
		}
		queue.timestamped.clear();
		queue.timestampedEntries = 0;
		queue.arrival.length = 0;
		if (latest) {
			queue.stats.arrivalFallbacks += 1;
			return latestFrame ? [...latestFrame.values()] : [latest];
		}
	}
	if (queue.arrival.length > 0) {
		const latest = queue.arrival[queue.arrival.length - 1];
		queue.arrival.length = 0;
		queue.stats.arrivalFallbacks += 1;
		return [latest];
	}
	queue.stats.frameMisses += 1;
	return [];
}
const OVERLAY_HOLD_MS = 200;
function holdOverlays(held, overlays, now) {
	const fresh = /* @__PURE__ */ new Set();
	for (const item of overlays) {
		const type = metadataTypeOf(item.data);
		fresh.add(type);
		held.set(type, {
			item,
			matchedAt: now
		});
	}
	const repeats = [];
	for (const [type, { item, matchedAt }] of held) {
		if (fresh.has(type)) continue;
		if (now - matchedAt > 200) held.delete(type);
		else repeats.push({
			...item,
			held: true
		});
	}
	return [...overlays, ...repeats];
}
function metadataQueueSnapshot(handle) {
	const queue = stateOf$1(handle);
	const lateOutcomes = queue.outcomes.filter((outcome) => outcome.late);
	const lateness = lateOutcomes.map((outcome) => outcome.latenessMs).filter((value) => value !== null).sort((a, b) => a - b);
	return {
		...queue.stats,
		timestampedPending: queue.timestampedEntries,
		arrivalPending: queue.arrival.length,
		recentLateShare: queue.outcomes.length >= LATENESS_WINDOW_MIN_MESSAGES ? lateOutcomes.length / queue.outcomes.length : null,
		recentLatenessMedianMs: nearestRank(lateness, .5),
		recentLatenessP90Ms: nearestRank(lateness, .9),
		recentLatenessMaxMs: lateness.length ? lateness[lateness.length - 1] : null
	};
}
function resetLatenessWindow(handle) {
	stateOf$1(handle).outcomes.length = 0;
}
function isLate(queue, key) {
	return queue.lastPresented !== null && (key - queue.lastPresented | 0) <= 0;
}
function recordPresentedFrame(queue, key, now) {
	queue.presented.delete(key);
	queue.presented.set(key, now);
	queue.lastPresented = key;
	queue.lastPresentedAt = now;
	for (const [timestamp, presentedAt] of queue.presented) {
		if (now - presentedAt <= LATENESS_WINDOW_MS && queue.presented.size <= LATENESS_MEMORY_LIMIT) break;
		queue.presented.delete(timestamp);
	}
	let expired = 0;
	while (expired < queue.outcomes.length && now - queue.outcomes[expired].at > LATENESS_WINDOW_MS) expired += 1;
	if (expired > 0) queue.outcomes.splice(0, expired);
}
function recordOutcome(queue, outcome) {
	queue.outcomes.push(outcome);
	if (queue.outcomes.length > LATENESS_MEMORY_LIMIT) queue.outcomes.splice(0, queue.outcomes.length - LATENESS_MEMORY_LIMIT);
}
function nearestRank(sorted, fraction) {
	if (sorted.length === 0) return null;
	return sorted[Math.min(sorted.length - 1, Math.ceil(fraction * sorted.length) - 1)];
}
function pruneMetadataQueue(queue, metadataRetentionMs, now) {
	if (metadataRetentionMs <= 0) return;
	for (const [timestamp, byType] of queue.timestamped) {
		for (const [type, item] of byType) {
			if (now - item.receivedAt <= metadataRetentionMs) continue;
			byType.delete(type);
			queue.timestampedEntries -= 1;
			queue.stats.expired += 1;
		}
		if (byType.size === 0) queue.timestamped.delete(timestamp);
	}
	while (queue.arrival.length && now - queue.arrival[0].receivedAt > metadataRetentionMs) {
		queue.arrival.shift();
		queue.stats.expired += 1;
	}
}
const LATE_SHARE_ON = .5;
const LATE_SHARE_OFF = .1;
const BUFFER_MARGIN_MS = 50;
const BUFFER_STEP_MS = 50;
const BUFFER_MAX_MS = 4e3;
const SETTLE_MS_PER_RAISED_MS = 10;
const SETTLE_BASE_MS = 1e3;
function nextWarningActive(active, recentLateShare) {
	if (recentLateShare == null) return active;
	if (recentLateShare >= LATE_SHARE_ON) return true;
	if (recentLateShare < LATE_SHARE_OFF) return false;
	return active;
}
function suggestedBufferMs(currentBufferMs, p90LatenessMs) {
	if (p90LatenessMs === null) return null;
	if (!Number.isFinite(currentBufferMs) || !Number.isFinite(p90LatenessMs)) return null;
	const needed = currentBufferMs + p90LatenessMs + BUFFER_MARGIN_MS;
	const suggested = Math.ceil(needed / BUFFER_STEP_MS) * BUFFER_STEP_MS;
	return suggested > BUFFER_MAX_MS ? null : suggested;
}
function bufferSettleMs(previousBufferMs, nextBufferMs) {
	const raisedBy = Math.max(0, nextBufferMs - previousBufferMs);
	if (!Number.isFinite(raisedBy)) return SETTLE_BASE_MS;
	return raisedBy * SETTLE_MS_PER_RAISED_MS + SETTLE_BASE_MS;
}
function globalActionFor(suggested, followedBufferMs) {
	if (suggested === null) return null;
	if (typeof followedBufferMs === "number" && Number.isFinite(followedBufferMs) && followedBufferMs >= suggested) return {
		kind: "follow",
		valueMs: followedBufferMs
	};
	return {
		kind: "raise",
		valueMs: suggested
	};
}
function lateNoticeDetails(snapshot, currentBufferMs, bufferSupported, followedBufferMs) {
	const suggested = bufferSupported ? suggestedBufferMs(currentBufferMs, snapshot.recentLatenessP90Ms) : null;
	let blockedBy = null;
	if (!bufferSupported) blockedBy = "unsupported";
	else if (!Number.isFinite(snapshot.recentLatenessP90Ms)) blockedBy = "unmeasured";
	else if (suggested === null) blockedBy = "maximum";
	return {
		latenessMs: snapshot.recentLatenessMedianMs == null ? null : Math.round(snapshot.recentLatenessMedianMs),
		latePercent: snapshot.recentLateShare == null ? null : Math.round(snapshot.recentLateShare * 100),
		bufferMs: currentBufferMs,
		suggestedBufferMs: suggested,
		blockedBy,
		globalAction: globalActionFor(suggested, followedBufferMs)
	};
}
const OVERLAY_PALETTE = [
	"#2563eb",
	"#dc2626",
	"#16a34a",
	"#ca8a04",
	"#9333ea",
	"#0891b2",
	"#ea580c",
	"#4f46e5",
	"#be123c",
	"#0f766e",
	"#f472b6",
	"#84cc16",
	"#fbbf24",
	"#38bdf8",
	"#92400e",
	"#d946ef",
	"#14532d",
	"#fdba74",
	"#f43f5e",
	"#5eead4",
	"#989900",
	"#ff96d3",
	"#e1a0fe",
	"#b6b4ff",
	"#e2684a",
	"#267d30",
	"#4d7800",
	"#e06285",
	"#78c7fd",
	"#786900",
	"#bc6ece",
	"#10d8d8",
	"#927eec",
	"#2bdda4",
	"#66da85",
	"#ab413e",
	"#5590f3",
	"#8fd465",
	"#1899ec",
	"#b1cc46"
];
const OVERLAY_NEUTRAL_COLOR = "#f8fafc";
const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
const OVERLAY_ROI_COLORS = {
	inclusion: {
		fill: "rgba(0,255,0,0.1)",
		stroke: "green"
	},
	exclusion: {
		fill: "rgba(255,0,0,0.1)",
		stroke: "red"
	}
};
const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
const NEAT_OVERLAY_DEFAULTS = {
	general: {
		lineWidth: 3,
		showRoi: true,
		applyRoiFiltering: true
	},
	types: {
		"object-detection": {
			visible: true,
			confidenceThreshold: 0,
			objects: []
		},
		segmentation: {
			visible: true,
			confidenceThreshold: 0,
			maskOpacity: .4,
			objects: []
		},
		tracking: {
			visible: true,
			confidenceThreshold: 0,
			history: {
				enabled: true,
				trailLength: 10,
				lostTrackTtlMs: 2e3
			}
		},
		"pose-estimation": {
			visible: true,
			showKeypoints: true,
			showKeypointLabels: false
		},
		classification: { visible: true }
	},
	roi: []
};
const RELEASE_AFTER_MS = 5e3;
function createColorMap() {
	return {
		holders: /* @__PURE__ */ new Map(),
		insertions: 0
	};
}
var NeatOverlayColors = class NeatOverlayColors {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatOverlayColors,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatOverlayColors,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatOverlayColors,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const classColorsOf = /* @__PURE__ */ new WeakMap();
function identityKey(identity) {
	if (identity === null || identity === void 0) return null;
	const text = String(identity);
	return text === "" ? null : text;
}
function isStale(holder, now) {
	return now - holder.lastSeen > RELEASE_AFTER_MS;
}
function olderThan(a, b) {
	return a.lastSeen < b.lastSeen || a.lastSeen === b.lastSeen && a.order < b.order;
}
function holdersBySlot(map) {
	const bySlot = /* @__PURE__ */ new Map();
	for (const [key, holder] of map.holders) {
		const group = bySlot.get(holder.slot);
		if (group) group.push({
			key,
			holder
		});
		else bySlot.set(holder.slot, [{
			key,
			holder
		}]);
	}
	return bySlot;
}
function pruneStaleSharers(map, now) {
	for (const group of holdersBySlot(map).values()) {
		if (group.length < 2) continue;
		const stale = group.filter(({ holder }) => isStale(holder, now));
		if (stale.length === group.length) {
			stale.sort((a, b) => olderThan(a.holder, b.holder) ? 1 : -1);
			stale.shift();
		}
		for (const { key } of stale) map.holders.delete(key);
	}
}
function separateFromSharers(map, key, holder, now) {
	let live = false;
	for (const [otherKey, other] of map.holders) {
		if (otherKey === key || other.slot !== holder.slot) continue;
		if (isStale(other, now)) map.holders.delete(otherKey);
		else live = true;
	}
	if (live) map.holders.delete(key);
	return live;
}
function freeSlot(map) {
	const used = /* @__PURE__ */ new Set();
	for (const holder of map.holders.values()) used.add(holder.slot);
	for (let slot = 0; slot < OVERLAY_PALETTE.length; slot += 1) if (!used.has(slot)) return slot;
	return -1;
}
function reclaimStaleSlot(map, now) {
	let oldest = null;
	for (const [key, holder] of map.holders) if (isStale(holder, now) && (oldest === null || olderThan(holder, oldest.holder))) oldest = {
		key,
		holder
	};
	if (oldest === null) return -1;
	map.holders.delete(oldest.key);
	return oldest.holder.slot;
}
function sharedSlot(map) {
	let chosen = null;
	for (const [slot, group] of holdersBySlot(map)) {
		const latest = group.reduce((a, b) => olderThan(a.holder, b.holder) ? b : a).holder;
		const candidate = {
			slot,
			lastSeen: latest.lastSeen,
			order: latest.order
		};
		if (chosen === null || olderThan(candidate, chosen)) chosen = candidate;
	}
	return chosen?.slot ?? 0;
}
function createColorAllocator(colors) {
	const classColors = classColorsOf.get(colors) ?? createColorMap();
	classColorsOf.set(colors, classColors);
	const maps = /* @__PURE__ */ new Map();
	function mapFor(channelIndex, namespace) {
		if (namespace === "class") return classColors;
		const key = `${channelIndex}:${namespace}`;
		let map = maps.get(key);
		if (!map) {
			map = createColorMap();
			maps.set(key, map);
		}
		return map;
	}
	return {
		colorFor(channelIndex, namespace, identity, now) {
			const key = identityKey(identity);
			if (key === null) return OVERLAY_NEUTRAL_COLOR;
			const map = mapFor(channelIndex, namespace);
			const existing = map.holders.get(key);
			if (existing && !(isStale(existing, now) && separateFromSharers(map, key, existing, now))) {
				existing.lastSeen = now;
				return OVERLAY_PALETTE[existing.slot];
			}
			let slot = freeSlot(map);
			if (slot < 0) {
				pruneStaleSharers(map, now);
				slot = reclaimStaleSlot(map, now);
			}
			if (slot < 0) slot = sharedSlot(map);
			map.insertions += 1;
			map.holders.set(key, {
				slot,
				lastSeen: now,
				order: map.insertions
			});
			return OVERLAY_PALETTE[slot];
		},
		clear() {
			maps.clear();
		},
		size(channelIndex, namespace) {
			return mapFor(channelIndex, namespace).holders.size;
		}
	};
}
function resolveColor({ allocator, channelIndex, namespace, identity, overrides, now }) {
	const key = identityKey(identity);
	if (overrides) {
		const own = key === null ? void 0 : overrides[key];
		if (typeof own === "string") return own;
		const fallback = overrides["default"];
		if (typeof fallback === "string") return fallback;
	}
	if (key === null) return OVERLAY_NEUTRAL_COLOR;
	return allocator.colorFor(channelIndex, namespace, key, now);
}
function letterbox(videoWidth, videoHeight, boxWidth, boxHeight) {
	if (!videoWidth || !videoHeight) return {
		scaleX: 1,
		scaleY: 1,
		offsetX: 0,
		offsetY: 0
	};
	const videoAspect = videoWidth / videoHeight;
	let drawWidth;
	let drawHeight;
	let offsetX = 0;
	let offsetY = 0;
	if (boxWidth / boxHeight > videoAspect) {
		drawHeight = boxHeight;
		drawWidth = videoAspect * drawHeight;
		offsetX = (boxWidth - drawWidth) / 2;
	} else {
		drawWidth = boxWidth;
		drawHeight = drawWidth / videoAspect;
		offsetY = (boxHeight - drawHeight) / 2;
	}
	return {
		scaleX: drawWidth / videoWidth,
		scaleY: drawHeight / videoHeight,
		offsetX,
		offsetY
	};
}
const MAX_RLE_MASK_PIXELS = 4194304;
const offscreenMaskSurface = {
	createContext() {
		const context = new OffscreenCanvas(1, 1).getContext("2d");
		if (!context) throw new Error("OffscreenCanvas has no 2d context");
		return context;
	},
	wrapPixels: (pixels, width, height) => new ImageData(pixels, width, height)
};
function decodeRleMaskAlpha(pixels, counts, maskWidth, maskHeight) {
	const total = maskWidth * maskHeight;
	let pos = 0;
	let foreground = false;
	for (let i = 0; i < counts.length && pos < total; i += 1) {
		const run = Number(counts[i]);
		const end = run > 0 ? Math.min(pos + run, total) : pos;
		if (foreground) for (; pos < end; pos += 1) pixels[(pos % maskHeight * maskWidth + Math.floor(pos / maskHeight)) * 4 + 3] = 255;
		else pos = end;
		foreground = !foreground;
	}
	return pixels;
}
var RleMaskCanvas = class {
	surface;
	context = null;
	pixels = /* @__PURE__ */ new Uint8ClampedArray(0);
	constructor(surface) {
		this.surface = surface;
	}
	paint(counts, width, height, color) {
		this.context ??= this.surface.createContext();
		const context = this.context;
		if (context.canvas.width !== width) context.canvas.width = width;
		if (context.canvas.height !== height) context.canvas.height = height;
		const length = width * height * 4;
		if (this.pixels.length < length) this.pixels = new Uint8ClampedArray(length);
		else this.pixels.fill(0, 0, length);
		const pixels = this.pixels.subarray(0, length);
		decodeRleMaskAlpha(pixels, counts, width, height);
		context.putImageData(this.surface.wrapPixels(pixels, width, height), 0, 0);
		context.save();
		context.globalCompositeOperation = "source-in";
		context.fillStyle = color;
		context.fillRect(0, 0, width, height);
		context.restore();
		return context.canvas;
	}
};
let pageMaskCanvas = null;
function sharedMaskCanvas() {
	pageMaskCanvas ??= new RleMaskCanvas(offscreenMaskSurface);
	return pageMaskCanvas;
}
function mapRoi(polygons, videoWidth, videoHeight, box) {
	return {
		polygons: polygons.map(({ type, points }) => ({
			type,
			points: points.map((p) => [p.x * videoWidth * box.scaleX + box.offsetX, p.y * videoHeight * box.scaleY + box.offsetY])
		})),
		drawn: false
	};
}
function drawRoiOnce(ctx, roi) {
	if (roi.drawn) return;
	roi.drawn = true;
	for (const { type, points } of roi.polygons) {
		if (points.length < 3) continue;
		ctx.beginPath();
		ctx.moveTo(points[0][0], points[0][1]);
		for (let i = 1; i < points.length; i += 1) ctx.lineTo(points[i][0], points[i][1]);
		ctx.closePath();
		const colors = type === "inclusion" ? OVERLAY_ROI_COLORS.inclusion : OVERLAY_ROI_COLORS.exclusion;
		ctx.fillStyle = colors.fill;
		ctx.strokeStyle = colors.stroke;
		ctx.lineWidth = 2;
		ctx.fill();
		ctx.stroke();
	}
}
function contains(polygon, x, y) {
	const pts = polygon.points;
	if (pts.length < 3) return false;
	let inside = false;
	for (let i = 0, j = pts.length - 1; i < pts.length; j = i, i += 1) {
		const [xi, yi] = pts[i];
		const [xj, yj] = pts[j];
		if (yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi || 1e-6) + xi) inside = !inside;
	}
	return inside;
}
function passesRoiFilter(roi, bbox, box, applyRoiFiltering) {
	if (!applyRoiFiltering) return true;
	const [x, y, w, h] = bbox;
	const cx = (x + w / 2) * box.scaleX + box.offsetX;
	const cy = (y + h / 2) * box.scaleY + box.offsetY;
	const inclusion = roi.polygons.filter((polygon) => polygon.type === "inclusion");
	const exclusion = roi.polygons.filter((polygon) => polygon.type === "exclusion");
	return (inclusion.length === 0 || inclusion.some((polygon) => contains(polygon, cx, cy))) && !exclusion.some((polygon) => contains(polygon, cx, cy));
}
function identityColor(dc, namespace, identity, overrides) {
	return resolveColor({
		allocator: dc.colors,
		channelIndex: dc.channel,
		namespace,
		identity,
		overrides,
		now: dc.now
	});
}
function classStyles(rows) {
	const styles = Object.create(null);
	const overrides = Object.create(null);
	for (const row of rows) {
		styles[row.label] = row;
		overrides[row.label] = row.color;
	}
	return {
		styles,
		overrides
	};
}
function styleFor(styles, label) {
	return styles[String(label)] ?? styles["default"];
}
function applyLineStyle(ctx, style, lineWidth) {
	ctx.lineWidth = style?.width ?? lineWidth;
	ctx.setLineDash(style?.style === "dashed" ? [6, 4] : style?.style === "dotted" ? [2, 2] : []);
}
function drawLabelPlate(dc, text, x, y, color) {
	const { ctx } = dc;
	const paddingX = 4;
	const paddingY = 3;
	const height = 18;
	ctx.font = dc.fonts.label;
	const width = ctx.measureText(text).width + 8;
	const labelY = Math.max(20, y);
	ctx.fillStyle = OVERLAY_LABEL_PLATE_COLOR;
	ctx.fillRect(x, labelY - height, width, height);
	ctx.fillStyle = color;
	ctx.fillText(text, x + paddingX, labelY - paddingY);
}
function percent(confidence) {
	return Math.round(Number(confidence) * 100);
}
const drawClassification = (dc, data) => {
	const classes = data?.top_classes;
	if (!classes || !dc.settings.types.classification.visible) return;
	const { ctx, box } = dc;
	ctx.font = dc.fonts.large;
	classes.slice(0, 3).forEach((entry, i) => {
		ctx.fillStyle = identityColor(dc, "class", entry.label);
		ctx.fillText(`${entry.label} (${percent(entry.confidence)}%)`, 10 * box.scaleX + box.offsetX, (20 + i * 20) * box.scaleY + box.offsetY);
	});
};
const drawObjectDetection = (dc, data) => {
	const objects = data?.objects;
	if (!objects) return;
	const { ctx, box, settings } = dc;
	const type = settings.types["object-detection"];
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) return;
	const { styles, overrides } = classStyles(type.objects);
	for (const object of objects) {
		if (Number(object.confidence) < type.confidenceThreshold) continue;
		const [x, y, w, h] = object.bbox;
		if (!passesRoiFilter(dc.roi, object.bbox, box, settings.general.applyRoiFiltering)) continue;
		const color = identityColor(dc, "class", object.label, overrides);
		ctx.strokeStyle = color;
		applyLineStyle(ctx, styleFor(styles, object.label), settings.general.lineWidth);
		ctx.font = dc.fonts.label;
		ctx.fillStyle = color;
		ctx.strokeRect(x * box.scaleX + box.offsetX, y * box.scaleY + box.offsetY, w * box.scaleX, h * box.scaleY);
		ctx.fillText(`${object.label} (${percent(object.confidence)}%)`, (x + 2) * box.scaleX + box.offsetX, (y - 6) * box.scaleY + box.offsetY);
	}
};
const COCO_SKELETON = [
	["nose", "left_eye"],
	["nose", "right_eye"],
	["left_eye", "left_ear"],
	["right_eye", "right_ear"],
	["nose", "left_shoulder"],
	["nose", "right_shoulder"],
	["left_shoulder", "left_elbow"],
	["left_elbow", "left_wrist"],
	["right_shoulder", "right_elbow"],
	["right_elbow", "right_wrist"],
	["left_shoulder", "left_hip"],
	["right_shoulder", "right_hip"],
	["left_hip", "right_hip"],
	["left_hip", "left_knee"],
	["left_knee", "left_ankle"],
	["right_hip", "right_knee"],
	["right_knee", "right_ankle"]
];
const KEYPOINT_MIN_CONFIDENCE = .3;
const BOX_PADDING = 8;
function confidenceAlpha(confidence) {
	const value = Number.isFinite(Number(confidence)) ? Number(confidence) : 1;
	return .18 + .82 * Math.min(1, Math.max(0, value));
}
function hasId$1(id) {
	return id !== null && id !== void 0 && id !== "";
}
const drawPoseEstimation = (dc, data) => {
	const poses = data?.poses;
	const type = dc.settings.types["pose-estimation"];
	if (!poses || !type.visible) return;
	const { ctx, box } = dc;
	const at = (kp) => [kp.x * box.scaleX + box.offsetX, kp.y * box.scaleY + box.offsetY];
	ctx.lineWidth = dc.settings.general.lineWidth;
	ctx.setLineDash([]);
	ctx.font = dc.fonts.label;
	for (const pose of poses) {
		if (!Array.isArray(pose?.keypoints)) continue;
		const color = identityColor(dc, "pose", pose.id);
		const keypoints = pose.keypoints.filter((kp) => Boolean(kp));
		const byName = new Map(keypoints.map((kp) => [kp.name, kp]));
		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		for (const [a, b] of COCO_SKELETON) {
			const from = byName.get(a);
			const to = byName.get(b);
			if (!from || !to) continue;
			ctx.beginPath();
			ctx.moveTo(...at(from));
			ctx.lineTo(...at(to));
			ctx.globalAlpha = confidenceAlpha(Math.min(Number(from.confidence ?? 1), Number(to.confidence ?? 1)));
			ctx.stroke();
		}
		for (const kp of keypoints) {
			ctx.globalAlpha = confidenceAlpha(kp.confidence);
			if (type.showKeypoints) {
				ctx.beginPath();
				ctx.arc(...at(kp), 3, 0, 2 * Math.PI);
				ctx.fill();
			}
			if (type.showKeypointLabels) ctx.fillText(String(kp.name), (kp.x + 4) * box.scaleX + box.offsetX, (kp.y - 4) * box.scaleY + box.offsetY);
		}
		ctx.globalAlpha = 1;
		const confident = keypoints.filter((kp) => Number(kp.confidence) > KEYPOINT_MIN_CONFIDENCE);
		if (confident.length < 2) continue;
		const xs = confident.map((kp) => kp.x);
		const ys = confident.map((kp) => kp.y);
		const left = Math.min(...xs) - BOX_PADDING;
		const top = Math.min(...ys) - BOX_PADDING;
		const width = Math.max(...xs) - Math.min(...xs) + 16;
		const height = Math.max(...ys) - Math.min(...ys) + 16;
		const boxLeft = left * box.scaleX + box.offsetX;
		const boxTop = top * box.scaleY + box.offsetY;
		ctx.strokeRect(boxLeft, boxTop, width * box.scaleX, height * box.scaleY);
		drawLabelPlate(dc, `${pose.label || "pose"}${hasId$1(pose.id) ? ` #${pose.id}` : ""}`, boxLeft, boxTop - 6, color);
	}
};
function polygonBounds(points) {
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const [px, py] of points) {
		if (px < minX) minX = px;
		if (py < minY) minY = py;
		if (px > maxX) maxX = px;
		if (py > maxY) maxY = py;
	}
	return [
		minX,
		minY,
		maxX - minX,
		maxY - minY
	];
}
function warnDropped(dc, id, reason) {
	const name = String(id ?? "<no id>");
	dc.warnOnce(`segment:${name}`, `segmentation: channel ${dc.channel} dropped RLE segment "${name}": ${reason}`);
}
function drawRleMask(dc, segment, bbox, color, opacity) {
	const mask = segment.mask;
	if (!mask || !Array.isArray(mask.size)) {
		warnDropped(dc, segment.id, "mask.size must be an array [mask_h, mask_w]");
		return false;
	}
	if (!Array.isArray(mask.counts)) {
		warnDropped(dc, segment.id, "mask.counts must be an array of run lengths, not a compressed byte string");
		return false;
	}
	const maskHeight = Math.floor(mask.size[0]);
	const maskWidth = Math.floor(mask.size[1]);
	if (!(maskWidth > 0) || !(maskHeight > 0)) {
		warnDropped(dc, segment.id, `mask.size must be positive, got ${maskHeight}x${maskWidth}`);
		return false;
	}
	if (maskWidth * maskHeight > 4194304) {
		warnDropped(dc, segment.id, `mask is ${maskHeight}x${maskWidth}, over the ${MAX_RLE_MASK_PIXELS} pixel decode buffer limit`);
		return false;
	}
	const image = dc.masks.paint(mask.counts, maskWidth, maskHeight, color);
	const { ctx, box } = dc;
	ctx.save();
	ctx.globalAlpha = opacity;
	ctx.imageSmoothingEnabled = true;
	ctx.drawImage(image, bbox[0] * box.scaleX + box.offsetX, bbox[1] * box.scaleY + box.offsetY, bbox[2] * box.scaleX, bbox[3] * box.scaleY);
	ctx.restore();
	return true;
}
const drawSegmentation = (dc, data) => {
	const segments = data?.segments;
	if (!Array.isArray(segments)) return;
	const { ctx, box, settings } = dc;
	const type = settings.types.segmentation;
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) return;
	const { styles, overrides } = classStyles(type.objects);
	for (const segment of segments) {
		const confidence = segment.confidence ?? 1;
		if (Number(confidence) < type.confidenceThreshold) continue;
		if (segment.mask_format !== "polygon" && segment.mask_format !== "rle") continue;
		let bbox = Array.isArray(segment.bbox) && segment.bbox.length === 4 ? segment.bbox : null;
		let polygon = null;
		if (segment.mask_format === "polygon") {
			if (!Array.isArray(segment.mask) || segment.mask.length < 3) continue;
			polygon = segment.mask;
			bbox ??= polygonBounds(polygon);
		}
		if (!bbox) {
			warnDropped(dc, segment.id, "an RLE mask needs a bbox as its destination rectangle");
			continue;
		}
		if (!passesRoiFilter(dc.roi, bbox, box, settings.general.applyRoiFiltering)) continue;
		const color = identityColor(dc, "class", segment.label, overrides);
		ctx.strokeStyle = color;
		applyLineStyle(ctx, styleFor(styles, segment.label), settings.general.lineWidth);
		ctx.font = dc.fonts.label;
		ctx.fillStyle = color;
		if (polygon) {
			ctx.beginPath();
			ctx.moveTo(polygon[0][0] * box.scaleX + box.offsetX, polygon[0][1] * box.scaleY + box.offsetY);
			for (let i = 1; i < polygon.length; i += 1) ctx.lineTo(polygon[i][0] * box.scaleX + box.offsetX, polygon[i][1] * box.scaleY + box.offsetY);
			ctx.closePath();
			ctx.save();
			ctx.globalAlpha = type.maskOpacity;
			ctx.fill();
			ctx.restore();
			ctx.stroke();
		} else if (!drawRleMask(dc, segment, bbox, color, type.maskOpacity)) continue;
		if (segment.show_rectangle === true) ctx.strokeRect(bbox[0] * box.scaleX + box.offsetX, bbox[1] * box.scaleY + box.offsetY, bbox[2] * box.scaleX, bbox[3] * box.scaleY);
		ctx.fillText(`${segment.label} (${percent(confidence)}%)`, (bbox[0] + 2) * box.scaleX + box.offsetX, (bbox[1] - 6) * box.scaleY + box.offsetY);
	}
};
function hasId(id) {
	return id !== null && id !== void 0 && id !== "";
}
function isIdentified(track) {
	return track.id !== null && track.id !== void 0;
}
function isDrawable(track) {
	const bbox = track?.bbox;
	return Array.isArray(bbox) && bbox.length >= 4 && bbox.slice(0, 4).every(Number.isFinite);
}
function updateTrackHistory(history, tracks, now, settings) {
	if (!settings.enabled) {
		history.clear();
		return;
	}
	const trailLength = Math.max(1, settings.trailLength);
	const current = /* @__PURE__ */ new Set();
	for (const track of tracks) {
		if (!isIdentified(track)) continue;
		const key = String(track.id);
		const [x, y, width, height] = track.bbox;
		current.add(key);
		const trail = history.get(key) ?? {
			points: [],
			lastSeen: now
		};
		trail.points = [...trail.points, {
			x: x + width / 2,
			y: y + height / 2
		}].slice(-trailLength);
		trail.lastSeen = now;
		history.set(key, trail);
	}
	for (const [key, trail] of history) if (!current.has(key) && now - trail.lastSeen > settings.lostTrackTtlMs) history.delete(key);
}
function drawTrail(dc, points, color, alpha) {
	if (points.length < 2) return;
	const { ctx, box } = dc;
	ctx.save();
	ctx.strokeStyle = color;
	ctx.lineWidth = dc.settings.general.lineWidth;
	ctx.globalAlpha = alpha;
	ctx.setLineDash([]);
	ctx.beginPath();
	points.forEach((point, i) => {
		const x = point.x * box.scaleX + box.offsetX;
		const y = point.y * box.scaleY + box.offsetY;
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	});
	ctx.stroke();
	ctx.restore();
}
const drawTracking = (dc, data) => {
	const tracks = data?.tracks;
	if (!Array.isArray(tracks)) return;
	const { ctx, box, settings } = dc;
	const type = settings.types.tracking;
	const visible = tracks.filter((track) => isDrawable(track) && !(Number(track.confidence ?? 1) < type.confidenceThreshold) && passesRoiFilter(dc.roi, track.bbox, box, settings.general.applyRoiFiltering));
	if (settings.general.showRoi) drawRoiOnce(ctx, dc.roi);
	if (!type.visible) {
		dc.trackHistory.clear();
		return;
	}
	if (!dc.held) updateTrackHistory(dc.trackHistory, visible, dc.now, type.history);
	const frameColors = /* @__PURE__ */ new Map();
	const trackColor = (id) => {
		if (id === null || id === void 0) return identityColor(dc, "track", id);
		const key = String(id);
		let color = frameColors.get(key);
		if (color === void 0) {
			color = identityColor(dc, "track", id);
			frameColors.set(key, color);
		}
		return color;
	};
	if (type.history.enabled) {
		const active = new Set(visible.filter(isIdentified).map((track) => String(track.id)));
		for (const [key, trail] of dc.trackHistory) drawTrail(dc, trail.points, trackColor(key), active.has(key) ? .72 : .35);
	}
	for (const track of visible) {
		const [x, y, w, h] = track.bbox;
		const color = trackColor(track.id);
		const left = x * box.scaleX + box.offsetX;
		const top = y * box.scaleY + box.offsetY;
		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		ctx.lineWidth = settings.general.lineWidth;
		ctx.setLineDash([]);
		ctx.strokeRect(left, top, w * box.scaleX, h * box.scaleY);
		const idText = hasId(track.id) ? ` #${track.id}` : "";
		const confidence = typeof track.confidence === "number" ? ` (${percent(track.confidence)}%)` : "";
		drawLabelPlate(dc, `${track.label || "track"}${idText}${confidence}`, left, top - 6, color);
	}
};
function stateOf(state) {
	return state;
}
const STRATEGIES = /* @__PURE__ */ new Map([
	["object-detection", drawObjectDetection],
	["segmentation", drawSegmentation],
	["tracking", drawTracking],
	["pose-estimation", drawPoseEstimation],
	["classification", drawClassification]
]);
const AUXILIARY_METADATA_TYPE = "auxiliary-visualization";
const WARNING_MEMORY_LIMIT = 64;
const FALLBACK_FONTS = fontsOf("sans-serif");
function fontsOf(family) {
	return {
		label: `14px ${family}`,
		large: `16px ${family}`
	};
}
function createOverlayState(channel, colors) {
	return newOverlayState(channel, colors, sharedMaskCanvas());
}
function newOverlayState(channel, colors, masks) {
	return {
		channel,
		colors: createColorAllocator(colors),
		trackHistory: /* @__PURE__ */ new Map(),
		masks,
		warned: {
			unknown: /* @__PURE__ */ new Set(),
			failed: /* @__PURE__ */ new Set(),
			strategy: /* @__PURE__ */ new Set()
		},
		fonts: null
	};
}
function resetOverlayState(handle) {
	const state = stateOf(handle);
	state.trackHistory.clear();
	state.colors.clear();
}
function warnOnce(state, kind, key, message, ...details) {
	const warned = state.warned[kind];
	if (warned.has(key) || warned.size >= WARNING_MEMORY_LIMIT) return;
	warned.add(key);
	console.warn(message, ...details);
}
function fontsFor(state, canvas) {
	if (state.fonts) return state.fonts;
	const family = canvas instanceof HTMLCanvasElement ? getComputedStyle(canvas).getPropertyValue("--font-sans").trim() : "";
	if (!family) return FALLBACK_FONTS;
	state.fonts = fontsOf(family);
	return state.fonts;
}
function drawFrame(ctx, view, items, handle, settings, now) {
	const state = stateOf(handle);
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
	ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
	if (items.length === 0) return;
	const box = letterbox(view.videoWidth, view.videoHeight, view.cssWidth, view.cssHeight);
	const frame = {
		ctx,
		channel: state.channel,
		settings,
		box,
		roi: mapRoi(settings.roi, view.videoWidth, view.videoHeight, box),
		colors: state.colors,
		fonts: fontsFor(state, ctx.canvas),
		now,
		trackHistory: state.trackHistory,
		masks: state.masks,
		warnOnce: (key, message) => warnOnce(state, "strategy", key, message)
	};
	for (const { message, held } of items) {
		const { type } = message;
		if (type === AUXILIARY_METADATA_TYPE) continue;
		const draw = STRATEGIES.get(type);
		if (!draw) {
			warnOnce(state, "unknown", type, `metadata: channel ${state.channel} has no overlay for type "${type}"`);
			continue;
		}
		ctx.save();
		try {
			draw({
				...frame,
				held
			}, message.data);
		} catch (error) {
			warnOnce(state, "failed", type, `metadata: channel ${state.channel} failed to draw ${type}`, error);
		} finally {
			ctx.restore();
		}
	}
}
const NEAT_MIN_TILE_WIDTH = 64;
const HEIGHT_PER_WIDTH = {
	"16:9": 9 / 16,
	"1:1": 1
};
function sanitizeArea(area) {
	const dimension = (value) => Number.isFinite(value) && value > 0 ? value : 0;
	return {
		width: dimension(area.width),
		height: dimension(area.height)
	};
}
function sanitizeGap(gap) {
	return Number.isFinite(gap) && gap > 0 ? gap : 0;
}
function packTiles(area, tileWidth, aspect, gap) {
	const ratio = HEIGHT_PER_WIDTH[aspect];
	const { width: areaWidth, height: areaHeight } = sanitizeArea(area);
	const spacing = sanitizeGap(gap);
	const requested = Number.isNaN(tileWidth) ? 64 : Math.max(64, tileWidth);
	const fitting = Math.min(requested, areaWidth, areaHeight / ratio);
	const width = Math.max(1, fitting < requested ? Math.floor(fitting) : requested);
	const height = width * ratio;
	const columns = Math.max(1, Math.floor((areaWidth + spacing) / (width + spacing)));
	const rows = Math.max(1, Math.floor((areaHeight + spacing) / (height + spacing)));
	return {
		columns,
		rows,
		perPage: columns * rows,
		tileWidth: width,
		tileHeight: height
	};
}
function fitAllTileWidth(area, count, aspect, gap) {
	const ratio = HEIGHT_PER_WIDTH[aspect];
	const { width: areaWidth, height: areaHeight } = sanitizeArea(area);
	const spacing = sanitizeGap(gap);
	const tiles = Number.isFinite(count) ? Math.max(1, Math.floor(count)) : 1;
	const widestRow = Math.floor((areaWidth + spacing) / (64 + spacing));
	const maxColumns = Math.min(tiles, Math.max(1, widestRow));
	let widest = 64;
	for (let columns = 1; columns <= maxColumns; columns++) {
		const rows = Math.ceil(tiles / columns);
		const byWidth = (areaWidth - (columns - 1) * spacing) / columns;
		const byHeight = (areaHeight - (rows - 1) * spacing) / rows / ratio;
		widest = Math.max(widest, Math.floor(Math.min(byWidth, byHeight)));
	}
	return widest;
}
const FALLBACK_GAP = 8;
function sameArea(a, b) {
	return a.width === b.width && a.height === b.height;
}
function sameLayout(a, b) {
	if (a === null || b === null) return a === b;
	return Object.keys(a).every((field) => a[field] === b[field]);
}
var NeatTileGrid = class NeatTileGrid {
	tileWidth = input.required(...ngDevMode ? [{ debugName: "tileWidth" }] : /* istanbul ignore next */ []);
	aspect = input("16:9", ...ngDevMode ? [{ debugName: "aspect" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	count = input.required(...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	layout = output();
	gridElement = viewChild.required("grid", ...ngDevMode ? [{ debugName: "gridElement" }] : /* istanbul ignore next */ []);
	area = signal(null, {
		...ngDevMode ? { debugName: "area" } : /* istanbul ignore next */ {},
		equal: (a, b) => a === null || b === null ? a === b : sameArea(a, b)
	});
	tokenGap = signal(null, ...ngDevMode ? [{ debugName: "tokenGap" }] : /* istanbul ignore next */ []);
	gapPx = computed(() => {
		const token = this.tokenGap();
		return token === null ? null : this.gap() ?? token;
	}, ...ngDevMode ? [{ debugName: "gapPx" }] : /* istanbul ignore next */ []);
	packed = computed(() => {
		const area = this.area();
		const gap = this.gapPx();
		if (area === null || !(area.width > 0 && area.height > 0) || gap === null) return null;
		return {
			...packTiles(area, this.tileWidth(), this.aspect(), gap),
			gap,
			areaWidth: area.width,
			areaHeight: area.height
		};
	}, {
		...ngDevMode ? { debugName: "packed" } : /* istanbul ignore next */ {},
		equal: sameLayout
	});
	view = computed(() => {
		const packed = this.packed();
		if (packed === null) return null;
		return {
			...packed,
			columns: Math.min(packed.columns, Math.max(1, this.count()))
		};
	}, ...ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []);
	constructor() {
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		effect(() => {
			const layout = this.packed();
			if (layout !== null) untracked(() => this.layout.emit(layout));
		});
		afterNextRender(() => {
			const resolved = parseFloat(getComputedStyle(this.gridElement().nativeElement).columnGap);
			this.tokenGap.set(Number.isFinite(resolved) ? resolved : FALLBACK_GAP);
			const observer = new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.area.set({
					width,
					height
				});
			});
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatTileGrid,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatTileGrid,
		isStandalone: true,
		selector: "neat-tile-grid",
		inputs: {
			tileWidth: {
				classPropertyName: "tileWidth",
				publicName: "tileWidth",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			aspect: {
				classPropertyName: "aspect",
				publicName: "aspect",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { layout: "layout" },
		viewQueries: [{
			propertyName: "gridElement",
			first: true,
			predicate: ["grid"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      #grid
      class="grid"
      [attr.data-ready]="view() !== null"
      [style.--grid-columns]="view()?.columns"
      [style.--grid-tile-width.px]="view()?.tileWidth"
      [style.--grid-tile-height.px]="view()?.tileHeight"
      [style.--grid-gap.px]="gapPx()"
    >
      <ng-content />
    </div>
  `,
		isInline: true,
		styles: [":host{display:block;width:100%;height:100%;min-height:0;overflow:hidden}.grid{display:grid;box-sizing:border-box;width:100%;height:100%;justify-content:center;align-content:center;grid-template-columns:repeat(var(--grid-columns, 1),var(--grid-tile-width, auto));grid-auto-rows:var(--grid-tile-height, auto);gap:var(--grid-gap, var(--neat-space-2))}.grid[data-ready=false]{visibility:hidden}.grid[data-ready=true]{visibility:visible}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatTileGrid,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-tile-grid",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <div
      #grid
      class="grid"
      [attr.data-ready]="view() !== null"
      [style.--grid-columns]="view()?.columns"
      [style.--grid-tile-width.px]="view()?.tileWidth"
      [style.--grid-tile-height.px]="view()?.tileHeight"
      [style.--grid-gap.px]="gapPx()"
    >
      <ng-content />
    </div>
  `,
			styles: [":host{display:block;width:100%;height:100%;min-height:0;overflow:hidden}.grid{display:grid;box-sizing:border-box;width:100%;height:100%;justify-content:center;align-content:center;grid-template-columns:repeat(var(--grid-columns, 1),var(--grid-tile-width, auto));grid-auto-rows:var(--grid-tile-height, auto);gap:var(--grid-gap, var(--neat-space-2))}.grid[data-ready=false]{visibility:hidden}.grid[data-ready=true]{visibility:visible}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		tileWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tileWidth",
				required: true
			}]
		}],
		aspect: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "aspect",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: true
			}]
		}],
		layout: [{
			type: i0.Output,
			args: ["layout"]
		}],
		gridElement: [{
			type: i0.ViewChild,
			args: ["grid", { isSignal: true }]
		}]
	}
});
function startFrameLoop(video, onFrame, onNoCurrentFrame) {
	return typeof video.requestVideoFrameCallback === "function" ? videoFrameLoop(video, onFrame, onNoCurrentFrame) : animationFrameLoop(video, onFrame, onNoCurrentFrame);
}
function hasCurrentFrame(video) {
	return video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA;
}
function videoFrameLoop(video, onFrame, onNoCurrentFrame) {
	let stopped = false;
	let pending = 0;
	const request = () => {
		pending = video.requestVideoFrameCallback((now, metadata) => {
			if (stopped) return;
			request();
			if (hasCurrentFrame(video)) onFrame({
				now,
				rtpTimestamp: metadata.rtpTimestamp ?? null
			});
			else onNoCurrentFrame();
		});
	};
	request();
	return () => {
		stopped = true;
		video.cancelVideoFrameCallback(pending);
	};
}
function animationFrameLoop(video, onFrame, onNoCurrentFrame) {
	let stopped = false;
	let pending = 0;
	let decoded = 0;
	const request = () => {
		pending = requestAnimationFrame((now) => {
			if (stopped) return;
			request();
			if (!hasCurrentFrame(video)) {
				onNoCurrentFrame();
				return;
			}
			const total = video.getVideoPlaybackQuality().totalVideoFrames;
			if (total === decoded) return;
			decoded = total;
			onFrame({
				now,
				rtpTimestamp: null
			});
		});
	};
	request();
	return () => {
		stopped = true;
		cancelAnimationFrame(pending);
	};
}
const NEAT_STREAM_STALE_MS = 1800;
const FRAME_STATS_INTERVAL_MS = 1e3;
const MAX_CANVAS_DPR = 2;
var NeatVideoTile = class NeatVideoTile {
	source = input(null, ...ngDevMode ? [{ debugName: "source" }] : /* istanbul ignore next */ []);
	settings = input(NEAT_OVERLAY_DEFAULTS, ...ngDevMode ? [{ debugName: "settings" }] : /* istanbul ignore next */ []);
	retentionMs = input(0, ...ngDevMode ? [{ debugName: "retentionMs" }] : /* istanbul ignore next */ []);
	channel = input(0, ...ngDevMode ? [{ debugName: "channel" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	status = input(null, ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	bars = input(true, ...ngDevMode ? [{ debugName: "bars" }] : /* istanbul ignore next */ []);
	selected = input(false, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	stateChange = output();
	frameStats = output();
	state = signal("empty", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	videoElement = viewChild.required("video", ...ngDevMode ? [{ debugName: "videoElement" }] : /* istanbul ignore next */ []);
	canvasElement = viewChild.required("canvas", ...ngDevMode ? [{ debugName: "canvasElement" }] : /* istanbul ignore next */ []);
	colors = inject(NeatOverlayColors);
	zone = inject(NgZone);
	document = inject(DOCUMENT);
	frameSettings = NEAT_OVERLAY_DEFAULTS;
	frameRetentionMs = 0;
	overlayState = null;
	currentState = "empty";
	canvas = null;
	context = null;
	view = {
		cssWidth: 0,
		cssHeight: 0,
		dpr: 1,
		videoWidth: 0,
		videoHeight: 0
	};
	playing = null;
	queue = createMetadataQueue();
	held = /* @__PURE__ */ new Map();
	lastFrameAt = null;
	staleTimer = null;
	staleCheckSawHidden = false;
	messagesThisSecond = 0;
	warnedUnreadable = false;
	warnedPlayback = false;
	destroyed = false;
	constructor() {
		effect(() => {
			this.frameSettings = this.settings();
			this.frameRetentionMs = this.retentionMs();
		});
		effect(() => {
			this.overlayState = createOverlayState(this.channel(), this.colors);
		});
		const host = inject(ElementRef).nativeElement;
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			this.canvas = this.canvasElement().nativeElement;
			const observer = this.zone.runOutsideAngular(() => new ResizeObserver((entries) => {
				const { width, height } = entries[entries.length - 1].contentRect;
				this.view.cssWidth = width;
				this.view.cssHeight = height;
				this.sizeCanvas(currentDpr());
			}));
			observer.observe(host);
			destroyRef.onDestroy(() => observer.disconnect());
		});
		afterRenderEffect(() => {
			const source = this.source();
			const stream = source?.stream() ?? null;
			untracked(() => this.play(source, stream));
		});
		destroyRef.onDestroy(() => {
			this.destroyed = true;
			this.stop();
		});
	}
	snapshot() {
		return metadataQueueSnapshot(this.queue);
	}
	resetLatenessWindow() {
		resetLatenessWindow(this.queue);
	}
	play(source, stream) {
		if (this.playing?.source === source && this.playing.stream === stream) return;
		this.stop();
		if (source === null || stream === null) return;
		const video = this.videoElement().nativeElement;
		this.context ??= this.canvasElement().nativeElement.getContext("2d");
		this.queue = createMetadataQueue();
		this.lastFrameAt = null;
		this.staleCheckSawHidden = false;
		this.messagesThisSecond = 0;
		video.srcObject = stream;
		this.startPlayback(video);
		const replay = () => this.startPlayback(video);
		const tracks = stream.getVideoTracks();
		for (const track of tracks) track.addEventListener("unmute", replay);
		const unsubscribe = source.onMetadata((text, receivedAt) => this.receive(text, receivedAt));
		const stopTimers = this.zone.runOutsideAngular(() => {
			const stopFrames = startFrameLoop(video, (frame) => this.present(frame, video), () => this.clearOverlays());
			const statsTimer = setInterval(() => this.reportFrameStats(video), FRAME_STATS_INTERVAL_MS);
			return () => {
				stopFrames();
				clearInterval(statsTimer);
			};
		});
		this.playing = {
			source,
			stream,
			stop: () => {
				stopTimers();
				unsubscribe();
				for (const track of tracks) track.removeEventListener("unmute", replay);
				video.srcObject = null;
			}
		};
	}
	startPlayback(video) {
		video.play().catch((error) => {
			if (error instanceof DOMException && error.name === "AbortError") return;
			if (this.warnedPlayback) return;
			this.warnedPlayback = true;
			const reason = error instanceof DOMException ? `${error.name}: ${error.message}` : error;
			console.warn(`video: channel ${this.channel()} cannot play its stream (${reason})`);
		});
	}
	stop() {
		if (this.playing === null) return;
		this.playing.stop();
		this.playing = null;
		if (this.staleTimer !== null) clearTimeout(this.staleTimer);
		this.staleTimer = null;
		this.clearOverlays();
		this.setState("empty");
	}
	receive(text, receivedAt) {
		const message = parseMetadataMessage(text);
		if (message === null) {
			if (!this.warnedUnreadable) {
				this.warnedUnreadable = true;
				console.warn(`metadata: channel ${this.channel()} dropped a message that is not a JSON object with a string "type"; later ones are dropped silently`);
			}
			return;
		}
		this.messagesThisSecond += 1;
		enqueueMetadata(this.queue, message, receivedAt);
	}
	present({ now, rtpTimestamp }, video) {
		this.lastFrameAt = now;
		this.setState("playing");
		this.staleTimer ??= setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS);
		const items = holdOverlays(this.held, takeMetadataForFrame(this.queue, rtpTimestamp, this.frameRetentionMs, now), now);
		const ctx = this.context;
		if (ctx === null || this.overlayState === null) return;
		const dpr = currentDpr();
		if (dpr !== this.view.dpr) this.sizeCanvas(dpr);
		this.view.videoWidth = video.videoWidth;
		this.view.videoHeight = video.videoHeight;
		drawFrame(ctx, this.view, items.map((item) => ({
			message: item.data,
			held: item.held === true
		})), this.overlayState, this.frameSettings, now);
	}
	checkStale() {
		this.staleTimer = null;
		if (this.lastFrameAt === null) return;
		const idle = performance.now() - this.lastFrameAt;
		if (this.document.hidden || this.staleCheckSawHidden) {
			this.staleCheckSawHidden = this.document.hidden;
			this.staleTimer = setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS);
			return;
		}
		if (idle < 1800) {
			this.staleTimer = setTimeout(() => this.checkStale(), NEAT_STREAM_STALE_MS - idle);
			return;
		}
		this.clearOverlays();
		this.setState("stopped");
	}
	clearOverlays() {
		const ctx = this.context;
		if (ctx !== null) {
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
		}
		this.held.clear();
		if (this.overlayState !== null) resetOverlayState(this.overlayState);
	}
	setState(next) {
		if (this.currentState === next) return;
		this.currentState = next;
		this.state.set(next);
		if (!this.destroyed) this.stateChange.emit(next);
	}
	reportFrameStats(video) {
		const snapshot = metadataQueueSnapshot(this.queue);
		const lastFrameAt = this.lastFrameAt;
		this.frameStats.emit({
			timestampMatches: snapshot.timestampMatches,
			arrivalFallbacks: snapshot.arrivalFallbacks,
			frameMisses: snapshot.frameMisses,
			expired: snapshot.expired,
			evicted: snapshot.evicted,
			late: snapshot.late,
			untimestampedReceived: snapshot.untimestampedReceived,
			timestampedPending: snapshot.timestampedPending,
			arrivalPending: snapshot.arrivalPending,
			recentLatenessMedianMs: snapshot.recentLatenessMedianMs,
			recentLatenessMaxMs: snapshot.recentLatenessMaxMs,
			metadataMessagesPerSecond: this.messagesThisSecond,
			video: {
				readyState: video.readyState,
				paused: video.paused,
				currentTime: video.currentTime,
				videoWidth: video.videoWidth,
				videoHeight: video.videoHeight,
				lastFrameAgeMs: lastFrameAt === null ? null : Math.round(performance.now() - lastFrameAt),
				active: this.currentState === "playing"
			}
		});
		this.messagesThisSecond = 0;
	}
	sizeCanvas(dpr) {
		const canvas = this.canvas;
		if (canvas === null) return;
		this.view.dpr = dpr;
		canvas.width = Math.round(this.view.cssWidth * dpr);
		canvas.height = Math.round(this.view.cssHeight * dpr);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatVideoTile,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatVideoTile,
		isStandalone: true,
		selector: "neat-video-tile",
		inputs: {
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			settings: {
				classPropertyName: "settings",
				publicName: "settings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			retentionMs: {
				classPropertyName: "retentionMs",
				publicName: "retentionMs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			channel: {
				classPropertyName: "channel",
				publicName: "channel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bars: {
				classPropertyName: "bars",
				publicName: "bars",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			stateChange: "stateChange",
			frameStats: "frameStats"
		},
		host: { properties: {
			"attr.data-state": "state()",
			"attr.data-selected": "selected() ? \"\" : null"
		} },
		viewQueries: [{
			propertyName: "videoElement",
			first: true,
			predicate: ["video"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "canvasElement",
			first: true,
			predicate: ["canvas"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <video #video class="video" autoplay playsinline [muted]="true"></video>
    <canvas #canvas class="overlay" aria-hidden="true"></canvas>
    @if (bars()) {
      @if (state() !== 'playing') {
        <p class="no-video"><span class="no-video-text">No active video received</span></p>
      }
      <div class="bar">
        <span class="label">{{ label() }}</span>
        <span class="status">{{ status() }}</span>
        <ng-content select="[neatTileChip]" />
      </div>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:block;width:100%;height:100%;overflow:hidden;isolation:isolate;border-radius:var(--radius);background:var(--muted)}.video,.overlay{position:absolute;inset:0;width:100%;height:100%}.video{object-fit:contain}.overlay{pointer-events:none}:host([data-state=\"empty\"]):after{content:\"\";position:absolute;inset:0;background:var(--muted)}:host([data-state=\"stopped\"]) .video{filter:blur(9px) saturate(.6) brightness(.75);transform:scale(1.07)}:host([data-state=\"stopped\"]) .overlay{visibility:hidden}.no-video{position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;margin:0;padding:var(--neat-space-2);text-align:center;font-size:var(--neat-text-sm)}.no-video-text{padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground)}.bar{position:absolute;inset-inline:0;bottom:0;z-index:1;display:flex;align-items:center;gap:var(--neat-space-2);padding:var(--neat-space-2) var(--neat-space-3);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground);font-size:var(--neat-text-xs)}.label{flex:none;font-weight:500}.status{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host([data-selected]):before{content:\"\";position:absolute;inset:0;z-index:2;border-radius:inherit;box-shadow:inset 0 0 0 var(--neat-focus-ring-width) var(--ring);pointer-events:none}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatVideoTile,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-video-tile",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.data-state]": "state()",
				"[attr.data-selected]": "selected() ? \"\" : null"
			},
			template: `
    <video #video class="video" autoplay playsinline [muted]="true"></video>
    <canvas #canvas class="overlay" aria-hidden="true"></canvas>
    @if (bars()) {
      @if (state() !== 'playing') {
        <p class="no-video"><span class="no-video-text">No active video received</span></p>
      }
      <div class="bar">
        <span class="label">{{ label() }}</span>
        <span class="status">{{ status() }}</span>
        <ng-content select="[neatTileChip]" />
      </div>
    }
  `,
			styles: [":host{position:relative;display:block;width:100%;height:100%;overflow:hidden;isolation:isolate;border-radius:var(--radius);background:var(--muted)}.video,.overlay{position:absolute;inset:0;width:100%;height:100%}.video{object-fit:contain}.overlay{pointer-events:none}:host([data-state=\"empty\"]):after{content:\"\";position:absolute;inset:0;background:var(--muted)}:host([data-state=\"stopped\"]) .video{filter:blur(9px) saturate(.6) brightness(.75);transform:scale(1.07)}:host([data-state=\"stopped\"]) .overlay{visibility:hidden}.no-video{position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;margin:0;padding:var(--neat-space-2);text-align:center;font-size:var(--neat-text-sm)}.no-video-text{padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground)}.bar{position:absolute;inset-inline:0;bottom:0;z-index:1;display:flex;align-items:center;gap:var(--neat-space-2);padding:var(--neat-space-2) var(--neat-space-3);background:var(--neat-video-scrim);color:var(--neat-video-scrim-foreground);font-size:var(--neat-text-xs)}.label{flex:none;font-weight:500}.status{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host([data-selected]):before{content:\"\";position:absolute;inset:0;z-index:2;border-radius:inherit;box-shadow:inset 0 0 0 var(--neat-focus-ring-width) var(--ring);pointer-events:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		settings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "settings",
				required: false
			}]
		}],
		retentionMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "retentionMs",
				required: false
			}]
		}],
		channel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "channel",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		bars: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bars",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}],
		stateChange: [{
			type: i0.Output,
			args: ["stateChange"]
		}],
		frameStats: [{
			type: i0.Output,
			args: ["frameStats"]
		}],
		videoElement: [{
			type: i0.ViewChild,
			args: ["video", { isSignal: true }]
		}],
		canvasElement: [{
			type: i0.ViewChild,
			args: ["canvas", { isSignal: true }]
		}]
	}
});
function currentDpr() {
	return Math.min(MAX_CANVAS_DPR, window.devicePixelRatio || 1);
}
export { KIOSK_POINTER_IDLE_MS, KioskService, NEAT_DANGER_BASE, NEAT_ICON_NAMES, NEAT_MIN_TILE_WIDTH, NEAT_OVERLAY_DEFAULTS, NEAT_OVERLAY_STYLE_FALLBACK_COLOR, NEAT_PRIMARY_BASE, NEAT_STREAM_STALE_MS, NEAT_WARN_BASE, NeatButton, NeatIcon, NeatInput, NeatOverlayColors, NeatPage, NeatPageToolbar, NeatSegmented, NeatShell, NeatSlider, NeatSwitch, NeatTab, NeatTabs, NeatTileGrid, NeatTooltip, NeatVideoTile, OVERLAY_HOLD_MS, SIMA_PALETTE, ThemeService, bufferSettleMs, buildColorScale, buildSurfaceScale, contrastRatio, createMetadataQueue, createOverlayState, drawFrame, enqueueMetadata, fitAllTileWidth, holdOverlays, lateNoticeDetails, metadataQueueSnapshot, nextWarningActive, packTiles, parseMetadataMessage, provideNeatUi, resetLatenessWindow, resetOverlayState, suggestedBufferMs, takeMetadataForFrame };

//# sourceMappingURL=sima-neat-ui.mjs.map