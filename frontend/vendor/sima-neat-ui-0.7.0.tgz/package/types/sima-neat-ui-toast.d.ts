import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
/** How long an error toast stays: long enough to read a sentence (#170's value). */
declare const ERROR_TOAST_MS = 4600;
/** How long a status toast stays (#170's value). */
declare const STATUS_TOAST_MS = 3200;
/** How long a warning toast stays: as long as an error, since it is read the same way. */
declare const WARNING_TOAST_MS = 4600;
/** The most toasts the host shows at once; the newest ones. */
declare const MAX_VISIBLE_TOASTS = 3;
/** The kinds of toast that carry a message and clear on their own. */
type MessageKind = 'error' | 'warning' | 'status';
/** A toast the host shows. */
type ToastEntry = {
  readonly id: number;
  readonly kind: MessageKind;
  readonly message: string;
} | {
  readonly id: number;
  readonly kind: 'progress';
  readonly title: string;
  readonly detail: string;
  /** Whole percent, or `null` while the work cannot say how far along it is. */
  readonly percent: number | null;
};
/**
 * The toasts the host shows: at most `MAX_VISIBLE_TOASTS`, oldest first. When there are more,
 * message toasts (error, warning, status) are hidden before progress toasts (oldest first in each
 * group): work in progress is what the user is waiting for, and it has no timer to clear it. The
 * newest toast is never hidden: a message that has just arrived is the news.
 */
declare function visibleToasts(entries: readonly ToastEntry[]): readonly ToastEntry[];
/**
 * The toasts that exist, oldest first, shared by `NeatToasts` (which adds them) and the host
 * (which shows them). Not exported by the entry: a toast is added through `NeatToasts`, and the
 * state stays out of its API.
 *
 * Message toasts clear themselves a fixed time after they are added, whether the host
 * shows them or newer toasts hide them: a toast is news for as long as it lives, and a hidden one
 * that waited for room would show its message late.
 */
declare class ToastStore {
  private readonly state;
  private readonly timers;
  private nextId;
  readonly entries: Signal<readonly ToastEntry[]>;
  constructor();
  /** Adds a message toast as the newest, and clears it after its kind's time. */
  show(kind: MessageKind, message: string): void;
  /** Adds a progress toast as the newest; it stays until settled or dismissed. Returns its id. */
  startProgress(title: string): number;
  /** Updates a progress toast that has not settled; does nothing for one that has. */
  updateProgress(id: number, detail: string, percent: number | null): void;
  /**
   * Replaces a progress toast that has not settled with its outcome, as the newest toast: the
   * outcome is news even if newer toasts hid the progress. Does nothing for one that has settled.
   */
  settleProgress(id: number, kind: 'error' | 'status', message: string): void;
  /**
   * Removes a toast, with no outcome in its place. Ids are never reused, so removing one that has
   * already gone (a progress toast that settled into a new toast) does nothing.
   */
  remove(id: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Shows the app's toasts (`NeatToasts`): render it once, beside the shell, and nowhere else:
 *
 * ```html
 * <neat-shell …>…</neat-shell>
 * <neat-toast-host />
 * ```
 *
 * Not inside the shell: the shell is the kit's primary entry point, which cannot import this one,
 * and an app that shows no toasts should not carry them.
 *
 * The toasts stack in the bottom-right corner, the newest last, at most three at a time. When
 * more exist, the oldest error, warning and status toasts are hidden first and the oldest
 * progress toasts last (work in progress is what the user is waiting for); a hidden toast shows
 * again if it is still there when the others clear.
 *
 * What the user sees and what a screen reader announces are two layers. The visible stack is
 * `aria-hidden`. A second overlay, never re-shown and never hidden, holds a visually hidden
 * `aria-live="polite"` region with one entry per toast: the message ("Error: " or "Warning: " in
 * front of an error or a warning), or a progress toast's title. An entry is added when its toast
 * is, so each toast is announced once, as it appears. A progress toast's changing detail and
 * percent are in a nested `aria-live="off"` part: a screen reader finds the current value when it
 * reads the region, but a long upload is not read out every second. The two layers are separate
 * because bringing the stack to the front (below) hides and shows it, which takes a live region out
 * of the accessibility tree and back with its content already in it, and that is not announced.
 *
 * Both layers are rendered in the CDK overlay layer rather than where the host stands, for two
 * reasons: a modal dialog hides everything outside that layer from assistive technology, which
 * would silence a toast raised by the dialog's own action, and the stack must show above the
 * dialog (as #170's toasts showed above its modals). Overlays stack in the order they were last
 * brought to the front, so each new toast brings the stack to the front again: an error raised by
 * a dialog's own action shows above the dialog, though the host is older. A toast that was on
 * screen before a dialog opened stays under the dialog until it clears or a newer toast arrives.
 *
 * The stack takes no pointer events: it has nothing to click, and a progress toast that stays for
 * as long as an upload runs must not sit on a dialog's buttons. Clicks pass through to whatever is
 * under a toast; the cost is that toast text cannot be selected.
 */
export declare class NeatToastHost {
  private readonly store;
  private readonly announcer;
  private readonly stack;
  private stackOverlay;
  private newestShown;
  protected readonly classes: Record<MessageKind | "progress", string>;
  protected readonly announcedKind: Record<MessageKind, string>;
  /** Every toast there is: an entry is announced when it appears, whether it is on screen or not. */
  protected readonly announced: import("@angular/core").Signal<readonly ToastEntry[]>;
  protected readonly visible: import("@angular/core").Signal<readonly ToastEntry[]>;
  constructor();
  /**
   * Puts the stack above every overlay that is open. Where the browser has the popover API the
   * CDK shows each overlay as a popover, and the top layer orders them by when they were shown,
   * so showing it again moves it to the top; elsewhere the overlays are siblings in the
   * container, and a later sibling is above an earlier one.
   */
  private bringToFront;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatToastHost, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatToastHost, "neat-toast-host", never, {}, {}, never, never, true, never>;
}
/** A toast for work that takes a while, as `NeatToasts.progress` returns it. */
interface NeatProgressToast {
  /**
   * Shows how far the work is: a line of detail ("clip.mp4 · file 1 of 3") and a percent from 0 to
   * 100, or `null` while it cannot say. Values outside the range are held to it.
   */
  update(detail: string, percent: number | null): void;
  /** The work succeeded: the toast becomes a status toast with this message. */
  done(message: string): void;
  /** The work failed: the toast becomes an error toast with this message. */
  fail(message: string): void;
  /**
   * Removes the toast with no outcome: the work did not end, it is reported elsewhere now (a dialog
   * that took it back). Nothing is announced. After it, and after `done` or `fail`, the handle
   * does nothing.
   */
  dismiss(): void;
}
/**
 * Short messages the app shows without taking the user's attention from what they are doing:
 *
 * ```ts
 * this.toasts.error('Could not start src3.');
 * this.toasts.warning('Uploaded clip.mp4, but could not restart src2.');
 * this.toasts.status('Stopped 2 sources.');
 * const upload = this.toasts.progress('Uploading 3 files');
 * upload.update('clip.mp4 · file 1 of 3', 41);
 * upload.done('Uploaded 3 files.');
 * ```
 *
 * An error or warning toast clears after 4.6 seconds and a status toast after 3.2. A progress toast
 * stays until `done` or `fail` turns it into an error or a status, so work that outlives the page
 * or dialog that started it keeps reporting, or until `dismiss` removes it. They show in the
 * `<neat-toast-host>` the app renders once. There is no toast without a host: the app must render
 * one, or nothing is shown.
 *
 * Toasts do not hold the kiosk toolbar: they are not part of the floating chrome, and they
 * clear on their own.
 */
export declare class NeatToasts {
  private readonly store;
  /** Reports a failure. */
  error(message: string): void;
  /**
   * Reports something that went partly wrong or needs the user's notice, short of a failure: the
   * upload went through, but a slot using the file could not restart.
   */
  warning(message: string): void;
  /** Reports what happened: the result of an action. */
  status(message: string): void;
  /** Starts a toast for work in progress, named by `title`: "Uploading 3 files". */
  progress(title: string): NeatProgressToast;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatToasts, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export type { NeatProgressToast };