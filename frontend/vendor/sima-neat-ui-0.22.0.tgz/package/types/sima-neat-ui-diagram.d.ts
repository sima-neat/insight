import { NeatTone } from "@sima/neat-ui";
import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
/** A side of a node, where edges meet it. */
type NeatDiagramSide = 'left' | 'right' | 'top' | 'bottom';
/**
 * What a node is in the drawing: `frame` holds other nodes (drawn behind the edges, its title and
 * detail top left), `block` is a card (label, detail, chips), `band` a strip such as a cable or a
 * bus (its label along it), `bracket` spans a row of siblings below them (a curly line and a
 * label).
 */
type NeatDiagramRole = 'frame' | 'block' | 'band' | 'bracket';
/**
 * How a node is drawn within its role: `accent` is the primary tint (e.g. the main device),
 * `dashed` a group, `ghost` dashed, transparent and quiet (a part that is not running), `muted`
 * filled with `--muted`.
 */
type NeatDiagramLook = 'default' | 'accent' | 'dashed' | 'ghost' | 'muted';
/** How an edge ends: plain, with an arrowhead, or with a dot. */
type NeatDiagramTip = 'none' | 'arrow' | 'dot';
/** How an edge's line is drawn. */
type NeatDiagramLine = 'solid' | 'dashed' | 'ghost';
/** A short fact on a block, drawn as the kit's status chip in its tone. */
interface NeatDiagramChip {
  readonly label: string;
  readonly tone: NeatTone;
}
interface NeatDiagramNode {
  readonly id: string;
  readonly label: string;
  /** A second line: what it is or where it runs. */
  readonly detail?: string;
  /** The node it sits in; `x` and `y` are relative to it. */
  readonly parent?: string;
  readonly x: number;
  readonly y: number;
  readonly w: number;
  readonly h: number;
  readonly role: NeatDiagramRole;
  /** Unset: `default`. */
  readonly look?: NeatDiagramLook;
  readonly chips?: readonly NeatDiagramChip[];
  /** The id of the level (`NeatDiagramSet.levels`) this block opens. */
  readonly opens?: string;
  /**
   * The side its incoming (`inSide`) or outgoing (`outSide`) edges meet it on; unset, each edge
   * end goes on the side that faces the other end.
   */
  readonly inSide?: NeatDiagramSide;
  readonly outSide?: NeatDiagramSide;
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
interface NeatDiagramEdge {
  readonly id: string;
  /** The node it leaves. */
  readonly from: string;
  /** The node it enters. */
  readonly to: string;
  /** Its colour, the charts' series colour 1 to 8; unset, or on a `ghost` line, muted. */
  readonly series?: number;
  /** Unset: `solid`. */
  readonly line?: NeatDiagramLine;
  /** Its tip at `from`; unset, `none`. */
  readonly start?: NeatDiagramTip;
  /** Its tip at `to`; unset, `arrow`. */
  readonly end?: NeatDiagramTip;
  /** A short label on the edge, at `labelAt`. */
  readonly label?: string;
  /** Where the label sits along the edge, 0 at `from` to 1 at `to`; unset, 0.5. */
  readonly labelAt?: number;
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/**
 * A box of the app's content (a template matched by the note's id or `data`), joined by a dotted
 * leader to its anchor: a point along its edges, or a point of its own. A note anchored by
 * `anchor` alone belongs to no edge, so it is never in focus with one: it dims whenever anything
 * is in focus.
 */
interface NeatDiagramNote {
  readonly id: string;
  /** The edges it is about; the anchor is the mean of their points at `along`. */
  readonly edges?: readonly string[];
  /** Where along its edges the anchor lies, 0 at their start to 1 at their end; unset, 0.5. */
  readonly along?: number;
  /**
   * The anchor as a point instead (a node's side, for a note about the node); without `x`, the
   * edges' mean x, for a leader into the middle of a bundle of parallel edges.
   */
  readonly anchor?: {
    readonly x?: number;
    readonly y: number;
  };
  /** The box's centre, per axis; unset, the anchor moved by `dx` and `dy`. */
  readonly x?: number;
  readonly y?: number;
  readonly dx?: number;
  readonly dy?: number;
  /**
   * Where the leader meets the box: its nearest point (unset; level or upright where it can be),
   * or its centre, under the box (`centre`; a slanted leader then meets no rounded corner).
   */
  readonly leaderTo?: 'centre';
  /** The app's, never read by the kit. */
  readonly data?: unknown;
}
/** One level: nodes, the edges between them and the notes on them. */
interface NeatDiagram {
  readonly nodes: readonly NeatDiagramNode[];
  readonly edges: readonly NeatDiagramEdge[];
  readonly notes?: readonly NeatDiagramNote[];
}
/**
 * A diagram with its drill-down levels, each placed by hand: a block whose `opens` names a level
 * opens it, and a level may open further levels.
 */
interface NeatDiagramSet {
  readonly overview: NeatDiagram;
  readonly levels?: Readonly<Record<string, NeatDiagram>>;
}
interface Point {
  x: number;
  y: number;
}
/**
 * The corners of the edge from `source` (leaving through `sourceSide`) to `target` (entering
 * through `targetSide`), ends included. One turn when the sides are at right angles (an L), two
 * when they face each other (a Z, its middle run `jog` further along the way than halfway; 0
 * when the ports are level, a straight line), and stubs out of both ports when the target lies
 * behind the source.
 */
declare function routePoints(source: Point, sourceSide: NeatDiagramSide, target: Point, targetSide: NeatDiagramSide, jog?: number): Point[];
/** A piece of a drawn edge: a straight run to `line`, or a turn (cubic bezier) to `curve[2]`. */
type Piece = {
  line: Point;
} | {
  curve: [Point, Point, Point];
};
/**
 * The corners rounded: each turn's legs are `bend` long, at most the shorter of its two runs
 * (half of a run between two turns, so neighbouring turns never overlap).
 */
declare function roundCorners(points: Point[], bend?: number): Piece[];
/** The SVG path through a route's corners (`routePoints`), drawn in the rounded shape. */
declare function pathThrough(points: Point[]): string;
/** Points along the pieces from `start` (each turn in `steps` parts): the drawn shape, sampled. */
declare function sampleRoute(start: Point, pieces: Piece[], steps?: number): Point[];
/**
 * The point `t` of the way along the drawn shape of the route through `points` (its corners, as
 * `routePoints` gives them), by length: 0 at its start, 1 at its end, clamped. Measured on the
 * rounded shape rather than on the corners, so an edge label or a note's anchor near a turn sits
 * on the line that is drawn.
 */
declare function pointAlong(points: Point[], t: number): Point;
interface Rect extends Point {
  w: number;
  h: number;
}
/** An edge as drawn: its ports and their sides, and its route in the rounded shape. */
interface EdgeLayout {
  /**
   * Its port on `from`, in the level's coordinates, and the side of `from` it leaves through. An
   * edge between a frame and a node inside it has its frame end on the border nearest the node and
   * runs inward: that end's side is the way it runs (`top` for a port on the bottom border).
   */
  source: Point;
  sourceSide: NeatDiagramSide;
  /** Its port on `to` and the side of `to` it enters through (for a frame, as above). */
  target: Point;
  targetSide: NeatDiagramSide;
  /** The SVG path of its rounded shape. */
  path: string;
  /** Its route's corners, ends included, along which `pointAlong` measures. */
  points: Point[];
}
/**
 * Each node's rectangle in the level's coordinates: its position plus those of the nodes it sits
 * in, however deep. A node whose parent is not on the level, or that lies inside itself, is left
 * out with what sits in it, so the rest of a broken diagram still draws; so is a node whose id an
 * earlier node already has.
 */
declare function absoluteRects(diagram: NeatDiagram): Map<string, Rect>;
/**
 * Per side: `t`, the way its ports are spread (offset grows along it), `n`, the way out of the
 * node.
 */
declare const SIDE_AXES: Record<NeatDiagramSide, {
  t: Point;
  n: Point;
}>;
/**
 * Each edge as drawn, by id: its ends on the sides that face each other (or that its nodes name),
 * spread along each side so a fan does not cross itself, and its rounded route, Z routes that
 * share a corridor spread apart. An edge with an end that is not a node on the level (or one left
 * out), or whose id an earlier edge already has, is left out.
 */
declare function layoutEdges(diagram: NeatDiagram): Map<string, EdgeLayout>;
/**
 * The pairs of edges (by id) whose straight port-to-port lines cross: a measure of how tangled a
 * level reads (the drawn curves leave and enter their ports the same way).
 */
declare function crossings(diagram: NeatDiagram): [string, string][];
/** True when the segments p1-p2 and p3-p4 cross properly (touching does not count). */
declare function intersect(p1: Point, p2: Point, p3: Point, p4: Point): boolean;
/** A node as drawn. */
interface DrawnNode {
  readonly node: NeatDiagramNode;
  /** In the level's coordinates. */
  readonly rect: Rect;
  readonly look: NeatDiagramLook;
  /** A block whose `opens` names a level that exists: it shows the open affordance. */
  readonly opens: boolean;
  /** A bracket's brace, in its own box (`BRACE_HEIGHT` high); null for the other roles. */
  readonly brace: string | null;
}
/** An edge's tip: an arrowhead (a closed path) or a dot, at the edge's `start` or `end`. */
type DrawnTip = {
  readonly end: 'start' | 'end';
  readonly shape: 'arrow';
  readonly d: string;
} | {
  readonly end: 'start' | 'end';
  readonly shape: 'dot';
  readonly cx: number;
  readonly cy: number;
  readonly r: number;
};
/** An edge as drawn. */
interface DrawnEdge {
  readonly id: string;
  /** The app's edge, for its tip's template and its words. */
  readonly edge: NeatDiagramEdge;
  readonly path: string;
  /** The CSS colour its line and tips take. */
  readonly colour: string;
  readonly line: NeatDiagramLine;
  readonly tips: readonly DrawnTip[];
  /** Its label and the point of the route it is centred on. */
  readonly label: {
    readonly text: string;
    readonly at: Point;
  } | null;
}
interface DrawnLevel {
  /** Frames and bands, drawn behind the edges; a frame after the frames it sits in. */
  readonly behind: readonly DrawnNode[];
  /** Blocks and brackets, drawn in front of the edges. */
  readonly front: readonly DrawnNode[];
  readonly edges: readonly DrawnEdge[];
  /** Each drawn edge's layout, by id, which the notes are placed along. */
  readonly layouts: ReadonlyMap<string, EdgeLayout>;
}
/** How tall a bracket's brace is (diagram units); its label sits below it. */
declare const BRACE_HEIGHT = 18;
/**
 * The level as drawn. `levels` are the ids of the levels that exist, which a block's `opens`
 * must name to show the open affordance. A part the layout cannot place (an id that names
 * nothing) is left out, named once in dev mode, and the rest is drawn.
 */
declare function drawLevel(diagram: NeatDiagram, levels: ReadonlySet<string>): DrawnLevel;
/**
 * The colour of a line, an edge's or a legend sample's: its series' token, else the muted colour.
 * A ghost is muted whatever its series: it is a part that does not run here, and stays quiet
 * beside the edges that do. `part` names what has the line in the dev-mode message.
 */
declare function lineColour(series: number | undefined, line: NeatDiagramLine | undefined, part: string): string;
/**
 * The palette index (from 0, as `NeatSeriesSwatch` and the kit's token rule count) of a diagram
 * series (from 1, as an edge's `series`): the one place the diagram converts between the two.
 * Null for a series that is not 1 to 8, which is named once in dev mode and drawn muted.
 */
declare function seriesIndex(series: number, part: string): number | null;
/** A drawn part in words, for the list that says the picture without it. */
interface DescribedPart {
  readonly id: string;
  readonly text: string;
}
/**
 * The level in words: each node by its label, detail and chips ("Decode, H.264, HW"), each edge
 * by its ends and label ("Camera to Decode, image"). Only what is drawn, so the words and the
 * picture say the same.
 */
declare function describeLevel(level: DrawnLevel): {
  readonly nodes: readonly DescribedPart[];
  readonly edges: readonly DescribedPart[];
};
/** A note as drawn: its box, the point it is about, and its leader (none under the box). */
interface NotePlacement {
  box: Rect;
  anchor: Point;
  /** From the anchor to the box; null while the anchor is under the box. */
  leader: [Point, Point] | null;
}
/**
 * Each note's placement, by id. `edges` are the level's laid-out edges (`layoutEdges`) and
 * `sizes` each note's measured box: a note not measured yet is not placed (the renderer places
 * it once it has its size). A note with nothing to anchor it is left out; an edge it names that
 * is not on its level is ignored, each named once. An edge on the level that the layout left
 * out is ignored quietly: the layout has named it.
 */
declare function placeNotes(diagram: NeatDiagram, edges: ReadonlyMap<string, EdgeLayout>, sizes: ReadonlyMap<string, {
  w: number;
  h: number;
}>): Map<string, NotePlacement>;
/** What the pointer or the keyboard is on. */
interface DiagramFocus {
  readonly kind: 'block' | 'edge';
  readonly id: string;
}
/** The parts that stay as they are while something is in focus; the rest is dimmed. */
interface FocusedParts {
  readonly nodes: ReadonlySet<string>;
  readonly edges: ReadonlySet<string>;
  readonly notes: ReadonlySet<string>;
}
/** The gap between the pointer and its tip, px on screen (the demo's). */
declare const TIP_GAP = 14;
/**
 * The parts in focus on `level`: a block with the edges that enter or leave it, an edge with the
 * nodes at its ends; with either, the notes on those edges. Null while nothing is in focus.
 */
declare function focusedParts(level: NeatDiagram, focus: DiagramFocus | null): FocusedParts | null;
/**
 * Where a tip of `size` goes for the pointer `at`, in a box of `box` (px from its corner): below
 * and right of the pointer, a gap away; on the other side on an axis where that leaves the box;
 * and pushed into the box where neither side has room, so it is never cut off.
 */
declare function placeTip(at: Point, size: {
  readonly w: number;
  readonly h: number;
}, box: {
  readonly w: number;
  readonly h: number;
}): {
  left: number;
  top: number;
};
/**
 * What the pointer and the keyboard put in focus on one diagram's box, found by delegation (the
 * parts' `data-node` and `data-edge`), so no listener runs per part. Created outside the zone; its
 * listeners write a signal only when what is in focus changes.
 */
declare class DiagramHover {
  private readonly box;
  /** The tip's element while it is rendered. */
  private readonly tip;
  private readonly pointer;
  /** The block whose open button has the focus. */
  private readonly keyboard;
  /** The pointer, px from the box's padding corner, for the tip. */
  private at;
  /** The pointer's part, else the keyboard's block. */
  readonly focus: import("@angular/core").Signal<DiagramFocus | null>;
  /** The edge whose tip shows: the one under the pointer. */
  readonly tipEdge: import("@angular/core").Signal<string | null>;
  constructor(box: HTMLElement,
  /** The tip's element while it is rendered. */
  tip: () => HTMLElement | undefined);
  /** Puts the tip by the pointer, inside the box. Called on each move and once it renders. */
  place(): void;
  /** Nothing is in focus: a new level has other parts. */
  clear(): void;
  destroy(): void;
  /**
   * The part under a mouse or a pen. Touch has no hover, and a held button is a drag of the
   * view, whose parts slide under the pointer: neither puts anything in focus.
   */
  private readonly over;
  private readonly leave;
  /**
   * An open button the keyboard focuses. A press on a block focuses its button too (d3-zoom lets
   * the press through), and after a pan from it the block would stay in focus with the rest
   * dimmed and no ring to say why; `:focus-visible` is the browser's word for the keyboard's.
   */
  private readonly focusIn;
  private readonly focusOut;
  /** `element` if it is one of this box's parts, not an ancestor of the box's. */
  private inBox;
}
/** What a block's template is given: the block. */
interface NeatDiagramBlockContext {
  readonly $implicit: NeatDiagramNode;
}
/** What the edge tip's template is given: the edge. */
interface NeatDiagramEdgeTipContext {
  readonly $implicit: NeatDiagramEdge;
}
/** What a note's template is given: the note. */
interface NeatDiagramNoteContext {
  readonly $implicit: NeatDiagramNote;
}
/**
 * The body of the diagram's blocks, below each block's label (the demo's live figures):
 *
 * ```html
 * <ng-template neatDiagramBlock let-node>
 *   @if (node.id === 'decode') { <span>{{ fps() }} fps</span> }
 * </ng-template>
 * ```
 *
 * The card keeps the node's size, so the app sizes the node's `h` (and `w`) for the body. A block
 * it renders nothing for keeps its card as it is.
 */
export declare class NeatDiagramBlockTemplate {
  readonly template: TemplateRef<NeatDiagramBlockContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramBlockTemplate, context: unknown): context is NeatDiagramBlockContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramBlockTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramBlockTemplate, "ng-template[neatDiagramBlock]", never, {}, {}, never, never, true, never>;
}
/**
 * The content of the diagram's notes, in a box joined to its anchor by a dotted leader:
 *
 * ```html
 * <ng-template neatDiagramNote let-note>
 *   @if (note.id === 'rate') { <b>Camera → Decode</b> {{ rate() }} msg/s }
 * </ng-template>
 * ```
 *
 * A note it renders nothing for is not drawn, nor its leader; without the template no note is. A
 * note anchored by `anchor` alone belongs to no edge, so it dims whenever anything is in focus.
 */
export declare class NeatDiagramNoteTemplate {
  readonly template: TemplateRef<NeatDiagramNoteContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramNoteTemplate, context: unknown): context is NeatDiagramNoteContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramNoteTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramNoteTemplate, "ng-template[neatDiagramNote]", never, {}, {}, never, never, true, never>;
}
/**
 * The tip of the edge under the pointer, by the pointer, in the popover's colours and kept inside
 * the diagram's box:
 *
 * ```html
 * <ng-template neatDiagramEdgeTip let-edge>
 *   <b>{{ edge.label }}</b> {{ rate(edge.id) }} msg/s
 * </ng-template>
 * ```
 *
 * It follows a mouse or a pen, never touch (which has no hover), and is hidden from assistive
 * technology: the diagram's hidden list says each edge in words, so a tip must not hold anything
 * a reader needs that the list or a note does not say. An edge it renders nothing for shows no
 * tip.
 */
export declare class NeatDiagramEdgeTipTemplate {
  readonly template: TemplateRef<NeatDiagramEdgeTipContext>;
  static ngTemplateContextGuard(_directive: NeatDiagramEdgeTipTemplate, context: unknown): context is NeatDiagramEdgeTipContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramEdgeTipTemplate, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatDiagramEdgeTipTemplate, "ng-template[neatDiagramEdgeTip]", never, {}, {}, never, never, true, never>;
}
/**
 * A hand-placed diagram in the kit's look:
 *
 * ```html
 * <neat-diagram [diagram]="system" label="The demo's system" [(level)]="level">
 *   <ng-template neatDiagramNote let-note>…</ng-template>
 * </neat-diagram>
 * ```
 *
 * Frames and bands are drawn behind one SVG of edges, blocks, brackets, edge labels and notes in
 * front of it, all in one container (what pan and zoom move). Every part is keyed by its id, so a
 * new diagram object with the same content (an app recomputing it on every poll) changes nothing
 * in the DOM, and a moved node is the same element, moved. A part whose ids name nothing is left
 * out and named once in dev mode; the rest is drawn.
 *
 * The host is a `figure` named by `label`; it fills the box the app gives it and clips what lies
 * outside. Chips are the kit's status chips; a block's body, the notes' content and the tip of
 * the edge under the pointer are the app's templates (`neatDiagramBlock`, `neatDiagramNote`,
 * `neatDiagramEdgeTip`). A visually hidden list after the drawing says the level's nodes and
 * edges in words.
 *
 * A block or an edge under the pointer, or a block whose open button has the focus, is in focus
 * with what it is joined to; the rest is dimmed. A block that opens a level is a button that opens
 * it; `level` is the path of open levels, which an app can bind to its route, and the bar over the
 * drawing goes back and shows the path. A path that leads nowhere (a stale route) is cut to the
 * part that does, and the model is set to it; so render the diagram once its data is there, since
 * a routed path is checked against the diagram given, a placeholder too.
 *
 * The user pans and zooms it (drag, wheel, pinch, double-click; with the box focused, the arrow
 * keys, `+`, `-` and `0`); it fits its level to the box by itself until they do, and `fit()` fits
 * it again (`DiagramZoom`). It takes the wheel and touch over its box (`touch-action: none`), so
 * give it a bounded box, not a long stretch of a scrolling page.
 */
export declare class NeatDiagramView {
  /** The overview and its drill-down levels. */
  readonly diagram: import("@angular/core").InputSignal<NeatDiagramSet>;
  /** The figure's accessible name: what the diagram shows. */
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * The path of open levels, ids of `diagram().levels`, each opened by a block of the level before
   * it; `[]` for the overview. Set by the open buttons, the back button and the breadcrumbs.
   */
  readonly level: import("@angular/core").ModelSignal<string[]>;
  protected readonly blockTemplate: import("@angular/core").Signal<NeatDiagramBlockTemplate | undefined>;
  protected readonly noteTemplate: import("@angular/core").Signal<NeatDiagramNoteTemplate | undefined>;
  private readonly edgeTipTemplate;
  private readonly noteSizes;
  private readonly content;
  private readonly edges;
  private readonly tipBox;
  private readonly bar;
  private readonly host;
  private readonly injector;
  private readonly zone;
  private zoom;
  private readonly hover;
  protected readonly BRACE_HEIGHT = 18;
  private readonly walked;
  /** The path as far as it leads: the levels shown. */
  private readonly path;
  /** The level shown: the one at the end of the path. */
  private readonly shown;
  /**
   * Each level of the path as a crumb, named by the block that opens it: its label, and on the
   * last crumb (where the user is) its detail, muted.
   */
  protected readonly crumbs: import("@angular/core").Signal<{
    label: string;
    detail: string | undefined;
  }[]>;
  /** What the back button goes to: the level before this one, or the overview. */
  protected readonly backTo: import("@angular/core").Signal<string>;
  protected readonly drawn: import("@angular/core").Signal<DrawnLevel>;
  /** The level's notes, each drawn (and measured) only while the app has a note template. */
  protected readonly notes: import("@angular/core").Signal<import("@sima/neat-ui/diagram").NeatDiagramNote[]>;
  /** Where each measured note goes, by id. */
  protected readonly placements: import("@angular/core").Signal<Map<string, NotePlacement>>;
  /** What a fit frames: the level's nodes, edges and placed notes. */
  private readonly extent;
  /** The parts in focus while something is (the rest is dimmed); null while nothing is. */
  protected readonly focused: import("@angular/core").Signal<FocusedParts | null>;
  /** The tip of the edge under the pointer, while the app has a tip template. */
  protected readonly edgeTip: import("@angular/core").Signal<{
    template: import("@angular/core").TemplateRef<NeatDiagramEdgeTipContext>;
    edge: import("@sima/neat-ui/diagram").NeatDiagramEdge;
  } | null>;
  /** The level in words, for the hidden list. */
  protected readonly described: import("@angular/core").Signal<{
    readonly nodes: readonly DescribedPart[];
    readonly edges: readonly DescribedPart[];
  }>;
  constructor();
  /** Fits the level to the box, animated unless reduced motion; it then fits by itself again. */
  fit(): void;
  /** Opens the level `block` opens, one deeper than the level shown. */
  protected open(block: NeatDiagramNode): void;
  /** Goes back to the level before this one. */
  protected back(): void;
  /** Goes to the level at `index` of the path (a breadcrumb). */
  protected goTo(index: number): void;
  /**
   * The control pressed may leave with its level (an open button, the last level's breadcrumb,
   * the bar on the way to the overview); the focus then stays in the diagram, on its box, instead
   * of falling to the page.
   */
  private go;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramView, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramView, "neat-diagram", never, {
    "diagram": {
      "alias": "diagram";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "level": {
      "alias": "level";
      "required": false;
      "isSignal": true;
    };
  }, {
    "level": "levelChange";
  }, ["blockTemplate", "noteTemplate", "edgeTipTemplate"], never, true, never>;
}
/** One entry of a diagram's legend: what a series colour or a line look stands for. */
interface NeatDiagramLegendItem {
  /** The series (1 to 8) whose colour it names, as an edge's `series`; unset, muted. */
  readonly series?: number;
  /** The line look it names, as an edge's `line`; unset, the series' swatch instead. */
  readonly line?: NeatDiagramLine;
  readonly label: string;
}
/**
 * What a diagram's colours and lines stand for, as the Autoware demo's legend chip:
 *
 * ```html
 * <neat-diagram-legend [items]="[
 *   { series: 1, label: 'image' },
 *   { series: 4, label: 'results' },
 *   { line: 'ghost', label: 'not run here' },
 * ]" />
 * ```
 *
 * A series without a `line` shows the kit's `NeatSeriesSwatch` for it, as the charts' legends do.
 * Any other item shows a short sample of its line (solid when unset), drawn by the edges' own
 * rules (lines.css) in the colour its edges take (`lineColour`): muted for a ghost, without a
 * series, or for a series that is not 1 to 8. Samples and swatches are `aria-hidden`: the label
 * names what they stand for, and a colour alone is not a name.
 */
export declare class NeatDiagramLegend {
  /** The entries, in the order shown. */
  readonly items: import("@angular/core").InputSignal<readonly NeatDiagramLegendItem[]>;
  protected readonly drawn: import("@angular/core").Signal<{
    label: string;
    swatch: number | null;
    line: NeatDiagramLine;
    colour: string | null;
  }[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatDiagramLegend, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatDiagramLegend, "neat-diagram-legend", never, {
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The level that opens on `blockId`: the block as its frame at the origin, sized to its children
 * with a padding, and everything inside the block, however deep, as placed (positions are
 * relative to the parent, so nothing moves); the nodes the edges from inside reach, in a column
 * left of the frame (senders) and right of it (receivers), vertically centred on it; and the edges
 * with an end inside. A node that both sends and receives goes in the senders' column only, so it
 * is on the level once. The outside nodes and the frame get their sides afresh (an overview's
 * `inSide` and `outSide` suit its placement, not this one), and the frame opens nothing (it is the
 * level). The diagram's notes are left behind: they are placed for it. A block that is not on the
 * diagram or holds nothing gives an empty level, named once.
 */
export declare function neatDrillDownLevel(diagram: NeatDiagram, blockId: string): NeatDiagram;
export type { NeatDiagram, NeatDiagramChip, NeatDiagramEdge, NeatDiagramLegendItem, NeatDiagramLine, NeatDiagramLook, NeatDiagramNode, NeatDiagramNote, NeatDiagramRole, NeatDiagramSet, NeatDiagramSide, NeatDiagramTip };