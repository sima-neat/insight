import * as i0 from "@angular/core";
import { EnvironmentProviders, InjectionToken, Signal, TemplateRef } from "@angular/core";
import { LucideActivity, LucideBlocks, LucideCable, LucideChevronLeft, LucideChevronRight, LucideCpu, LucideEllipsis, LucideFileText, LucideFolderOpen, LucideInfo, LucideLayoutGrid, LucideMaximize, LucideMaximize2, LucideMinimize, LucideMoon, LucidePalette, LucidePanelLeftClose, LucidePanelLeftOpen, LucideRadioTower, LucideRectangleHorizontal, LucideSearch, LucideShapes, LucideSquare, LucideSun, LucideX } from "@lucide/angular";
import { IsActiveMatchOptions } from "@angular/router";
import { TemplatePortal } from "@angular/cdk/portal";
import * as i1$5 from "@spartan-ng/brain/button";
import * as i1$4 from "@spartan-ng/brain/tooltip";
import * as i1$3 from "@spartan-ng/brain/slider";
import * as i1$2 from "@spartan-ng/brain/tabs";
import * as i1$1 from "@spartan-ng/brain/popover";
import { BrnPopover } from "@spartan-ng/brain/popover";
import * as i1 from "@spartan-ng/brain/input";
type ColorStep = 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950;
type ColorScale = Record<Exclude<ColorStep, 0>, string>;
type SurfaceScale = Record<ColorStep, string>;
/** Builds a 50-950 ramp in OKLCH around `base`, which becomes step 500 unchanged. */
export declare function buildColorScale(base: string): ColorScale;
/**
 * Builds the neutral surface ramp: white, the two palette backgrounds and the palette text as
 * anchors, with 200-900 interpolated in OKLab between the alternate background and the text.
 */
export declare function buildSurfaceScale(): SurfaceScale;
/**
 * Colour maths for the theme: hex <-> linear sRGB <-> OKLab/OKLCH, and WCAG 2.x contrast.
 * OKLab matrices from Björn Ottosson, "A perceptual color space for image processing" (2020).
 */
/** OKLCH: lightness 0..1, chroma >= 0, hue in degrees. */
interface Oklch {
  l: number;
  c: number;
  h: number;
}
/** Three channels: gamma-encoded or linear sRGB, or OKLab `[L, a, b]`. */
type Vec3 = readonly [number, number, number];
/** Validates `#RRGGBB` in either case and returns it in upper case. */
declare function normalizeHex(hex: string): string;
/** Converts `#RRGGBB` (either case) to OKLab `[L, a, b]`. */
declare function hexToOklab(hex: string): Vec3;
/** Converts OKLab `[L, a, b]` to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklabToHex(lab: Vec3): string;
/** Converts `#RRGGBB` (either case) to OKLCH. */
declare function hexToOklch(hex: string): Oklch;
/** Converts OKLCH to upper-case `#RRGGBB`, clamping channels into sRGB. */
declare function oklchToHex(color: Oklch): string;
/** Whether an OKLCH colour can be shown in sRGB without clamping. */
declare function isInSrgbGamut(color: Oklch): boolean;
/**
 * `foreground` at `alpha` (0 to 1) over an opaque `background`, blended per channel in
 * gamma-encoded sRGB as browsers composite a translucent fill such as Tailwind's `bg-x/10`.
 */
declare function composite(foreground: string, alpha: number, background: string): string;
/**
 * `color` with an alpha channel, as `#RRGGBBAA`, for a translucent token such as a scrim. The alpha
 * is rounded to the nearest of the 256 values the hex byte can hold.
 */
declare function withAlpha(color: string, alpha: number): string;
/** WCAG 2.x relative luminance of `#RRGGBB`. */
declare function relativeLuminance(hex: string): number;
/** WCAG 2.x contrast ratio (1 to 21) between two `#RRGGBB` colours, in either order. */
export declare function contrastRatio(a: string, b: string): number;
/** The fixed SiMa.ai brand palette (identical to the Slides/PowerPoint theme). */
export declare const SIMA_PALETTE: {
  readonly text: "#010F0E";
  readonly background: "#F3F4F5";
  readonly backgroundAlt: "#E8E9EB";
  readonly white: "#FFFFFF";
  readonly orange: "#D26728";
  readonly purple: "#D1CEE6";
  readonly blue: "#5998DD";
  readonly mint: "#C0E8DB";
  readonly green: "#2A9C4F";
  readonly lime: "#A4CC2D";
};
/** Base of the primary scale. Swapping it (for example to the palette blue) re-derives the whole primary ramp. */
export declare const NEAT_PRIMARY_BASE: string;
/** Functional colours outside the palette, which has no red or amber but errors and warnings need them. */
export declare const NEAT_DANGER_BASE = "#C8372D";
/** Used unchanged as the warning fill (step 500 of its scale), with palette text colour on it. */
export declare const NEAT_WARN_BASE = "#E9A23B";
/**
 * The kit's start-up in one call: it applies the stored colour scheme before the first render.
 * The colours themselves come from the kit stylesheet (`@sima/neat-ui/styles/neat-ui.css`).
 */
export declare function provideNeatUi(): EnvironmentProviders;
type NeatColorScheme = 'light' | 'dark';
/** The dark theme's selector: tokens.generated.css and the `dark` variant in neat-ui.tailwind.css. */
declare const NEAT_DARK_CLASS = "neat-dark";
/**
 * Light/dark switch for the kit. Light is the default regardless of the OS preference (which is
 * deliberately never read); dark is opt-in and persisted.
 */
export declare class ThemeService {
  private readonly root;
  private readonly current;
  readonly scheme: Signal<NeatColorScheme>;
  constructor();
  /**
   * Applies `scheme` and, unless `persist` is false, stores it for later page loads. Without
   * storing, the scheme holds for this page load only, as a URL parameter that themes a shared
   * link needs: the user's stored choice stays, and a later toggle stores as usual.
   */
  setScheme(scheme: NeatColorScheme, { persist }?: {
    persist?: boolean;
  }): void;
  toggle(): void;
  private apply;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * An icon from the kit's curated set. Decorative by default (hidden from assistive technology);
 * give it a `label` when it carries meaning on its own. It takes its colour from the surrounding
 * text.
 */
export declare class NeatIcon {
  readonly name: import("@angular/core").InputSignal<"media" | "streaming" | "viewer" | "peripherals" | "stats" | "board" | "info" | "sun" | "moon" | "kiosk-enter" | "kiosk-exit" | "rail-expand" | "rail-collapse" | "palette" | "shapes" | "blocks" | "document" | "previous" | "next" | "close" | "aspect-wide" | "aspect-square" | "search" | "more" | "fit-all">;
  /** Edge length in pixels. */
  readonly size: import("@angular/core").InputSignal<number>;
  /** Accessible name; leave unset for a decorative icon. */
  readonly label: import("@angular/core").InputSignal<string | undefined>;
  protected readonly glyph: import("@angular/core").Signal<typeof import("@lucide/angular").LucideFolderOpen | typeof import("@lucide/angular").LucideRadioTower | typeof import("@lucide/angular").LucideLayoutGrid | typeof import("@lucide/angular").LucideCable | typeof import("@lucide/angular").LucideActivity | typeof import("@lucide/angular").LucideCpu | typeof import("@lucide/angular").LucideInfo | typeof import("@lucide/angular").LucideSun | typeof import("@lucide/angular").LucideMoon | typeof import("@lucide/angular").LucideMaximize | typeof import("@lucide/angular").LucideMinimize | typeof import("@lucide/angular").LucidePanelLeftOpen | typeof import("@lucide/angular").LucidePanelLeftClose | typeof import("@lucide/angular").LucidePalette | typeof import("@lucide/angular").LucideShapes | typeof import("@lucide/angular").LucideBlocks | typeof import("@lucide/angular").LucideFileText | typeof import("@lucide/angular").LucideChevronLeft | typeof import("@lucide/angular").LucideChevronRight | typeof import("@lucide/angular").LucideX | typeof import("@lucide/angular").LucideRectangleHorizontal | typeof import("@lucide/angular").LucideSquare | typeof import("@lucide/angular").LucideSearch | typeof import("@lucide/angular").LucideEllipsis | typeof import("@lucide/angular").LucideMaximize2>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatIcon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatIcon, "neat-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The kit's icon vocabulary: names say what an icon means in the app, the value is the Lucide
 * glyph that draws it. This is the only file that references Lucide glyphs, so a glyph is swapped
 * in one place and only the glyphs listed here end up in an app's bundle.
 */
declare const NEAT_ICONS: {
  media: typeof LucideFolderOpen;
  streaming: typeof LucideRadioTower;
  viewer: typeof LucideLayoutGrid;
  peripherals: typeof LucideCable;
  stats: typeof LucideActivity;
  board: typeof LucideCpu;
  info: typeof LucideInfo;
  sun: typeof LucideSun;
  moon: typeof LucideMoon;
  'kiosk-enter': typeof LucideMaximize;
  'kiosk-exit': typeof LucideMinimize;
  'rail-expand': typeof LucidePanelLeftOpen;
  'rail-collapse': typeof LucidePanelLeftClose;
  palette: typeof LucidePalette;
  shapes: typeof LucideShapes;
  blocks: typeof LucideBlocks;
  document: typeof LucideFileText;
  previous: typeof LucideChevronLeft;
  next: typeof LucideChevronRight;
  close: typeof LucideX;
  'aspect-wide': typeof LucideRectangleHorizontal;
  'aspect-square': typeof LucideSquare;
  search: typeof LucideSearch;
  more: typeof LucideEllipsis;
  'fit-all': typeof LucideMaximize2;
};
type NeatIconName = keyof typeof NEAT_ICONS;
/** Every name in the registry, in registry order, for galleries and pickers. */
export declare const NEAT_ICON_NAMES: readonly NeatIconName[];
/** One page in the shell's rail. */
interface NeatNavItem {
  /** Shown as the link's name, its tooltip and, while the page is active, the page title. */
  label: string;
  icon: NeatIconName;
  /** Absolute app path, for example `/media`; the item stays active on routes nested under it. */
  path: string;
}
/** How long the pointer must rest before `KioskService.pointerIdle` turns true. */
export declare const KIOSK_POINTER_IDLE_MS = 2500;
/**
 * Kiosk mode for expos: the shell hides its rail and top bar, and pages can hide their own chrome
 * while the pointer rests (`pointerIdle`). Kiosk keeps the current colour scheme and is not
 * persisted; it comes from the button or from a `?kiosk` URL parameter read once at start.
 *
 * `enter()` also asks for browser fullscreen. The URL parameter does not, because browsers refuse
 * fullscreen without a user gesture; booth machines use the browser's own kiosk flag instead.
 * If fullscreen was obtained by `enter()`, leaving it (Esc) leaves kiosk mode too.
 *
 * A component whose UI lives outside the floating chrome but belongs to it (a popover opened from
 * the page toolbar) holds the toolbar with `holdToolbar()`, so the chrome does not fade under it.
 *
 * The document listeners are plain DOM listeners outside change detection; signals change only
 * when the state does, so pointer movement does not cause renders.
 */
export declare class KioskService {
  private readonly document;
  private readonly isActive;
  private readonly isPointerIdle;
  /** Whether the current fullscreen is the one `enter()` asked for. */
  private ownsFullscreen;
  /** Unreleased `holdToolbar()` calls; the pointer never counts as idle while there are any. */
  private holds;
  private idleTimer;
  readonly active: Signal<boolean>;
  /**
   * True once the pointer has rested for `KIOSK_POINTER_IDLE_MS`; false again on pointer or touch
   * input, and false throughout a `holdToolbar()`.
   */
  readonly pointerIdle: Signal<boolean>;
  constructor();
  /** Turns kiosk on and asks for fullscreen; kiosk stays on if fullscreen is refused. */
  enter(): Promise<void>;
  /** Turns kiosk off, leaving fullscreen only if `enter()` obtained it. */
  exit(): Promise<void>;
  toggle(): Promise<void>;
  /**
   * Keeps `pointerIdle` false, so the kiosk chrome stays shown, until the returned function is
   * called. Holds stack: the pointer can go idle again only once every hold is released, and then
   * only after resting a full `KIOSK_POINTER_IDLE_MS`. Releasing twice counts once.
   */
  holdToolbar(): () => void;
  private onFullscreenChange;
  private onActivity;
  /** Starts the countdown to idle over; while the toolbar is held there is nothing to count. */
  private restartIdleTimer;
  static ɵfac: i0.ɵɵFactoryDeclaration<KioskService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The app frame: an icon rail with the pages on the left (expandable to show labels), a top bar
 * with logo, app name, page title and app-specific items, and the content area for the routed
 * page. It fills the viewport; the content area gives its page the remaining space and never
 * scrolls itself, so pages own their scrolling (see `neat-page`).
 *
 * Content projection: the default slot is the content area (usually a `<router-outlet />`);
 * elements marked `neatTopbarEnd` go to the right side of the top bar. The active page's own
 * controls (`*neatPageToolbar`) appear between the page title and that end slot.
 *
 * Kiosk mode (`KioskService`, entered from the top bar or with `?kiosk`) drops the rail and the
 * top bar, gives the content area the whole viewport and floats an exit control over its top
 * right corner while the pointer moves; the page toolbar floats beside it on the same terms. Its
 * view is re-created on entering and leaving kiosk mode, so the page keeps the toolbar's state.
 */
export declare class NeatShell {
  readonly appName: import("@angular/core").InputSignal<string>;
  readonly navItems: import("@angular/core").InputSignal<NeatNavItem[]>;
  protected readonly theme: ThemeService;
  protected readonly kiosk: KioskService;
  protected readonly pageToolbar: import("@angular/core").Signal<import("@angular/cdk/portal").TemplatePortal<any> | null>;
  protected readonly toolbarLabel = "Page tools";
  private readonly router;
  private readonly injector;
  protected readonly activeMatch: IsActiveMatchOptions;
  protected readonly railExpanded: import("@angular/core").WritableSignal<boolean>;
  private readonly kioskExit;
  private readonly kioskButton;
  /** Label of the nav item the current route belongs to; the first match wins. */
  protected readonly pageTitle: import("@angular/core").Signal<string>;
  constructor();
  /**
   * The mirror of entering: leaving kiosk mode with the exit control removes it, which drops focus
   * to <body>; hand focus to the top-bar kiosk button that comes back, where kiosk mode was entered.
   * Not when kiosk mode ends otherwise (Esc leaving fullscreen, for example), when focus may be on
   * the page and must stay there.
   */
  protected focusKioskButtonAfterExit(): void;
  protected toggleRail(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatShell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatShell, "neat-shell", never, {
    "appName": {
      "alias": "appName";
      "required": true;
      "isSignal": true;
    };
    "navItems": {
      "alias": "navItems";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["[neatTopbarEnd]", "*"], true, never>;
}
/**
 * True for content rendered inside the page toolbar, in the top bar or the kiosk bar alike.
 * Internal to the kit: a popover reads it to hold the kiosk bar open while it is open.
 */
declare const IN_PAGE_TOOLBAR: InjectionToken<boolean>;
/**
 * Where the active page's toolbar is handed to the shell. Internal to the kit: pages use
 * `*neatPageToolbar`, the shell renders `portal`.
 */
declare class PageToolbarSlot {
  private readonly current;
  /** The registered page toolbar, or null when the active page has none. */
  readonly portal: Signal<TemplatePortal | null>;
  register(portal: TemplatePortal): void;
  unregister(portal: TemplatePortal): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageToolbarSlot, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The page's toolbar: `<div *neatPageToolbar>…</div>` on a page renders that content in the
 * shell's top bar, between the page title and the end slot, while the page exists. In kiosk mode,
 * where the top bar is hidden, it renders in a floating bar beside the exit control that shows
 * while the pointer moves. The content stays the page's: its bindings and injection context are
 * those of the page's template.
 *
 * One page toolbar at a time; a second one throws in dev mode.
 */
export declare class NeatPageToolbar {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPageToolbar, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPageToolbar, "[neatPageToolbar]", never, {}, {}, never, never, true, never>;
}
/**
 * A page in the shell's content area. It fills its parent and owns at most one scroll context:
 * with `scroll="body"` (the default) its body is the single scroll container; with
 * `scroll="none"` nothing scrolls and the content sizes itself to the page (for example a grid
 * that fits the screen).
 *
 * With `padding="page"` (the default) the content keeps the kit's page inset from the content
 * area's edges, so every app's pages line up; `padding="none"` lets full-bleed content (a video
 * grid, a map) reach the edges.
 *
 * Elements marked `neatPageAside` form the page's side panel (an inspector, say), shown on the
 * right while `aside="open"`. The panel is `--neat-aside-width` wide and scrolls on its own; the
 * body narrows beside it rather than being covered, keeping its own scroll setting. The aside is
 * the one supported second scroll context of a page. Closed, the panel and its content are out
 * of the DOM, but projected content is still instantiated (content projection always creates
 * it): gate expensive content with an `@if` of your own.
 */
export declare class NeatPage {
  readonly scroll: import("@angular/core").InputSignal<"none" | "body">;
  readonly padding: import("@angular/core").InputSignal<"none" | "page">;
  readonly aside: import("@angular/core").InputSignal<"open" | "closed">;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPage, "neat-page", never, {
    "scroll": {
      "alias": "scroll";
      "required": false;
      "isSignal": true;
    };
    "padding": {
      "alias": "padding";
      "required": false;
      "isSignal": true;
    };
    "aside": {
      "alias": "aside";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[neatPageAside]"], true, never>;
}
type NeatButtonVariant = 'primary' | 'secondary' | 'outlined' | 'text' | 'danger';
/** `touch` is a 3rem (48px) target, above the 44px minimum, for kiosk and touch screens. */
type NeatButtonSize = 'small' | 'medium' | 'large' | 'touch';
/**
 * A button or link styled as a kit button. Content is the label and/or a `neat-icon`; an
 * icon-only button needs an `aria-label` (and usually a `neatTooltip` with the same text).
 *
 * Built from Spartan's brain primitive and helm's class map rather than on helm's directive:
 * every host directive of a public directive becomes public API, and helm stays internal.
 * The classes go through Angular's `[class]` binding, not helm's `classes()`, which rewrites
 * `className` and can drop a `[class.x]` binding that changes in the same render.
 *
 * A toggle button binds `pressed`: it sets `aria-pressed` and the pressed look. Leave it undefined
 * on a button that is not a toggle, since `aria-pressed="false"` would announce one.
 */
export declare class NeatButton {
  readonly variant: import("@angular/core").InputSignal<NeatButtonVariant>;
  readonly size: import("@angular/core").InputSignal<NeatButtonSize>;
  /** Square (or, with `rounded`, circular) and sized for a single icon. */
  readonly iconOnly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Fully rounded ends: a pill, or a circle when `iconOnly`. */
  readonly rounded: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * A toggle's state: `aria-pressed` and the pressed look. Undefined for a button that is not a
   * toggle. Only for `button[neatButton]`: `aria-pressed` is not valid on a link. The primary
   * variant is a solid fill already, so its pressed look is the least distinct (2.78:1 against
   * its resting fill in dark); put toggles on the other variants.
   */
  readonly pressed: import("@angular/core").InputSignal<boolean | undefined>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatButton, "button[neatButton], a[neatButton]", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "iconOnly": {
      "alias": "iconOnly";
      "required": false;
      "isSignal": true;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
      "isSignal": true;
    };
    "pressed": {
      "alias": "pressed";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1$5.BrnButton;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
type NeatTooltipPosition = 'top' | 'right' | 'bottom' | 'left';
/**
 * A short text label shown on mouse or pen hover and on keyboard focus, hidden on leave, blur and
 * Escape; the host carries `aria-describedby` while it is shown. It never opens on touch (a tap
 * would trigger the host's action too), so it must not carry anything the host's accessible name
 * does not.
 *
 * `neatTooltip` takes a string only. Its declared type is brain's (`string | TemplateRef | null`)
 * because a host-directive alias keeps the primitive's input type; templates are not supported.
 *
 * Built like helm's tooltip (brain primitive plus helm's classes) rather than on top of it: a host
 * directive cannot re-expose inputs of its own host directives, and every host directive of a
 * public directive becomes public API.
 */
export declare class NeatTooltip {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatTooltip, "[neatTooltip]", never, {}, {}, never, never, true, [{
    directive: typeof i1$4.BrnTooltip;
    inputs: {
      "brnTooltip": "neatTooltip";
      "position": "neatTooltipPosition";
      "tooltipDisabled": "neatTooltipDisabled";
    };
    outputs: {};
  }]>;
}
/**
 * Helm's switch classes (`lib/ui/switch`), copied because helm keeps them inline rather than as
 * constants. switch.spec checks that each string still appears in the vendored helm, so a helm
 * update that changes one fails until this table is reviewed.
 *
 * Helm puts the track classes on its focusable button. Here the host button holds the label as
 * well, so the track is a span inside it, and the track's focus and validation classes never
 * match: the host draws the focus ring instead.
 */
declare const SWITCH_HELM_CLASSES: {
  /** `hlm-switch.ts`: the track, which carries `data-state` and `data-size` as brain's button does. */
  readonly track: "data-checked:bg-primary data-unchecked:bg-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 dark:data-unchecked:bg-input/80 rounded-full border border-transparent shadow-xs focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 data-[size=default]:h-[18.4px] data-[size=default]:w-[32px] data-[size=sm]:h-[14px] data-[size=sm]:w-[24px] group/switch inline-flex shrink-0 items-center transition-all outline-none data-disabled:cursor-not-allowed data-disabled:opacity-50";
  /** `hlm-switch-thumb.ts` */
  readonly thumb: "bg-background dark:data-unchecked:bg-foreground dark:data-checked:bg-primary-foreground rounded-full group-data-[size=default]/switch:size-4 group-data-[size=sm]/switch:size-3 data-unchecked:translate-x-0 data-checked:ltr:translate-x-[calc(100%-2px)] data-checked:rtl:-translate-x-[calc(100%-2px)] pointer-events-none block ring-0 transition-transform";
};
/**
 * An on/off switch on a native button: `<button neatSwitch [(checked)]="bars">Bars</button>`. The
 * content is the visible label and the accessible name; without content, give it an `aria-label`.
 * Space and Enter toggle it as they click any button.
 *
 * A component rather than a directive on brain's switch: brain's switch is itself a component that
 * renders its own button, so it cannot sit on this one. The host is the native button, which
 * brings focus, keyboard activation and `disabled`; the switch adds the role, the state and the
 * track drawn with helm's classes.
 */
export declare class NeatSwitch {
  readonly checked: import("@angular/core").ModelSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly hostClasses: string;
  protected readonly trackClasses: string;
  protected readonly thumbClasses: string;
  protected readonly state: import("@angular/core").Signal<"checked" | "unchecked">;
  protected toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSwitch, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSwitch, "button[neatSwitch]", never, {
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checkedChange";
  }, never, ["*"], true, never>;
}
/**
 * Helm's slider classes (`lib/ui/slider/src/lib/hlm-slider.ts`), copied because helm keeps them
 * inline in its template. slider.spec checks that each string still appears in the vendored helm,
 * so a helm update that changes one fails until this table is reviewed. The kit's slider is
 * horizontal with one thumb and no ticks; helm's vertical and tick classes stay as they are.
 */
declare const SLIDER_HELM_CLASSES: {
  readonly root: "group flex w-full touch-none flex-col select-none data-vertical:h-full data-vertical:min-h-40 data-vertical:w-auto data-vertical:flex-row data-[disabled]:pointer-events-none data-[disabled]:opacity-50";
  readonly frame: "relative flex w-full items-center group-data-vertical:w-auto group-data-vertical:flex-col";
  readonly track: "bg-muted rounded-full data-horizontal:h-1.5 data-horizontal:w-full data-vertical:h-full data-vertical:w-1.5 relative grow overflow-hidden";
  readonly range: "bg-primary absolute select-none data-draggable-range:cursor-move data-horizontal:h-full data-vertical:w-full";
  readonly thumb: "border-primary ring-ring/50 size-4 rounded-full border bg-white shadow-sm transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden absolute block shrink-0 select-none after:absolute after:-inset-2";
};
/**
 * A horizontal slider for one number: `<neat-slider label="Tile width" [min]="120" [max]="480"
 * [step]="10" [(value)]="width" />`. `label` is the accessible name (it is not displayed); arrows
 * step, Page Up and Down and Shift step by ten, Home and End jump to the ends.
 *
 * `value` changes on every step of a drag, not only when the pointer is released, so whatever it
 * drives (the tile grid's repacking, for one) previews live. A value outside `min`..`max` is shown
 * clamped and stays as it is until the user moves the slider.
 *
 * `describedBy` is the id of the element that describes the slider (a note on where its value
 * applies, say); it goes on the thumb, the focusable element, like the name. The disabled state is
 * mirrored on the thumb as `aria-disabled` too: brain sets it on the root only, which assistive
 * technology never reaches from the thumb.
 *
 * Brain's slider is the host directive; its track, range and thumb directives draw it with helm's
 * classes. Brain holds a list of values (it also does ranges), so the kit's single number is kept
 * in step with it here.
 */
export declare class NeatSlider {
  readonly value: import("@angular/core").ModelSignal<number>;
  readonly min: import("@angular/core").InputSignal<number>;
  readonly max: import("@angular/core").InputSignal<number>;
  readonly step: import("@angular/core").InputSignal<number>;
  /** The accessible name, announced with the value. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The id of the element that describes the slider; announced after the name and value. */
  readonly describedBy: import("@angular/core").InputSignal<string | undefined>;
  protected readonly rootClasses: string;
  protected readonly frameClasses: string;
  protected readonly trackClasses: string;
  protected readonly rangeClasses: string;
  protected readonly thumbClasses: string;
  /** Brain's disabled state (also set by forms), as the attribute the thumb mirrors. */
  protected readonly disabledAttr: Signal<'true' | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSlider, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSlider, "neat-slider", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": true;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": true;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "describedBy": {
      "alias": "describedBy";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, [{
    directive: typeof i1$3.BrnSlider;
    inputs: {
      "min": "min";
      "max": "max";
      "step": "step";
      "disabled": "disabled";
      "aria-label": "label";
    };
    outputs: {};
  }]>;
}
/** One choice of a `neat-segmented`: its value, its label and an optional icon before the label. */
interface NeatSegmentedOption<T> {
  readonly value: T;
  readonly label: string;
  readonly icon?: NeatIconName;
}
/**
 * Helm's toggle-group classes (`lib/ui/toggle-group`), copied because helm keeps them inline; the
 * segment's variant classes come from helm's exported `toggleVariants`. segmented.spec checks
 * that each copied string still appears in the vendored helm, so a helm update that changes one
 * fails until this table is reviewed.
 */
declare const SEGMENTED_HELM_CLASSES: {
  /** `hlm-toggle-group.ts` */
  readonly group: "rounded-md data-[spacing=0]:data-[variant=outline]:shadow-xs group/toggle-group flex w-fit flex-row items-center gap-[--spacing(var(--gap))] data-vertical:flex-col data-vertical:items-stretch";
  /** `hlm-toggle-group-item.ts` */
  readonly item: "data-[state=on]:bg-muted group-data-[spacing=0]/toggle-group:rounded-none group-data-[spacing=0]/toggle-group:px-2 group-data-[spacing=0]/toggle-group:shadow-none group-data-horizontal/toggle-group:data-[spacing=0]:first:rounded-s-md group-data-vertical/toggle-group:data-[spacing=0]:first:rounded-t-md group-data-horizontal/toggle-group:data-[spacing=0]:last:rounded-e-md group-data-vertical/toggle-group:data-[spacing=0]:last:rounded-b-md shrink-0 focus:z-10 focus-visible:z-10 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:border-s-0 group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:border-t-0 group-data-horizontal/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-s group-data-vertical/toggle-group:data-[spacing=0]:data-[variant=outline]:first:border-t";
};
/**
 * A row of mutually exclusive choices, such as a tile shape: `<neat-segmented label="Tile shape"
 * [options]="shapes" [(value)]="shape" />`. It is a radio group named by `label`: one tab stop
 * (the checked option, else the first), arrow keys move the choice and wrap, Home and End jump to
 * the ends, and a click on the checked option keeps it checked.
 *
 * Built on helm's toggle-group look but not on brain's toggle group: brain makes its items pressed
 * toggle buttons (`aria-pressed`, rewritten on every change) with no arrow keys, while a choice of
 * one is a radio group. The roles, the roving tab stop, the keys and `data-state` are the kit's.
 */
export declare class NeatSegmented<T> {
  readonly value: import("@angular/core").ModelSignal<T>;
  readonly options: import("@angular/core").InputSignal<readonly NeatSegmentedOption<T>[]>;
  /** The group's accessible name; each option is named by its own label. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly groupClasses: string;
  protected readonly itemClasses: string;
  /** The option keyboard focus enters on: the checked one, else the first. */
  protected readonly tabStop: import("@angular/core").Signal<number>;
  private readonly segments;
  /** Moves the choice from the segment at `current` (the one with focus) as the key says. */
  protected move(event: KeyboardEvent, current: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSegmented<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSegmented<any>, "neat-segmented", never, {
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
/**
 * Helm's tabs classes (`lib/ui/tabs`), copied because helm keeps them inline; the list's classes
 * come from helm's exported `listVariants`. tabs.spec checks that each copied string still appears
 * in the vendored helm, so a helm update that changes one fails until this table is reviewed.
 */
declare const TABS_HELM_CLASSES: {
  /** `hlm-tabs.ts` */
  readonly root: "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col";
  /** `hlm-tabs-trigger.ts`, in its four parts: base, line variant, active, and the underline. */
  readonly trigger: "gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_neat-icon:not([class*='text-'])]:text-[length:--spacing(4)] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring text-foreground/60 hover:text-foreground dark:text-muted-foreground dark:hover:text-foreground relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_neat-icon]:pointer-events-none [&_neat-icon]:shrink-0";
  readonly triggerLine: "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent";
  readonly triggerActive: "data-active:bg-background dark:data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 data-active:text-foreground";
  readonly triggerIndicator: "after:bg-foreground after:absolute after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100";
  /** `hlm-tabs-content.ts` */
  readonly content: "flex-1 text-sm outline-none";
};
/**
 * One tab of a `neat-tabs`. Its panel goes in an `<ng-template>`, so it is created only while the
 * tab is open and destroyed when another one opens:
 * `<neat-tab label="General" value="general"><ng-template>…</ng-template></neat-tab>`.
 */
export declare class NeatTab {
  readonly label: import("@angular/core").InputSignal<string>;
  /** Identifies the tab in `neat-tabs`' `value`; unique within one `neat-tabs`. */
  readonly value: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The panel template, which `neat-tabs` renders while this tab is open. */
  readonly content: import("@angular/core").Signal<TemplateRef<any>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTab, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTab, "neat-tab", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["content"], never, true, never>;
}
/**
 * Tabs with one open panel: `<neat-tabs label="Channel settings" [(value)]="tab">` around
 * `neat-tab` children. The tab list is named by `label`. Arrow keys move to the next or previous
 * tab and open it, skipping disabled tabs and wrapping; Home and End jump to the ends; the open tab
 * is the only tab stop. Only the open tab's panel exists: the others are not created at all. When
 * `value` names no tab (or is unset), the first enabled tab is open, so the list stays reachable.
 *
 * The tabs do not scroll: a panel taller than the space it has is for the surrounding page or pane
 * to scroll, which keeps one scroll context.
 *
 * Brain's tabs are the host directive; its list, trigger and content directives give the tab
 * roles, the keyboard handling and the panel's labelling. Brain derives element ids from the tab
 * keys alone (`brn-tabs-label-<key>`), so the kit gives brain keys prefixed per instance and keeps
 * `value` in the app's terms. Brain's lazy content keeps a visited panel alive, so the kit renders
 * the open panel itself.
 */
export declare class NeatTabs {
  /** The open tab's `value`. */
  readonly value: import("@angular/core").ModelSignal<string | undefined>;
  /** The tab list's accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  protected readonly tabs: import("@angular/core").Signal<readonly NeatTab[]>;
  /** The tab shown open: the one `value` names, else the first enabled one. */
  protected readonly open: import("@angular/core").Signal<string | undefined>;
  protected readonly rootClasses: string;
  protected readonly listClasses: string;
  protected readonly triggerClasses: string;
  protected readonly contentClasses: string;
  private readonly prefix;
  constructor();
  /** The key brain knows a tab by: its value, prefixed per instance. */
  protected key(value: string): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTabs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTabs, "neat-tabs", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, ["tabs"], never, true, [{
    directive: typeof i1$2.BrnTabs;
    inputs: {};
    outputs: {};
  }]>;
}
type NeatPopoverAlign = 'start' | 'center' | 'end';
/**
 * Helm's popover classes (`lib/ui/popover`), copied because helm keeps them inline. popover.spec
 * checks that the string still appears in the vendored helm, so a helm update that changes it
 * fails until this table is reviewed.
 */
declare const POPOVER_HELM_CLASSES: {
  /** `hlm-popover-content.ts`: the panel. */
  readonly content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 gap-4 rounded-md p-4 text-sm shadow-md ring-1 duration-100 relative flex w-72 flex-col outline-none";
};
/** The panel's content: `<ng-template neatPopoverContent>…</ng-template>` inside `neat-popover`. */
export declare class NeatPopoverContent {
  readonly template: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopoverContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPopoverContent, "ng-template[neatPopoverContent]", never, {}, {}, never, never, true, never>;
}
/**
 * The button that opens and closes a `neat-popover`: `<button neatPopoverTrigger>` inside it. It
 * can be a `neatButton` with a tooltip as well. It announces the dialog it opens
 * (`aria-haspopup`, `aria-expanded`) and names the panel in `aria-controls` while it is open.
 *
 * The kit's own rather than brain's trigger: brain's points `aria-controls` at the panel while it
 * is closed too, when no element has that id.
 */
export declare class NeatPopoverTrigger {
  protected readonly popover: NeatPopover;
  readonly element: HTMLButtonElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopoverTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatPopoverTrigger, "button[neatPopoverTrigger]", never, {}, {}, never, never, true, never>;
}
/**
 * A panel of controls that opens below a button and stays open while they are used:
 *
 * ```html
 * <neat-popover label="View options" align="end" [(open)]="viewOptionsOpen">
 *   <button neatButton neatPopoverTrigger iconOnly aria-label="View options">…</button>
 *   <ng-template neatPopoverContent>…</ng-template>
 * </neat-popover>
 * ```
 *
 * The panel is a non-modal dialog named by `label`, on the popover surface. `align` lines it up
 * with the trigger's start, centre or end; it flips above the trigger when there is no room below.
 * The content template is created on opening and destroyed on closing, so keep its state (a typed
 * value, a checked switch) in the page. On opening, focus moves to the panel's first focusable
 * element. Escape, a click outside, the trigger, or `open` set to false close it; focus then goes
 * back to the trigger, unless the closing click put it somewhere else. Setting `open` to true
 * opens it as the trigger does, which is how a keyboard shortcut opens it.
 *
 * In the page toolbar, an open popover keeps the kiosk bar shown (`KioskService.holdToolbar`):
 * the panel lies outside the bar, so a pointer resting on it would otherwise fade the bar out.
 *
 * Brain's popover is the host directive: it places the panel, closes it on Escape and outside
 * clicks and moves focus in and out. The kit renders the dialog element itself, so that it can
 * name it, and gives the overlay pane around it no role.
 */
export declare class NeatPopover {
  /** Whether the panel is open; it follows the trigger, Escape and outside clicks. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  /** The panel's accessible name. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly panelId: string;
  protected readonly panelClasses: string;
  protected readonly brain: BrnPopover;
  protected readonly content: import("@angular/core").Signal<NeatPopoverContent>;
  private readonly trigger;
  constructor();
  /** Opens or closes the panel, as the trigger does. */
  toggle(): void;
  private show;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatPopover, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatPopover, "neat-popover", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, ["content", "trigger"], ["*"], true, [{
    directive: typeof i1$1.BrnPopover;
    inputs: {
      "align": "align";
    };
    outputs: {};
  }]>;
}
/** What `NeatConfirm.ask` asks: the copy of the dialog and the weight of its confirm button. */
interface NeatConfirmOptions {
  /** The question, which names the dialog: "Reset all channels to global?". */
  title: string;
  /** What confirming does, which describes the dialog. */
  message: string;
  /** The confirm button's label, a verb for the action: "Reset". */
  confirmLabel: string;
  /** The cancel button's label; `'Cancel'` by default. */
  cancelLabel?: string;
  /** `'danger'` for an action that destroys or cannot be undone; `'default'` by default. */
  tone?: 'default' | 'danger';
}
/**
 * Helm's alert-dialog classes (`lib/ui/alert-dialog`), copied because helm keeps them inline.
 * confirm.spec checks that each string still appears in the vendored helm, so a helm update that
 * changes one fails until this table is reviewed.
 */
declare const CONFIRM_HELM_CLASSES: {
  /** `hlm-alert-dialog-content.ts`: the panel. */
  readonly content: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 bg-popover text-popover-foreground ring-foreground/10 gap-6 rounded-xl p-6 ring-1 duration-100 data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-lg group/alert-dialog-content grid w-full outline-none";
  /** `hlm-alert-dialog-header.ts`: title above message. */
  readonly header: "grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-6 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-start sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]";
  /** `hlm-alert-dialog-title.ts`. */
  readonly title: "text-lg font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2";
  /** `hlm-alert-dialog-description.ts`: the message. */
  readonly description: "text-muted-foreground *:[a]:hover:text-foreground text-sm text-balance md:text-pretty *:[a]:underline *:[a]:underline-offset-3";
  /** `hlm-alert-dialog-footer.ts`: the buttons, stacked on narrow screens. */
  readonly footer: "flex flex-col-reverse gap-2 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end";
  /** `hlm-alert-dialog-overlay.ts`: the backdrop over the page. */
  readonly overlay: "data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 isolate bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs";
};
/**
 * Asks the user to confirm an action before the app takes it:
 *
 * ```ts
 * if (await this.confirm.ask({ title: 'Reset all channels to global?', message: '…',
 *     confirmLabel: 'Reset', tone: 'danger' })) {
 *   this.store.resetAllChannels();
 * }
 * ```
 *
 * `ask` shows a modal alert dialog, named by the title and described by the message, with a cancel
 * and a confirm button. It resolves `true` when the confirm button is pressed and `false` on
 * cancel or Escape, once the dialog has closed and focus is back on the element that had it. A
 * click on the backdrop does nothing: the question needs an answer. Focus starts on cancel, the
 * choice that changes nothing, and stays inside the dialog. A `tone: 'danger'` confirm button is
 * the danger `neatButton`, otherwise the primary one.
 *
 * One question at a time: an `ask` while a dialog is open resolves that one `false` and closes it
 * at once, then shows the new one, which gives focus back where the first came from. A dialog
 * still closing after a button press keeps that answer.
 */
export declare class NeatConfirm {
  private readonly dialogs;
  private current;
  ask(options: NeatConfirmOptions): Promise<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatConfirm, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** `medium` matches the kit's medium button (2.25rem), `small` its small one (2rem). */
type NeatInputSize = 'small' | 'medium';
/**
 * Helm's input classes (`lib/ui/input/src/lib/hlm-input.ts`), copied because helm keeps them
 * inline. input.spec checks that the string still appears in the vendored helm, so a helm update
 * that changes it fails until this is reviewed.
 */
declare const INPUT_HELM_CLASSES = "dark:bg-input/30 border-input focus-visible:border-ring focus-visible:ring-ring/50 data-[matches-spartan-invalid=true]:ring-destructive/20 dark:data-[matches-spartan-invalid=true]:ring-destructive/40 data-[matches-spartan-invalid=true]:border-destructive dark:data-[matches-spartan-invalid=true]:border-destructive/50 h-9 rounded-md border bg-transparent px-2.5 py-1 text-base shadow-xs transition-[color,box-shadow] file:h-7 file:text-sm file:font-medium focus-visible:ring-3 data-[matches-spartan-invalid=true]:ring-3 md:text-sm file:text-foreground placeholder:text-muted-foreground w-full min-w-0 outline-none file:inline-flex file:border-0 file:bg-transparent disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50";
/**
 * A text or number field: `<input neatInput type="number" inputmode="numeric" min="1">`. Every
 * native attribute (type, inputmode, min, max, placeholder, id, disabled) keeps its meaning; the
 * kit only styles the field. Name it with a `<label for>` or an `aria-label`.
 *
 * `size` is the kit's height, not the native character width: bind it (`[size]="'small'"`) or set
 * it as an attribute, which the browser ignores as a width since it is not a number.
 *
 * Brain's input is the host directive. Its `id` input is exposed so that an `id` the app sets
 * stays on the element (brain would otherwise replace it with its own) and a label can point at
 * it.
 */
export declare class NeatInput {
  readonly size: import("@angular/core").InputSignal<NeatInputSize>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatInput, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatInput, "input[neatInput]", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.BrnInput;
    inputs: {
      "id": "id";
    };
    outputs: {};
  }]>;
}
/**
 * One metadata message from the stream's data channel. `_insight.rtp_timestamp` identifies the
 * video frame the message describes; messages without it can only be matched by arrival order.
 */
interface NeatMetadataMessage {
  type: string;
  timestamp?: number;
  frame_id?: unknown;
  data?: unknown;
  _insight?: {
    rtp_timestamp?: number;
  };
}
/**
 * Parses a data-channel text message. Returns null for anything that is not a JSON object with a
 * string `type`, so a caller can drop it without reasoning about the payload. Everything else,
 * `data` and `_insight` included, is kept exactly as received.
 */
export declare function parseMetadataMessage(text: string): NeatMetadataMessage | null;
/** A message with the time it arrived, as the queue stores and returns it. */
interface NeatMetadataItem {
  receivedAt: number;
  data: NeatMetadataMessage;
}
/** An item as returned for drawing; `held` marks one redrawn from an earlier frame. */
type NeatDrawableMetadataItem = NeatMetadataItem & {
  held?: true;
};
/** The last item of each metadata type, kept by `holdOverlays` between frames. */
type NeatHeldOverlays = Map<string, {
  item: NeatMetadataItem;
  matchedAt: number;
}>;
/** Cumulative counters; they survive `resetLatenessWindow`. */
interface NeatMetadataQueueStats {
  timestampMatches: number;
  arrivalFallbacks: number;
  frameMisses: number;
  expired: number;
  evicted: number;
  untimestampedReceived: number;
  late: number;
}
interface NeatMetadataSnapshot extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  /** Null until the window holds enough messages for a share to mean anything. */
  recentLateShare: number | null;
  /** Null while the window holds no late message whose frame is still remembered. */
  recentLatenessMedianMs: number | null;
  recentLatenessP90Ms: number | null;
  recentLatenessMaxMs: number | null;
}
/**
 * The per-stream queue. Create it with `createMetadataQueue` and pass it to this module's
 * functions; `metadataQueueSnapshot` reports what it holds. Its contents are not accessible.
 */
interface NeatMetadataQueue {
  readonly __neatMetadataQueue: never;
}
export declare function createMetadataQueue(): NeatMetadataQueue;
export declare function enqueueMetadata(handle: NeatMetadataQueue, message: NeatMetadataMessage, receivedAt: number): void;
/**
 * The metadata to draw on a frame the browser is presenting. `rtpTimestamp` is the frame's RTP
 * timestamp, or null when the browser does not report one. A retention of 0 never expires.
 */
export declare function takeMetadataForFrame(handle: NeatMetadataQueue, rtpTimestamp: number | null, metadataRetentionMs: number, now: number): NeatMetadataItem[];
export declare const OVERLAY_HOLD_MS = 200;
export declare function holdOverlays(held: NeatHeldOverlays, overlays: NeatMetadataItem[], now: number): NeatDrawableMetadataItem[];
export declare function metadataQueueSnapshot(handle: NeatMetadataQueue): NeatMetadataSnapshot;
export declare function resetLatenessWindow(handle: NeatMetadataQueue): void;
/** The part of a queue snapshot that the late notice reads. */
type NeatLatenessSnapshot = Pick<NeatMetadataSnapshot, 'recentLateShare' | 'recentLatenessMedianMs' | 'recentLatenessP90Ms'>;
/**
 * Why no buffer is suggested: the browser cannot set one, the window has no lateness sample, or
 * the suggestion would pass the maximum.
 */
type NeatLateNoticeBlocker = 'unsupported' | 'unmeasured' | 'maximum';
/**
 * The notice's second button: `raise` lifts the value the channels follow to the suggestion;
 * `follow` only lets this channel adopt the followed value, which already covers it.
 */
interface NeatGlobalBufferAction {
  kind: 'raise' | 'follow';
  valueMs: number;
}
interface NeatLateNoticeDetails {
  latenessMs: number | null;
  latePercent: number | null;
  bufferMs: number;
  suggestedBufferMs: number | null;
  blockedBy: NeatLateNoticeBlocker | null;
  globalAction: NeatGlobalBufferAction | null;
}
export declare function nextWarningActive(active: boolean, recentLateShare: number | null): boolean;
export declare function suggestedBufferMs(currentBufferMs: number, p90LatenessMs: number | null): number | null;
export declare function bufferSettleMs(previousBufferMs: number, nextBufferMs: number): number;
export declare function lateNoticeDetails(snapshot: NeatLatenessSnapshot, currentBufferMs: number, bufferSupported: boolean, followedBufferMs?: number | null): NeatLateNoticeDetails;
/**
 * Identity colours, handed out by the overlay colour allocator in slot order. The first 20 are
 * hand-picked to stay apart on dark and bright video; the last 20 are overflow. Keep 40 entries;
 * overlay-palette.spec.ts checks their separation. Five per row keeps the slot numbers countable.
 */
declare const OVERLAY_PALETTE: readonly string[];
/** The colour of an overlay with no identity: a track or pose without an id, a label-less class. */
declare const OVERLAY_NEUTRAL_COLOR = "#f8fafc";
/** The dark plate behind track and pose labels, so the label reads in its identity colour. */
declare const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
/** ROI polygons: a faint fill so the video stays visible, and a full-strength outline. */
declare const OVERLAY_ROI_COLORS: {
  readonly inclusion: {
    readonly fill: "rgba(0,255,0,0.1)";
    readonly stroke: "green";
  };
  readonly exclusion: {
    readonly fill: "rgba(255,0,0,0.1)";
    readonly stroke: "red";
  };
};
/** The colour a class style row resolves to when its stored colour is missing or not a string. */
export declare const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
/** How a class's boxes and outlines are stroked. */
type NeatOverlayLineStyle = 'solid' | 'dashed' | 'dotted';
/**
 * A class style row: overlays whose label equals `label` draw in `color` with this line. The row
 * labelled `default` applies to every label without a row of its own.
 */
interface NeatOverlayClassStyle {
  readonly label: string;
  readonly color: string;
  readonly style: NeatOverlayLineStyle;
  /** Line width in CSS pixels: thin (1) or thick (3). It overrides `general.lineWidth`. */
  readonly width: 1 | 3;
}
/**
 * A region of interest. Coordinates are normalized to 0..1 of the video frame, so a polygon fits
 * any resolution the stream is sent at.
 */
interface NeatRoiPolygon {
  readonly type: 'inclusion' | 'exclusion';
  readonly points: readonly {
    readonly x: number;
    readonly y: number;
  }[];
}
/**
 * The resolved overlay settings for one channel. The app resolves them once per change (defaults,
 * global values, the channel's own values); drawing reads them every frame and never parses or
 * validates them.
 */
interface NeatOverlaySettings {
  readonly general: {
    /** Line width in CSS pixels for every overlay line a class row does not override. */
    readonly lineWidth: number;
    /** Draw the ROI polygons under the detection, segmentation and tracking overlays. */
    readonly showRoi: boolean;
    /** Hide detections, segments and tracks whose box centre falls outside the ROI. */
    readonly applyRoiFiltering: boolean;
  };
  readonly types: {
    readonly 'object-detection': {
      readonly visible: boolean;
      /** 0..1; an object without a confidence always passes. */
      readonly confidenceThreshold: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly segmentation: {
      readonly visible: boolean;
      /** 0..1; a segment without a confidence counts as fully confident. */
      readonly confidenceThreshold: number;
      /** 0..1, the alpha of mask fills. */
      readonly maskOpacity: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly tracking: {
      readonly visible: boolean;
      readonly confidenceThreshold: number;
      readonly history: {
        /** Draw each track's recent centre positions as a trail. */
        readonly enabled: boolean;
        /** Positions kept per track. */
        readonly trailLength: number;
        /** How long the trail of a track that left the frame stays, in milliseconds. */
        readonly lostTrackTtlMs: number;
      };
    };
    readonly 'pose-estimation': {
      readonly visible: boolean;
      /** Dots on the joints. */
      readonly showKeypoints: boolean;
      /** Joint names next to the dots. */
      readonly showKeypointLabels: boolean;
    };
    readonly classification: {
      readonly visible: boolean;
    };
  };
  readonly roi: readonly NeatRoiPolygon[];
}
/** The settings a channel draws with when nothing is stored. */
export declare const NEAT_OVERLAY_DEFAULTS: NeatOverlaySettings;
/** An identity that has not been drawn for this long no longer holds its slot. */
declare const RELEASE_AFTER_MS = 5000;
/**
 * What an identity names. A class label names the same thing on every channel; track and pose
 * ids are only unique within one stream.
 */
type ColorNamespace = 'class' | 'track' | 'pose';
/** Hands out palette colours to identities; one per tile. */
interface ColorAllocator {
  /** The colour of `identity`, recording that it was drawn at `now`. */
  colorFor(channelIndex: number, namespace: ColorNamespace, identity: unknown, now: number): string;
  /** Drops the track and pose colours. Class colours are the page's and stay. */
  clear(): void;
  size(channelIndex: number, namespace: ColorNamespace): number;
}
/**
 * The page's overlay colour memory. Class colours are shared by every tile created with the same
 * instance, so one class has one colour on every tile; track and pose colours stay per tile.
 * Provided in root for the page; a test or a second, independent page creates its own. Apps only
 * pass it to `createOverlayState`; it has no members of its own.
 */
export declare class NeatOverlayColors {
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatOverlayColors, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A tile's allocator: its track and pose colours are its own, its class colours are `colors`'.
 * Internal; `createOverlayState` calls it. One map per (channel, namespace), or the shared map for
 * classes.
 *
 * A new identity takes the lowest free slot. When every slot is held, it takes the slot whose
 * holders have all been absent for longer than RELEASE_AFTER_MS, the one absent longest first. An
 * identity drawn more recently than that is live, and a live identity never loses its slot: when
 * every slot is live, the newcomer shares the slot drawn longest ago. Ties go to the identity
 * inserted first. Each map is independent; timestamps in one map do not affect another. Every
 * tile draws with the page's clock, so `lastSeen` values from different tiles compare correctly.
 */
declare function createColorAllocator(colors: NeatOverlayColors): ColorAllocator;
/**
 * The colour to draw an identity in: its override, then the `default` override for anything
 * unlisted, then the neutral colour for a missing identity, then the allocator's.
 */
declare function resolveColor({ allocator, channelIndex, namespace, identity, overrides, now }: {
  allocator: ColorAllocator;
  channelIndex: number;
  namespace: ColorNamespace;
  identity: unknown;
  overrides?: Readonly<Record<string, string>>;
  now: number;
}): string;
/**
 * Ceiling on a decoded mask: 2048 * 2048 pixels is 16 MiB at 4 bytes each. A memory bound only. It
 * cannot tell a full-image mask sent by mistake from a large legitimate one, since the schema lets
 * a producer send at bbox resolution; that mistake is caught by the dropped-segment warning, not by
 * this number.
 */
declare const MAX_RLE_MASK_PIXELS: number;
/** Where RLE masks are decoded and tinted: an offscreen 2D context and the ImageData it takes. */
interface MaskSurfaceFactory {
  createContext(): OffscreenCanvasRenderingContext2D;
  /** Wraps the decode buffer for `putImageData` without copying it. */
  wrapPixels(pixels: Uint8ClampedArray<ArrayBuffer>, width: number, height: number): ImageData;
}
/**
 * Runs alternate over the mask flattened column-major and the first run is background. Fills a
 * zeroed buffer, leaving foreground pixels opaque black for the caller to tint.
 */
declare function decodeRleMaskAlpha(pixels: Uint8ClampedArray, counts: readonly unknown[], maskWidth: number, maskHeight: number): Uint8ClampedArray;
/**
 * One reusable surface for RLE masks. A segment is decoded, tinted and drawn before the next one is
 * touched, and drawing is synchronous, so one canvas and one pixel buffer serve every segment of
 * every tile. The context is created on the first mask, so a page without RLE masks never
 * allocates one.
 */
declare class RleMaskCanvas {
  private readonly surface;
  private context;
  /** Grows to the largest mask seen and is never shrunk; a view of it is handed out per mask. */
  private pixels;
  constructor(surface: MaskSurfaceFactory);
  /**
   * Decodes `counts` into a `width`×`height` mask tinted with `color` and returns the canvas that
   * holds it, ready to be drawn. The caller checks the size against MAX_RLE_MASK_PIXELS.
   */
  paint(counts: readonly unknown[], width: number, height: number, color: string): OffscreenCanvas;
}
/** The page's one mask surface, shared by every tile; see RleMaskCanvas. */
declare function sharedMaskCanvas(): RleMaskCanvas;
/** The overlay canvas and the video under it, as drawFrame needs them. */
interface NeatOverlayView {
  /** The canvas's CSS size; the video is contained in it. */
  cssWidth: number;
  cssHeight: number;
  /** Device pixels per CSS pixel the canvas's backing store is sized with. */
  dpr: number;
  /** The video's intrinsic size, the space metadata coordinates are in. 0 before it is known. */
  videoWidth: number;
  videoHeight: number;
}
/** One message to draw; `held` marks one repeated from an earlier frame. */
interface NeatOverlayItem {
  message: NeatMetadataMessage;
  held: boolean;
}
/**
 * A channel's drawing memory across frames: track trails, its track and pose colours, the
 * warnings it has given. Create it with `createOverlayState` and pass it to `drawFrame`.
 */
interface NeatOverlayState {
  readonly __neatOverlayState: never;
}
/**
 * A channel's overlay state. Class colours come from `colors`, shared with every tile created
 * with the same instance; RLE masks are decoded on the page's one offscreen surface.
 */
export declare function createOverlayState(channel: number, colors: NeatOverlayColors): NeatOverlayState;
/**
 * Internal, for specs: a state whose RLE masks are decoded on a surface of its own, made by
 * `surface`, instead of the page's OffscreenCanvas.
 */
declare function createOverlayStateWithMasks(channel: number, colors: NeatOverlayColors, surface: MaskSurfaceFactory): NeatOverlayState;
/** Forgets the channel's track trails and its track and pose colours, as after the stream stops. */
export declare function resetOverlayState(handle: NeatOverlayState): void;
/**
 * Clears the overlay and draws `items` over a video shown with `object-fit: contain`. The context
 * is scaled by `view.dpr`, so every line width, font size and offset is in CSS pixels. A message
 * of an unknown type, or one whose strategy throws, is skipped with one warning per channel and
 * type; the frame's other messages still draw. Auxiliary-panel messages are skipped silently.
 */
export declare function drawFrame(ctx: CanvasRenderingContext2D, view: NeatOverlayView, items: readonly NeatOverlayItem[], handle: NeatOverlayState, settings: NeatOverlaySettings, now: number): void;
interface NeatTileArea {
  readonly width: number;
  readonly height: number;
}
interface NeatTilePack {
  readonly columns: number;
  readonly rows: number;
  /** How many tiles fit at once: `columns * rows`. */
  readonly perPage: number;
  /** The tile size actually used; below the requested width only when one tile did not fit. */
  readonly tileWidth: number;
  readonly tileHeight: number;
}
/**
 * The narrowest tile the kit lays out, in CSS pixels. Below this a tile is a postage stamp, so with
 * very many items in a small area the page pages instead of shrinking tiles further. Only an area
 * smaller than this makes a tile narrower (it then shrinks to the area).
 */
export declare const NEAT_MIN_TILE_WIDTH = 64;
/**
 * How many tiles of `tileWidth` fit into `area` with `gap` between them (and none around the
 * outside), in columns and rows. The gap counts only between tiles, which is why the area is
 * widened by one gap before dividing: `n` tiles take `n * tile + (n - 1) * gap`.
 *
 * `tileWidth` is raised to `NEAT_MIN_TILE_WIDTH` (a NaN, zero or negative one too). If even one
 * tile does not fit, it shrinks to the area while keeping 16:9, to whole CSS pixels so it
 * never rounds past the edge; that rule wins over the minimum. A tile is at least 1 px, so an
 * empty area (before the first measurement) still yields one tile.
 */
export declare function packTiles(area: NeatTileArea, tileWidth: number, gap: number): NeatTilePack;
/**
 * The widest tile, in whole CSS pixels, at which `count` tiles fit into `area` on one page. For
 * each column count from 1 to `count` the rows follow (`ceil(count / columns)`), and the tile is
 * bounded by both the width and the height of the area; the column count with the widest tile
 * wins. Whole pixels, rounded down, so a floating-point edge can never make `packTiles` drop a
 * row that this function counted on.
 *
 * Never below `NEAT_MIN_TILE_WIDTH`: when `count` tiles would need narrower ones, the result is
 * the minimum and the caller pages. A count that is not a finite number of at least 1 is one tile;
 * a fractional count is rounded down.
 */
export declare function fitAllTileWidth(area: NeatTileArea, count: number, gap: number): number;
/**
 * What the grid reports: the packing, the gap it used between tiles and the content box it was
 * packed into. A page that sizes tiles itself (to fit a count, say) needs the gap the grid used,
 * which may be the kit's token rather than a number the page chose.
 */
interface NeatTileLayout extends NeatTilePack {
  /** Space between tiles in CSS pixels. */
  readonly gap: number;
  readonly areaWidth: number;
  readonly areaHeight: number;
}
/**
 * Lays its items out as 16:9 tiles of a fixed width in a centred grid, as many as fit into its own box
 * without scrolling or overflowing. The tile width comes from the page (a slider, say); the grid
 * works out the columns, rows and tiles per page and reports them through `layout`, so the page
 * can slice its items to `perPage`. The grid never pages itself.
 *
 * It fills its parent and measures its own box, never the shell's, so it repacks when the parent
 * changes size for any reason. `layout` is emitted when a value of it changes, not on every
 * resize notification.
 *
 * `count` is the number of projected items. When fewer than a row's worth are shown, they form a
 * centred block of their own width instead of hugging the left edge of a full-width row.
 *
 * The gap defaults to the kit's `--neat-space-2` token, read once when the grid initialises; an
 * explicit `gap` (in CSS pixels) overrides it.
 */
export declare class NeatTileGrid {
  /** Tile width in CSS pixels; a tile wider than the area shrinks to it. */
  readonly tileWidth: import("@angular/core").InputSignal<number>;
  /** Space between tiles in CSS pixels; the kit's `--neat-space-2` when unset. */
  readonly gap: import("@angular/core").InputSignal<number | undefined>;
  /** The number of projected items. */
  readonly count: import("@angular/core").InputSignal<number>;
  readonly layout: import("@angular/core").OutputEmitterRef<NeatTileLayout>;
  private readonly gridElement;
  private readonly area;
  /** The token's gap, known once the grid has rendered and its stylesheet can be read. */
  private readonly tokenGap;
  /**
   * The gap in use. It waits for the token to be read even when `gap` is set, so the read never
   * sees a gap this component applied itself.
   */
  protected readonly gapPx: import("@angular/core").Signal<number | null>;
  private readonly packed;
  /** What the template draws: the packed tiles, in as many columns as there are items to show. */
  protected readonly view: import("@angular/core").Signal<{
    columns: number;
    gap: number;
    areaWidth: number;
    areaHeight: number;
    rows: number;
    perPage: number;
    tileWidth: number;
    tileHeight: number;
  } | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTileGrid, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTileGrid, "neat-tile-grid", never, {
    "tileWidth": {
      "alias": "tileWidth";
      "required": true;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": true;
      "isSignal": true;
    };
  }, {
    "layout": "layout";
  }, never, ["*"], true, never>;
}
/**
 * Where a `neat-video-tile` gets its video and metadata. The tile knows nothing about how they
 * arrive (WebRTC, a file, a canvas); the app implements this for its transport.
 */
interface NeatTileSource {
  /** The channel's video, or null while connecting or when it has none. */
  readonly stream: Signal<MediaStream | null>;
  /**
   * Registers a listener for raw metadata text; returns the unsubscribe function. `receivedAt` is
   * on the `performance.now()` clock, the one presented frames are timed with.
   */
  onMetadata(listener: (text: string, receivedAt: number) => void): () => void;
}
/** A tile whose stream presents no frame for this long has stopped. */
export declare const NEAT_STREAM_STALE_MS = 1800;
/**
 * `empty` until the stream presents its first frame, `playing` while frames arrive, `stopped`
 * once none has arrived for `NEAT_STREAM_STALE_MS`; it plays again when frames return.
 */
type NeatTileState = 'empty' | 'playing' | 'stopped';
/**
 * The tile's frame-sync counters and video state, as the app reports them (the `synchronization`
 * and `video` groups of vf's browser egress report). Counters are cumulative for the current
 * stream. Every count and pixel size is a whole number: vf parses them as integers and drops a
 * report with a fraction in one.
 */
interface NeatFrameStats extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  recentLatenessMedianMs: number | null;
  recentLatenessMaxMs: number | null;
  /** Valid metadata messages received in the last second. */
  metadataMessagesPerSecond: number;
  /** The video element when the stats were taken. */
  video: {
    /** `HTMLMediaElement.readyState`, 0 to 4. */
    readyState: number;
    paused: boolean;
    /** Seconds, fractional. */
    currentTime: number;
    videoWidth: number;
    videoHeight: number;
    /** Whole milliseconds since the stream's last presented frame; null before its first. */
    lastFrameAgeMs: number | null;
    /** Whether the tile is `playing`. */
    active: boolean;
  };
}
/**
 * Plays a source's video with its metadata drawn as overlays, each frame with the metadata that
 * describes it. It fills the box it is given.
 *
 * The frame loop runs outside Angular and touches no signal: per frame it matches the queued
 * metadata to the presented frame, holds a type that is missing for a moment, and draws. The
 * component sees a state change and, at most once a second, `frameStats`. Inputs the loop needs
 * are copied into fields when they change, so a frame never reads an input or resolves settings.
 *
 * With `bars` on, a bar along the bottom shows `label`, `status` and the chips projected with
 * `neatTileChip`, and a tile without video says so. With `bars` off it is only video and overlay.
 */
export declare class NeatVideoTile {
  readonly source: import("@angular/core").InputSignal<NeatTileSource | null>;
  /** The channel's resolved overlay settings; a new object for each change. */
  readonly settings: import("@angular/core").InputSignal<NeatOverlaySettings>;
  /** How long metadata waits for its frame, in milliseconds; 0 waits indefinitely. */
  readonly retentionMs: import("@angular/core").InputSignal<number>;
  /** The number overlay warnings name the tile by, such as the app's channel. */
  readonly channel: import("@angular/core").InputSignal<number>;
  /** The bar's left text, such as the channel number. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The bar's status text. */
  readonly status: import("@angular/core").InputSignal<string | null>;
  readonly bars: import("@angular/core").InputSignal<boolean>;
  readonly selected: import("@angular/core").InputSignal<boolean>;
  readonly stateChange: import("@angular/core").OutputEmitterRef<NeatTileState>;
  /** The frame-sync counters, once a second while there is a stream. */
  readonly frameStats: import("@angular/core").OutputEmitterRef<NeatFrameStats>;
  protected readonly state: import("@angular/core").WritableSignal<NeatTileState>;
  private readonly videoElement;
  private readonly canvasElement;
  private readonly colors;
  private readonly zone;
  private readonly document;
  private frameSettings;
  private frameRetentionMs;
  private overlayState;
  private currentState;
  private canvas;
  private context;
  /** The canvas's CSS size and pixel ratio; the video size is filled in per frame. */
  private readonly view;
  private playing;
  private queue;
  private readonly held;
  /** When the current stream last presented a frame; null until its first. */
  private lastFrameAt;
  private staleTimer;
  /** The last stale check found the tab hidden, so the frame time it would judge is from before. */
  private staleCheckSawHidden;
  private messagesThisSecond;
  private warnedUnreadable;
  private warnedPlayback;
  private destroyed;
  constructor();
  /** The metadata queue's counters and lateness window, for the app's lateness notice. */
  snapshot(): NeatMetadataSnapshot;
  /**
   * Forgets the lateness measured so far, as after the app changes the video sync buffer: what was
   * measured belongs to the old buffer. The cumulative counters stay.
   */
  resetLatenessWindow(): void;
  private play;
  /**
   * Muted autoplay is allowed everywhere, so a rejection is either an AbortError (a newer stream or
   * a pause interrupted it, which is expected) or a real refusal that would leave the tile empty for
   * good, such as NotAllowedError or NotSupportedError. Those are logged, once per tile.
   */
  private startPlayback;
  private stop;
  private receive;
  private present;
  /**
   * One timer at a time, re-armed for the remainder instead of on every frame, so a stream that
   * plays costs one timeout per stale period. A hidden tab presents no frames, so the check waits
   * there instead of stopping a stream that is still running. The first check after the tab
   * returns waits a full period too: the last frame time is from before the tab was hidden, and a
   * check right after the return, before the first new frame, would stop a live stream. A dead one
   * stops a period later.
   */
  private checkStale;
  /** Forgets what was drawn: the canvas, held overlays, track trails and track colours. */
  private clearOverlays;
  private setState;
  private reportFrameStats;
  private sizeCanvas;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatVideoTile, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatVideoTile, "neat-video-tile", never, {
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
    "retentionMs": {
      "alias": "retentionMs";
      "required": false;
      "isSignal": true;
    };
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "bars": {
      "alias": "bars";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
  }, {
    "stateChange": "stateChange";
    "frameStats": "frameStats";
  }, never, ["[neatTileChip]"], true, never>;
}
export type { ColorScale, ColorStep, NeatButtonSize, NeatButtonVariant, NeatColorScheme, NeatConfirmOptions, NeatDrawableMetadataItem, NeatFrameStats, NeatGlobalBufferAction, NeatHeldOverlays, NeatIconName, NeatInputSize, NeatLateNoticeBlocker, NeatLateNoticeDetails, NeatLatenessSnapshot, NeatMetadataItem, NeatMetadataMessage, NeatMetadataQueue, NeatMetadataQueueStats, NeatMetadataSnapshot, NeatNavItem, NeatOverlayClassStyle, NeatOverlayItem, NeatOverlayLineStyle, NeatOverlaySettings, NeatOverlayState, NeatOverlayView, NeatPopoverAlign, NeatRoiPolygon, NeatSegmentedOption, NeatTileArea, NeatTileLayout, NeatTilePack, NeatTileSource, NeatTileState, NeatTooltipPosition, SurfaceScale };