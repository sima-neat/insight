import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, ElementRef, TemplateRef, contentChild, effect, inject, input, model, untracked } from "@angular/core";
import { DOCUMENT, NgTemplateOutlet } from "@angular/common";
import { InteractivityChecker } from "@angular/cdk/a11y";
import { OverlayContainer } from "@angular/cdk/overlay";
import * as i1 from "@spartan-ng/brain/popover";
import { BrnPopover, BrnPopoverContent, provideBrnPopoverConfig, provideBrnPopoverDefaultOptions } from "@spartan-ng/brain/popover";
import { KioskService, ɵIN_PAGE_TOOLBAR, ɵhlm } from "@sima/neat-ui";
const PANEL_CLASSES = ɵhlm({ content: "bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 gap-4 rounded-md p-4 text-sm shadow-md ring-1 duration-100 relative flex w-72 flex-col outline-none" }.content, "ring-border [--neat-surface:var(--popover)]");
const SIDE_OFFSET = 4;
let nextPopoverId = 0;
var NeatPopoverContent = class NeatPopoverContent {
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopoverContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPopoverContent,
		isStandalone: true,
		selector: "ng-template[neatPopoverContent]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopoverContent,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatPopoverContent]" }]
	}]
});
var NeatPopoverTrigger = class NeatPopoverTrigger {
	popover = inject(NeatPopover);
	element = inject(ElementRef).nativeElement;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopoverTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: NeatPopoverTrigger,
		isStandalone: true,
		selector: "button[neatPopoverTrigger]",
		host: {
			attributes: {
				"type": "button",
				"aria-haspopup": "dialog"
			},
			listeners: { "click": "popover.toggle()" },
			properties: {
				"attr.aria-expanded": "popover.open()",
				"attr.aria-controls": "popover.open() ? popover.panelId : null"
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopoverTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[neatPopoverTrigger]",
			host: {
				type: "button",
				"aria-haspopup": "dialog",
				"[attr.aria-expanded]": "popover.open()",
				"[attr.aria-controls]": "popover.open() ? popover.panelId : null",
				"(click)": "popover.toggle()"
			}
		}]
	}]
});
var NeatPopover = class NeatPopover {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	panelId = `neat-popover-${++nextPopoverId}`;
	panelClasses = PANEL_CLASSES;
	brain = inject(BrnPopover);
	content = contentChild.required(NeatPopoverContent, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	trigger = contentChild.required(NeatPopoverTrigger, ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	overlayContainer = inject(OverlayContainer);
	interactivity = inject(InteractivityChecker);
	document = inject(DOCUMENT);
	constructor() {
		this.brain.stateChanged.subscribe((state) => this.open.set(state === "open"));
		effect(() => {
			const open = this.open();
			untracked(() => open ? this.show() : this.brain.close());
		});
		effect((onCleanup) => {
			if (!this.open()) return;
			const closeOnOutsideFocus = (event) => {
				if (event.target instanceof Node && !this.holdsFocus(event.target)) this.open.set(false);
			};
			this.document.addEventListener("focusin", closeOnOutsideFocus);
			onCleanup(() => this.document.removeEventListener("focusin", closeOnOutsideFocus));
		});
		const kiosk = inject(KioskService);
		if (inject(ɵIN_PAGE_TOOLBAR)) effect((onCleanup) => {
			if (this.open() && kiosk.active()) onCleanup(kiosk.holdToolbar());
		});
	}
	toggle() {
		this.open.update((open) => !open);
	}
	carryTabOrder(event) {
		if (event.key !== "Tab" || event.altKey || event.ctrlKey || event.metaKey) return;
		const tabbables = this.tabbablesIn(event.currentTarget);
		if (event.shiftKey && event.target === tabbables[0]) {
			event.preventDefault();
			this.open.set(false);
			this.trigger().element.focus();
		} else if (!event.shiftKey && event.target === tabbables.at(-1)) {
			const next = this.tabbableAfterTrigger();
			if (next) {
				event.preventDefault();
				next.focus();
			}
			this.open.set(false);
		}
	}
	holdsFocus(node) {
		return this.trigger().element.contains(node) || this.overlayContainer.getContainerElement().contains(node);
	}
	tabbablesIn(root) {
		const container = this.overlayContainer.getContainerElement();
		const walker = this.tabbableWalker(root, container);
		const found = [];
		for (let node = walker.nextNode(); node; node = walker.nextNode()) found.push(node);
		return found;
	}
	tabbableAfterTrigger() {
		const walker = this.tabbableWalker(this.document.body, this.overlayContainer.getContainerElement());
		walker.currentNode = this.trigger().element;
		return walker.nextNode();
	}
	tabbableWalker(root, excluded) {
		return this.document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, (node) => {
			if (node === excluded) return NodeFilter.FILTER_REJECT;
			return this.interactivity.isTabbable(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
		});
	}
	show() {
		const trigger = this.trigger().element;
		trigger.focus({ preventScroll: true });
		this.brain.setOrigin(trigger);
		this.brain.open();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatPopover,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NeatPopover,
		isStandalone: true,
		selector: "neat-popover",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: { classAttribute: "contents" },
		providers: [provideBrnPopoverConfig({ sideOffset: SIDE_OFFSET }), provideBrnPopoverDefaultOptions({ role: null })],
		queries: [{
			propertyName: "content",
			first: true,
			predicate: NeatPopoverContent,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "trigger",
			first: true,
			predicate: NeatPopoverTrigger,
			descendants: true,
			isSignal: true
		}],
		hostDirectives: [{
			directive: i1.BrnPopover,
			inputs: ["align", "align"]
		}],
		ngImport: i0,
		template: `
    <ng-content />
    <ng-template brnPopoverContent>
      <div
        role="dialog"
        [id]="panelId"
        [attr.aria-label]="label()"
        [attr.data-state]="brain.stateComputed()"
        [class]="panelClasses"
        (keydown)="carryTabOrder($event)"
      >
        <ng-container [ngTemplateOutlet]="content().template" />
      </div>
    </ng-template>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: BrnPopoverContent,
			selector: "[brnPopoverContent]",
			exportAs: ["brnPopoverContent"]
		}, {
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatPopover,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-popover",
			imports: [BrnPopoverContent, NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideBrnPopoverConfig({ sideOffset: SIDE_OFFSET }), provideBrnPopoverDefaultOptions({ role: null })],
			hostDirectives: [{
				directive: BrnPopover,
				inputs: ["align"]
			}],
			host: { class: "contents" },
			template: `
    <ng-content />
    <ng-template brnPopoverContent>
      <div
        role="dialog"
        [id]="panelId"
        [attr.aria-label]="label()"
        [attr.data-state]="brain.stateComputed()"
        [class]="panelClasses"
        (keydown)="carryTabOrder($event)"
      >
        <ng-container [ngTemplateOutlet]="content().template" />
      </div>
    </ng-template>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		content: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatPopoverContent), { isSignal: true }]
		}],
		trigger: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatPopoverTrigger), { isSignal: true }]
		}]
	}
});
export { NeatPopover, NeatPopoverContent, NeatPopoverTrigger };

//# sourceMappingURL=sima-neat-ui-popover.mjs.map