import { DOCUMENT, NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, InjectionToken, TemplateRef, afterRenderEffect, booleanAttribute, computed, contentChild, effect, inject, input, isDevMode, model, resource, signal, viewChild } from "@angular/core";
import { NeatButton, NeatIcon, NeatInlineButton, ɵreducedMotion } from "@sima/neat-ui";
import { NeatBubble } from "@sima/neat-ui/bubble";
const SETTLE_MS = 2500;
const CAPTION = {
	idle: "Copy",
	copied: "Copied",
	failed: "Could not copy"
};
const ANNOUNCEMENT = {
	idle: "",
	copied: "Copied to the clipboard.",
	failed: "Could not copy: the browser refused the clipboard."
};
var NeatCopyButton = class NeatCopyButton {
	text = input.required(...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	what = input.required(...ngDevMode ? [{ debugName: "what" }] : /* istanbul ignore next */ []);
	inline = input(false, {
		...ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	state = signal("idle", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	caption = computed(() => CAPTION[this.state()], ...ngDevMode ? [{ debugName: "caption" }] : /* istanbul ignore next */ []);
	icon = computed(() => this.state() === "copied" ? "check" : "copy", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	name = computed(() => this.state() === "idle" ? `Copy ${this.what()}` : this.caption(), ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	announcement = computed(() => ANNOUNCEMENT[this.state()], ...ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []);
	timer;
	constructor() {
		inject(DestroyRef).onDestroy(() => clearTimeout(this.timer));
	}
	async copy() {
		let copied = true;
		try {
			await navigator.clipboard.writeText(this.text());
		} catch {
			copied = false;
		}
		this.state.set(copied ? "copied" : "failed");
		clearTimeout(this.timer);
		this.timer = setTimeout(() => this.state.set("idle"), SETTLE_MS);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCopyButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatCopyButton,
		isStandalone: true,
		selector: "neat-copy-button",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			what: {
				classPropertyName: "what",
				publicName: "what",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			inline: {
				classPropertyName: "inline",
				publicName: "inline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    @if (inline()) {
      <button neatInlineButton type="button" [attr.aria-label]="name()" (click)="copy()">
        <neat-icon [name]="icon()" [size]="14" />
        {{ caption() }}
      </button>
    } @else {
      <button
        neatButton
        type="button"
        variant="text"
        size="small"
        [attr.aria-label]="name()"
        (click)="copy()"
      >
        <neat-icon [name]="icon()" [size]="16" />
        {{ caption() }}
      </button>
    }
    <span class="sr-only" role="status">{{ announcement() }}</span>
  `,
		isInline: true,
		styles: [":host{position:relative;display:inline-flex}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "directive",
				type: NeatInlineButton,
				selector: "button[neatInlineButton], a[neatInlineButton]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCopyButton,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-copy-button",
			imports: [
				NeatButton,
				NeatIcon,
				NeatInlineButton
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    @if (inline()) {
      <button neatInlineButton type="button" [attr.aria-label]="name()" (click)="copy()">
        <neat-icon [name]="icon()" [size]="14" />
        {{ caption() }}
      </button>
    } @else {
      <button
        neatButton
        type="button"
        variant="text"
        size="small"
        [attr.aria-label]="name()"
        (click)="copy()"
      >
        <neat-icon [name]="icon()" [size]="16" />
        {{ caption() }}
      </button>
    }
    <span class="sr-only" role="status">{{ announcement() }}</span>
  `,
			styles: [":host{position:relative;display:inline-flex}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: true
			}]
		}],
		what: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "what",
				required: true
			}]
		}],
		inline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inline",
				required: false
			}]
		}]
	}
});
const PLAIN = "plain";
const SCOPES = {
	keyword: [
		"keyword",
		"storage",
		"variable.language",
		"keyword.operator.new",
		"keyword.operator.expression",
		"keyword.operator.logical.python",
		"keyword.operator.sizeof",
		"keyword.operator.alignof",
		"keyword.operator.typeid",
		"keyword.operator.delete",
		"keyword.operator.cast",
		"punctuation.definition.template-expression",
		"punctuation.section.embedded",
		"markup.heading",
		"meta.diff.header",
		"entity.name.section",
		"punctuation.definition.list.begin.markdown"
	],
	string: [
		"string",
		"punctuation.definition.string",
		"storage.type.string",
		"markup.inline.raw",
		"markup.inserted"
	],
	comment: [
		"comment",
		"punctuation.definition.comment",
		"markup.quote"
	],
	constant: [
		"constant",
		"support.constant",
		"variable.other.constant",
		"variable.other.enummember",
		"entity.name.constant",
		"keyword.other.unit",
		"storage.type.number",
		"markup.changed"
	],
	type: [
		"entity.name.type",
		"entity.name.class",
		"entity.name.namespace",
		"entity.name.scope-resolution",
		"entity.other.inherited-class",
		"support.type",
		"support.class",
		"storage.type.built-in",
		"storage.type.primitive"
	],
	function: [
		"entity.name.function",
		"support.function",
		"variable.function",
		"meta.function-call.generic",
		"markup.underline.link",
		"string.other.link",
		"meta.diff.range"
	],
	property: [
		"variable.other.property",
		"variable.other.object.property",
		"variable.other.member",
		"support.variable.property",
		"support.type.property-name",
		"meta.object-literal.key",
		"entity.other.attribute-name",
		"entity.name.tag.yaml",
		"variable.other.env"
	],
	tag: [
		"entity.name.tag",
		"support.class.component",
		"markup.deleted"
	],
	[PLAIN]: [
		"keyword.operator",
		"variable.parameter",
		"punctuation.definition.tag",
		"markup.bold",
		"markup.italic",
		"meta.template.expression",
		"meta.embedded"
	]
};
const CODE_THEME = {
	name: "neat-code",
	type: "light",
	fg: PLAIN,
	bg: PLAIN,
	settings: Object.entries(SCOPES).map(([kind, scope]) => ({
		scope: [...scope],
		settings: { foreground: kind }
	}))
};
const KINDS = new Set(Object.keys(SCOPES).filter((kind) => kind !== PLAIN));
function kindOf(color) {
	return color !== void 0 && KINDS.has(color) ? color : null;
}
function codeLines(rows) {
	const empty = (row) => row.every((run) => !run.text);
	const shown = rows.length > 1 && empty(rows[rows.length - 1]) ? rows.length - 1 : rows.length;
	return rows.slice(0, shown).map((runs, i) => ({
		runs,
		end: i < rows.length - 1 ? "\n" : ""
	}));
}
function plainLines(code) {
	return codeLines(code.split("\n").map((text) => text ? [{
		text,
		kind: null
	}] : []));
}
let shiki;
function loadShiki() {
	shiki ??= Promise.all([import("@shikijs/primitive"), import("@shikijs/engine-javascript")]).then(([{ codeToTokensBase, createShikiPrimitive }, { createJavaScriptRegexEngine }]) => ({
		primitive: createShikiPrimitive({
			engine: createJavaScriptRegexEngine(),
			themes: [CODE_THEME],
			langs: []
		}),
		tokenize: codeToTokensBase
	}));
	shiki.catch(() => shiki = void 0);
	return shiki;
}
const highlighters = /* @__PURE__ */ new Map();
function runsOf(tokens) {
	const runs = [];
	for (const token of tokens) {
		const kind = kindOf(token.color);
		const last = runs[runs.length - 1];
		if (last?.kind === kind) runs[runs.length - 1] = {
			text: last.text + token.content,
			kind
		};
		else runs.push({
			text: token.content,
			kind
		});
	}
	return runs;
}
function loadHighlighter(load) {
	let highlighter = highlighters.get(load);
	if (highlighter) return highlighter;
	highlighter = Promise.all([loadShiki(), load()]).then(([{ primitive, tokenize }, grammar]) => {
		const registrations = grammar.default;
		primitive.loadLanguageSync(registrations);
		const lang = registrations[registrations.length - 1].name;
		return { lines: (code) => codeLines(tokenize(primitive, code, {
			lang,
			theme: CODE_THEME.name
		}).map(runsOf)) };
	});
	highlighters.set(load, highlighter);
	highlighter.catch(() => highlighters.delete(load));
	return highlighter;
}
const warned = /* @__PURE__ */ new Set();
function warnOnce(problem) {
	if (!isDevMode() || warned.has(problem)) return;
	warned.add(problem);
	console.warn(`neat-code-block: ${problem}`);
}
async function highlighterFor(language, languages) {
	if (!Object.hasOwn(languages, language)) {
		warnOnce(`no grammar for the language "${language}", so its code shows plain; add one with provideNeatCodeLanguages`);
		return;
	}
	try {
		return await loadHighlighter(languages[language]);
	} catch (error) {
		warnOnce(`the grammar of "${language}" did not load, so its code shows plain: ${error}`);
		return;
	}
}
function provideNeatCodeLanguages(languages) {
	return {
		provide: NEAT_CODE_LANGUAGES,
		useFactory: () => ({
			...inject(NEAT_CODE_LANGUAGES, {
				optional: true,
				skipSelf: true
			}) ?? DEFAULT_CODE_LANGUAGES,
			...languages
		})
	};
}
const python = () => import("@shikijs/langs/python");
const cpp = () => import("@shikijs/langs/cpp");
const shell = () => import("@shikijs/langs/shellscript");
const yaml = () => import("@shikijs/langs/yaml");
const typescript = () => import("@shikijs/langs/typescript");
const javascript = () => import("@shikijs/langs/javascript");
const markdown = () => import("@shikijs/langs/markdown");
const docker = () => import("@shikijs/langs/docker");
const DEFAULT_CODE_LANGUAGES = {
	python,
	py: python,
	cpp,
	"c++": cpp,
	c: () => import("@shikijs/langs/c"),
	shellscript: shell,
	bash: shell,
	sh: shell,
	shell,
	zsh: shell,
	json: () => import("@shikijs/langs/json"),
	yaml,
	yml: yaml,
	cmake: () => import("@shikijs/langs/cmake"),
	typescript,
	ts: typescript,
	cts: typescript,
	mts: typescript,
	javascript,
	js: javascript,
	cjs: javascript,
	mjs: javascript,
	html: () => import("@shikijs/langs/html"),
	css: () => import("@shikijs/langs/css"),
	markdown,
	md: markdown,
	docker,
	dockerfile: docker,
	go: () => import("@shikijs/langs/go")
};
const NEAT_CODE_LANGUAGES = new InjectionToken("neat-ui: the languages code blocks color", {
	providedIn: "root",
	factory: () => DEFAULT_CODE_LANGUAGES
});
function placesOf(mark, texts) {
	const isLine = (n) => Number.isInteger(n) && n >= 1 && n <= texts.length;
	const named = JSON.stringify(mark);
	const lines = `the code has lines 1 to ${texts.length}`;
	if ("lines" in mark) {
		const [from, to] = mark.lines;
		if (!isLine(from) || !isLine(to) || from > to) return `the mark ${named} names no lines: ${lines}`;
		return Array.from({ length: to - from + 1 }, (_, i) => ({
			line: from - 1 + i,
			whole: true
		}));
	}
	if (!isLine(mark.line)) return `the mark ${named} names no line: ${lines}`;
	const line = mark.line - 1;
	const text = texts[line];
	const columns = mark.from !== void 0 || mark.to !== void 0;
	if (mark.text !== void 0 && columns) return `the mark ${named} gives both text and columns: give one`;
	if (mark.text !== void 0) {
		const start = mark.text ? text.indexOf(mark.text) : -1;
		if (start < 0) return `the mark ${named} names no text on line ${mark.line}: ${JSON.stringify(text)}`;
		return [{
			line,
			whole: false,
			start,
			end: start + mark.text.length
		}];
	}
	if (columns) {
		const { from, to } = mark;
		const isColumn = (n) => n !== void 0 && Number.isInteger(n) && n >= 1 && n <= text.length;
		if (!isColumn(from) || !isColumn(to) || from > to) return `the mark ${named} names no columns of line ${mark.line}, which has 1 to ${text.length}`;
		return [{
			line,
			whole: false,
			start: from - 1,
			end: to
		}];
	}
	return [{
		line,
		whole: true
	}];
}
function placesIn(marks, texts, strict) {
	return marks.flatMap((mark, index) => {
		const places = placesOf(mark, texts);
		if (typeof places !== "string") return places.map((place) => ({
			...place,
			mark: index
		}));
		if (strict) throw new Error(`neat-code-block: ${places}`);
		return [];
	});
}
function runsBetween(runs, start, end) {
	const cut = [];
	let at = 0;
	for (const run of runs) {
		const from = Math.max(start, at);
		const to = Math.min(end, at + run.text.length);
		if (from < to) cut.push({
			text: run.text.slice(from - at, to - at),
			kind: run.kind
		});
		at += run.text.length;
	}
	return cut;
}
const coverOf = (places, start, end) => places.find((place) => !place.whole && place.start <= start && place.end >= end);
const covers = (places, start, end) => coverOf(places, start, end) !== void 0;
function markLine(line, sets, shown, seen) {
	const whole = sets.map((places) => places.some((place) => place.whole));
	const parts = sets.map((places, i) => whole[i] ? [] : places);
	const length = line.runs.reduce((sum, run) => sum + run.text.length, 0);
	const cuts = [.../* @__PURE__ */ new Set([
		0,
		length,
		...parts.flat().flatMap((p) => p.whole ? [] : [p.start, p.end])
	])].sort((a, b) => a - b);
	const pieces = [];
	for (let i = 0; i < cuts.length - 1; i++) {
		const [start, end] = [cuts[i], cuts[i + 1]];
		const ever = parts.some((places) => covers(places, start, end));
		pieces.push({
			start,
			end,
			ever,
			on: ever && covers(parts[shown], start, end)
		});
	}
	const isOn = (i) => pieces[i]?.on === true;
	const firstOf = (index) => {
		if (index === null || seen.has(index)) return false;
		seen.add(index);
		return true;
	};
	const bandIndex = sets[shown].find((place) => place.whole)?.mark ?? null;
	const bandFirst = firstOf(bandIndex);
	return {
		band: whole.some(Boolean) ? whole[shown] : null,
		bandIndex,
		bandFirst,
		pieces: pieces.map((piece, i) => {
			const runs = runsBetween(line.runs, piece.start, piece.end);
			if (!piece.ever) return {
				runs,
				mark: null
			};
			const [start, end] = [piece.on && isOn(i - 1), piece.on && isOn(i + 1)];
			const join = start && end ? "both" : start ? "start" : end ? "end" : null;
			const index = piece.on ? coverOf(parts[shown], piece.start, piece.end)?.mark ?? null : null;
			return {
				runs,
				mark: {
					on: piece.on,
					join,
					index,
					first: firstOf(index)
				}
			};
		}),
		end: line.end
	};
}
function focusLines(lines, texts, sets, shown, strict = isDevMode()) {
	const placed = sets.map((marks) => placesIn(marks, texts, strict));
	const seen = /* @__PURE__ */ new Set();
	return {
		lines: lines.map((line, i) => markLine(line, placed.map((places) => places.filter((place) => place.line === i)), shown, seen)),
		marked: placed[shown].length > 0
	};
}
var NeatCodeNote = class NeatCodeNote {
	neatCodeNote = input(...ngDevMode ? [void 0, { debugName: "neatCodeNote" }] : /* istanbul ignore next */ []);
	neatCodeNoteSide = input("top", ...ngDevMode ? [{ debugName: "neatCodeNoteSide" }] : /* istanbul ignore next */ []);
	template = inject(TemplateRef);
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCodeNote,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NeatCodeNote,
		isStandalone: true,
		selector: "ng-template[neatCodeNote]",
		inputs: {
			neatCodeNote: {
				classPropertyName: "neatCodeNote",
				publicName: "neatCodeNote",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			neatCodeNoteSide: {
				classPropertyName: "neatCodeNoteSide",
				publicName: "neatCodeNoteSide",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCodeNote,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[neatCodeNote]" }]
	}],
	propDecorators: {
		neatCodeNote: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "neatCodeNote",
				required: false
			}]
		}],
		neatCodeNoteSide: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "neatCodeNoteSide",
				required: false
			}]
		}]
	}
});
function scrollToShow(box, target, smooth) {
	const view = box.getBoundingClientRect();
	const top = view.top + box.clientTop;
	const left = view.left + box.clientLeft;
	const shown = target.getBoundingClientRect();
	const outOfView = (start, end, from, size) => start < from || end > from + size;
	let dy = 0;
	let dx = 0;
	if (outOfView(shown.top, shown.bottom, top, box.clientHeight)) dy = shown.top - top - shown.height;
	if (outOfView(shown.left, shown.right, left, box.clientWidth)) dx = shown.left - left - parseFloat(getComputedStyle(box).paddingInlineStart || "0");
	if (!dy && !dx) return;
	box.scrollTo({
		top: box.scrollTop + dy,
		left: box.scrollLeft + dx,
		behavior: smooth ? "smooth" : "instant"
	});
}
const NOTE_CLOSE_DELAY = 150;
const sameElements = (a, b) => a !== null && a.length === b.length && a.every((element, i) => element === b[i]);
var NeatCodeBlock = class NeatCodeBlock {
	code = input.required(...ngDevMode ? [{ debugName: "code" }] : /* istanbul ignore next */ []);
	copy = input(...ngDevMode ? [void 0, { debugName: "copy" }] : /* istanbul ignore next */ []);
	overflow = input("wrap", ...ngDevMode ? [{ debugName: "overflow" }] : /* istanbul ignore next */ []);
	language = input(null, ...ngDevMode ? [{ debugName: "language" }] : /* istanbul ignore next */ []);
	lineNumbers = input(false, ...ngDevMode ? [{ debugName: "lineNumbers" }] : /* istanbul ignore next */ []);
	marks = input([], ...ngDevMode ? [{ debugName: "marks" }] : /* istanbul ignore next */ []);
	dim = input(true, {
		...ngDevMode ? { debugName: "dim" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	steps = input([], ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	step = model(0, ...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	stepControls = input(false, {
		...ngDevMode ? { debugName: "stepControls" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	note = contentChild(NeatCodeNote, ...ngDevMode ? [{ debugName: "note" }] : /* istanbul ignore next */ []);
	languages = inject(NEAT_CODE_LANGUAGES);
	box = viewChild.required("box", ...ngDevMode ? [{ debugName: "box" }] : /* istanbul ignore next */ []);
	bubble = viewChild(NeatBubble, ...ngDevMode ? [{ debugName: "bubble" }] : /* istanbul ignore next */ []);
	document = inject(DOCUMENT);
	highlighter = resource({
		...ngDevMode ? { debugName: "highlighter" } : /* istanbul ignore next */ {},
		params: () => this.language() ?? void 0,
		loader: ({ params: language }) => highlighterFor(language, this.languages)
	});
	plain = computed(() => plainLines(this.code()), ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	texts = computed(() => this.plain().map((line) => line.runs.map((run) => run.text).join("")), ...ngDevMode ? [{ debugName: "texts" }] : /* istanbul ignore next */ []);
	lines = computed(() => {
		const highlighter = this.highlighter.hasValue() ? this.highlighter.value() : void 0;
		return highlighter ? highlighter.lines(this.code()) : this.plain();
	}, ...ngDevMode ? [{ debugName: "lines" }] : /* istanbul ignore next */ []);
	stepCount = computed(() => this.steps().length, ...ngDevMode ? [{ debugName: "stepCount" }] : /* istanbul ignore next */ []);
	shownStep = computed(() => Math.max(0, Math.min(this.step(), this.stepCount() - 1)), ...ngDevMode ? [{ debugName: "shownStep" }] : /* istanbul ignore next */ []);
	focus = computed(() => {
		const steps = this.steps();
		return steps.length ? focusLines(this.lines(), this.texts(), steps.map((step) => step.marks), this.shownStep()) : focusLines(this.lines(), this.texts(), [this.marks()], 0);
	}, ...ngDevMode ? [{ debugName: "focus" }] : /* istanbul ignore next */ []);
	dimmed = computed(() => this.dim() && this.focus().marked, ...ngDevMode ? [{ debugName: "dimmed" }] : /* istanbul ignore next */ []);
	digits = computed(() => String(this.lines().length).length, ...ngDevMode ? [{ debugName: "digits" }] : /* istanbul ignore next */ []);
	hoverNotes = computed(() => this.note() !== void 0 && !this.stepCount() && this.focus().marked, ...ngDevMode ? [{ debugName: "hoverNotes" }] : /* istanbul ignore next */ []);
	openMark = signal(null, ...ngDevMode ? [{ debugName: "openMark" }] : /* istanbul ignore next */ []);
	dismissed = null;
	pointerOnMark = false;
	pointerOnBubble = false;
	closeTimer;
	noteContext = computed(() => {
		if (!this.note()) return null;
		if (this.stepCount()) {
			const index = this.shownStep();
			return {
				$implicit: this.steps()[index],
				index
			};
		}
		const index = this.openMark();
		const mark = index === null ? void 0 : this.marks()[index];
		return this.hoverNotes() && index !== null && mark ? {
			$implicit: mark,
			index
		} : null;
	}, ...ngDevMode ? [{ debugName: "noteContext" }] : /* istanbul ignore next */ []);
	noteAnchor = signal(null, ...ngDevMode ? [{ debugName: "noteAnchor" }] : /* istanbul ignore next */ []);
	announcement = computed(() => {
		const count = this.stepCount();
		if (!count) return "";
		const label = this.steps()[this.shownStep()].label;
		return `Step ${this.shownStep() + 1} of ${count}${label ? `: ${label}` : ""}`;
	}, ...ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []);
	constructor() {
		afterRenderEffect(() => {
			this.focus();
			const box = this.box().nativeElement;
			const first = box.querySelector(".line[data-marked], mark[data-on]:not([data-line])");
			if (first) scrollToShow(box, first, !ɵreducedMotion());
		});
		afterRenderEffect(() => {
			const context = this.noteContext();
			this.focus();
			if (!context) return;
			const box = this.box().nativeElement;
			const elements = this.stepCount() ? [...box.querySelectorAll(".line[data-marked], mark[data-on]:not([data-line])")] : [...box.querySelectorAll(`[data-mark="${context.index}"]`)].map((element) => element.hasAttribute("data-line") ? element.closest(".line") ?? element : element);
			const anchor = elements.length ? elements : [box];
			if (!sameElements(this.noteAnchor(), anchor)) this.noteAnchor.set(anchor);
		});
		effect((onCleanup) => {
			if (this.openMark() === null) return;
			const press = (event) => {
				const target = event.target;
				const bubble = this.bubbleElement();
				if (this.markOf(target) === null && !bubble?.contains(target)) this.closeNote();
			};
			const key = (event) => {
				if (event.key !== "Escape") return;
				this.dismissed = this.openMark();
				this.closeNote();
			};
			this.document.addEventListener("pointerdown", press, true);
			this.document.addEventListener("keydown", key);
			onCleanup(() => {
				this.document.removeEventListener("pointerdown", press, true);
				this.document.removeEventListener("keydown", key);
			});
		});
	}
	describedBy(index) {
		return index !== null && this.hoverNotes() && this.openMark() === index ? this.bubble()?.id ?? null : null;
	}
	markOf(node) {
		if (!(node instanceof Element) || !this.box().nativeElement.contains(node)) return null;
		const mark = node.closest("[data-mark]");
		return mark ? Number(mark.getAttribute("data-mark")) : null;
	}
	bubbleElement() {
		const id = this.bubble()?.id;
		return id ? this.document.getElementById(id) : null;
	}
	pointerOver(event) {
		if (!this.hoverNotes() || event.pointerType !== "mouse" && event.pointerType !== "pen") return;
		const mark = this.markOf(event.target);
		if (mark !== this.dismissed) this.dismissed = null;
		this.pointerOnMark = mark !== null;
		if (mark === null) this.closeSoon();
		else if (mark !== this.dismissed) this.openNote(mark);
	}
	pointerLeave(event) {
		if (event.pointerType !== "mouse" && event.pointerType !== "pen") return;
		this.pointerOnMark = false;
		this.dismissed = null;
		this.closeSoon();
	}
	focusIn(event) {
		const mark = this.markOf(event.target);
		if (mark !== null && this.hoverNotes()) {
			this.dismissed = null;
			this.openNote(mark);
		}
	}
	focusOut(event) {
		if (this.markOf(event.relatedTarget) === null) this.closeSoon();
	}
	tap(event) {
		const mark = this.markOf(event.target);
		if (mark !== null && this.hoverNotes()) {
			this.dismissed = null;
			this.openNote(mark);
		}
	}
	bubbleHover(over) {
		this.pointerOnBubble = over;
		if (over) clearTimeout(this.closeTimer);
		else this.closeSoon();
	}
	openNote(mark) {
		clearTimeout(this.closeTimer);
		this.openMark.set(mark);
	}
	closeSoon() {
		clearTimeout(this.closeTimer);
		if (this.openMark() === null) return;
		this.closeTimer = setTimeout(() => {
			const focused = this.markOf(this.document.activeElement);
			if (!(this.pointerOnMark || this.pointerOnBubble || focused !== null && focused === this.openMark())) this.closeNote();
		}, NOTE_CLOSE_DELAY);
	}
	closeNote() {
		clearTimeout(this.closeTimer);
		this.pointerOnBubble = false;
		this.openMark.set(null);
	}
	move(by) {
		const next = this.shownStep() + by;
		if (next < 0 || next >= this.stepCount()) return false;
		this.step.set(next);
		return true;
	}
	onKeydown(event) {
		if (!this.stepCount() || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
		if (this.box().nativeElement.contains(event.target)) return;
		const by = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
		if (by && this.move(by)) event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NeatCodeBlock,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NeatCodeBlock,
		isStandalone: true,
		selector: "neat-code-block",
		inputs: {
			code: {
				classPropertyName: "code",
				publicName: "code",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			copy: {
				classPropertyName: "copy",
				publicName: "copy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overflow: {
				classPropertyName: "overflow",
				publicName: "overflow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			language: {
				classPropertyName: "language",
				publicName: "language",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lineNumbers: {
				classPropertyName: "lineNumbers",
				publicName: "lineNumbers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marks: {
				classPropertyName: "marks",
				publicName: "marks",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dim: {
				classPropertyName: "dim",
				publicName: "dim",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			steps: {
				classPropertyName: "steps",
				publicName: "steps",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepControls: {
				classPropertyName: "stepControls",
				publicName: "stepControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { step: "stepChange" },
		host: {
			listeners: {
				"keydown": "onKeydown($event)",
				"pointerover": "pointerOver($event)",
				"pointerleave": "pointerLeave($event)",
				"focusin": "focusIn($event)",
				"focusout": "focusOut($event)",
				"click": "tap($event)"
			},
			properties: {
				"attr.tabindex": "stepCount() ? 0 : null",
				"attr.role": "stepCount() ? \"group\" : null",
				"attr.aria-label": "stepCount() ? \"Code in steps\" : null"
			}
		},
		queries: [{
			propertyName: "note",
			first: true,
			predicate: NeatCodeNote,
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "box",
			first: true,
			predicate: ["box"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "bubble",
			first: true,
			predicate: NeatBubble,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <pre
      #box
      [attr.data-overflow]="overflow()"
      [attr.data-line-numbers]="lineNumbers() || null"
      [attr.data-dim]="dimmed() || null"
      [style.--line-number-digits]="digits()"
    ><code><ng-content>@for (line of focus().lines; track $index) {<span class="line" [attr.data-marked]="line.band || null">@if (line.band !== null) {<mark data-line [attr.data-on]="line.band || null" [attr.role]="line.band ? null : 'none'" [attr.data-mark]="hoverNotes() ? line.bandIndex : null" [attr.tabindex]="hoverNotes() && line.bandFirst ? 0 : null" [attr.aria-describedby]="describedBy(line.bandIndex)"><ng-container *ngTemplateOutlet="pieces; context: { $implicit: line.pieces }" /></mark>} @else {<ng-container *ngTemplateOutlet="pieces; context: { $implicit: line.pieces }" />}{{ line.end }}</span>}</ng-content></code></pre>
    <ng-content select="[neatCodeNote]" />
    @if (note(); as note) {
      <neat-bubble
        [anchor]="noteContext() ? noteAnchor() : null"
        [side]="note.neatCodeNoteSide()"
        (hover)="bubbleHover($event)"
      >
        @if (noteContext(); as context) {
          <ng-container *ngTemplateOutlet="note.template; context: context" />
        }
      </neat-bubble>
    }
    @if (copy(); as what) {
      <neat-copy-button [text]="code()" [what]="what" />
    }
    @if (stepCount(); as count) {
      @if (stepControls()) {
        <div class="steps">
          <button
            neatButton
            type="button"
            variant="text"
            size="small"
            [attr.aria-disabled]="shownStep() === 0 || null"
            (click)="move(-1)"
          >
            <neat-icon name="previous" [size]="16" />
            Previous
          </button>
          <span class="position">{{ shownStep() + 1 }} of {{ count }}</span>
          <button
            neatButton
            type="button"
            variant="text"
            size="small"
            [attr.aria-disabled]="shownStep() === count - 1 || null"
            (click)="move(1)"
          >
            Next
            <neat-icon name="next" [size]="16" />
          </button>
        </div>
      }
      <span class="sr-only" aria-live="polite">{{ announcement() }}</span>
    }

    <!-- A mark that no step has shown at the moment is no mark to a screen reader (role none). -->
    <ng-template #pieces let-pieces>
      @for (piece of pieces; track $index) {
        @if (piece.mark; as mark) {
          <mark
            [attr.data-on]="mark.on || null"
            [attr.data-join]="mark.join"
            [attr.role]="mark.on ? null : 'none'"
            [attr.data-mark]="hoverNotes() ? mark.index : null"
            [attr.tabindex]="hoverNotes() && mark.first ? 0 : null"
            [attr.aria-describedby]="describedBy(mark.index)"
            ><ng-container *ngTemplateOutlet="runs; context: { $implicit: piece.runs }"
          /></mark>
        } @else {
          <ng-container *ngTemplateOutlet="runs; context: { $implicit: piece.runs }" />
        }
      }
    </ng-template>
    <ng-template #runs let-runs>
      @for (run of runs; track $index) {
        <span [attr.data-kind]="run.kind">{{ run.text }}</span>
      }
    </ng-template>
  `,
		isInline: true,
		styles: [":host{--mark-inset: var(--neat-space-2);position:relative;display:grid;grid-template-columns:minmax(0,1fr) auto;grid-template-rows:minmax(0,1fr);align-items:center;min-width:0;padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--muted);font-size:var(--neat-text-xs);line-height:1.6}:host(:focus-visible){outline:2px solid var(--ring);outline-offset:2px}pre{max-height:100%;min-width:0;margin:0 calc(-1 * var(--mark-inset));padding:0 var(--mark-inset);overflow:auto}code{display:block}neat-copy-button{align-self:start;margin-inline-start:var(--neat-space-2)}pre[data-overflow=wrap]{white-space:pre-wrap;overflow-wrap:anywhere}pre[data-overflow=scroll] code{min-inline-size:max-content}.line{display:block;margin-inline:calc(-1 * var(--mark-inset));padding-inline:var(--mark-inset)}pre[data-line-numbers]{--line-number-gutter: calc(var(--line-number-digits) * 1ch + var(--neat-space-3));counter-reset:line}pre[data-line-numbers] .line{padding-inline-start:calc(var(--mark-inset) + var(--line-number-gutter));text-indent:calc(-1 * var(--line-number-gutter))}pre[data-line-numbers] .line:before{content:counter(line) / \"\";counter-increment:line;display:inline-block;inline-size:calc(var(--line-number-digits) * 1ch);margin-inline-end:var(--neat-space-3);text-indent:0;text-align:end;color:var(--muted-foreground);-webkit-user-select:none;user-select:none}[data-kind]{color:var(--code-kind)}[data-kind=keyword]{--code-kind: var(--neat-code-keyword)}[data-kind=string]{--code-kind: var(--neat-code-string)}[data-kind=comment]{--code-kind: var(--neat-code-comment)}[data-kind=constant]{--code-kind: var(--neat-code-constant)}[data-kind=type]{--code-kind: var(--neat-code-type)}[data-kind=function]{--code-kind: var(--neat-code-function)}[data-kind=property]{--code-kind: var(--neat-code-property)}[data-kind=tag]{--code-kind: var(--neat-code-tag)}mark{background:none;color:inherit}.line[data-marked]{background:var(--neat-code-mark)}mark:not([data-line]){margin-inline:-.2em;padding:.1em .2em;border-radius:calc(var(--radius) / 2);-webkit-box-decoration-break:clone;box-decoration-break:clone}mark:not([data-line])[data-on]{background:var(--neat-code-mark)}mark[data-join=start],mark[data-join=both]{border-start-start-radius:0;border-end-start-radius:0}mark[data-join=end],mark[data-join=both]{border-start-end-radius:0;border-end-end-radius:0}pre[data-dim] .line{color:var(--muted-foreground)}pre[data-dim] .line [data-kind]{color:inherit}pre[data-dim] mark[data-on]{color:var(--foreground)}pre[data-dim] mark[data-on] [data-kind]{color:var(--code-kind)}@media(prefers-reduced-motion:no-preference){.line,mark,[data-kind]{transition:color var(--neat-transition-duration),background-color var(--neat-transition-duration)}}.steps{grid-column:1 / -1;display:flex;align-items:center;gap:var(--neat-space-2);margin-block-start:var(--neat-space-2)}.position{color:var(--muted-foreground);font-variant-numeric:tabular-nums}\n"],
		dependencies: [
			{
				kind: "component",
				type: NeatBubble,
				selector: "neat-bubble",
				inputs: ["anchor", "side"],
				outputs: ["hover"]
			},
			{
				kind: "directive",
				type: NeatButton,
				selector: "button[neatButton], a[neatButton]",
				inputs: [
					"variant",
					"size",
					"iconOnly",
					"rounded",
					"pressed"
				]
			},
			{
				kind: "component",
				type: NeatCopyButton,
				selector: "neat-copy-button",
				inputs: [
					"text",
					"what",
					"inline"
				]
			},
			{
				kind: "component",
				type: NeatIcon,
				selector: "neat-icon",
				inputs: [
					"name",
					"size",
					"label"
				]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NeatCodeBlock,
	decorators: [{
		type: Component,
		args: [{
			selector: "neat-code-block",
			imports: [
				NeatBubble,
				NeatButton,
				NeatCopyButton,
				NeatIcon,
				NgTemplateOutlet
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[attr.tabindex]": "stepCount() ? 0 : null",
				"[attr.role]": "stepCount() ? \"group\" : null",
				"[attr.aria-label]": "stepCount() ? \"Code in steps\" : null",
				"(keydown)": "onKeydown($event)",
				"(pointerover)": "pointerOver($event)",
				"(pointerleave)": "pointerLeave($event)",
				"(focusin)": "focusIn($event)",
				"(focusout)": "focusOut($event)",
				"(click)": "tap($event)"
			},
			template: `
    <pre
      #box
      [attr.data-overflow]="overflow()"
      [attr.data-line-numbers]="lineNumbers() || null"
      [attr.data-dim]="dimmed() || null"
      [style.--line-number-digits]="digits()"
    ><code><ng-content>@for (line of focus().lines; track $index) {<span class="line" [attr.data-marked]="line.band || null">@if (line.band !== null) {<mark data-line [attr.data-on]="line.band || null" [attr.role]="line.band ? null : 'none'" [attr.data-mark]="hoverNotes() ? line.bandIndex : null" [attr.tabindex]="hoverNotes() && line.bandFirst ? 0 : null" [attr.aria-describedby]="describedBy(line.bandIndex)"><ng-container *ngTemplateOutlet="pieces; context: { $implicit: line.pieces }" /></mark>} @else {<ng-container *ngTemplateOutlet="pieces; context: { $implicit: line.pieces }" />}{{ line.end }}</span>}</ng-content></code></pre>
    <ng-content select="[neatCodeNote]" />
    @if (note(); as note) {
      <neat-bubble
        [anchor]="noteContext() ? noteAnchor() : null"
        [side]="note.neatCodeNoteSide()"
        (hover)="bubbleHover($event)"
      >
        @if (noteContext(); as context) {
          <ng-container *ngTemplateOutlet="note.template; context: context" />
        }
      </neat-bubble>
    }
    @if (copy(); as what) {
      <neat-copy-button [text]="code()" [what]="what" />
    }
    @if (stepCount(); as count) {
      @if (stepControls()) {
        <div class="steps">
          <button
            neatButton
            type="button"
            variant="text"
            size="small"
            [attr.aria-disabled]="shownStep() === 0 || null"
            (click)="move(-1)"
          >
            <neat-icon name="previous" [size]="16" />
            Previous
          </button>
          <span class="position">{{ shownStep() + 1 }} of {{ count }}</span>
          <button
            neatButton
            type="button"
            variant="text"
            size="small"
            [attr.aria-disabled]="shownStep() === count - 1 || null"
            (click)="move(1)"
          >
            Next
            <neat-icon name="next" [size]="16" />
          </button>
        </div>
      }
      <span class="sr-only" aria-live="polite">{{ announcement() }}</span>
    }

    <!-- A mark that no step has shown at the moment is no mark to a screen reader (role none). -->
    <ng-template #pieces let-pieces>
      @for (piece of pieces; track $index) {
        @if (piece.mark; as mark) {
          <mark
            [attr.data-on]="mark.on || null"
            [attr.data-join]="mark.join"
            [attr.role]="mark.on ? null : 'none'"
            [attr.data-mark]="hoverNotes() ? mark.index : null"
            [attr.tabindex]="hoverNotes() && mark.first ? 0 : null"
            [attr.aria-describedby]="describedBy(mark.index)"
            ><ng-container *ngTemplateOutlet="runs; context: { $implicit: piece.runs }"
          /></mark>
        } @else {
          <ng-container *ngTemplateOutlet="runs; context: { $implicit: piece.runs }" />
        }
      }
    </ng-template>
    <ng-template #runs let-runs>
      @for (run of runs; track $index) {
        <span [attr.data-kind]="run.kind">{{ run.text }}</span>
      }
    </ng-template>
  `,
			styles: [":host{--mark-inset: var(--neat-space-2);position:relative;display:grid;grid-template-columns:minmax(0,1fr) auto;grid-template-rows:minmax(0,1fr);align-items:center;min-width:0;padding:var(--neat-space-2) var(--neat-space-3);border-radius:var(--radius);background:var(--muted);font-size:var(--neat-text-xs);line-height:1.6}:host(:focus-visible){outline:2px solid var(--ring);outline-offset:2px}pre{max-height:100%;min-width:0;margin:0 calc(-1 * var(--mark-inset));padding:0 var(--mark-inset);overflow:auto}code{display:block}neat-copy-button{align-self:start;margin-inline-start:var(--neat-space-2)}pre[data-overflow=wrap]{white-space:pre-wrap;overflow-wrap:anywhere}pre[data-overflow=scroll] code{min-inline-size:max-content}.line{display:block;margin-inline:calc(-1 * var(--mark-inset));padding-inline:var(--mark-inset)}pre[data-line-numbers]{--line-number-gutter: calc(var(--line-number-digits) * 1ch + var(--neat-space-3));counter-reset:line}pre[data-line-numbers] .line{padding-inline-start:calc(var(--mark-inset) + var(--line-number-gutter));text-indent:calc(-1 * var(--line-number-gutter))}pre[data-line-numbers] .line:before{content:counter(line) / \"\";counter-increment:line;display:inline-block;inline-size:calc(var(--line-number-digits) * 1ch);margin-inline-end:var(--neat-space-3);text-indent:0;text-align:end;color:var(--muted-foreground);-webkit-user-select:none;user-select:none}[data-kind]{color:var(--code-kind)}[data-kind=keyword]{--code-kind: var(--neat-code-keyword)}[data-kind=string]{--code-kind: var(--neat-code-string)}[data-kind=comment]{--code-kind: var(--neat-code-comment)}[data-kind=constant]{--code-kind: var(--neat-code-constant)}[data-kind=type]{--code-kind: var(--neat-code-type)}[data-kind=function]{--code-kind: var(--neat-code-function)}[data-kind=property]{--code-kind: var(--neat-code-property)}[data-kind=tag]{--code-kind: var(--neat-code-tag)}mark{background:none;color:inherit}.line[data-marked]{background:var(--neat-code-mark)}mark:not([data-line]){margin-inline:-.2em;padding:.1em .2em;border-radius:calc(var(--radius) / 2);-webkit-box-decoration-break:clone;box-decoration-break:clone}mark:not([data-line])[data-on]{background:var(--neat-code-mark)}mark[data-join=start],mark[data-join=both]{border-start-start-radius:0;border-end-start-radius:0}mark[data-join=end],mark[data-join=both]{border-start-end-radius:0;border-end-end-radius:0}pre[data-dim] .line{color:var(--muted-foreground)}pre[data-dim] .line [data-kind]{color:inherit}pre[data-dim] mark[data-on]{color:var(--foreground)}pre[data-dim] mark[data-on] [data-kind]{color:var(--code-kind)}@media(prefers-reduced-motion:no-preference){.line,mark,[data-kind]{transition:color var(--neat-transition-duration),background-color var(--neat-transition-duration)}}.steps{grid-column:1 / -1;display:flex;align-items:center;gap:var(--neat-space-2);margin-block-start:var(--neat-space-2)}.position{color:var(--muted-foreground);font-variant-numeric:tabular-nums}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		code: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "code",
				required: true
			}]
		}],
		copy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "copy",
				required: false
			}]
		}],
		overflow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overflow",
				required: false
			}]
		}],
		language: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "language",
				required: false
			}]
		}],
		lineNumbers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lineNumbers",
				required: false
			}]
		}],
		marks: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marks",
				required: false
			}]
		}],
		dim: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dim",
				required: false
			}]
		}],
		steps: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steps",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["stepChange"]
		}],
		stepControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepControls",
				required: false
			}]
		}],
		note: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => NeatCodeNote), { isSignal: true }]
		}],
		box: [{
			type: i0.ViewChild,
			args: ["box", { isSignal: true }]
		}],
		bubble: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NeatBubble), { isSignal: true }]
		}]
	}
});
export { NeatCodeBlock, NeatCodeNote, NeatCopyButton, provideNeatCodeLanguages };

//# sourceMappingURL=sima-neat-ui-code-block.mjs.map