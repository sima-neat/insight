import { DestroyRef, NgZone, computed, effect, inject, isSignal, signal, untracked } from "@angular/core";
const BACKOFF_MS = [
	1e3,
	2e3,
	5e3,
	1e4
];
const STALL_MS = 5e3;
const HEALTH_INTERVAL_MS = 1e3;
const UNREACHABLE_TEXT = "Insight not reachable";
const WAITING_TEXT = {
	no_video: "Waiting for video",
	codec_changed: "Video format changed",
	insight_unreachable: UNREACHABLE_TEXT,
	negotiation_failed: "Could not connect"
};
const GATEWAY_STATUSES = /* @__PURE__ */ new Set([
	502,
	503,
	504
]);
function openInsightConnection(options, events) {
	const log = options.log ?? (() => void 0);
	let videoBufferMs = options.videoBufferMs;
	let closed = false;
	let peer = null;
	let receiver = null;
	let health = null;
	let failures = 0;
	let checking = false;
	let retryTimer = null;
	let healthTimer = null;
	const clearRetry = () => {
		if (retryTimer !== null) clearTimeout(retryTimer);
		retryTimer = null;
	};
	const dropPeer = () => {
		const pc = peer;
		peer = null;
		receiver = null;
		health = null;
		events.videoDelayMs(null);
		events.stats(null);
		pc?.close();
	};
	const close = () => {
		if (closed) return;
		closed = true;
		clearRetry();
		if (healthTimer !== null) clearInterval(healthTimer);
		healthTimer = null;
		dropPeer();
		events.stream(null);
		events.waiting(null);
		log("closed");
	};
	const fail = (text) => {
		close();
		log("failed", text);
		events.failure(text);
	};
	const retry = (reason) => {
		if (closed) return;
		dropPeer();
		events.stream(null);
		const delay = BACKOFF_MS[Math.min(failures, BACKOFF_MS.length - 1)];
		failures += 1;
		clearRetry();
		log("retrying", {
			reason,
			inMs: delay
		});
		retryTimer = setTimeout(() => void attempt(), delay);
	};
	const attempt = async () => {
		if (closed) return;
		clearRetry();
		dropPeer();
		const pc = new RTCPeerConnection();
		peer = pc;
		receiver = pc.addTransceiver("video", { direction: "recvonly" }).receiver;
		if (videoBufferMs !== void 0) applyJitterBufferTarget(receiver, videoBufferMs);
		log("connecting", {
			offerUrl: options.offerUrl,
			videoBufferMs
		});
		const metadata = pc.createDataChannel("metadata", {
			ordered: true,
			maxRetransmits: 0
		});
		metadata.onmessage = (event) => {
			if (pc !== peer || typeof event.data !== "string") return;
			events.metadata(event.data, performance.now());
		};
		pc.ontrack = (event) => {
			if (pc !== peer || event.track.kind !== "video") return;
			log("track");
			events.waiting(null);
			events.stream(event.streams[0] ?? new MediaStream([event.track]));
		};
		pc.onconnectionstatechange = () => {
			if (pc !== peer) return;
			log("connection state", pc.connectionState);
			if (pc.connectionState === "connected") failures = 0;
			else if (pc.connectionState === "failed" || pc.connectionState === "closed") retry(`connection ${pc.connectionState}`);
		};
		try {
			const offer = await pc.createOffer();
			await pc.setLocalDescription(offer);
			const response = await fetch(options.offerUrl, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					type: offer.type,
					sdp: offer.sdp
				})
			}).catch(() => {
				throw new OfferError(null, {
					code: null,
					message: null
				});
			});
			if (!response.ok) throw new OfferError(response.status, await errorOf(response));
			const answer = await response.json();
			if (closed || pc !== peer) return;
			await pc.setRemoteDescription(answer);
			log("answered");
			health = {
				framesDecoded: -1,
				progressAt: Date.now(),
				disconnectedSince: null,
				delaySeconds: null,
				emittedCount: 0,
				bytesReceived: null,
				sampledAt: null
			};
		} catch (error) {
			if (pc !== peer) return;
			if (error instanceof OfferError && error.final) fail(error.failureText());
			else {
				events.waiting(error instanceof OfferError ? error.waitingText() : null);
				retry(error instanceof Error ? `offer: ${error.message}` : "offer failed");
			}
		}
	};
	const checkHealth = async () => {
		const pc = peer;
		if (closed || checking || !pc || !health) return;
		checking = true;
		try {
			const reports = await pc.getStats();
			const inbound = inboundVideo(reports);
			const current = health;
			if (pc !== peer || !current) return;
			const now = Date.now();
			const framesDecoded = inbound?.framesDecoded ?? 0;
			if (framesDecoded > current.framesDecoded) {
				current.framesDecoded = framesDecoded;
				current.progressAt = now;
			}
			const connected = pc.connectionState === "connected";
			events.videoDelayMs(sampleDelay(current, connected, inbound));
			events.stats(connected && inbound ? sampleStats(current, inbound, reports) : null);
			if (pc.connectionState === "disconnected") current.disconnectedSince ??= now;
			else current.disconnectedSince = null;
			const disconnected = current.disconnectedSince !== null && now - current.disconnectedSince >= STALL_MS;
			if (now - current.progressAt >= STALL_MS) retry("no new frame decoded");
			else if (disconnected) retry("disconnected");
		} catch {} finally {
			checking = false;
		}
	};
	if (typeof RTCPeerConnection !== "function") {
		closed = true;
		events.failure("This browser has no WebRTC");
		return {
			close: () => void 0,
			setVideoBufferMs: () => void 0
		};
	}
	healthTimer = setInterval(() => void checkHealth(), HEALTH_INTERVAL_MS);
	attempt();
	return {
		close,
		setVideoBufferMs(ms) {
			videoBufferMs = ms;
			if (receiver !== null && ms !== void 0) applyJitterBufferTarget(receiver, ms);
		}
	};
}
function inboundVideo(reports) {
	for (const report of reports.values()) if (report.type === "inbound-rtp" && report.kind === "video") return report;
	return null;
}
function sampleDelay(current, connected, video) {
	const delaySeconds = video?.jitterBufferDelay ?? 0;
	const emittedCount = video?.jitterBufferEmittedCount ?? 0;
	const frames = emittedCount - current.emittedCount;
	const seconds = delaySeconds - (current.delaySeconds ?? 0);
	const hadBaseline = current.delaySeconds !== null;
	current.delaySeconds = delaySeconds;
	current.emittedCount = emittedCount;
	return connected && hadBaseline && frames > 0 ? seconds / frames * 1e3 : null;
}
function sampleStats(current, video, reports) {
	const bytes = video.bytesReceived ?? null;
	const seconds = current.sampledAt === null ? 0 : (video.timestamp - current.sampledAt) / 1e3;
	const bitsPerSecond = seconds > 0 && bytes !== null && current.bytesReceived !== null ? (bytes - current.bytesReceived) * 8 / seconds : 0;
	current.bytesReceived = bytes;
	current.sampledAt = video.timestamp;
	return {
		codec: codecOf(reports, video.codecId),
		width: video.frameWidth ?? null,
		height: video.frameHeight ?? null,
		framesPerSecond: video.framesPerSecond ?? null,
		bitsPerSecond
	};
}
function codecOf(reports, codecId) {
	const mimeType = codecId === void 0 ? void 0 : reports.get(codecId)?.mimeType;
	if (typeof mimeType !== "string") return null;
	return mimeType.split("/")[1] || null;
}
function applyJitterBufferTarget(receiver, ms) {
	if (!("jitterBufferTarget" in receiver)) return;
	try {
		receiver.jitterBufferTarget = ms;
	} catch {}
}
async function errorOf(response) {
	try {
		const { error } = await response.json();
		return {
			code: typeof error?.code === "string" ? error.code : null,
			message: typeof error?.message === "string" ? error.message : null
		};
	} catch {
		return {
			code: null,
			message: null
		};
	}
}
var OfferError = class extends Error {
	status;
	code;
	detail;
	constructor(status, body) {
		super(status === null ? "no answer" : `HTTP ${status}`);
		this.status = status;
		this.code = body.code;
		this.detail = body.message;
	}
	get final() {
		return this.status !== null && this.status >= 400 && this.status < 500;
	}
	failureText() {
		if (this.status === 415) return "Codec not supported by this browser";
		return this.detail ?? `Connection failed: HTTP ${this.status}`;
	}
	waitingText() {
		if (this.code !== null) return Object.hasOwn(WAITING_TEXT, this.code) ? WAITING_TEXT[this.code] : null;
		return this.status === null || GATEWAY_STATUSES.has(this.status) ? UNREACHABLE_TEXT : null;
	}
};
function neatInsightChannel(channel, options = {}) {
	const destroyRef = inject(DestroyRef);
	const zone = inject(NgZone);
	const { offer, videoBufferMs, log } = options;
	const offerUrl = typeof offer === "function" ? offer(channel) : offer ?? `/api/channels/${channel}/offer`;
	const bufferMs = isSignal(videoBufferMs) ? videoBufferMs : () => videoBufferMs;
	const stream = signal(null, ...ngDevMode ? [{ debugName: "stream" }] : /* istanbul ignore next */ []);
	const waiting = signal(null, ...ngDevMode ? [{ debugName: "waiting" }] : /* istanbul ignore next */ []);
	const failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	const videoDelayMs = signal(null, ...ngDevMode ? [{ debugName: "videoDelayMs" }] : /* istanbul ignore next */ []);
	const stats = signal(null, ...ngDevMode ? [{ debugName: "stats" }] : /* istanbul ignore next */ []);
	const listeners = /* @__PURE__ */ new Set();
	const connection = zone.runOutsideAngular(() => openInsightConnection({
		offerUrl,
		videoBufferMs: untracked(bufferMs),
		log
	}, {
		stream: (value) => stream.set(value),
		waiting: (text) => waiting.set(text),
		failure: (text) => failure.set(text),
		videoDelayMs: (ms) => videoDelayMs.set(ms),
		stats: (value) => stats.set(value),
		metadata: (text, receivedAt) => {
			for (const listener of listeners) listener(text, receivedAt);
		}
	}));
	if (isSignal(videoBufferMs)) effect(() => {
		const ms = videoBufferMs();
		untracked(() => connection.setVideoBufferMs(ms));
	});
	const stopOnDestroy = destroyRef.onDestroy(() => connection.close());
	return {
		stream: stream.asReadonly(),
		notice: computed(() => failure() ?? waiting()),
		failure: failure.asReadonly(),
		videoDelayMs: videoDelayMs.asReadonly(),
		stats: stats.asReadonly(),
		videoBufferSupported: typeof RTCRtpReceiver === "function" && "jitterBufferTarget" in RTCRtpReceiver.prototype,
		onMetadata(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		close() {
			stopOnDestroy();
			connection.close();
		}
	};
}
export { neatInsightChannel };

//# sourceMappingURL=sima-neat-ui-insight.mjs.map