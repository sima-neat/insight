import * as i0 from "@angular/core";
import { InjectionToken, Provider, TemplateRef } from "@angular/core";
/**
 * The kinds of code text the block colors, each drawn in the theme's `--neat-code-<kind>`.
 * Anything else (names, operators, punctuation) is the block's own text color.
 */
type CodeKind = 'keyword' | 'string' | 'comment' | 'constant' | 'type' | 'function' | 'property' | 'tag';
/** A stretch of one line's text and its kind, `null` for text the block does not color. */
interface CodeRun {
  readonly text: string;
  readonly kind: CodeKind | null;
}
/**
 * One line as the block shows it: its runs, then its line break (`''` on the last line), so the
 * lines' text is the code as given.
 */
interface CodeLine {
  readonly runs: readonly CodeRun[];
  readonly end: '' | '\n';
}
/**
 * The lines of code split at its line breaks, from each line's runs. Code that ends with a line
 * break has an empty last row, which is not a line of its own: the line before it keeps the break.
 */
declare function codeLines(rows: readonly (readonly CodeRun[])[]): CodeLine[];
/** The code's lines uncolored: what a block shows without a language, and while one loads. */
declare function plainLines(code: string): CodeLine[];
/**
 * A mark: lines, or a part of a line, that a code block sets apart while it dims the rest.
 *
 * Lines and columns count from 1, as people read them: line 1 is the first line, as `lineNumbers`
 * numbers it, and column 1 its first character (a tab counts as one). Ranges include both ends.
 *
 * - `{ lines: [4, 6] }` marks lines 4 to 6 and `{ line: 9 }` line 9 alone, each with a band
 *   across the block.
 * - `{ line: 9, text: 'model.run' }` marks the first `model.run` on line 9, with a marker behind
 *   it.
 * - `{ line: 9, from: 12, to: 20 }` marks columns 12 to 20 of line 9, for text that comes more
 *   than once on its line.
 */
type NeatCodeMark = {
  readonly lines: readonly [from: number, to: number];
} | {
  readonly line: number;
  readonly text?: string;
  readonly from?: never;
  readonly to?: never;
} | {
  readonly line: number;
  readonly from: number;
  readonly to: number;
  readonly text?: never;
};
/**
 * One step of a code block's steps: the marks it shows, and a short label that a screen reader
 * hears when the block moves to it.
 *
 * An app adds what it shows beside the block for each step (a note) to its own steps, which
 * the block takes as they are:
 *
 * ```ts
 * interface Step extends NeatCodeStep {
 *   readonly note: string;
 * }
 * ```
 */
interface NeatCodeStep {
  /** The lines and parts of lines the step marks. A step with none shows the code undimmed. */
  readonly marks: readonly NeatCodeMark[];
  /** What the step is about in a few words ("Open the camera"), said when the block moves to it. */
  readonly label?: string;
}
/**
 * A part mark as a line shows it: whether the shown marks have it, and which of its ends join a
 * neighbor that is on too.
 */
interface PieceMark {
  readonly on: boolean;
  /** `start`, `end` or `both`: the ends that touch another mark that is on, drawn square. */
  readonly join: 'start' | 'end' | 'both' | null;
  /** Which of the shown marks this is (the first that covers it), from 0; null while it is off. */
  readonly index: number | null;
  /** Whether it is the first element of that mark, which takes the mark's tab stop. */
  readonly first: boolean;
}
/** A stretch of a line: its runs, in a mark of some step or in none (`mark` null). */
interface CodePiece {
  readonly runs: readonly CodeRun[];
  readonly mark: PieceMark | null;
}
/**
 * A line as a block with marks shows it. `band` is whether the shown marks have the line whole,
 * or null for a line no step has whole. Its pieces are cut at every column any step's marks start
 * or end at, so the elements stay the same from step to step and only their state changes, which
 * lets a mark fade out as the next fades in.
 */
interface MarkedLine {
  readonly band: boolean | null;
  /** Which of the shown marks has the line whole, from 0, or null. */
  readonly bandIndex: number | null;
  /** Whether the line is the first element of that mark, which takes the mark's tab stop. */
  readonly bandFirst: boolean;
  readonly pieces: readonly CodePiece[];
  readonly end: CodeLine['end'];
}
/** A block's lines with marks, and whether the shown marks have any line or part. */
interface CodeFocus {
  readonly lines: readonly MarkedLine[];
  readonly marked: boolean;
}
/**
 * The lines with the marks of `sets` (each a step's marks, or the block's `marks` alone), showing
 * those at `shown`. Every set is placed on the plain text of the lines, `texts`, so a mark that
 * names no line or text throws in dev mode whichever step it belongs to.
 */
declare function focusLines(lines: readonly CodeLine[], texts: readonly string[], sets: readonly (readonly NeatCodeMark[])[], shown: number, strict?: boolean): CodeFocus;
/** What a code block gives its note template: the step or the mark, and its index from 0. */
interface NeatCodeNoteContext<T> {
  /** The step shown, or the mark the note is for, as the app gave it. */
  readonly $implicit: T;
  /** Its index in the block's `steps` or `marks`, from 0. */
  readonly index: number;
}
/**
 * The note a code block shows in a bubble (`NeatBubble`) beside its marks: the template is given
 * the step or the mark, as the app gave it, so it shows the app's own words for it.
 *
 * ```html
 * <neat-code-block [code]="source" language="python" [steps]="walk" [(step)]="at" stepControls>
 *   <ng-template [neatCodeNote]="walk" let-step>{{ step.note }}</ng-template>
 * </neat-code-block>
 * ```
 *
 * With `steps`, the bubble shows the step's note beside the step's marks (the whole code for a
 * step without marks) and moves with the step. With `marks`, each mark is a tab stop, and its note
 * shows while a mouse or a pen is over the mark or the bubble, while the mark has the keyboard's
 * focus, or after a tap on it; Escape and a press elsewhere put it away. The bubble describes the
 * mark the focus is on (`aria-describedby`).
 *
 * `neatCodeNote` takes the block's steps or marks only so that the template's `let-` variable has
 * their type (`step.note` above). The template shows whatever it renders, so a mark without a note
 * of its own should not be in a block whose marks have notes.
 */
export declare class NeatCodeNote<T extends NeatCodeStep | NeatCodeMark = NeatCodeStep | NeatCodeMark> {
  /** The block's `steps` or `marks`, which give the template's variable its type. */
  readonly neatCodeNote: import("@angular/core").InputSignal<readonly T[] | undefined>;
  /** The side of the marks the bubble prefers, a `NeatBubbleSide`: `top` by default. */
  readonly neatCodeNoteSide: import("@angular/core").InputSignal<"top" | "right" | "bottom" | "left">;
  /** @internal */
  readonly template: TemplateRef<NeatCodeNoteContext<T>>;
  static ngTemplateContextGuard<T extends NeatCodeStep | NeatCodeMark>(_directive: NeatCodeNote<T>, context: unknown): context is NeatCodeNoteContext<T>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCodeNote<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NeatCodeNote<any>, "ng-template[neatCodeNote]", never, {
    "neatCodeNote": {
      "alias": "neatCodeNote";
      "required": false;
      "isSignal": true;
    };
    "neatCodeNoteSide": {
      "alias": "neatCodeNoteSide";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * What a code block does with a line wider than itself: `wrap` breaks it, `scroll` keeps it whole
 * and scrolls the block sideways.
 */
type NeatCodeOverflow = 'wrap' | 'scroll';
/**
 * Code set apart on the muted fill, as written, with an optional Copy button at its end.
 *
 * ```html
 * <neat-code-block [code]="command" copy="install command" />
 * ```
 *
 * For a command to run, a file to paste or a URL to copy. For a name or a path in running text,
 * use `code[neatCode]` instead.
 *
 * `copy` names what the code is and adds a `NeatCopyButton` beside the code. "install command"
 * names the button "Copy install command". Without `copy` the block has no button.
 *
 * `overflow` is `wrap` by default, for short code such as a command, which then breaks anywhere.
 * Use `scroll` for a whole file, whose lines keep their shape and scroll sideways.
 *
 * `language` colors the code in the theme's code colors:
 *
 * ```html
 * <neat-code-block [code]="source" language="python" copy="example" overflow="scroll" />
 * ```
 *
 * The block colors Python, C++, C, shell, JSON, YAML, CMake, TypeScript, JavaScript, HTML, CSS,
 * Markdown, Dockerfile and Go by themselves; `provideNeatCodeLanguages` adds others. The
 * highlighter (Shiki) and each language's grammar load the first time a block on the page shows
 * that language, so a page without a colored block loads none of it, and one with Python only
 * never loads C++. While they load, the block shows the code plain, in the same layout. A
 * language the block does not know leaves the code plain and is named once in dev mode.
 *
 * `lineNumbers` numbers the lines in a gutter at their start. The numbers are not part of the text:
 * a selection leaves them out, a screen reader does not read them, and Copy copies the code as
 * given, colored or not.
 *
 * `marks` sets lines, or parts of lines, apart, and dims the rest of the code. A `NeatCodeMark`
 * counts lines and columns from 1, as `lineNumbers` numbers them:
 *
 * ```html
 * <neat-code-block [code]="source" language="cpp" [marks]="marks" />
 * ```
 *
 * ```ts
 * readonly marks: NeatCodeMark[] = [{ lines: [4, 6] }, { line: 9, text: 'model.run' }];
 * ```
 *
 * A marked line gets a band across the block, and a marked part a rounded marker behind it, both
 * in the theme's mark tint (`--neat-code-mark`). Marked code keeps its colors, each held to 4.5:1
 * on the tint. The rest dims to the muted text color, which still reads at 4.5:1 on the block.
 * `[dim]="false"` leaves the rest as it is.
 *
 * A marked part is a `mark` element, which a screen reader announces as highlighted. Marks change
 * nothing of the text: a selection and Copy take the code as given. A mark that names no line, or
 * text its line does not have, throws in dev mode and is left out in production.
 *
 * `steps` walks through the code a set of marks at a time, each a `NeatCodeStep` with an optional
 * `label`. `step` is the one shown, from 0. Bind it both ways to show a note of your own beside
 * the block:
 *
 * ```html
 * <neat-code-block [code]="source" [steps]="walk" [(step)]="at" stepControls />
 * <p>{{ walk[at()].note }}</p>
 * ```
 *
 * While a block has steps, it shows their marks and does not use `marks`. A `step` outside the
 * steps shows the nearest one and is left as it is. `stepControls` adds a Previous and a Next
 * button and the position ("2 of 5") below the code.
 *
 * A block with steps is a tab stop, and the left and right arrow keys move to the step before and
 * after. On the code itself, which is a tab stop of its own while it scrolls sideways, they scroll
 * it instead. Moving to a step fades its marks in as the last ones fade out, at once under reduced
 * motion. A polite live region says the step ("Step 2 of 5: Open the camera").
 *
 * The block scrolls its own box, never the page, to bring the first mark into view when the marks
 * shown change. Give the block a height or a `max-height`, and its code scrolls inside it: a long
 * file then walks to a mark further down without moving the page.
 *
 * A `NeatCodeNote` template inside the block shows a note in a bubble beside the marks: the shown
 * step's, or a mark's while it is hovered, focused or tapped, in the app's own words:
 *
 * ```html
 * <neat-code-block [code]="source" language="python" [steps]="walk" [(step)]="at" stepControls>
 *   <ng-template [neatCodeNote]="walk" let-step>{{ step.note }}</ng-template>
 * </neat-code-block>
 * ```
 *
 * An app that colors its code itself (spans from a highlighter run at build time) puts them
 * inside the element. They are shown in place of the block's own lines, without `language`,
 * `lineNumbers` or marks, and `code` stays what Copy copies, so they must spell the same text. The
 * steps, their controls and the keys still work, so the app can mark its own spans by `step`:
 *
 * ```html
 * <neat-code-block [code]="source" copy="app.ts">
 *   @for (run of runs; track $index) {
 *     <span [class]="run.kind">{{ run.text }}</span>
 *   }
 * </neat-code-block>
 * ```
 *
 * Angular leaves out the line breaks between a template's elements, so only the spans' own text
 * shows, as written.
 */
export declare class NeatCodeBlock {
  /** The code, as text: shown, and copied by the Copy button. */
  readonly code: import("@angular/core").InputSignal<string>;
  /** What the code is, which adds a Copy button named after it ("Copy install command"). */
  readonly copy: import("@angular/core").InputSignal<string | undefined>;
  /** Whether a long line wraps or scrolls sideways (a `NeatCodeOverflow`). */
  readonly overflow: import("@angular/core").InputSignal<NeatCodeOverflow>;
  /**
   * The language the code is in, by its Shiki name or an alias (`"python"`, `"cpp"`, `"bash"`),
   * which colors it; `null`, the default, shows it plain.
   */
  readonly language: import("@angular/core").InputSignal<string | null>;
  /** Whether the lines are numbered, in a gutter that a selection and Copy leave out. */
  readonly lineNumbers: import("@angular/core").InputSignal<boolean>;
  /**
   * The lines and parts of lines the block sets apart (a `NeatCodeMark` each), counted from 1.
   * Not used while the block has `steps`.
   */
  readonly marks: import("@angular/core").InputSignal<readonly NeatCodeMark[]>;
  /** Whether the code outside the marks dims while there are marks. On by default. */
  readonly dim: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * A walk through the code, a `NeatCodeStep` at a time, each with its own marks. While there are
   * steps, the block is a tab stop whose arrow keys move between them.
   */
  readonly steps: import("@angular/core").InputSignal<readonly NeatCodeStep[]>;
  /** The step shown, from 0: bind it both ways to follow the block, or to move it. */
  readonly step: import("@angular/core").ModelSignal<number>;
  /** Whether Previous and Next buttons and the position ("2 of 5") show under the code. */
  readonly stepControls: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** The note template, which shows the step's or the mark's note in a bubble. */
  protected readonly note: import("@angular/core").Signal<NeatCodeNote<NeatCodeMark | NeatCodeStep> | undefined>;
  /** The languages the block colors: its own, and those the app added (which win). */
  private readonly languages;
  private readonly box;
  private readonly bubble;
  private readonly document;
  private readonly highlighter;
  /** The code's lines uncolored, and their text, which marks are placed on. */
  private readonly plain;
  private readonly texts;
  /** The lines shown: colored once the language's highlighter is there, plain until then. */
  private readonly lines;
  protected readonly stepCount: import("@angular/core").Signal<number>;
  /** The step shown: `step`, kept to the steps there are. */
  protected readonly shownStep: import("@angular/core").Signal<number>;
  /** The lines with every step's marks on them (or `marks` alone), those of the shown step on. */
  protected readonly focus: import("@angular/core").Signal<CodeFocus>;
  protected readonly dimmed: import("@angular/core").Signal<boolean>;
  /** How many digits the last line's number has, which sets the gutter's width. */
  protected readonly digits: import("@angular/core").Signal<number>;
  /** Whether each mark shows its note on hover, focus or a tap: marks, no steps, and a note. */
  protected readonly hoverNotes: import("@angular/core").Signal<boolean>;
  /** The mark whose note shows, by its index in `marks`. */
  private readonly openMark;
  /** A mark whose note Escape put away, which the pointer or the focus must leave to show it again. */
  private dismissed;
  /** Whether a mouse or a pen is over the open mark, or over the bubble. */
  private pointerOnMark;
  private pointerOnBubble;
  private closeTimer;
  /** What the note template is given, null while no note shows. */
  protected readonly noteContext: import("@angular/core").Signal<{
    $implicit: NeatCodeStep;
    index: number;
  } | {
    $implicit: NeatCodeMark;
    index: number;
  } | null>;
  /** The elements the note's bubble points at, found once they are rendered. */
  protected readonly noteAnchor: import("@angular/core").WritableSignal<readonly Element[] | null>;
  /** What the live region says of the shown step, which it says again on each change. */
  protected readonly announcement: import("@angular/core").Signal<string>;
  constructor();
  /** The bubble's id on the mark whose note shows, for `aria-describedby`. */
  protected describedBy(index: number | null): string | null;
  /** The mark (its index in `marks`) of a node inside the code, null for none. */
  private markOf;
  private bubbleElement;
  protected pointerOver(event: PointerEvent): void;
  protected pointerLeave(event: PointerEvent): void;
  protected focusIn(event: FocusEvent): void;
  protected focusOut(event: FocusEvent): void;
  /** A tap on a mark (or a click) shows its note. */
  protected tap(event: MouseEvent): void;
  protected bubbleHover(over: boolean): void;
  private openNote;
  /** Puts the note away after the delay, unless the pointer or the keyboard's focus holds it. */
  private closeSoon;
  private closeNote;
  /** Moves `by` steps, if there is a step there; whether it moved. */
  protected move(by: number): boolean;
  protected onKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCodeBlock, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCodeBlock, "neat-code-block", never, {
    "code": {
      "alias": "code";
      "required": true;
      "isSignal": true;
    };
    "copy": {
      "alias": "copy";
      "required": false;
      "isSignal": true;
    };
    "overflow": {
      "alias": "overflow";
      "required": false;
      "isSignal": true;
    };
    "language": {
      "alias": "language";
      "required": false;
      "isSignal": true;
    };
    "lineNumbers": {
      "alias": "lineNumbers";
      "required": false;
      "isSignal": true;
    };
    "marks": {
      "alias": "marks";
      "required": false;
      "isSignal": true;
    };
    "dim": {
      "alias": "dim";
      "required": false;
      "isSignal": true;
    };
    "steps": {
      "alias": "steps";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "stepControls": {
      "alias": "stepControls";
      "required": false;
      "isSignal": true;
    };
  }, {
    "step": "stepChange";
  }, ["note"], ["*", "[neatCodeNote]"], true, never>;
}
/**
 * A small Copy button that puts `text` on the clipboard and says whether it did.
 *
 * ```html
 * <code neatCode>{{ url }}</code>
 * <neat-copy-button [text]="url" what="stream URL" />
 * ```
 *
 * `NeatCodeBlock` shows one beside its code. Use this part on its own for text shown some other
 * way: a URL in running text, or code whose Copy button sits outside it (above a set of tabs).
 *
 * After a click the button says "Copied", with a check, or "Could not copy". It says the same in a
 * polite live region, and offers to copy again after 2.5 s.
 *
 * With `inline` it is a `neatInlineButton` with a smaller icon, set into a line of text: after a
 * URL in a details list, where a small button's 2rem would set the line's height.
 *
 * Its accessible name is "Copy" and `what`: "Copy stream URL", so a page with several buttons
 * does not read as a list of "Copy". The name starts with the visible caption, so a voice user can
 * say what they see.
 *
 * It needs a secure context. A browser gives the clipboard to pages served over https and from
 * localhost only, so on a page served over plain http the button says it could not copy. It has
 * no fallback.
 */
export declare class NeatCopyButton {
  /** The text the button copies. */
  readonly text: import("@angular/core").InputSignal<string>;
  /** What the text is, for the button's name: `install command` names it "Copy install command". */
  readonly what: import("@angular/core").InputSignal<string>;
  /** Set into a line of text, as a `neatInlineButton`, instead of a small text button. */
  readonly inline: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  private readonly state;
  protected readonly caption: import("@angular/core").Signal<string>;
  protected readonly icon: import("@angular/core").Signal<"check" | "copy">;
  protected readonly name: import("@angular/core").Signal<string>;
  protected readonly announcement: import("@angular/core").Signal<string>;
  private timer;
  constructor();
  protected copy(): Promise<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatCopyButton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatCopyButton, "neat-copy-button", never, {
    "text": {
      "alias": "text";
      "required": true;
      "isSignal": true;
    };
    "what": {
      "alias": "what";
      "required": true;
      "isSignal": true;
    };
    "inline": {
      "alias": "inline";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The languages a code block can color, by the name its `language` takes: for each, a function
 * that imports the language's grammar.
 *
 * Each import names a grammar module of Shiki's `@shikijs/langs` package (the kit installs it with
 * its highlighter), as a dynamic `import()`, so the grammar loads only when a block shows that
 * language:
 *
 * ```ts
 * const languages: NeatCodeLanguages = {
 *   rust: () => import('@shikijs/langs/rust'),
 *   toml: () => import('@shikijs/langs/toml'),
 * };
 * ```
 *
 * A module's default export is the language's grammar after those it embeds, as `@shikijs/langs`
 * gives it. A static import would put the grammar in the bundle of every page that imports the
 * file.
 */
type NeatCodeLanguages = Readonly<Record<string, () => Promise<{
  readonly default: readonly object[];
}>>>;
/**
 * Adds languages to the ones a code block colors by itself, or gives one another grammar.
 *
 * ```ts
 * providers: [
 *   provideNeatCodeLanguages({
 *     rust: () => import('@shikijs/langs/rust'),
 *     rs: () => import('@shikijs/langs/rust'),
 *   }),
 * ],
 * ```
 *
 * Each key is a name a block's `language` takes, so a language used by two names (its id and an
 * alias) is listed under both. The kit colors Python, C++, C, shell, JSON, YAML, CMake,
 * TypeScript, JavaScript, HTML, CSS, Markdown, Dockerfile and Go without it.
 *
 * It goes in any `providers`: the app's `app.config.ts` for every page, a route's for the pages
 * under it, a component's for the blocks in its template. Each adds to the languages of the place
 * around it, so a page's languages come on top of the app's. Within one `providers` list, call it
 * once with all of that place's languages: a second call there replaces the first.
 */
export declare function provideNeatCodeLanguages(languages: NeatCodeLanguages): Provider;
/**
 * The languages a code block colors by itself, under each grammar's Shiki name and aliases (the
 * spec holds the names to the grammars). Their grammars are MIT licensed but YAML's, whose
 * TextMate bundle grants every use without conditions; C++'s embeds GLSL's, which states no
 * license (AGENTS.md "How the code block colors code").
 */
declare const DEFAULT_CODE_LANGUAGES: NeatCodeLanguages;
/**
 * The languages the code blocks here color: the kit's own, and those `provideNeatCodeLanguages`
 * added on the way (which win).
 */
declare const NEAT_CODE_LANGUAGES: InjectionToken<Readonly<Record<string, () => Promise<{
  readonly default: readonly object[];
}>>>>;
export type { NeatCodeLanguages, NeatCodeMark, NeatCodeNoteContext, NeatCodeOverflow, NeatCodeStep };