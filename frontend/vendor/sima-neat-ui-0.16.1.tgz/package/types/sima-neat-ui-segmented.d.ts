import { NeatIconName } from "@sima/neat-ui";
import * as i0 from "@angular/core";
/** One choice of a `neat-segmented`: its value, its label and an optional icon before the label. */
interface NeatSegmentedOption<T> {
  readonly value: T;
  readonly label: string;
  readonly icon?: NeatIconName;
}
/**
 * A row of mutually exclusive choices, such as a tile shape: `<neat-segmented label="Tile shape"
 * [options]="shapes" [(value)]="shape" />`. It is a radio group named by `label`: one tab stop
 * (the checked option, else the first), arrow keys move the choice and wrap, Home and End jump to
 * the ends, and a click on the checked option keeps it checked.
 *
 * Drawn as an iOS-style switch: a track with a raised thumb that slides under the chosen label.
 * Not built on brain's toggle group: brain makes its items pressed toggle buttons (`aria-pressed`,
 * rewritten on every change) with no arrow keys, while a choice of one is a radio group. The
 * roles, the roving tab stop, the keys and `data-state` are the kit's.
 */
export declare class NeatSegmented<T> {
  readonly value: import("@angular/core").ModelSignal<T>;
  readonly options: import("@angular/core").InputSignal<readonly NeatSegmentedOption<T>[]>;
  /** The group's accessible name; each option is named by its own label. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly groupClasses = "relative isolate inline-grid grid-flow-col auto-cols-[minmax(max-content,1fr)] rounded-lg bg-neat-segmented-track p-0.5 aria-disabled:opacity-50";
  protected readonly thumbClasses = "pointer-events-none absolute inset-y-0.5 left-0.5 z-0 w-[calc((100%-4px)/var(--neat-segmented-count))] translate-x-[calc(var(--neat-segmented-index)*100%)] rounded-md bg-neat-segmented-thumb shadow-sm ring-1 ring-neat-segmented-thumb-edge transition-transform duration-280 ease-[cubic-bezier(.3,.7,.2,1)] motion-reduce:transition-none";
  protected readonly itemClasses = "relative z-10 inline-flex h-8 cursor-pointer items-center justify-center gap-1.5 rounded-md bg-transparent px-3.5 text-sm font-medium whitespace-nowrap text-foreground outline-none transition-colors duration-200 motion-reduce:transition-none disabled:pointer-events-none focus-visible:z-20 focus-visible:ring-[3px] focus-visible:ring-ring data-[state=on]:font-semibold data-[state=on]:text-primary before:absolute before:inset-y-1.5 before:left-0 before:w-px before:bg-muted-foreground/40 before:transition-opacity before:duration-200 motion-reduce:before:transition-none first-of-type:before:hidden data-[state=on]:before:opacity-0 [[data-state=on]+&]:before:opacity-0";
  /** The index of the checked option, or -1 when the value is none of the options. */
  protected readonly chosen: import("@angular/core").Signal<number>;
  /**
   * The option keyboard focus enters on: the checked one, else the first. It is also the thumb's
   * index: the thumb is drawn only while an option is checked, and then the two are the same.
   */
  protected readonly tabStop: import("@angular/core").Signal<number>;
  private readonly segments;
  /** Focuses the control's tab stop, the checked option (else the first): where Tab enters it. */
  focus(): void;
  /** Moves the choice from the segment at `current` (the one with focus) as the key says. */
  protected move(event: KeyboardEvent, current: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatSegmented<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatSegmented<any>, "neat-segmented", never, {
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
export type { NeatSegmentedOption };