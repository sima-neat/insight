import "@sima/neat-ui";
import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
/**
 * One metadata message from the stream's data channel. `_insight.rtp_timestamp` identifies the
 * video frame the message describes; messages without it can only be matched by arrival order.
 */
interface NeatMetadataMessage {
  type: string;
  timestamp?: number;
  frame_id?: unknown;
  data?: unknown;
  _insight?: {
    rtp_timestamp?: number;
  };
}
/**
 * Parses a data-channel text message. Returns null for anything that is not a JSON object with a
 * string `type`, so a caller can drop it without reasoning about the payload. Everything else,
 * `data` and `_insight` included, is kept exactly as received.
 */
declare function parseMetadataMessage(text: string): NeatMetadataMessage | null;
/** A message with the time it arrived, as the queue stores and returns it. */
interface NeatMetadataItem {
  receivedAt: number;
  data: NeatMetadataMessage;
}
/** An item as returned for drawing; `held` marks one redrawn from an earlier frame. */
type NeatDrawableMetadataItem = NeatMetadataItem & {
  held?: true;
};
/** The last item of each metadata type, kept by `holdOverlays` between frames. */
type NeatHeldOverlays = Map<string, {
  item: NeatMetadataItem;
  matchedAt: number;
}>;
/** Cumulative counters; they survive `resetLatenessWindow`. */
interface NeatMetadataQueueStats {
  timestampMatches: number;
  arrivalFallbacks: number;
  frameMisses: number;
  expired: number;
  evicted: number;
  untimestampedReceived: number;
  late: number;
}
/**
 * What a tile's metadata queue holds and how late it has been, from `NeatVideoTile.snapshot`: the
 * cumulative counters and the messages still waiting for a frame, then the lateness of the last
 * five seconds, which the app's lateness notice reads. The `recent` figures are `null` while the
 * window has too little to say.
 */
interface NeatMetadataSnapshot extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  /** Null until the window holds enough messages for a share to mean anything. */
  recentLateShare: number | null;
  /** Null while the window holds no late message whose frame is still remembered. */
  recentLatenessMedianMs: number | null;
  recentLatenessP90Ms: number | null;
  recentLatenessMaxMs: number | null;
}
/**
 * The per-stream queue. Create it with `createMetadataQueue` and pass it to this module's
 * functions; `metadataQueueSnapshot` reports what it holds. Its contents are not accessible.
 */
interface NeatMetadataQueue {
  readonly __neatMetadataQueue: never;
}
declare function createMetadataQueue(): NeatMetadataQueue;
declare function enqueueMetadata(handle: NeatMetadataQueue, message: NeatMetadataMessage, receivedAt: number): void;
/**
 * The metadata to draw on a frame the browser is presenting. `rtpTimestamp` is the frame's RTP
 * timestamp, or null when the browser does not report one. A retention of 0 never expires.
 */
declare function takeMetadataForFrame(handle: NeatMetadataQueue, rtpTimestamp: number | null, metadataRetentionMs: number, now: number): NeatMetadataItem[];
declare const OVERLAY_HOLD_MS = 200;
declare function holdOverlays(held: NeatHeldOverlays, overlays: NeatMetadataItem[], now: number): NeatDrawableMetadataItem[];
declare function metadataQueueSnapshot(handle: NeatMetadataQueue): NeatMetadataSnapshot;
declare function resetLatenessWindow(handle: NeatMetadataQueue): void;
/** The part of a queue snapshot that the late notice reads. */
type NeatLatenessSnapshot = Pick<NeatMetadataSnapshot, 'recentLateShare' | 'recentLatenessMedianMs' | 'recentLatenessP90Ms'>;
/**
 * Why no buffer is suggested: the browser cannot set one, the window has no lateness sample, or
 * the suggestion would pass the maximum.
 */
type NeatLateNoticeBlocker = 'unsupported' | 'unmeasured' | 'maximum';
/**
 * The notice's second button: `raise` lifts the value the channels follow to the suggestion;
 * `follow` only lets this channel adopt the followed value, which already covers it.
 */
interface NeatGlobalBufferAction {
  kind: 'raise' | 'follow';
  valueMs: number;
}
/**
 * What an app's "metadata late" notice shows and offers, from `lateNoticeDetails`: how late the
 * metadata is (median ms, share of messages in percent), the video sync buffer in use, the
 * suggested one, why none is suggested if so, and the action for the global setting.
 */
interface NeatLateNoticeDetails {
  latenessMs: number | null;
  latePercent: number | null;
  bufferMs: number;
  suggestedBufferMs: number | null;
  blockedBy: NeatLateNoticeBlocker | null;
  globalAction: NeatGlobalBufferAction | null;
}
/**
 * Whether the late-metadata warning is on after this sample, from whether it was on before and
 * the recent late share (0 to 1, `null` when unknown, which changes nothing). It turns on at half
 * the messages late and off below a tenth; in between it stays as it was, so a share hovering
 * around one value does not make the chip blink.
 */
export declare function nextWarningActive(active: boolean, recentLateShare: number | null): boolean;
declare function suggestedBufferMs(currentBufferMs: number, p90LatenessMs: number | null): number | null;
/**
 * How long, in ms, to keep the late warning off after the video sync buffer changes from
 * `previousBufferMs` to `nextBufferMs`: a browser moves to a raised jitter buffer target
 * gradually, roughly 100 ms per second of video, and what is measured until it has arrived still
 * describes the old buffer. A second, plus ten times the raise (a lowered buffer: a second).
 */
export declare function bufferSettleMs(previousBufferMs: number, nextBufferMs: number): number;
/**
 * What the "metadata late" notice says and offers for `snapshot`, the lateness window
 * (`NeatMetadataSnapshot`'s `recent` figures), when the video sync buffer is `currentBufferMs`.
 * `bufferSupported` is whether the browser can set a buffer at all, and `followedBufferMs` the
 * value the app's channels follow, if it has one, which decides whether the second button raises
 * it or only lets this channel adopt it. The suggested buffer covers the slowest tenth of the
 * messages (the 90th percentile) plus a margin, in steps of 50 ms, up to the 4000 ms maximum.
 */
export declare function lateNoticeDetails(snapshot: NeatLatenessSnapshot, currentBufferMs: number, bufferSupported: boolean, followedBufferMs?: number | null): NeatLateNoticeDetails;
/** The dark plate behind track and pose labels, so the label reads in its identity colour. */
declare const OVERLAY_LABEL_PLATE_COLOR = "rgba(15, 23, 42, 0.82)";
/**
 * ROI polygons, unlike the identity colours, use the kit's own green and danger red: the user
 * draws them, so they belong to the app's chrome rather than to the footage's labels. A faint fill
 * keeps the video visible under them and a full-strength 2px outline marks the edge; a highlighted
 * polygon (the one under the pointer, or the app's pick) takes `fillActive`, the same hue three
 * times as strong, so it stands out from its neighbours while the video still shows through.
 */
declare const OVERLAY_ROI_COLORS: {
  readonly inclusion: {
    readonly fill: string;
    readonly fillActive: string;
    readonly stroke: "#2A9C4F";
  };
  readonly exclusion: {
    readonly fill: string;
    readonly fillActive: string;
    readonly stroke: "#C8372D";
  };
};
/** The colour a class style row resolves to when its stored colour is missing or not a string. */
export declare const NEAT_OVERLAY_STYLE_FALLBACK_COLOR = "#00ff00";
/** How a class's boxes and outlines are stroked. */
type NeatOverlayLineStyle = 'solid' | 'dashed' | 'dotted';
/**
 * A class style row: overlays whose label equals `label` draw in `color` with this line. The row
 * labelled `default` applies to every label without a row of its own.
 */
interface NeatOverlayClassStyle {
  readonly label: string;
  readonly color: string;
  readonly style: NeatOverlayLineStyle;
  /** Line width in CSS pixels: thin (1) or thick (3). It overrides `general.lineWidth`. */
  readonly width: 1 | 3;
}
/**
 * A region of interest. Coordinates are normalized to 0..1 of the video frame, so a polygon fits
 * any resolution the stream is sent at.
 */
interface NeatRoiPolygon {
  readonly type: 'inclusion' | 'exclusion';
  readonly points: readonly {
    readonly x: number;
    readonly y: number;
  }[];
}
/**
 * The resolved overlay settings for one channel. The app resolves them once per change (defaults,
 * global values, the channel's own values); drawing reads them every frame and never parses or
 * validates them.
 */
interface NeatOverlaySettings {
  readonly general: {
    /** Line width in CSS pixels for every overlay line a class row does not override. */
    readonly lineWidth: number;
    /** Draw the ROI polygons under the detection, segmentation and tracking overlays. */
    readonly showRoi: boolean;
    /** Hide detections, segments and tracks whose box centre falls outside the ROI. */
    readonly applyRoiFiltering: boolean;
  };
  readonly types: {
    readonly 'object-detection': {
      readonly visible: boolean;
      /** 0..1; an object without a confidence always passes. */
      readonly confidenceThreshold: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly segmentation: {
      readonly visible: boolean;
      /** 0..1; a segment without a confidence counts as fully confident. */
      readonly confidenceThreshold: number;
      /** 0..1, the alpha of mask fills. */
      readonly maskOpacity: number;
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly tracking: {
      readonly visible: boolean;
      readonly confidenceThreshold: number;
      readonly history: {
        /** Draw each track's recent centre positions as a trail. */
        readonly enabled: boolean;
        /** Positions kept per track. */
        readonly trailLength: number;
        /** How long the trail of a track that left the frame stays, in milliseconds. */
        readonly lostTrackTtlMs: number;
      };
    };
    readonly 'pose-estimation': {
      readonly visible: boolean;
      /** Dots on the joints. */
      readonly showKeypoints: boolean;
      /** Joint names next to the dots. */
      readonly showKeypointLabels: boolean;
      /** The box and label plate around each pose. */
      readonly showBoxes: boolean;
      /**
       * Colour, line and width by the pose's label (`person`, `hand`); a pose without a row keeps
       * its identity colour.
       */
      readonly objects: readonly NeatOverlayClassStyle[];
    };
    readonly classification: {
      readonly visible: boolean;
    };
  };
  readonly roi: readonly NeatRoiPolygon[];
}
/** The settings a channel draws with when nothing is stored. */
export declare const NEAT_OVERLAY_DEFAULTS: NeatOverlaySettings;
/** The box tiles are laid out in, in CSS pixels (`NeatTileGrid` measures it from its host). */
interface NeatTileArea {
  readonly width: number;
  readonly height: number;
}
/** How tiles of one size fill an area: the grid they form and the size each tile gets. */
interface NeatTilePack {
  readonly columns: number;
  readonly rows: number;
  /** How many tiles fit at once: `columns * rows`. */
  readonly perPage: number;
  /** The tile size actually used; below the requested width only when one tile did not fit. */
  readonly tileWidth: number;
  readonly tileHeight: number;
}
/**
 * The narrowest tile the kit lays out, in CSS pixels. Below this a tile is a postage stamp, so with
 * very many items in a small area the page pages instead of shrinking tiles further. Only an area
 * smaller than this makes a tile narrower (it then shrinks to the area).
 */
export declare const NEAT_MIN_TILE_WIDTH = 64;
/**
 * How many tiles of `tileWidth` fit into `area` with `gap` between them (and none around the
 * outside), in columns and rows. The gap counts only between tiles, which is why the area is
 * widened by one gap before dividing: `n` tiles take `n * tile + (n - 1) * gap`.
 *
 * `tileWidth` is raised to `NEAT_MIN_TILE_WIDTH` (a NaN, zero or negative one too). If even one
 * tile does not fit, it shrinks to the area while keeping 16:9, to whole CSS pixels so it
 * never rounds past the edge; that rule wins over the minimum. A tile is at least 1 px, so an
 * empty area (before the first measurement) still yields one tile.
 */
declare function packTiles(area: NeatTileArea, tileWidth: number, gap: number): NeatTilePack;
/**
 * The widest tile, in whole CSS pixels, at which `count` tiles fit into `area` on one page. For
 * each column count from 1 to `count` the rows follow (`ceil(count / columns)`), and the tile is
 * bounded by both the width and the height of the area; the column count with the widest tile
 * wins. Whole pixels, rounded down, so a floating-point edge can never make the grid drop a row
 * that this function counted on.
 *
 * Never below `NEAT_MIN_TILE_WIDTH`: when `count` tiles would need narrower ones, the result is
 * the minimum and the caller pages. A count that is not a finite number of at least 1 is one tile;
 * a fractional count is rounded down.
 */
export declare function fitAllTileWidth(area: NeatTileArea, count: number, gap: number): number;
/**
 * What the grid reports: the packing, the gap it used between tiles and the content box it was
 * packed into. A page that sizes tiles itself (to fit a count, say) needs the gap the grid used,
 * which may be the kit's token rather than a number the page chose.
 */
interface NeatTileLayout extends NeatTilePack {
  /** Space between tiles in CSS pixels. */
  readonly gap: number;
  readonly areaWidth: number;
  readonly areaHeight: number;
}
/**
 * Lays its items out as 16:9 tiles of a fixed width in a centred grid, as many as fit into its own box
 * without scrolling or overflowing. The tile width comes from the page (a slider, say); the grid
 * works out the columns, rows and tiles per page and reports them through `layout`, so the page
 * can slice its items to `perPage`. The grid never pages itself.
 *
 * It fills its parent and measures its own box, never the shell's, so it repacks when the parent
 * changes size for any reason. `layout` is emitted when a value of it changes, not on every
 * resize notification.
 *
 * `count` is the number of projected items. When fewer than a row's worth are shown, they form a
 * centred block of their own width instead of hugging the left edge of a full-width row.
 *
 * The gap defaults to the kit's `--neat-space-2` token, read once when the grid initialises; an
 * explicit `gap` (in CSS pixels) overrides it.
 */
export declare class NeatTileGrid {
  /** Tile width in CSS pixels; a tile wider than the area shrinks to it. */
  readonly tileWidth: import("@angular/core").InputSignal<number>;
  /** Space between tiles in CSS pixels; the kit's `--neat-space-2` when unset. */
  readonly gap: import("@angular/core").InputSignal<number | undefined>;
  /** The number of projected items. */
  readonly count: import("@angular/core").InputSignal<number>;
  /**
   * The packed grid: columns, rows, tiles per page and the tile size. Emitted once the box is
   * measured and again whenever a value of it changes; slice your items to `perPage`.
   */
  readonly layout: import("@angular/core").OutputEmitterRef<NeatTileLayout>;
  private readonly gridElement;
  private readonly area;
  /** The token's gap, known once the grid has rendered and its stylesheet can be read. */
  private readonly tokenGap;
  /**
   * The gap in use. It waits for the token to be read even when `gap` is set, so the read never
   * sees a gap this component applied itself.
   */
  protected readonly gapPx: import("@angular/core").Signal<number | null>;
  private readonly packed;
  /** What the template draws: the packed tiles, in as many columns as there are items to show. */
  protected readonly view: import("@angular/core").Signal<{
    columns: number;
    gap: number;
    areaWidth: number;
    areaHeight: number;
    rows: number;
    perPage: number;
    tileWidth: number;
    tileHeight: number;
  } | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatTileGrid, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatTileGrid, "neat-tile-grid", never, {
    "tileWidth": {
      "alias": "tileWidth";
      "required": true;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": true;
      "isSignal": true;
    };
  }, {
    "layout": "layout";
  }, never, ["*"], true, never>;
}
/**
 * Where a `neat-video-tile` gets its video and metadata. The tile knows nothing about how they
 * arrive (WebRTC, a file, a canvas); the app implements this for its transport.
 */
interface NeatTileSource {
  /** The channel's video, or null while connecting or when it has none. */
  readonly stream: Signal<MediaStream | null>;
  /**
   * Registers a listener for raw metadata text; returns the unsubscribe function. `receivedAt` is
   * on the `performance.now()` clock, the one presented frames are timed with.
   */
  onMetadata(listener: (text: string, receivedAt: number) => void): () => void;
}
/** A tile whose stream presents no frame for this long has stopped. */
declare const NEAT_STREAM_STALE_MS = 1800;
/**
 * `empty` until the stream presents its first frame, `playing` while frames arrive, `stopped`
 * once none has arrived for the stale timeout (about 1.8 s); it plays again when frames return.
 */
type NeatTileState = 'empty' | 'playing' | 'stopped';
/**
 * Where the shown image sits inside the tile, in CSS pixels from the tile's top-left corner: the
 * video without the bars `object-fit: contain` leaves around it.
 */
interface NeatVideoBox {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}
/**
 * What the overlay drew for one presented frame: the messages matched to it, and the ones held
 * over from an earlier frame because this frame had none of their type (`held`).
 */
interface NeatTileFrame {
  /** When the frame was presented, on the `performance.now()` clock. */
  readonly now: number;
  /** One message per type at most; empty when nothing matched and nothing is held. */
  readonly messages: readonly {
    readonly message: NeatMetadataMessage;
    readonly held: boolean;
  }[];
}
/**
 * Called once for each frame the tile presents, after the overlay is drawn, outside Angular: it
 * runs up to the video's frame rate, so it must be cheap and should not touch Angular state per
 * call (write a signal at most when its value changes).
 */
type NeatTileFrameListener = (frame: NeatTileFrame) => void;
/**
 * The tile's frame-sync counters and video state, as the app reports them (the `synchronization`
 * and `video` groups of vf's browser egress report). Counters are cumulative for the current
 * stream. Every count and pixel size is a whole number: vf parses them as integers and drops a
 * report with a fraction in one.
 */
interface NeatFrameStats extends NeatMetadataQueueStats {
  timestampedPending: number;
  arrivalPending: number;
  recentLatenessMedianMs: number | null;
  recentLatenessMaxMs: number | null;
  /** Valid metadata messages received in the last second. */
  metadataMessagesPerSecond: number;
  /** The video element when the stats were taken. */
  video: {
    /** `HTMLMediaElement.readyState`, 0 to 4. */
    readyState: number;
    paused: boolean;
    /** Seconds, fractional. */
    currentTime: number;
    videoWidth: number;
    videoHeight: number;
    /** Whole milliseconds since the stream's last presented frame; null before its first. */
    lastFrameAgeMs: number | null;
    /** Whether the tile is `playing`. */
    active: boolean;
  };
}
/**
 * Plays a source's video with its metadata drawn as overlays, each frame with the metadata that
 * describes it. It fills the box it is given.
 *
 * The frame loop runs outside Angular and touches no signal: per frame it matches the queued
 * metadata to the presented frame, holds a type that is missing for a moment, and draws. The
 * component sees a state change and, at most once a second, `frameStats`. Inputs the loop needs
 * are copied into fields when they change, so a frame never reads an input or resolves settings.
 *
 * With `bars` on, a bar along the bottom shows `label`, `status` and the chips projected with
 * `neatTileChip`, and a tile without video says so. With `bars` off it is only video and overlay.
 *
 * Content projected with `neatTileOverlay` fills a layer over the tile, above the overlay canvas
 * and below the bar; `videoBox` says where the image is inside it and `barHeight` how tall the bar
 * is. Without video the layer stays above what covers the image and below the no-video note, which
 * lets pointer input through. The layer itself catches no pointer input, so the video under it
 * keeps its hits; its content takes them only where it sets `pointer-events: auto`.
 */
export declare class NeatVideoTile {
  /**
   * Where the video and its metadata come from; `null` (the default) leaves the tile `empty`.
   * Give it the channel's source once it has one: the tile plays its stream and draws its metadata.
   */
  readonly source: import("@angular/core").InputSignal<NeatTileSource | null>;
  /** The channel's resolved overlay settings; a new object for each change. */
  readonly settings: import("@angular/core").InputSignal<NeatOverlaySettings>;
  /** How long metadata waits for its frame, in milliseconds; 0 waits indefinitely. */
  readonly retentionMs: import("@angular/core").InputSignal<number>;
  /** The number overlay warnings name the tile by, such as the app's channel. */
  readonly channel: import("@angular/core").InputSignal<number>;
  /** The bar's left text, such as the channel number. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The bar's status text. */
  readonly status: import("@angular/core").InputSignal<string | null>;
  /** Whether the bar along the bottom (`label`, `status`, chips) and the no-video note show. */
  readonly bars: import("@angular/core").InputSignal<boolean>;
  /** Draws the kit's focus ring around the tile, for the tile the app has chosen. */
  readonly selected: import("@angular/core").InputSignal<boolean>;
  /**
   * Shows the picture as in a mirror (a selfie view): the video and every overlay flip
   * horizontally, while overlay text (labels, plates) still reads left to right. The bar, the
   * no-video note and the `neatTileOverlay` layer are not flipped; content projected there reads
   * the app's own `mirror` value to follow. `videoBox` is the same with and without it. The
   * region-of-interest editor does not follow `mirror`: it works in the unflipped picture.
   */
  readonly mirror: import("@angular/core").InputSignal<boolean>;
  /**
   * Called once for each presented frame with what the overlay drew (see `NeatTileFrame`), for an
   * app that acts on a frame's metadata (counting poses, say) in step with the picture. It runs
   * outside Angular; a listener that throws is logged once per tile and the frames keep drawing.
   */
  readonly frameListener: import("@angular/core").InputSignal<NeatTileFrameListener | null>;
  /** The tile's state each time it changes: `empty`, `playing` or `stopped`. */
  readonly stateChange: import("@angular/core").OutputEmitterRef<NeatTileState>;
  /** The frame-sync counters, once a second while there is a stream. */
  readonly frameStats: import("@angular/core").OutputEmitterRef<NeatFrameStats>;
  protected readonly state: import("@angular/core").WritableSignal<NeatTileState>;
  private readonly box;
  /**
   * Where the shown image sits in the tile. Non-null only while the tile is `playing` and the
   * video and the tile have a size: before the first frame the surface covers the video, and once
   * the stream is `stopped` the frozen frame is blurred and scaled up, so no box describes it.
   * Unlike the frame loop's fields it is a signal, for overlays that follow the image: it is
   * written only when the tile's state or the tile's or the video's size changes, never per frame,
   * and an unchanged box does not notify.
   */
  readonly videoBox: Signal<NeatVideoBox | null>;
  private readonly barSize;
  /**
   * The height in CSS pixels of the bar along the bottom as laid out, 0 while `bars` is off. For
   * content projected with `neatTileOverlay` that keeps clear of the bar without copying its
   * styling. It changes only when the bar's size does, never per frame.
   */
  readonly barHeight: Signal<number>;
  private readonly videoElement;
  private readonly canvasElement;
  private readonly barElement;
  private readonly colors;
  private readonly zone;
  private readonly document;
  private frameSettings;
  private frameRetentionMs;
  private frameListenerFn;
  private overlayState;
  private currentState;
  private canvas;
  private context;
  /** The canvas's CSS size and pixel ratio; the video size is filled in per frame. */
  private readonly view;
  private playing;
  private queue;
  private readonly held;
  /** When the current stream last presented a frame; null until its first. */
  private lastFrameAt;
  private staleTimer;
  /** The last stale check found the tab hidden, so the frame time it would judge is from before. */
  private staleCheckSawHidden;
  private messagesThisSecond;
  private warnedUnreadable;
  private warnedPlayback;
  private warnedListener;
  private destroyed;
  constructor();
  /** The metadata queue's counters and lateness window, for the app's lateness notice. */
  snapshot(): NeatMetadataSnapshot;
  /**
   * Forgets the lateness measured so far, as after the app changes the video sync buffer: what was
   * measured belongs to the old buffer. The cumulative counters stay.
   */
  resetLatenessWindow(): void;
  private play;
  /**
   * Muted autoplay is allowed everywhere, so a rejection is either an AbortError (a newer stream or
   * a pause interrupted it, which is expected) or a real refusal that would leave the tile empty for
   * good, such as NotAllowedError or NotSupportedError. Those are logged, once per tile.
   */
  private startPlayback;
  private stop;
  private receive;
  private present;
  private notifyListener;
  /**
   * One timer at a time, re-armed for the remainder instead of on every frame, so a stream that
   * plays costs one timeout per stale period. A hidden tab presents no frames, so the check waits
   * there instead of stopping a stream that is still running. The first check after the tab
   * returns waits a full period too: the last frame time is from before the tab was hidden, and a
   * check right after the return, before the first new frame, would stop a live stream. A dead one
   * stops a period later.
   */
  private checkStale;
  /** Forgets what was drawn: the canvas, held overlays, track trails and track colours. */
  private clearOverlays;
  private setState;
  private reportFrameStats;
  /** Called when the tile or the video changes size or the tile's state changes, never per frame. */
  private updateVideoBox;
  private sizeCanvas;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatVideoTile, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatVideoTile, "neat-video-tile", never, {
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "settings": {
      "alias": "settings";
      "required": false;
      "isSignal": true;
    };
    "retentionMs": {
      "alias": "retentionMs";
      "required": false;
      "isSignal": true;
    };
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "bars": {
      "alias": "bars";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "mirror": {
      "alias": "mirror";
      "required": false;
      "isSignal": true;
    };
    "frameListener": {
      "alias": "frameListener";
      "required": false;
      "isSignal": true;
    };
  }, {
    "stateChange": "stateChange";
    "frameStats": "frameStats";
  }, never, ["[neatTileOverlay]", "[neatTileChip]"], true, never>;
}
/** What a click does: nothing, or places points of an inclusion or an exclusion polygon. */
type NeatRoiDrawMode = 'off' | 'inclusion' | 'exclusion';
/**
 * Draws regions of interest on the image of the `neat-video-tile` it is placed in, and lets the
 * user add polygons by clicking points on it. Project it into the tile with `neatTileOverlay`:
 *
 * ```html
 * <neat-video-tile>
 *   <neat-roi-editor
 *     neatTileOverlay
 *     [regions]="regions"
 *     [mode]="mode"
 *     [(highlighted)]="highlighted"
 *     (regionsChange)="…"
 *   />
 * </neat-video-tile>
 * ```
 *
 * While the tile plays, it sits on the tile's video box, so a point is a position on the image,
 * not on the letterbox, and it stays there when the tile resizes. Without video (none yet, or
 * stopped) it uses the tile's full box instead, so regions can be seen and drawn before a stream
 * plays; points are normalized to whichever box was used, which is exact for a stream of the
 * tile's shape. Until it knows either box it draws nothing and takes no input. The full box is
 * meant for a tile with `bars` off: with bars on, the no-video note and the bar paint above the
 * editor and cover what lies under them.
 *
 * With a `mode` of `inclusion` or `exclusion`, each click adds a point. A click within 10 px of
 * the first point closes the polygon once it has three; so does a double-click. The second click
 * of a double-click (`detail` 2 or more) is ignored, so a double-click is its first click plus a
 * close. `regionsChange` emits when a polygon closes, with it appended to `regions`; the editor
 * never changes `regions` itself.
 * A right-click or Backspace removes the open polygon's last point, and the polygon with its only
 * point. Escape cancels the whole polygon, and so does a new `mode` or `regions` from outside, or
 * the box it is drawn on changing between the image and the tile. Drawing is pointer-only: the
 * polygon is open on the host, which takes focus on the first point so Backspace and Escape reach
 * it.
 *
 * In every mode, `off` included, the regions themselves take the pointer:
 * - Hovering one sets `highlighted` to its index in `regions` (where regions overlap, the one
 *   drawn last, on top), and leaving it sets null. An app binds the same index to its region list,
 *   so either side can highlight; a highlighted region has a stronger fill and outline.
 * - A right-click on one, while no polygon is open, opens a small bubble there with a Delete
 *   button, which emits `regionsChange` without that region. The button takes focus; Escape, a
 *   press outside the bubble, focus leaving it or new `regions` close it. It is a shortcut for the
 *   pointer: an app still offers the keyboard its own way to remove regions, such as its list.
 * Elsewhere the editor leaves mode `off` to what is under it.
 *
 * The open polygon lives in component signals: it changes per click, and the polyline follows the
 * pointer only while a polygon is open, so a pointer that moves over an idle editor costs no
 * change detection beyond entering and leaving a region.
 */
export declare class NeatRoiEditor {
  /** The polygons to draw. Open polygons are not part of it until `regionsChange` brings them. */
  readonly regions: import("@angular/core").InputSignal<readonly NeatRoiPolygon[]>;
  /** What a click does; `off` leaves the tile to what is under the editor, but for the regions. */
  readonly mode: import("@angular/core").InputSignal<NeatRoiDrawMode>;
  /** A closed polygon appended to `regions`, or `regions` without a deleted one, in a new array. */
  readonly regionsChange: import("@angular/core").OutputEmitterRef<readonly NeatRoiPolygon[]>;
  /** The index in `regions` of the region to highlight, as the pointer or the app set it. */
  readonly highlighted: import("@angular/core").ModelSignal<number | null>;
  private readonly host;
  private readonly injector;
  private readonly renderer;
  private readonly document;
  private readonly videoBox;
  private readonly menuElement;
  /**
   * The editor's own size, which is the tile's: its host fills the tile's overlay layer. Measured
   * here rather than asked of the tile because it is exactly the area whose clicks `locate` maps,
   * and the tile keeps its own measure in a plain field for its frame loop, not in a signal.
   */
  private readonly size;
  private readonly boxSource;
  protected readonly box: import("@angular/core").Signal<NeatVideoBox | null>;
  /**
   * The open polygon's points, normalized to the box. A box that only changes size leaves it
   * alone (that is why it is normalized); anything that changes what a click would mean, or what
   * the polygon is drawn among, starts over.
   */
  private readonly open;
  /** The last place the pointer was, normalized; the open polyline runs to it. */
  private readonly pointer;
  /**
   * The open Delete bubble. New regions close it, since its index may name another region by
   * then, and so does a change of box, which moves the region it was opened on.
   */
  private readonly menu;
  /** What had focus when the bubble opened, given focus back when Escape or Delete closes it. */
  private focusBeforeMenu;
  protected readonly drawing: import("@angular/core").Signal<boolean>;
  protected readonly placed: import("@angular/core").Signal<{
    index: number;
    points: string;
    fill: string;
    stroke: "#2A9C4F" | "#C8372D";
    strokeWidth: number;
  }[]>;
  protected readonly draft: import("@angular/core").Signal<{
    line: string;
    stroke: "#2A9C4F" | "#C8372D";
    startX: number;
    startY: number;
  } | null>;
  /**
   * The Delete button's name, the region named as an app's list names it: "Delete Inclusion 2".
   * None for an index past the list, which `openMenu` already refuses.
   */
  protected readonly menuLabel: import("@angular/core").Signal<string | null>;
  constructor();
  protected onClick(event: MouseEvent): void;
  protected onDoubleClick(event: MouseEvent): void;
  protected cancelOnEscape(event: Event): void;
  protected undoOnBackspace(event: Event): void;
  protected undoOnRightClick(event: MouseEvent): void;
  /** Opens the Delete bubble for the region at `index` at the pointer, instead of the browser's. */
  protected openMenu(event: MouseEvent, index: number): void;
  protected deleteFromMenu(): void;
  protected closeMenuOnEscape(event: Event): void;
  protected closeMenuOnFocusOut(event: FocusEvent): void;
  /** Closes the bubble; `restoreFocus` when focus was in it and would otherwise fall to the page. */
  private closeMenu;
  /** Moves the bubble in from the tile's edges as far as its size needs, and focuses Delete. */
  private placeMenu;
  private inMenu;
  /** Drops the open polygon's last point; the polygon is gone with its only one. */
  private undoPoint;
  private close;
  /**
   * Where the pointer is on the box, 0..1 on each axis and clamped, with the box it was measured
   * against; null without a box to measure. The host fills the tile's overlay layer, so its corner
   * is the tile's.
   */
  private locate;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRoiEditor, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatRoiEditor, "neat-roi-editor", never, {
    "regions": {
      "alias": "regions";
      "required": true;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "highlighted": {
      "alias": "highlighted";
      "required": false;
      "isSignal": true;
    };
  }, {
    "regionsChange": "regionsChange";
    "highlighted": "highlightedChange";
  }, never, never, true, never>;
}
/**
 * The name of each region, in the order given: its type, numbered per type in list order
 * ("Inclusion 1", "Exclusion 1", "Exclusion 2", "Inclusion 2"). Every region counts, drawable or
 * not, so an app's region list and `neat-roi-editor`'s Delete bubble name the same region alike.
 */
export declare function neatRoiNames(regions: readonly NeatRoiPolygon[]): string[];
/**
 * A dot in the outline colour of a region type, as `neat-roi-editor` draws it on the video: put
 * it before a region's name in a list (`<neat-roi-swatch [type]="region.type" />`) so the list
 * and the image read alike. It is decoration, hidden from assistive technology, so the name next
 * to it must say the type.
 */
export declare class NeatRoiSwatch {
  /** The region type whose outline colour the dot takes: `inclusion` or `exclusion`. */
  readonly type: import("@angular/core").InputSignal<"inclusion" | "exclusion">;
  protected readonly color: import("@angular/core").Signal<"#2A9C4F" | "#C8372D">;
  static ɵfac: i0.ɵɵFactoryDeclaration<NeatRoiSwatch, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NeatRoiSwatch, "neat-roi-swatch", never, {
    "type": {
      "alias": "type";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type { NeatFrameStats, NeatGlobalBufferAction, NeatLateNoticeBlocker, NeatLateNoticeDetails, NeatLatenessSnapshot, NeatMetadataMessage, NeatMetadataQueueStats, NeatMetadataSnapshot, NeatOverlayClassStyle, NeatOverlayLineStyle, NeatOverlaySettings, NeatRoiDrawMode, NeatRoiPolygon, NeatTileArea, NeatTileFrame, NeatTileFrameListener, NeatTileLayout, NeatTilePack, NeatTileSource, NeatTileState, NeatVideoBox };